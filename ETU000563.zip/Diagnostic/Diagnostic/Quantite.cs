﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    class Quantite
    {
        int id;
        String sex;
        int idElement;
        decimal normmin;
        decimal normmax;

        public Quantite()
        {

        }

        public Quantite(int id, string sex, int idelement, decimal normmin, decimal normmax)
        {
            this.setid(id);
            this.setsex(sex);
            this.setidElement(idelement);
            this.setnormmin(normmin);
            this.setnormmax(normmax);
        }
        public Quantite(string sex, int idelement, decimal normmin, decimal normmax)
        {

            this.setsex(sex);
            this.setidElement(idelement);
            this.setnormmin(normmin);
            this.setnormmax(normmax);
        }
        public int getid()
        {
            return id;
        }

        public String getsex()
        {
            return sex;
        }
        public int getidElement()
        {
            return idElement;
        }

        public decimal getnormmin()
        {
            return normmin;
        }
        public decimal getnormmax()
        {
            return normmax;
        }

        public void setid(int id)
        {
            this.id = id;
        }
        public void setsex(string id)
        {
            this.sex = id;
        }
        public void setidElement(int id)
        {
            this.idElement = id;
        }

        public void setnormmin(decimal norm)
        {
            this.normmin = norm;
        }
        public void setnormmax(decimal norm)
        {
            this.normmax = norm;
        }

        public List<Quantite> findQuantite(String critere)
        {
            List<Quantite> liste = new List<Quantite>();
            List<int> id = new List<int>();
            List<string> sex = new List<string>();
            List<int> idelement = new List<int>();
            List<decimal> normmin = new List<decimal>();
            List<decimal> normmax = new List<decimal>();

            Quantite ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            /* try
             {*/
            connexion.Open();
            if (critere == null)
            {
                cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Quantity]", connexion);
            }
            else
            {
                cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Quantity] " + critere + "", connexion);
            }
            read = cmdt.ExecuteReader();
            if (read.HasRows)
            {
                while (read.Read())
                {
                    // Console.WriteLine("miditra boucle1");
                    id.Add(read.GetByte(0));

                    sex.Add(read.GetString(1));
                    idelement.Add(read.GetByte(2));
                    normmin.Add(read.GetDecimal(3));
                    normmax.Add(read.GetDecimal(4));



                }


                for (int k = 0; k < id.Count; k++)
                {
                    ma = new Quantite(id.ElementAt(k), sex.ElementAt(k), idelement.ElementAt(k), normmin.ElementAt(k), normmax.ElementAt(k));
                    liste.Add(ma);

                }


            }
            /*  }
              catch (Exception ex)
              {
                  throw ex;
              }

              finally
              {
                  connexion.Close();
              }*/

            return liste;
        }
    }
}
