﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    class Connexion
    {
        SqlConnection co;
        public Connexion()
        {
            co = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Diag;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        }

        public SqlConnection getCo()
        {
            return co;
        }
    }
}
