﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diagnostic
{
    public partial class Cercle : Panel
    {
        int x = 0;
        int y = 0;
        bool down;
        Point top;
        Point center;
        //public Diagnostique d;
        public Element elmt;
        List<double> dou = new List<double>();

        public Cercle(int ix, int iy, Point centre, Element el)
        {
            top = new Point(ix, iy);
            center = centre;
            setX(ix);
            setY(iy);

            this.x = ix;
            this.y = iy;

            this.Width = 100;
            this.Height = 20;
            this.Location = new Point(ix, iy);
            this.BackColor = Color.Transparent;

            this.elmt = el;
            elmt.setcurrval(el.getmaxval());
            el.setdesc(el.getdesc());
        }
        public Cercle()
        {

        }

        public Double getdistance1(double max, double min)
        {
            return max - min;
        }

        public Double getdistance(Point pt1, Point pt2)
        {
            Double x = Math.Pow((pt2.X - pt1.X), 2);
            Double y = Math.Pow((pt2.Y - pt1.Y), 2);

            Double result = Math.Sqrt(x + y);
            return result;
        }

        public Double value(Point pt1, Point pt2, Double max, Double min)
        {
            return ((getdistance(pt1, pt2) * getdistance1(max, min)) / getdistance(this.top, this.center)) + min;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Orange), 0, 0, 10, 10);
            //Console.WriteLine("Coucou");
            g.DrawString(elmt.getcurrval().ToString(), new Font("Arial", 10), new SolidBrush(Color.Black), 10, 0);


        }
        public Double getval()
        {
            return elmt.getcurrval();
        }

        protected void getvalue()
        {
            //  g.DrawString(d.getcurrval().ToString(), new Font("Arial", 10), new SolidBrush(Color.Black), 10, 0);
            MessageBox.Show(elmt.getcurrval().ToString());

        }

        public int getX()
        {
            return this.x;
        }

        public void setX(int X)
        {
            this.x = X;
        }

        public int getY()
        {
            return this.y;
        }

        public void setY(int Y)
        {
            this.y = Y;
        }

        public double getA0(Point pt1, Point pt2)
        {
            double A0 = (double)(pt2.Y - pt1.Y) / (double)(pt2.X - pt1.X);
            return A0;
        }

        public double getB0(Point pt1, double A0)
        {
            double B0 = (double)pt1.Y - (double)(A0 * pt1.X);
            return B0;
        }

        public double getA1(double A0)
        {
            double A1 = -1 / A0;
            return A1;
        }

        public double getB1(Point pt3, double A1)
        {
            double B1 = pt3.Y - (A1 * pt3.X);
            return B1;
        }

        public Point getXY(Point pt1, Point pt2, Point pt3)
        {
            int X;
            int Y;
            if (pt1.X == pt2.X)
            {
                X = pt1.X;
                Y = pt3.Y;
            }
            else
            {
                X = (int)((getB1(pt3, getA1(getA0(pt1, pt2))) - getB0(pt1, getA0(pt1, pt2))) / (getA0(pt1, pt2) - getA1(getA0(pt1, pt2))));
                Y = (int)((getA1(getA0(pt1, pt2)) * X) + getB1(pt3, getA1(getA0(pt1, pt2))));
            }
            Point p = new Point(X, Y);
            return p;
        }


        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }


        protected override void OnMouseMove(MouseEventArgs e)
        {
            int mouseX = e.X + this.Location.X;
            int mouseY = e.Y + this.Location.Y;
            if (down)
            {
                Point mouse = new Point(mouseX, mouseY);
                Point temp = getXY(center, top, mouse);
                if ((temp.X < top.X && temp.X > center.X) || (temp.X < center.X && temp.X > top.X) && (temp.Y < center.Y && temp.Y > top.Y) || (temp.Y < top.Y && temp.Y > center.Y) || (temp.Y > top.Y && temp.Y < center.Y))
                {
                    Double val = value(this.center, temp, elmt.getmaxval(), elmt.getminval());
                    elmt.setcurrval(val);
                    // Console.WriteLine("currval :" + d.getdesc() + d.getcurrval());
                    this.Location = temp;
                    Console.WriteLine("Isany double : " + dou.Count());
                    this.Parent.Refresh();
                }
                // this.getvalue();

            }

        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
        }

    }
}
