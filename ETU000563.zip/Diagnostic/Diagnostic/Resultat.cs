﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    class Resultat
    {
        
        public String maladie;
        public Double pourcentage;

        public Resultat(String maladie, Double pourcentage)
        {
            
            this.setmaladie(maladie);
            this.setpourcentage(pourcentage);
        }

    
        public string getmaladie()
        {
            return maladie;
        }
        public double getpourcentage()
        {
            return pourcentage;
        }

      
        public void setmaladie(String maladie)
        {
            this.maladie = maladie;
        }
        public void setpourcentage(Double pourcentage)
        {
            this.pourcentage = pourcentage;
        }
    }
}
