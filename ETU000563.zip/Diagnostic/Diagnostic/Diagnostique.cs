﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    class Diagnostique
    {
        int id;
        string description;
        double currval;
        double minval;
        double maxval;
        double minnormval;
        double maxnormval;
        string unite;

        public Diagnostique()
        {

        }
        public Diagnostique(int id, string desc, double currval, double minval, double maxval, double minnormval, double maxnormval, string unite)
        {
            this.setid(id);
            this.setdesc(desc);
            this.setcurrval(currval);
            this.setminval(minval);
            this.setmaxval(maxval);
            this.setminnormval(minnormval);
            this.setmaxnormval(maxnormval);
            this.setunite(unite);
        }
        public Diagnostique(int id, string desc, double minval, double maxval, string unite, double minnormval, double maxnormval)
        {

            this.setid(id);
            this.setdesc(desc);
            this.setminval(minval);
            this.setmaxval(maxval);
            this.setminnormval(minnormval);
            this.setmaxnormval(maxnormval);
            this.setunite(unite);
        }
        public Diagnostique(string desc, double currval, double minval, double maxval, double minnormval, double maxnormval, string unite)
        {

            this.setdesc(desc);
            this.setcurrval(currval);
            this.setminval(minval);
            this.setmaxval(maxval);
            this.setminnormval(minnormval);
            this.setmaxnormval(maxnormval);
            this.setunite(unite);
        }
        public int getid()
        {
            return id;
        }
        public string getdesc()
        {
            return description;
        }
        public double getcurrval()
        {
            return currval;
        }
        public double getminval()
        {
            return minval;
        }
        public double getmaxval()
        {
            return maxval;
        }
        public double getminnormval()
        {
            return minnormval;
        }
        public double getmaxnormval()
        {
            return maxnormval;
        }
        public string getunite()
        {
            return unite;
        }

        public void setid(int id)
        {
            this.id = id;
        }
        public void setdesc(string desc)
        {
            this.description = desc;
        }
        public void setcurrval(double currval)
        {
            this.currval = currval;
        }
        public void setminval(double minval)
        {
            this.minval = minval;
        }
        public void setmaxval(double maxval)
        {
            this.maxval = maxval;
        }

        public void setminnormval(double minnormval)
        {
            this.minnormval = minnormval;
        }
        public void setmaxnormval(double maxval)
        {
            this.maxnormval = maxval;
        }
        public void setunite(string unite)
        {
            this.unite = unite;
        }


        public List<Diagnostique> findMatch(String critere)
        {
            List<Diagnostique> liste = new List<Diagnostique>();
            List<int> id = new List<int>();
            List<string> desc = new List<string>();
            List<Double> minval = new List<Double>();
            List<Double> maxval = new List<Double>();
            List<Double> minnormval = new List<Double>();
            List<Double> maxnormval = new List<Double>();
            List<string> unite = new List<string>();

            Diagnostique ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            /*  try
              {*/
            connexion.Open();
            if (critere == null)
            {
                cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Diagnostique]", connexion);
            }
            else
            {
                cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Diagnostique] " + critere + "", connexion);
            }
            read = cmdt.ExecuteReader();
            if (read.HasRows)
            {
                while (read.Read())
                {
                    // Console.WriteLine("miditra boucle1");
                    id.Add(read.GetInt32(0));

                    desc.Add(read.GetString(1));

                    minval.Add(read.GetDouble(2));
                    //Console.WriteLine("mivoka boucle1");
                    maxval.Add(read.GetDouble(3));
                    unite.Add(read.GetString(4));


                    minnormval.Add(read.GetDouble(5));
                    maxnormval.Add(read.GetDouble(6));

                }


                for (int k = 0; k < id.Count; k++)
                {
                    ma = new Diagnostique(id.ElementAt(k), desc.ElementAt(k), minval.ElementAt(k), maxval.ElementAt(k), unite.ElementAt(k), minnormval.ElementAt(k), maxnormval.ElementAt(k));
                    liste.Add(ma);

                }


            }
            /*}
          catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               connexion.Close();
           }*/

            return liste;
        }

        /* public List<Diagnostique> listediag()
         {
             List<Diagnostique> liste = new List<Diagnostique>();
             List<int> id = new List<int>();
             List<string> desc = new List<string>();
             List<Double> minval = new List<Double>();
             List<Double> maxval = new List<Double>();
             List<Double> minnormval = new List<Double>();
             List<Double> maxnormval = new List<Double>();
             List<string> unite = new List<string>();

             Diagnostique prod;
             Connexion co = new Connexion();
             SqlConnection connex = co.getCo();
             SqlCommand cmd;
             SqlDataReader read;

             try
             {
                 String url = "select * from [dbo].[Diagnostique]";
                 cmd = new SqlCommand(url, connex);
                 connex.Open();
                 Console.WriteLine("url: "+url);
                 read = cmd.ExecuteReader();
                 if (read.HasRows)
                 {
                     Console.WriteLine("miditra if");

                     while (read.Read())
                     {
                         Console.WriteLine("miditra boucle1");
                         id.Add(read.GetInt32(0));

                         desc.Add(read.GetString(1));

                        minval.Add(Double.Parse(read.GetString(2)));
                         Console.WriteLine("mivoka boucle1");
                         //maxval.Add(read.GetFloat(3));
                         unite.Add(read.GetString(4));


                         minnormval.Add(read.GetFloat(5));
                         maxnormval.Add(read.GetFloat(6));


                     }

                     Console.WriteLine("id " + id.Count);
                     for (int k = 0; k < id.Count; k++)
                     {

                         Console.WriteLine("id " +id.ElementAt(k));
                         prod = new Diagnostique(id.ElementAt(k), desc.ElementAt(k), minval.ElementAt(k), maxval.ElementAt(k), unite.ElementAt(k), minnormval.ElementAt(k) , maxnormval.ElementAt(k));
                         liste.Add(prod);
                     }
                     Console.WriteLine("ivelany");
                 }

                 else
                 {
                     Console.WriteLine("O elements");
                 }
             }


             catch (Exception ex)
             {
                 ex.GetBaseException();
             }
             finally
             {
                 //read.Close();
                 connex.Close();
             }

            // Console.WriteLine("mamerina");
             return liste;
         }*/
    }
}
