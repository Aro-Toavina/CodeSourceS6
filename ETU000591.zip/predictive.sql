-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Lun 30 Avril 2018 à 10:03
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `predictive`
--

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `Id` int(11) NOT NULL,
  `libelle` varchar(50) NOT NULL,
  `valeurMin` varchar(10) NOT NULL,
  `valeurMax` varchar(10) NOT NULL,
  `unite` varchar(10) NOT NULL,
  `maladieInf` varchar(50) NOT NULL,
  `maladieMax` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`Id`, `libelle`, `valeurMin`, `valeurMax`, `unite`, `maladieInf`, `maladieMax`) VALUES
(1, 'Hématies', '4200000', '6200000', 'mm3', 'Anémie', 'Polyglobulie'),
(2, 'Hémoglobine', '13', '18', 'g/100ml', 'Anemie', 'Polyglobulie'),
(4, 'Phosphatases alcalines', '53', '128', 'ui/L', '-', 'Hépatite'),
(5, 'Transaminases ASAT', '0', '35', 'U/L', '-', 'Hépatite'),
(8, 'Transaminases ALAT', '0', '45', 'U/L', '-', 'Hépatite'),
(9, 'Créatininémie', '0', 'f:100/m:20', 'Umol/L', '-', 'Insuffisance Rénale'),
(10, 'Glycémie', '4', '6', 'mmol/L', 'Hypoglycemie', 'Diabète'),
(11, 'Uricémie', '0', '410', 'Umol/L', '-', 'Goutte'),
(12, 'Cholestérolémie totale', '3', '6,2', 'mmol/L', 'Insuffisance Hépatite', 'Syndrome de surcharge'),
(13, 'Lipasémie', '0', '60', 'U/L', '-', 'Pancréatite'),
(14, 'Sodium', '137', '145', 'mmol/L', 'Hyponatrémie', 'Hypernatrémie'),
(15, 'Chlore', '98', '107', 'mmol/L', 'Hypochloremie', 'Hyperchlorémie'),
(16, 'Potassium', '3,6', '5', 'mmol/L', 'Hypokaliémie', 'Hyperkaliémie'),
(17, 'CRP', '0', '10', 'mg/L', '-', 'présence d\'une inflammation');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
