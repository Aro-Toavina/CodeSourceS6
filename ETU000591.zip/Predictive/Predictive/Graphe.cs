﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Predictive
{
    class Graphe : System.Windows.Forms.Panel
    {
        public Graphe() { }

        public Graphe(int x, int y)
        {
            this.Location = new Point(x, y);
            this.Height = 20;
            this.Width = 20;
          

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            int x1 = this.Width / 4;
            int y1 = this.Height / 4;
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Green), 0, 0, 11, 11);
        }


    }
}
