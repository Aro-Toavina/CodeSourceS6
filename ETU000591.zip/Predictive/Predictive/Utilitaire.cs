﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Predictive
{
    class Utilitaire
    {
        public double getCoeffA2(double a1)
        {
            return (-1) / a1;
        }
        public double getCoeffA1(Point final,Point centre)
        {
            return ((double)final.Y - (double)centre.Y) / ((double)final.X - (double)centre.X);
        }
        public double getB(Point point,double a)
        {
            return point.Y - (a * point.X);
        }
        public double getX(double a1,double a2,double b1,double b2)
        {
            return Math.Abs((b2 - b1) / (a1 - a2));
        }
        public double getY(double x,double b,double a)
        {
            return (a * x) + b;
        }
    }
}
