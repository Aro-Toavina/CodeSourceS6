﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Predictive
{
    class Bilan
    {
        String id;
        String libelle;
        String valeurMin;
        String valeurMax;
        String unite;
        String maladieInf;
        String maladieMax;
        

        //setters

        public void setId(String i)
        {
            id = i;
        }
        public void setLibelle(String l)
        {
            libelle = l;
        }

        public void setValeurMin(String v)
        {
            valeurMin = v;
        }

        public void setValeurMax(String v)
        {
            valeurMax = v;
        }
     
        public void setUnite(String u)
        {
            unite = u;
        }

        public void setMaladieMin(String m)
        {
            maladieInf = m;
        }
        public void setMaladieMax(String m)
        {
            maladieMax = m;
        }
        //getters
        public String getId()
        {
            return id;
        }
        public String getValeurMin()
        {
            return valeurMin;
        }
        public String getValeurMax()
        {
            return valeurMax;
        }
        public String getUnite()
        {
            return unite;
        }
        public String getMaladieInf()
        {
            return maladieInf;
        }
        public String getMaladieMax()
        {
            return maladieMax;
        }
        public String getLibelle()
        {
            return libelle;
        }

        //Constructeur
        public Bilan()
        {

        }
        public Bilan(String i,String l,String vMin,String vMax,String unite,String mMin,String mMax)
        {
            setId(i);
            setLibelle(l);
            setValeurMin(vMin);
            setValeurMax(vMax);
            setUnite(unite);
            setMaladieMin(mMin);
            setMaladieMax(mMax);
        }

    }
}
