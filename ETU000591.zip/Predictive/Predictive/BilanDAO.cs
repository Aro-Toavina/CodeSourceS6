﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Predictive
{
    class BilanDAO
    {
        private MySqlConnection connection = new MySqlConnection();
        public List<Bilan> findAll()
        {
            List<Bilan> resultat = new List<Bilan>();
            MySqlDataReader read;
            ConnexionBase connex = new ConnexionBase();
            connection = connex.ConnectionSQL();
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select*from bilan";
            read = cmd.ExecuteReader();

            while (read.Read())
            {
                String id = read[0].ToString();
                String libelle = read[1].ToString();
                String valeurMin = read[2].ToString();
                String valeurMax = read[3].ToString();
                String unite = read[4].ToString();
                String maladieInf = read[5].ToString();
                String maladieMax = read[6].ToString();
               // Console.WriteLine(valeurMin);
               // resultat.Add(new Bilan());
               resultat.Add(new Bilan(id, libelle, valeurMin, valeurMax, unite, maladieInf, maladieMax));
            }
            connection.Close();
            return resultat;
        }
    }
}
