﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Predictive
{
    class Listener
    {
        Form1 form;
        Point pointTemp = new Point();
        Point pointFarany = new Point();
        public Listener(Form1 f)
        {
            form = f;
        }
        public void MouseDown(object sender, MouseEventArgs e)
        {
            pointTemp = this.getPoint(e);

        }
        public void MouseUp(object sender, MouseEventArgs e)
        {
            pointFarany = new Point(e.X, e.Y);
            changeCoord();
            this.actualiseValeur("femme");
        }
        public void MouseMove(object sender, MouseEventArgs e)
        {
           
        }

        public void actualiseValeur(String personne)
        {
            Point[] lesPoints = form.getPoints();
            double[] pourcentage = this.getPourcentage(lesPoints);
            BilanDAO dao = new BilanDAO();
            List<Bilan> bilans = dao.findAll(); 
            String[] maladie=new String[14];
            form.getTabeau().Rows.Clear();
         //   this.tabResMaladie("homme");
            for (int i = 0; i < lesPoints.Length; i++)
            {
                //   this.getMaladie(bilans[i], pourcentage[i]);
                // maladie[i] = this.getMaladie(bilans[i], pourcentage[i]);
                // Console.WriteLine(bilans[i].getLibelle()+"  : "+this.getMaladie(bilans[i], pourcentage[i]));  
                // Console.WriteLine(bilans[i].getLibelle()+" : "+this.percent(bilans[i], pourcentage[i], "homme"));
                //  this.testMaladie(bilans[i], pourcentage[i], "homme");
                
               //Console.WriteLine(this.tabResMaladie(personne)[i]);
             //   Console.WriteLine(bilans[i].getLibelle()+"  :   "+this.resultat("femme")[i]);
              //  form.getNoms().ElementAt(i).Width = 150;
                form.getNoms().ElementAt(i).BackColor = Color.Transparent;
                //  form.getNoms().ElementAt(i).Height = 200;
                form.getTabeau().Rows.Add(bilans[i].getLibelle(), bilans[i].getValeurMin(), bilans[i].getValeurMax(), Math.Round(this.percent(bilans[i], pourcentage[i], personne),2));

            }
                if ((this.tabResMaladie(personne).ElementAt(0).CompareTo(this.tabResMaladie(personne).ElementAt(1)) ==0) && ((this.tabResMaladie(personne).ElementAt(0).CompareTo(this.tabResMaladie(personne).ElementAt(2)) == 0) && ((this.tabResMaladie(personne).ElementAt(1).CompareTo(this.tabResMaladie(personne).ElementAt(2)) == 0))))
                {
                form.getLabel6().Text = "vous êtes en bonne santé aucune maladie detecter!";
                }
            else
            {
                form.getLabel6().Text = this.tabResMaladie(personne).ElementAt(0);
                form.getLabel7().Text = this.tabResMaladie(personne).ElementAt(1);
                form.getLabel8().Text = this.tabResMaladie(personne).ElementAt(2);
            }
         

        }
        public void changeCoord()
        {
            
            Utilitaire util = new Utilitaire();
            Point centre = new Point(316, 328);
            Point temp = new Point();
            if (centre.X == pointTemp.X)
            {
                 temp = new Point(centre.X, pointFarany.Y);
               
               
            }
            else
            {
                double a1 = util.getCoeffA1(pointTemp, centre);
                double a2 = util.getCoeffA2(a1);
                double b1 = util.getB(pointTemp, a1);
                double b2 = util.getB(pointFarany, a2);
                double x =util.getX(a1, a2, b1, b2);
                double y =util.getY(x, b2, a2);
                temp = new Point((int)x, (int)y);
               // Console.WriteLine("x ="+pointTemp.X +" x0="+centre.X+"// y="+pointTemp.Y+" y0="+centre.Y);
               // Console.WriteLine("a1="+a1);
            }
           double po= form.distance(new Point(316, 328), temp);
            Console.WriteLine();
            this.updatePoint(pointTemp, temp);
            form.getPanel().Refresh();
        }
        public Boolean testMaladie(Bilan bilan,double p,String personne)
        {
           double valeur = this.percent(bilan, p, personne);
            String[] vM = bilan.getValeurMax().Split('/');
            double valeurMax = 0;
            if (vM.Length == 1)
            {
              //  Console.WriteLine(bilan.getLibelle()+" : "+ double.Parse(bilan.getValeurMax()));
                double temp = double.Parse(bilan.getValeurMax());
             if(double.Parse(bilan.getValeurMin())<valeur && valeur < temp)
                {
                    return false;
                }
            

            }
            else
            {
                if (personne.CompareTo("femme") == 0)
                {
                    valeurMax = double.Parse(vM[0].Split(':').ElementAt(1));
                    //Console.WriteLine("ato");
                    if (double.Parse(bilan.getValeurMin()) < valeur && valeur < valeurMax)
                    {
                        return false;
                    }
                }
                else
                {
                    valeurMax = double.Parse(vM[1].Split(':').ElementAt(1));
                    if (double.Parse(bilan.getValeurMin()) < valeur && valeur < valeurMax)
                    {
                        return false;
                    }
                }

            }

            return true;
        }
        public double traitementValeurMax(String v,String personne)
        {
            String[] vM = v.Split('/');
            double valeurMax = 0;
            if (vM.Length == 1)
            {
                return double.Parse(v);
            }
            else
            {
                if (personne.CompareTo("femme") == 0)
                {
                    return double.Parse(vM[0].Split(':').ElementAt(1));
                }
                else
                {
                   return double.Parse(vM[1].Split(':').ElementAt(1));
                   
                }
            }
            return 0;
        }
       
        public String getMaladie(Bilan b ,double p,String personne)
        {
            Boolean test = this.testMaladie(b,p,personne);
            double valeur = percent(b, p, personne);
           // Console.WriteLine(p+" boolean: "+test);
            if (test == true)
            {
                double valeurMin = double.Parse(b.getValeurMin());
                double valeurMax = this.traitementValeurMax(b.getValeurMax(), personne);
                if (valeur < valeurMin)
                {
                    return b.getMaladieInf();
                }
                if (valeur > valeurMax)
                {
                    return b.getMaladieMax();
                }
            }
            return "tsisy";
        }
        public double niveauMaladie(Bilan b,double p, String personne)
        {
            double resultat = 0;
            Boolean test = this.testMaladie(b, p, personne);
            double valeur = percent(b, p, personne);
            if (test == true)
            {
                double valeurMin = double.Parse(b.getValeurMin());
                double valeurMax = this.traitementValeurMax(b.getValeurMax(), personne);
                if (valeur < valeurMin)
                {
                    return Math.Abs(100-((valeur*100)/(valeurMin)));
                }
                if (valeur > valeurMax)
                {
                    return Math.Abs(100 -((valeur * 100) /( valeurMax)));
                }

            }

                return resultat;
        }
        public double[] resultat(String personne)
        {
            double[] valiny = new double[14];
            Point[] lesPoints = form.getPoints();
            double[] pourcentage = this.getPourcentage(lesPoints);
            BilanDAO dao = new BilanDAO();
            List<Bilan> bilans = dao.findAll();
            for(int i = 0; i < bilans.Count; i++)
            {
                valiny[i] = Math.Round( this.niveauMaladie(bilans[i], pourcentage[i], personne),2);
            }
            return valiny;
        }
        public double[] trieDesc(String personne)
        {
            double[] pourcentage = this.resultat(personne);
            double[] po = new double[14];
            double temp = 0;
            for(int i = 14; i!=0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    int k = j + 1;
                    if (k == 14)
                    {
                        k = 13;
                    }
                    if (pourcentage[j] < pourcentage[k])
                    {
                        temp = pourcentage[j];
                        pourcentage[j] = pourcentage[k];
                        pourcentage[k] = temp;
                    }
                }
                   
                
            }
            return pourcentage;
        }
        public String[] tabResMaladie(String personne)
        {
            double[] res = this.trieDesc(personne);
            Point[] lesPoints = form.getPoints();
            double[] pourcentage = this.getPourcentage(lesPoints);
            double[] percentMaladie = this.resultat(personne);
            BilanDAO dao = new BilanDAO();
            List<Bilan> bilans = dao.findAll();
            List<String> valiny =new List<String>();
            int j = 0;
         for(int i = 0; i < 3; i++)
            {
                for(int k = 0; k < bilans.Count; k++)
                {
                  //  Console.WriteLine(percentMaladie[k] + "  :   " + res[i]);
                    if (percentMaladie[k] == res[i])
                    {
                        valiny.Add(bilans[k].getLibelle() + " : " + res[i] + "%");
                        j++;
                    }
                }
            }
            

            return valiny.ToArray();
        }
        public void updatePoint(Point point,Point nouvelle)
        {
            Point[] temp = form.getPoints();
            for (int i = 0; i < form.getPoints().Length; i++)
            {
                if (point.X == form.getPoints().ElementAt(i).X && point.Y == form.getPoints().ElementAt(i).Y)
                {
                    temp[i] = nouvelle;
                    form.getNoms()[i].Location = nouvelle;
                }
            }
            form.setPoints(temp);
        }
       
        public void getPointApproximite(Point[] points)
        {
           


        }
       public double[] getPourcentage(Point[] thePoints)
        {
            double[] resultat = new double[14];
            
            for(int i = 0; i < thePoints.Length; i++)
            {
                resultat[i] =this.calculPourcentage( form.distance(new Point(316, 328), thePoints[i]));
            }
            return resultat;
        }
        public int getIndice(MouseEventArgs e)
        {
            int x = e.X;
            int y = e.Y;

            int indice = 0;
            for (int i = 0; i < form.getPoints().Length; i++)
            {

                int xTemp = Math.Abs(x - form.getPoints().ElementAt(i).X);
                int yTemp = Math.Abs(y - form.getPoints().ElementAt(i).Y);
                //Console.WriteLine("Calcul x=" + xTemp + " calcul y=" + yTemp);

                if ((xTemp >= 0 && xTemp <= 10) && (yTemp >= 0 && yTemp <= 10))
                {
                    indice = i;
                }
            }
            return indice;
        }
        public Point getPoint(MouseEventArgs e)
        {
            Point temp = new Point();
            int x = e.X;
            int y = e.Y;
        
           
            for (int i = 0; i < form.getPoints().Length; i++)
            {

                int xTemp = Math.Abs(x - form.getPoints().ElementAt(i).X);
                int yTemp = Math.Abs(y - form.getPoints().ElementAt(i).Y);
                //Console.WriteLine("Calcul x=" + xTemp + " calcul y=" + yTemp);

                if ((xTemp >= 0 && xTemp <= 10) && (yTemp >= 0 && yTemp <= 10))
                {
                    temp= form.getPoints().ElementAt(i);
                }
            }
            return temp;
        }
        public double calculPourcentage(double p)
        {
            return (100 * p) / 316;
        }
        public double percent(Bilan b, double p,String personne)
        {
            String[] vM = b.getValeurMax().Split('/');
            double valeurMax = 0;
            if (vM.Length == 1)
            {
                return (double.Parse(b.getValeurMax())) * p / 100;
            }
            else
            {
                if (personne.CompareTo("femme") == 0)
                {
                    valeurMax =double.Parse( vM[0].Split(':').ElementAt(1));
                    //Console.WriteLine("ato");
                }
                else
                {
                    valeurMax = double.Parse(vM[1].Split(':').ElementAt(1));
                }
                return (valeurMax * p) / 100;
            }
        }
        

        
    }
}
