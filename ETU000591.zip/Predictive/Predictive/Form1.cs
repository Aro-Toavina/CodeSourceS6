﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Predictive
{
    public partial class Form1 : Form
    {
        private Double angleReference = Math.PI / 7;
        private bool down = false;
        private int x = 0;
        private int y = 0;
        private List<Graphe> cercles = new List<Graphe>();
        private Point[] points = new Point[14];
        private Label[] noms = new Label[14];
        Graphics line;
       private List<Bilan> elements = new List<Bilan>();
        
       
        public double distance(Point a, Point b) {
            return Math.Sqrt(((b.Y - a.Y) * (b.Y - a.Y)) + (((b.X - a.X) * (b.X - a.X))));
        }
       

        public Form1()
        {
            InitializeComponent();
            Double rayon = 316;
            BilanDAO dao = new BilanDAO();
            elements = dao.findAll();
            Listener listener = new Listener(this);
            for (int o = 0; o < elements.Count; o++)
            {
              //  Console.WriteLine(angleReference*o);
                Point point = this.generetaPoint(rayon, this.angleReference * o);
               
                points[o] = point;
                noms[o] = new Label();
                noms[o].Location = point;
               // noms[o].Width = 110;
               noms[o].Text = elements.ElementAt(o).getLibelle();
                noms[o].BackColor = Color.Transparent;
                

            }
         

            /*cercle.MouseMove += cercleMouseMove;
            cercle.MouseDown += cercleMouseDown;
            cercle.MouseUp += cercleMouseUp;
            panel1.Controls.Add(cercle);*/
           
            panel1.MouseDown += listener.MouseDown;
            panel1.MouseUp += listener.MouseUp;
            panel1.MouseMove += listener.MouseMove;
        }
        public DataGridView getTabeau()
        {
            return dataGridView1;
        }
        public Point[] getPoints()
        {
            return points;
        }
        public Label[] getNoms()
        {
            return noms;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void setPoints(Point[] t)
        {
            points = t;
        }

        public Panel getPanel()
        {
            return panel1;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            line = e.Graphics;
            Pen pen = new Pen(Color.FromArgb(189, 189, 189), 1);
            float[] dashValues = { 5, 5, 5, 5 };
            pen.DashPattern = dashValues;
            this.drawGraph(line, pen);
           
        }
        private void drawGraph(Graphics g, Pen pen)
        {
            Pen penGraph = new Pen(Color.Transparent, 2);
            int x0 = 316;
            int y0 = 328;
            Double rayon = 316;
            Point center = new Point(x0, y0);
            Point pointTemp = new Point(x0, 0);
            Graphe cercle = new Graphe(x0, 0);
            Graphe cercleTemp = new Graphe(pointTemp.X, pointTemp.Y);
           
            g.FillPolygon(Brushes.CadetBlue, points);
            for (int i = 0; i < elements.Count; i++)
            {
                Point point = points.ElementAt(i);
                Label label = noms.ElementAt(i);
               
                g.FillEllipse(new SolidBrush(Color.Aquamarine), point.X, point.Y, 11, 11);
                this.drawLine(g, pen, center, point);
                this.drawLine(g, penGraph, pointTemp, point);
               // Console.WriteLine(i + "- x=" + point.X+" y="+point.Y);
                pointTemp = point;

                panel1.Controls.Add(label);
               // Console.WriteLine(li.getPourcentage()[i]);
            }
          


            //Point point1 = new Point(cercle.Location.X, cercle.Location.Y);
            Pen p = new Pen(Color.Black, 2);
            //this.drawLine(g, p, point1, new Point(x0, 0));
            this.drawLine(g, penGraph, pointTemp, new Point(x0, 0));
            
        }
        private void drawLine(Graphics g, Pen pen, Point point1, Point point2)
        {
            g.DrawLine(pen, point1, point2);
        }
        private Point generetaPoint(Double rayon, Double angle)
        {
            int x = (int)(rayon * (Math.Sin(angle) + 1));
            int y = (int)(rayon * (-Math.Cos(angle) + 1));
            return new Point(x, y);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public Label getLabel6()
        {
            return label6;
        }
        public Label getLabel7()
        {
            return label7;
        }
        public Label getLabel8()
        {
            return label8;
        }
        private void drawCercle(Graphics g)
        {
            Graphe cercle = new Graphe(10, 10);
            cercle.MouseMove += cercleMouseMove;
            cercle.MouseDown += cercleMouseDown;
            cercle.MouseUp += cercleMouseUp;
            panel1.Controls.Add(cercle);

            Graphe cercle2 = new Graphe(50, 50);
            cercle2.MouseMove += cercleMouseMove;
            cercle2.MouseDown += cercleMouseDown;
            cercle2.MouseUp += cercleMouseUp;
            panel1.Controls.Add(cercle2);

            Point point1 = new Point(cercle.Location.X, cercle.Location.Y);
            Point point2 = new Point(cercle2.Location.X, cercle2.Location.Y);
            Pen penGraph = new Pen(Color.Black, 2);
            this.drawLine(g, penGraph, point1, point2);
        }

        private void cercleMouseDown(object sender, EventArgs e)
        {
            Graphe cercle = new Graphe();
            cercle = (Graphe)sender;
            down = true;
            x = Cursor.Position.X - (this.Left + cercle.Left);
            y = Cursor.Position.Y - (this.Top + cercle.Top);
        }

        private void cercleMouseMove(object sender, MouseEventArgs e)
        {
            if (down)
            {
                Graphe cercle = new Graphe();
                cercle = (Graphe)sender;
                cercle.Left = Cursor.Position.X - this.Left - x;
                cercle.Top = Cursor.Position.Y - this.Left - y;
                panel1.Refresh();
            }
        }

        private void cercleMouseUp(object sender, MouseEventArgs e)
        {
            down = false;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
