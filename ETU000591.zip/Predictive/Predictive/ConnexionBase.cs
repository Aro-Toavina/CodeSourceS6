﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Predictive
{
    class ConnexionBase
    {
        private MySqlConnection _Connection = new MySqlConnection();
        public MySqlConnection ConnectionSQL()
        {
            string _ConnectionString = "Database=predictive;Data Source=localhost;User Id=root;Password=root";

            _Connection.ConnectionString = _ConnectionString;

            return _Connection;

        }
    }
}
