﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class Maladie
    {
        private String id;
        private String name;
        private int estimation = 0;

        public Maladie() { }

        public Maladie(String id, String name, int estimation)
        {
            this.id = id;
            this.name = name;
            this.estimation = estimation;
        }

        public Maladie(String id, String name)
        {
            this.setId(id);
            this.setName(name);
        }

        public String getId()
        {
            return id;
        }

        public String getName()
        {
            return name;
        }

        public int getEstimation()
        {
            return estimation;
        }

        public void setId(String id)
        {
            this.id = id;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public void setEstimation(int estimation)
        {
            this.estimation = estimation;
        }

        public Maladie getMaladieById(String idMaladie)
        {
            Maladie maladie = null;
            Util util = new Util();
            var conn = util.getConnection();
            conn.Open();
            var command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM public.maladie where id ='" + idMaladie + "';";
            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                maladie = new Maladie(reader.GetString(0), reader.GetString(1));
            }
            Console.WriteLine(maladie.getId()+": "+maladie.getName());
            conn.Close();
            return maladie;
        }
    }
}
