﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyMedico
{
    public partial class Form1 : Form
    {
        private int nbrElement;
        private Double angleReference ;
        private int x0;
        private int y0;
        private Double rayon;
        private Point center;
        private List<Cercle> cercles = new List<Cercle>();
        private List<Element> elements;
        private List<Maladie> maladies;

        public Form1()
        {
            InitializeComponent();
            elements = new Element().getListElement();
            nbrElement = elements.Count;
            rayon = 250;
            x0 = 250;
            y0 = 250;
            center = new Point(x0 + 60, y0 + 60);
            angleReference = (2 * Math.PI) / nbrElement;
            this.setCercles();
            this.circularProgressBar1.Value = 0;
            this.circularProgressBar2.Value = 0;
            this.circularProgressBar3.Value = 0;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            Graphics line = e.Graphics;
            Pen pen = new Pen(Color.FromArgb(189, 189, 189), 1);
            Pen penPoligone = new Pen(Color.Blue, 1);
            float[] dashValues = { 10, 10};
            pen.DashPattern = dashValues;
            this.drawGraph(line, pen);
            drawPoligon(line,penPoligone);
        }

        private void drawGraph(Graphics g, Pen pen)
        {
            for (int i = 0; i < nbrElement; i++)
            {
                Point point = this.generetaPoint(rayon, this.angleReference * i);
                this.drawLine(g, pen, center, point);
            }
        }

        private void drawLine(Graphics g, Pen pen, Point point1, Point point2)
        {
            g.DrawLine(pen, point1, point2);
        }

        private Point generetaPoint(Double rayon, Double angle)
        {
            int x = (int)(rayon * (Math.Sin(angle) + 1));
            int y = (int)(rayon * (-Math.Cos(angle) + 1));
            return new Point(x + 60, y + 60);
        }

        private void setCercles()
        {
            for (int i = 0; i < nbrElement; i++)
            {
                Point point = this.generetaPoint(rayon, this.angleReference * i);
                Element element = new Element(elements.ElementAt(i).getId(), elements.ElementAt(i).getName(), elements.ElementAt(i).getRefMin(), elements.ElementAt(i).getRefMax(), elements.ElementAt(i).getUnite());
                this.cercles.Add(new Cercle(point.X, point.Y, element));
                Label label = new Label();
                label.Text = elements.ElementAt(i).getName() + " " + elements.ElementAt(i).getUnite();
                label.Size = new System.Drawing.Size(120, 15);
                label.BackColor = Color.Transparent;
                label.Location = new Point(point.X - 40, point.Y - 20);
                panel7.Controls.Add(label);
                panel7.Controls.Add(cercles.ElementAt(i));
            }
        }

        private void bunifuCheckbox1_OnChange(object sender, EventArgs e)
        {
            if (this.bunifuCheckbox2.Checked || this.bunifuCheckbox3.Checked)
            {
                this.bunifuCheckbox2.Checked = false;
                this.bunifuCheckbox3.Checked = false;
            }
        }

        private void bunifuCheckbox2_OnChange(object sender, EventArgs e)
        {
            if (this.bunifuCheckbox1.Checked || this.bunifuCheckbox3.Checked)
            {
                this.bunifuCheckbox1.Checked = false;
                this.bunifuCheckbox3.Checked = false;
            }
        }

        private void bunifuCheckbox3_OnChange_1(object sender, EventArgs e)
        {
            if (this.bunifuCheckbox1.Checked || this.bunifuCheckbox2.Checked)
            {
                this.bunifuCheckbox1.Checked = false;
                this.bunifuCheckbox2.Checked = false;
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                maladies  = new List<Maladie>();
                Personne personne = new Personne();
                personne.setGender(bunifuCheckbox1.Checked, bunifuCheckbox2.Checked, bunifuCheckbox3.Checked);
                personne.setAge(int.Parse(bunifuMetroTextbox1.Text));

                Dosage dosage = new Dosage();
                
                for (int i = 0; i < cercles.Count; i++)
                {
                    Atteinte atteinte = new Atteinte();
                    Element element = cercles.ElementAt(i).getElement();
                    dosage = dosage.getDosage(element, personne);
                    int statut = dosage.getStatus(dosage, element);
                    Console.WriteLine(statut + " " + element.getId() + " value= " + element.getValue().ToString());
                    atteinte = atteinte.getAtteinte(statut, cercles.ElementAt(i).getElement());
                    atteinte.Maladie.setEstimation(atteinte.getEstimation(statut, dosage, element));
                    if(atteinte.Maladie.getEstimation() != 0)
                    {
                        this.maladies.Add(atteinte.Maladie);
                    }
                    Console.WriteLine("estimation == " + atteinte.Maladie.getEstimation());
                }

                Console.WriteLine("taille ="+maladies.Count);
                var orderByMaladies = from m in maladies orderby m.getEstimation() descending select m;
                maladies = orderByMaladies.ToList<Maladie>();

                this.showResult();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                new AlertForm(ex.Message).Show();
            }
           
        }

        private void drawPoligon(Graphics g, Pen p)
        {
            Point[] points = getAllPointCercles().ToArray();
            g.DrawPolygon(p,points);
        }

        private List<Point> getAllPointCercles()
        {
            List<Point> allPoints = new List<Point>();
            for (int i = 0; i < cercles.Count; i++)
                allPoints.Add(cercles.ElementAt(i).Location);
            return allPoints;
        }

        public void showResult()
        {

            this.label6.Width = 100;
            this.label6.Text = maladies.ElementAt(0).getName();

            for (int i = 0; i <= maladies.ElementAt(0).getEstimation(); i++)
            {
                Thread.Sleep(5);
                this.circularProgressBar1.Value = i;
                this.circularProgressBar1.Text = i.ToString() + "%";
            }

            this.label7.Width = 100;
            this.label7.Text = maladies.ElementAt(1).getName();
            for (int i = 0; i <= maladies.ElementAt(1).getEstimation(); i++)
            {
                Thread.Sleep(5);
                this.circularProgressBar2.Value = i;
                this.circularProgressBar2.Text = i.ToString() + "%";
            }

            this.label8.Width = 100;
            this.label8.Text = maladies.ElementAt(2).getName();
            for (int i = 0; i <= maladies.ElementAt(2).getEstimation(); i++)
            {
                Thread.Sleep(5);
                this.circularProgressBar3.Value = i;
                this.circularProgressBar3.Text = i.ToString() + "%";
            }
        }

    }
}
