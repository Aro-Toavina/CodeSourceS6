﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class Atteinte
    {
        private String id;
        private int statut;
        private Maladie maladie;
        private Element element;

        public Atteinte()
        {
            maladie = new Maladie();
        }

        public Atteinte(String id, int statut, String idMaladie, Element element)
        {
            Id = id;
            Statut = statut;
            Element = element;
            setMaladie(idMaladie);
        }

        public void setMaladie(String idMaladie)
        {
            maladie = new Maladie();
            if(idMaladie != null)
                maladie = maladie.getMaladieById(idMaladie);
        }

        public string Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public int Statut
        {
            get
            {
                return statut;
            }

            set
            {
                statut = value;
            }
        }

        internal Maladie Maladie
        {
            get
            {
                return maladie;
            }

            set
            {
                maladie = value;
            }
        }

        internal Element Element
        {
            get
            {
                return element;
            }

            set
            {
                element = value;
            }
        }

        public Atteinte getAtteinte(int statut, Element element)
        {
            Util util = new Util();
            var conn = util.getConnection();
            conn.Open();
            var command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM public.Atteinte where idelement ='" + element.getId() + "' and satut=" + statut + ";";
            var reader = command.ExecuteReader();

            //Console.WriteLine("SELECT * FROM public.Atteinte where idElement ='" + element.getId() + "' and sexe='" + personne.getGender() + "';");

            Atteinte result = new Atteinte();

            while (reader.Read())
            {
                result = new Atteinte(reader.GetString(0), reader.GetInt32(1),reader.GetString(2), element);
            }
            Console.WriteLine(result.Id);
            conn.Close();
            return result;
        }

        public int getEstimation(int statut, Dosage dosage, Element element)
        {
            int result = 0;
            if(statut == 1)
            {
                result = (int)((100 * (element.getValue() - dosage.MaxNorm)) / (element.getRefMax() - dosage.MaxNorm));
            }
            else if( statut == 0)
            {
                result = (int)((100 * (dosage.MinNorm - element.getValue())) / (dosage.MinNorm - element.getRefMin()));
            }

            return result;
        }
    }
}
