﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace AnalyMedico
{
    class Cercle : Panel
    {
        private bool down = false;
        private int x = 0;
        private int y = 0;
        private Point pointCentre;
        private Point pointTop;
        private EquationDroite equation;
        private Element element;
        private double rayon = 0;
        private Label outputValue;

        public Cercle() { }

        public Cercle(int X, int Y, Element element)
        {
            this.Location = new Point(X - 5, Y - 5);
            this.Height = 15;
            this.Width = 100;
            this.x = X;
            this.y = Y;
            pointTop = new Point(X, Y);
            pointCentre = new Point(310, 310);
            equation = new EquationDroite(pointCentre, new Point(X, Y));
            rayon = this.distance(pointCentre, pointTop);
            this.BackColor = Color.Transparent;
            this.element = element;
            this.element.setValue(element.getRefMax());
            this.setOutputValue();
        }

        public void setElment(Element element)
        {
            this.element = element;
        }

        public Element getElement()
        {
            return this.element;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Red), 0, 0, 10, 10);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (down)
            {
                int mouseX = e.X + this.Location.X;
                int mouseY = e.Y + this.Location.Y;
                EquationDroite equationDroiteP = equation.getEquationDroitePerpendiculaire(new Point(mouseX, mouseY));
                if (equation.getA0() == 10000)
                {
                    this.y = mouseY;
                    Point newPoint = new Point(x - 5, y - 5);
                    this.verifDistance1(distance(pointCentre, newPoint), newPoint);
                }
                else
                {
                    Point newPoint = projection(equationDroiteP);
                    verifDistance2(distance(pointCentre,newPoint),equationDroiteP,newPoint);
                    this.Parent.Refresh();
                }
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
        }

        public double distance(Point p1, Point p2)
        {
            int x1 = p1.X;
            int y1 = p1.Y;
            int x2 = p2.X;
            int y2 = p2.Y;
            double d = Math.Sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)));
            return d - 5;
        }

        public Point projection(EquationDroite equationDroiteP)
        {
            this.x = (int)((equationDroiteP.getB0() - equation.getB0()) / (equation.getA0() - equationDroiteP.getA0()));
            this.y = (int)((equation.getA0() * this.x) + equation.getB0());
            return new Point(x - 5, y - 5);
        }

        public void verifDistance1(double distance, Point newPoint)
        {
            if (distance> rayon)
            {
                this.Location = new Point(pointTop.X - 5, pointTop.Y - 5);
                this.outputValue.Text = this.element.getRefMax().ToString();
                element.setValue(this.element.getRefMax());
            }
            else if (this.distance(newPoint, pointTop) > rayon)
            {
                this.Location = new Point(pointCentre.X - 5, pointCentre.Y - 5);
                this.outputValue.Text = this.element.getRefMin().ToString();
                element.setValue(this.element.getRefMin());
            }
            else
            {
                this.Location = newPoint;
                int newValue = (int)this.distance(pointCentre, newPoint);
                this.outputValue.Text = Math.Round(getValue(newPoint), 2).ToString();
                element.setValue(Math.Round(getValue(newPoint), 2));
            }
            this.Parent.Refresh();
        }

        public void verifDistance2(double distance, EquationDroite equationDroiteP, Point newPoint)
        {
            if (distance > rayon)
            {
                this.Location = new Point(pointTop.X - 5, pointTop.Y - 5);
                this.outputValue.Text = this.element.getRefMax().ToString();
                element.setValue(this.element.getRefMax());
            }
            else if (this.distance(newPoint,pointTop) > rayon)
            {
                this.Location = new Point(pointCentre.X - 5, pointCentre.Y - 5);
                this.outputValue.Text = this.element.getRefMin().ToString();
                element.setValue(this.element.getRefMin());
            }
            else
            {
                this.Location = newPoint;
                int newValue = (int)this.distance(pointCentre, newPoint);
                this.outputValue.Text = Math.Round(getValue(newPoint),2).ToString();
                element.setValue(Math.Round(getValue(newPoint), 2));
            }
        }

        public void setOutputValue()
        {
            outputValue = new Label();
            outputValue.Text = element.getRefMax().ToString();
            outputValue.Left = 10;
            outputValue.Size = new System.Drawing.Size(100, 40);
            outputValue.BackColor = Color.Transparent;
            this.Controls.Add(outputValue);
        }

        public int setPourcentage(int distance)
        {
            double pourcentage = (100 * distance) / 245;
            return (int)pourcentage;
        }

        public double getValue(Point point)
        {
            double value = ((element.getRefMax() - element.getRefMin()) * distance(pointCentre, point)) / rayon;
            return element.getRefMin() +  value;
        }
        
    }
}
