﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class Dosage
    {
        private String id;
        private String idElement;
        private int minAge;
        private int maxAge;
        private double minNorm;
        private double maxNorm;
        private String sexe;

        public Dosage()
        {

        }

        public Dosage(String id, String idElement, int minAge, int maxAge, double minNorm, double maxNorm, String sexe)
        {
            Id = id;
            IdElement = idElement;
            MinAge = minAge;
            MaxAge = maxAge;
            MinNorm = minNorm;
            MaxNorm = maxNorm;
            Sexe = sexe;
        }
        

        public string Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string IdElement
        {
            get
            {
                return idElement;
            }

            set
            {
                idElement = value;
            }
        }

        public int MinAge
        {
            get
            {
                return minAge;
            }

            set
            {
                minAge = value;
            }
        }

        public int MaxAge
        {
            get
            {
                return maxAge;
            }

            set
            {
                maxAge = value;
            }
        }

        public double MinNorm
        {
            get
            {
                return minNorm;
            }

            set
            {
                minNorm = value;
            }
        }

        public double MaxNorm
        {
            get
            {
                return maxNorm;
            }

            set
            {
                maxNorm = value;
            }
        }

        public String Sexe
        {
            get
            {
                return sexe;
            }

            set
            {
                sexe = value;
            }
        }

        public Dosage getDosage(Element element, Personne personne)
        {
            Util util = new Util();
            var conn = util.getConnection();
            conn.Open();
            var command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM public.dosage where idElement ='" + element.getId() +"' and sexe='"+ personne.getGender() +"';";
            var reader = command.ExecuteReader();

            //Console.WriteLine("SELECT * FROM public.dosage where idElement ='" + element.getId() + "' and sexe='" + personne.getGender() + "';");

            Dosage result = new Dosage();

            while (reader.Read())
            {
                result = new Dosage(reader.GetString(0), reader.GetString(1), reader.GetInt32(2), reader.GetInt32(3), reader.GetDouble(4), reader.GetDouble(5), reader.GetString(6));
            }
            Console.WriteLine(result.Id);
            conn.Close();
            return result;
        }
        
        public int getStatus(Dosage dosage, Element element)
        {
            int status = 0;

            if (dosage.MaxNorm < element.getValue())
            {
                status = 1;
                //Console.WriteLine("hyper " + element.getValue().ToString() +" > " + dosage.MaxNorm);
            }
            else if (dosage.MinNorm > element.getValue())
            {
                status = 0;
                //Console.WriteLine("hypo  " + element.getValue().ToString() + " > " + dosage.MinNorm);
            }
            else
            {
                status = 2;
                //Console.WriteLine("norm " + element.getValue().ToString());
            }

            return status;
        }
    }
}
