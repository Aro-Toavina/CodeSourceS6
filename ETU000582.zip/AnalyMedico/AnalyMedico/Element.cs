﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class Element
    {
        private String id;
        private String name;
        private Double value;
        private Double refMin;
        private Double refMax;
        private String unite;

        public Element() { }

        public Element(String name, Double value, Double refMin, Double refMax, String unite)
        {
            setName(name);
            setValue(value);
            setRefMin(refMin);
            setRefMax(refMax);
            setUnite(unite);
        }

        public Element(String id, String name, Double refMin, Double refMax, String unite)
        {
            setId(id);
            setName(name);
            setRefMin(refMin);
            setRefMax(refMax);
            setUnite(unite);
        }

        public void setId(String id)
        {
            this.id = id;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public void setValue(Double value)
        {
            this.value = value;
        }

        public void setRefMin(Double refMin)
        {
            this.refMin = refMin;
        }

        public void setRefMax(Double refMax)
        {
            this.refMax = refMax;
        }

        public void setUnite(String unite)
        {
            this.unite = unite;
        }

        public String getId()
        {
            return id;
        }

        public String getName()
        {
            return name;
        }

        public Double getValue()
        {
            return value;
        }

        public Double getRefMin()
        {
            return refMin;
        }

        public Double getRefMax()
        {
            return refMax;
        }

        public String getUnite()
        {
            return unite;
        }

        public List<Element> getListElement()
        {
            Util util = new Util();
            var conn = util.getConnection();
            conn.Open();
            var command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM public.element;";
            var reader = command.ExecuteReader();

            List<Element> result = new List<Element>();

            while (reader.Read())
            {
                Element element = new Element(reader.GetString(0), reader.GetString(1), reader.GetDouble(2), reader.GetDouble(3), reader.GetString(4));
                result.Add(element);
            }

            conn.Close();
            return result;
        }

        public Element getElementByName(String name)
        {
            Element element = null;
            Util util = new Util();
            var conn = util.getConnection();
            conn.Open();
            var command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM public.element where nom =" + name + ";";
            var reader = command.ExecuteReader();
            
            while (reader.Read())
            {
                element = new Element(reader.GetString(0), reader.GetString(1), reader.GetDouble(2), reader.GetDouble(3), reader.GetString(4));
            }

            conn.Close();
            return element;
        }
    }
}
