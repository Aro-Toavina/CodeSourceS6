﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class EquationDroite
    {
        private Double A0;
        private Double B0;

        public EquationDroite(Point p1, Point p2)
        {
            setEquation(p1, p2);
        }

        public EquationDroite(Double A, Double B)
        {
            this.A0 = A;
            this.B0 = B;
        }

        public EquationDroite()
        {

        }

        public void setEquation(Point p1, Point p2)
        {
            if (p1.X == p2.X)
            {
                A0 = 10000;
            }
            else
            {
                A0 = (double)(p1.Y - p2.Y) / (double)(p1.X - p2.X);
                B0 = p1.Y - (A0 * (p1.X));
            }
        }

        public Double getA0()
        {
            return A0;
        }

        public Double getB0()
        {
            return B0;
        }
        public EquationDroite getEquationDroitePerpendiculaire(Point p3)
        {
            Double A1 = (-1) / A0;
            Double B1 = p3.Y - (A1 * (p3.X));
            EquationDroite equation = new EquationDroite(A1, B1);
            return equation;
        }
    }
}
