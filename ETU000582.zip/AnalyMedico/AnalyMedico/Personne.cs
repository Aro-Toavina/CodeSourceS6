﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyMedico
{
    class Personne
    {
        private String gender;
        private int age;
        private List<Element> elements;

        public Personne() { }

        public String getGender()
        {
            return gender;
        }

        public int getAge()
        {
            return age;
        }

        public List<Element> getElements()
        {
            return elements;
        }

        public void setGender(Boolean male, Boolean female, Boolean kids)
        {
            if (male)
            {
                gender = "M";
            }
            else if(female)
            {
                gender = "F";
            }
            else if (kids)
            {
                gender = "E";
            }
            else
            {
                throw new Exception("vous n'avez pas choisis votre sexe bordel de merde");
            }
        }

        public void setAge(int age)
        {
            if (age < 0 || age == null)
            {
                throw new Exception("age non valide");
            }
            else
            {

                this.age = age;
            }
        }

        public void setElements(List<Element> elements)
        {
            this.elements = elements;
        }
        
    }
}
