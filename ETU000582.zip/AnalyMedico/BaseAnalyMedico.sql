create table element(
	id varchar(7) primary key,
	designation VARCHAR(50),
	refMin FLOAT,
	refMax FLOAT,
	unite VARCHAR(20)
);

create table dosage(
	id varchar(7) primary key,
	idElement varchar(7),
	minAge INTEGER,
	maxAge INTEGER,
	minNorm FLOAT,
	maxNorm FLOAT,
	sexe varchar(1),
    foreign key (idElement) references element(id)
);

create table maladie(
	id varchar(7) primary key,
	nom varchar(35)
);

create table atteinte(
	id varchar(7) primary key,
	satut	int,
	idMaladie	varchar(7),
	idDiagnostic	varchar(7),
	foreign key (idDiagnostic) references diagnostic(id),
	foreign key (idMaladie) references maladie(id)
);

INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM1','Hémoglobine',3,28,'g/100ml');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM2','Hématocite',0,100,'%');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM3','Leucocytes',3000,20000,'mm3');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM4','Plaquettes',100000,500000,'mm3');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM5','Gamma Gt',0,55,'ui/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM6','Phosphates alcalines',0,400,'ui/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM7','Transaminases ASAT',0,60,'u/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM8','Transaminases ALAT',0,60,'u/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM9','Créatininémie',0,130,'umol/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM10','Glycémie',0,10,'mmol/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM11','Uricémie',0,500,'umol/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM12','Cholestérolémie totale',0,10,'mmol/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM13','Lipasémie',0,60,'u/l');
INSERT INTO public.element(id, designation, refmin, refmax, unite) VALUES ('ELM14','Sodium',100,200,'mmol/l');

/*DOSAGE*/

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS1','ELM1',0,10,12,14.5,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS2','ELM1',11,100,14,17,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS3','ELM1',11,100,12.5,15.5,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS4','ELM2',0,10,37,45,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS5','ELM2',11,100,40,52,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS6','ELM2',11,100,37,46,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS7','ELM3',0,10,000,11000,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS8','ELM3',11,100,4000,10000,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS9','ELM3',11,100,4000,10000,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS10','ELM4',0,10,160000,500000,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS11','ELM4',11,100,160000,35000,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS12','ELM4',11,100,160000,35000,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS13','ELM5',0,10,5,20,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS14','ELM5',11,100,5,30,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS15','ELM5',11,100,5,25,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS16','ELM6',0,10,100,300,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS17','ELM6',11,100,40,128,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS18','ELM6',11,100,40,128,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS19','ELM7',0,10,5,30,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS20','ELM7',11,100,0,35,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS21','ELM7',11,100,0,35,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS22','ELM8',0,10,5,30,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS23','ELM8',11,100,5,35,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS24','ELM8',11,100,5,35,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS25','ELM9',0,10,0,90,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS26','ELM9',11,100,65,120,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS27','ELM9',11,100,50,100,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS31','ELM10',0,10,4,6,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS32','ELM10',11,100,4,6,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS33','ELM10',11,100,4,6,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS34','ELM11',0,10,0,410,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS35','ELM11',11,100,0,410,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS36','ELM11',11,100,0,410,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS37','ELM12',0,10,3,6.2,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS38','ELM12',11,100,3,6.2,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS39','ELM12',11,100,3,6.2,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS40','ELM13',0,10,0,60,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS40','ELM13',11,100,0,60,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS40','ELM13',11,100,0,60,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS41','ELM14',0,10,137,145,'E');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS42','ELM14',11,100,137,145,'H');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS43','ELM14',11,100,137,145,'F');

INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS','ELM',,,,,'');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS','ELM',,,,,'');
INSERT INTO public.dosage(id, idelement, minage, maxage, minnorm, maxnorm, sexe) VALUES ('DOS','ELM',,,,,'');

/*LES MALADIES*/

insert into maladie values('MAL3','hémopathie');
insert into maladie values('MAL4','cancer');
insert into maladie values('MAL5','psoriasis');
insert into maladie values('MAL6','hypoxie');
insert into maladie values('MAL7','glycogénose');

insert into maladie values('MAL8','insuffisance rénale chronique');
insert into maladie values('MAL9','déshydratation');
insert into maladie values('MAL10','diabète insipide');
insert into maladie values('MAL11','acido-cétose diabétique');

insert into maladie values('MAL12','polyglobulie');
insert into maladie values('MAL13','maladie de Vaquez');

insert into maladie values('MAL14','anémies');
insert into maladie values('MAL15','leucémie');
insert into maladie values('MAL18','hemorragie');

insert into maladie values('MAL16','infection bactérienne');
insert into maladie values('MAL17','infection parasitaire ');

insert into maladie values('MAL18','maladie inflammatoire');
insert into maladie values('MAL19','collagénose');
insert into maladie values('MAL20','pancreatite');


insert into maladie values('MAL21','atteinte thyroïdienne');
insert into maladie values('MAL22','diabete');

insert into maladie values('MAL23','atteinte musculaire');
insert into maladie values('MAL24','atteinte cardiaque');

insert into maladie values('MAL25','hypertension artérielle ');
insert into maladie values('MAL26','Diarrhées');
insert into maladie values('MAL27','Insuffisance rénale');

insert into maladie values('MAL28','maladies cardio-vasculaires ');
insert into maladie values('MAL29','maladies dermatologiques');

insert into maladie values('MAL38','Hépatite');

insert into maladie values('MAL31','Hypoplaquettose');
insert into maladie values('MAL32','Hyperplaquettose');

insert into maladie values('MAL33','Hypoglycémie');
insert into maladie values('MAL34','Hyperglycémie');


insert into maladie values('MAL35','gouttes');
insert into maladie values('MAL36','Insuffisance hépatique');
insert into maladie values('MAL37','Syndrome de surcharge');

insert into maladie values('MAL40','');
insert into maladie values('MAL39','');

insert into maladie values('MAL','');

/*ATTEINTES*/

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT1',0,'MAL14','ELM1');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT2',1,'MAL12','ELM1');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT3',0,'MAL14','ELM2');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT4',1,'MAL12','ELM2');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT5',0,'MAL15','ELM3');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT6',1,'MAL16','ELM3');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT7',0,'MAL31','ELM4');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT8',1,'MAL32','ELM4');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT10',1,'MAL5','ELM5');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT12',1,'MAL38','ELM6');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT14',1,'MAL38','ELM7');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT16',1,'MAL38','ELM8');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT18',1,'MAL27','ELM9');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT19',0,'MAL33','ELM10');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT20',1,'MAL34','ELM10');


INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT22',1,'MAL35','ELM11');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT23',0,'MAL36','ELM12');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT24',1,'MAL37','ELM12');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT26',1,'MAL20','ELM13');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT27',0,'MAL26','ELM14');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT28',1,'MAL22','ELM14');

INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT29',0,'MAL','ELM');
INSERT INTO public.atteinte(id, satut, idmaladie, idelement) VALUES ('ATT30',1,'MAL','ELM');