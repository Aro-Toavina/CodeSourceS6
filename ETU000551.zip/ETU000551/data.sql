create table axe(
	id int primary key,
	numero_axe int,
	nom_axe varchar(30)
	);
create table maladie(
	id int primary key
	nom_aretina varchar(50)
);

create table comp_maladie(
	id int primary key,
	maladie int ,
	axe int,
	sexe varchar(20),
	val_min int,
	val_max int,
	foreign key(maladie) references maladie(id),
	foreign key(axe) references axe(id)
	);
	
insert into axe value(1,1,'H�maties');
insert into axe value(2,2,'H�moglobine');
insert into axe value(3,3,'Phosphatases alcalines');
insert into axe value(4,4,'Transaminases ASAT');
insert into axe value(5,5,'Transaminases ALAT');
insert into axe value(6,6,'Creatinin�mie');
insert into axe value(7,7,'Glyc�mie');
insert into axe value(8,8,'Uric�mie');
insert into axe value(9,9,'Cholestorol�mie totale');
insert into axe value(10,10,'Lipas�mie');
insert into axe value(11,11,'Sodium');
insert into axe value(12,12,'Potassium');
insert into axe value(13,13,'Chlore');
insert into axe value(14,14,'Anti-Strptolysine O');



insert into maladie values(1,'An�mie');
insert into maladie values(2,'Plyglobulie');
insert into maladie values(3,'Hepatie');
insert into maladie values(4,'Insuffisance renale');
insert into maladie values(5,'Hypoglyc�mie');
insert into maladie values(6,'Hyperglyc�mie ou Diab�te');
insert into maladie values(7,'Hyperuric�mie ou Goutte');
insert into maladie values(8,'Insuffisance h�patique');
insert into maladie values(9,'Syndrome de surcharge');
insert into maladie values(10,'Pancr�atite');
insert into maladie values(11,'Hyponatr�mie');
insert into maladie values(12,'Hypernatr�mie');
insert into maladie values(13,'Hypokali�mie');
insert into maladie values(14,'Hyperkali�mie');
insert into maladie values(15,'Hypochlorh�mie');
insert into maladie values(16,'Hyperchlorh�mie');
insert into maladie values(17,'Rhumatisme Articulaire Aig�');

insert into comp_maladie value(1,1,1,NULL,4200000,NULL);
insert into comp_maladie value(2,2,1,NULL,NULL,6200000);
insert into comp_maladie value(3,,,NULL,,);
insert into comp_maladie value(4,,,NULL,,);
insert into comp_maladie value(5,,,NULL,,);
insert into comp_maladie value(6,,,NULL,,);
insert into comp_maladie value(7,,,NULL,,);
insert into comp_maladie value(8,,,NULL,,);
insert into comp_maladie value(9,,,NULL,,);
insert into comp_maladie value(10,,,NULL,,);
insert into comp_maladie value(11,,,NULL,,);
insert into comp_maladie value(12,,,NULL,,);
insert into comp_maladie value(13,,,NULL,,);
insert into comp_maladie value(14,,,NULL,,);
insert into comp_maladie value(15,,,NULL,,);
insert into comp_maladie value(16,,,NULL,,);
insert into comp_maladie value(17,,,NULL,,);
insert into comp_maladie value(18,,,NULL,,);
insert into comp_maladie value(19,,,NULL,,);






















