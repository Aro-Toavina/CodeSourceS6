﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    public partial class Form1 : Form
    {
        private int nbVar = 0;
       
       
        private int MaxY = 120;
        private int countCursor = 0;
        private double[][] valInit = null;

        public Form1()
        {
            try
            {
                InitializeComponent();
                AxeDAO axedao = new AxeDAO();
                List<Axe> listeAxe = axedao.listeNomAxe();
                Graph.ChartAreas[0].AxisY.Maximum = MaxY;
                nbVar = listeAxe.Count;
                MessageBox.Show(nbVar.ToString());
                for (int i = 0; i < nbVar; i++)
                {
                    Graph.Series["Series1"].Points.AddY(50);
                    Graph.Series["Series1"].Points.ElementAt(i).AxisLabel = listeAxe.ElementAt(i).getNom();
                }
                saveValues();
            }catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
           

        }
        private void initValues()
        {
            for (int i = 0; i < nbVar; i++)
            {
                Graph.Series["Series1"].Points.ElementAt(i).YValues = valInit[i];

            }

        }
        private void saveValues()
        {
            valInit = new double[nbVar][];
            for (int i = 0; i < nbVar; i++)
            {
                valInit[i] = new double[1];
                valInit[i] = Graph.Series["Series1"].Points.ElementAt(i).YValues;
            }
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            // centre du point
            double x = this.Graph.Size.Width - this.Graph.Location.X;
            double y = this.Graph.Size.Height - this.Graph.Location.Y;
            x = 415; y = 356;
            double[] yvalues = new double[1];

            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);

            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
            string wid = mEvent.Y.ToString();
            string hei = mEvent.X.ToString();
            MessageBox.Show("centre x=" + hei + "centre y=" + wid);
           // MessageBox.Show("graph width" + this.Graph.Size.Width.ToString()+ "x location"+ this.Graph.Location.X.ToString());
          //  MessageBox.Show("graph height" + this.Graph.Size.Height.ToString() + "y location" + this.Graph.Location.Y.ToString());
            //   MessageBox.Show(msgA + "\n" + msgB + "\n" + msgC + "\n" + msgD);
            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    MessageBox.Show(yvalues[0].ToString());
                    Graph.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
                }
                else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());

                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());

                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }



                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());
                }
                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                    MessageBox.Show(yvalues[0].ToString());

                }

                MessageBox.Show("yvalues=" + yvalues[0]);
            }


            saveValues();

            

        }
     
        private void changeValueAxe(int indexAxe, double newValue)
        {
            double[] yvalues = new double[1];
            yvalues[0] = newValue;
            Graph.Series["Series1"].Points.ElementAt(indexAxe).YValues = yvalues;
        }
        private static double calculHypotenuse(double x, double y)
        {
            // 10 sur l'echelle equivaut a 12px
            return Math.Sqrt(x * x + y * y) * 10.0 / 12;
        }
        private void Graph_MouseMove(object sender, EventArgs e)
        {

            double x = this.Graph.Size.Width - this.Graph.Location.X;
            double y = this.Graph.Size.Height - this.Graph.Location.Y;
            x = 415; y = 356;
            double[] yvalues = new double[1];
            Random rdn = new Random();
            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);

            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
       
            initValues();
            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }



                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();

                }
                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                    label18.Text = yvalues[0].ToString();
                }
            }
            else
            {
                //Console.WriteLine("Reinitialized = " + valInit[0][0]);
                initValues();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
