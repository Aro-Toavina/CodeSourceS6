﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class AxeDAO
    {
        public List<Axe> listeNomAxe()
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select * from axe", conn);

                read = command.ExecuteReader();
                List<Axe> axe = new List<Axe>();

                while (read.Read())
                {


                    
                    int numero = int.Parse(read["numero_axe"].ToString());
                    string nom = read["nom_axe"].ToString();



                    axe.Add(new Axe(numero, nom));
                }
                return axe;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

    }
}
