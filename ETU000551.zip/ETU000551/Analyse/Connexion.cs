﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Connexion
    {
        public SqlConnection getConnect()
        {

            SqlConnection sqlConne;
            String sconnect;
            sconnect = "Server= ADMIN-PC\\SQLEXPRESS; Database=AnalyseMedical; Integrated Security=true;";
            sqlConne = new SqlConnection(sconnect);
            sqlConne.Open();
            return sqlConne;
        }
    }
}
