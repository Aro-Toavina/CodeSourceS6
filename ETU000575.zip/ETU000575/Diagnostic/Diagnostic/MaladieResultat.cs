﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class MaladieResultat
    {
        private String idMaladie;
        private String sexe;
        private int age;
        private List<DetailsCritereMaladie> criteresCorrespondants; //Avec le pourcentage de chance d'attrapper la maladie

        private List<DetailsCritereMaladie> allSymptoms;//Tous les symptomes correspondant a la maladie dependant du sexe et de l'age de la personne
        private double sommePourcentage;
        private double poucentageAtteintMaladie;

        public MaladieResultat()
        {
            criteresCorrespondants = new List<DetailsCritereMaladie>();
        }

        public MaladieResultat(String idMaladie,String sexe, int age)
        {
            criteresCorrespondants = new List<DetailsCritereMaladie>();
            this.setIMaladie(idMaladie);
            this.setSexe(sexe);
            this.setAge(age);
        }


        public void setIMaladie(String idMaladie)
        {
            this.idMaladie = idMaladie;
        }
        public String getIdMaladie()
        {
            return this.idMaladie;
        }
        public void setSexe(String sexe)
        {
            this.sexe = sexe;
        }
        public String getSexe()
        {
            return this.sexe;
        }
        public void setAge(int age)
        {
            this.age = age;
        }
        public int getAge()
        {
            return this.age;
        }
        public void setCriteresCorrespondants(List<DetailsCritereMaladie> criteresCorrespondants)
        {
            this.criteresCorrespondants = criteresCorrespondants;
        }
        public void addCriteresCorrespondants(DetailsCritereMaladie criteresCorrespondants)
        {
            this.criteresCorrespondants.Add(criteresCorrespondants);
        }
        public List<DetailsCritereMaladie> getCriteresCorrespondants()
        {
            return this.criteresCorrespondants;
        }
        public void setAllSymptoms()
        {
            try
            {
                this.allSymptoms = new DetailsCritereMaladieDAO().findDetailsCritereMaladie(" where idMaladie="+this.idMaladie+" and sexe='" + this.sexe + "'  and debutAge<=" + this.age + " and finAge>" + this.age + "");
            }
            catch(Exception ex)
            {
                throw new Exception("Tous les symptomes correspondant a cette maladie: " + ex.Message);
            }
        }
        public List<DetailsCritereMaladie> getAllSymptoms()
        {
            return this.allSymptoms;
        }

        public void setSommePourcentage()
        {
            int i = 0;
            double reponse=0;
            for (i = 0; i < criteresCorrespondants.Count; i++)
            {
                reponse += criteresCorrespondants.ElementAt(i).getPourcentageAtteint();
            }
            this.sommePourcentage = reponse;
        }
        public void setPourcentageAtteintMaladie()
        {
            try
            {
                this.setAllSymptoms();
                this.setSommePourcentage();
                this.poucentageAtteintMaladie = (this.sommePourcentage) / double.Parse(allSymptoms.Count.ToString());
            }
            catch(Exception ex)
            {
                throw new Exception("Pourcentage d'etre atteint par la maladie: " + ex.Message);
            }
        }
        public double getPourcentageAtteintMaladie()
        {
            try
            {
                    return this.poucentageAtteintMaladie;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }




    }
}
