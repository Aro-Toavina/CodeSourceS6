﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class Maladie
    {
        private string id;
        private string nomMaladie;
        private List<DetailsCritereMaladie> symptomes;
        private double pourcentageSymptomesAtteint;
        // private int estAtteint;

        public Maladie(){}

        public Maladie(string id,string nomMaladie)
        {
            this.id = id;
            this.nomMaladie = nomMaladie;
        }
        public Maladie(string nomMaladie)
        {
            this.setNomMaladie(nomMaladie);
        }
        public void setId(string id)
        {
            this.id = id;
        }
        public string getId()
        {
            return this.id;
        }
        public void setNomMaladie(string nomMaladie)
        {
            this.nomMaladie = nomMaladie;
        }
        public string getNomMaladie()
        {
            return this.nomMaladie;
        }
        public void setSymptomes()
        {
            try
            {
                this.symptomes = new DetailsCritereMaladieDAO().findDetailsCritereMaladie(" where idMaladie=" + this.id);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public List<DetailsCritereMaladie> getSymptomes()
        {
            try
            {
                return this.symptomes;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void setPourcentageSymptomesAtteint(List<DetailsCritereMaladie> mesAnalyses)
        {
            try
            {
                this.pourcentageSymptomesAtteint = (mesAnalyses.Count * 100) / this.symptomes.Count;
               // Console.WriteLine("pourcentageSymptomesAtteint= (" + mesAnalyses.Count + "* 100) / " + this.symptomes.Count);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public double getPourcentageSymptomesAtteint()
        {
            return this.pourcentageSymptomesAtteint;
        }
        public double getPourcentageSymptomesAtteint(List<DetailsCritereMaladie>mesAnalyses)
        {
            try
            {
                this.setSymptomes();
                this.setPourcentageSymptomesAtteint(mesAnalyses);
                return this.pourcentageSymptomesAtteint;
            }
            catch(Exception ex)
            {
                throw new Exception("Get Pourcentage Symptomes atteints: " + ex.Message);
            }
        }
    }
}
