﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Globalization;

namespace Diagnostic
{
    public class CriteresAnalyseDAO
    {
        public List<CriteresAnalyse> findCriteresAnalyse(string condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[CriteresAnalyse] " + condition, conn);
                conn.Open();
                read = command.ExecuteReader();
                List<CriteresAnalyse> pro = new List<CriteresAnalyse>();

                while (read.Read())
                {
                    //int id = int.Parse(read["id"].ToString());
                    String id = read["id"].ToString();
                    String nomCritere = (read["nomCritere"].ToString());
                    String unite = (read["unite"].ToString());
                    double debutIntNormal = double.Parse(read["debutIntNormal"].ToString());
                    double finIntNormal = double.Parse(read["finIntNormal"].ToString());
                    double minValeur = double.Parse(read["minValeur"].ToString());
                    double maxValeur = double.Parse(read["maxValeur"].ToString());

                    pro.Add(new CriteresAnalyse(id, nomCritere, unite,debutIntNormal,finIntNormal,minValeur,maxValeur));
                }
                return pro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public string findIdCriteresAnalyse(string condition)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();
                //if(conn.State==ConnectionState.Open)
                conn.Open();
                //throw new  Exception("SELECT id FROM [dbo].[CriteresAnalyse]  " + condition);
                command = new SqlCommand("SELECT top 1 id FROM [dbo].[CriteresAnalyse]  " + condition + "", conn);

                read = command.ExecuteReader();
                string reponse = "";
                if (read != null)
                {
                    read.Read();
                    reponse = read["id"].ToString();
                }
                if (read != null) read.Close();
                if (conn != null) conn.Close();
                return reponse;

            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Id du CriteresAnalyse non trouve: " + ex.Message);

            }
            finally
            {
                //                if (read != null) read.Close();
                if (command != null) command.Dispose();
            }

        }

        public void insertCriteresAnalyse(CriteresAnalyse m)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();
                NumberFormatInfo nfi = new NumberFormatInfo();
                nfi.NumberDecimalSeparator = ".";

                command = new SqlCommand("INSERT INTO  [dbo].[CriteresAnalyse](nomCritere,unite,debutIntNormal,finIntNormal,minValeur,maxValeur) VALUES('" + m.getNomCritere() + "','"+m.getUnite()+"',"+m.getDebutIntNormal().ToString(nfi)+","+m.getFinIntNormal().ToString(nfi)+","+m.getMinValeur().ToString(nfi)+","+m.getMaxValeur().ToString(nfi)+")", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion du CriteresAnalyse : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

    }
}
