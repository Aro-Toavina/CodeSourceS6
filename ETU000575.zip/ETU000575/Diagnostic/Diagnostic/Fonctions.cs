﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Diagnostic
{
    public class Fonctions
    {
        //Get coordonnees d'un point
        public Point getCoordPoint(Point pointOrigine, int distance, double angle)
        {
            try
            {
                int xNewPoint = (int)(pointOrigine.X + (Math.Sin(angle) * distance));
                int ynewPoint = (int)(pointOrigine.Y - (Math.Cos(angle) * distance));
                return new Point(xNewPoint, ynewPoint);
            }
            catch(Exception ex)
            {
                throw new Exception("GetCoordonnees d'un point: " + ex.Message);
            }
        }

        //Tracage d'une ligne
        public void tracerLigne(Graphics gr,Point origine,int distance, double angle)
        {
            try
            {
                Pen p = new Pen(Color.Gray, 3);
                Point point2 = getCoordPoint(origine, distance, angle);
                //Console.WriteLine("Angle=" + angle + " Point1(" + origine.X + ";" + origine.Y + ") et Point2(" + point2.X + ";" + point2.Y + ")");
                gr.DrawLine(p, origine, point2);
                // gr.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Tracage de ligne: "+ex.Message);
            }
        }

        //Mise en place des sommets du polygone (= de la graphe)
        public Point[] setSommetsGraphe(Axe[] axes)
        {
            try
            {
                Point[] newSommets = new Point[axes.Length];
                int i = 0;
                for (i = 0; i < axes.Length; i++)
                {
                    newSommets[i] = axes[i].getPositionCourbe();
                }
                return newSommets;
              
            }
            catch(Exception ex)
            {
                throw new Exception("Set sommets graphe: "+ex.Message);
            }
        }

        //Tracage d'un polygone (= de la graphe + ses sommets représentés par des points)
        public void tracerGraphe(Graphics g,Point[] lesSommets,Color couleur,float epaisseur)
        { 
            Pen p = new Pen(couleur, epaisseur);
            g.DrawPolygon(p, lesSommets);
            int i = 0;
            for (i = 0; i < lesSommets.Length; i++)
            {
                g.FillEllipse(new SolidBrush(Color.Red), lesSommets[i].X, lesSommets[i].Y, 5, 5);
            }
            

        }

        //Distance entre deux points
        public double distance2Points(Point point1,Point point2)
        {
            try
            {
                int X = (point2.X - point1.X)* (point2.X - point1.X);
                int Y= (point2.Y - point1.Y) * (point2.Y - point1.Y);
                return  Math.Sqrt(X + Y);
            }
            catch(Exception ex)
            {
                throw new Exception("Distance entre 2 points: " + ex.Message);
            }
        }

        //Trouver le point (=la graduation) le plus proche de la clique
        public int[] axeCorrespondant(Point pointClique,Axe[] allAxes)
        {
            try
            {
                Axe currAxe = allAxes[0];
                int indiceAxe = 0;
                int xPointProche = currAxe.getPointsGraduations()[0].X;
                int yPointProche = currAxe.getPointsGraduations()[0].Y;
                
                double distanceMinEntreLesPoints = this.distance2Points(currAxe.getPointsGraduations()[0],pointClique);
                int i = 0,j=0;
                double distanceEntrePoints = 0;
                for (i = 0; i < allAxes.Length; i++)
                {
                    for (j = 0; j < allAxes[i].getPointsGraduations().Length; j++) {
                        distanceEntrePoints = this.distance2Points(pointClique, allAxes[i].getPointsGraduations()[j]);
                        if (distanceEntrePoints < distanceMinEntreLesPoints) {
                            indiceAxe = i;
                            xPointProche = allAxes[i].getPointsGraduations()[j].X;
                            yPointProche = allAxes[i].getPointsGraduations()[j].Y;
                            distanceMinEntreLesPoints = distanceEntrePoints;
                        }
                    }
                }


                int[] reponse = new int[3];
                reponse[0] = indiceAxe;     //Indice de l'axe le plus proche
                reponse[1] = xPointProche;  //Abscisse du point le plus proche
                reponse[2] = yPointProche;  //Ordonnees du point le plus proche
               // Console.WriteLine("Distance entre les points="+distanceMinEntreLesPoints);
                return reponse;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
