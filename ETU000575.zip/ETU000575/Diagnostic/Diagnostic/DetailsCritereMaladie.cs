﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class DetailsCritereMaladie
    {
        private string id;
        private string sexe;
        private string idMaladie;
        private string idCritere;
        private int debutAge;
        private int finAge;
        private double debutValeurCritere;
        private double finValeurCritere;
        private int etat;   //1-> Hausse; 0->Baisse

        //Test si vous avez ce critere
        private int estMalade;
        private double pourcentageAtteint;


        public DetailsCritereMaladie(string id, string sexe, string idMaladie, string idCritere, int debutAge, int finAge, double debutValeurCritere, double finValeurCritere, int etat)
        {
            try
            {
                this.id = id;
                this.sexe = sexe;
                this.idMaladie = idMaladie;
                this.idCritere = idCritere;
                this.debutAge = debutAge;
                this.finAge = finAge;
                this.debutValeurCritere = debutValeurCritere;
                this.finValeurCritere = finValeurCritere;
                this.etat = etat;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DetailsCritereMaladie(string sexe, string idMaladie, string idCritere, int debutAge, int finAge, double debutValeurCritere, double finValeurCritere, int etat)
        {
            try
            {
                this.setSexe(sexe);
                this.setIdMaladie(idMaladie);
                this.setIdCritere(idCritere);
                this.setDebutAge(debutAge);
                this.setFinAge(finAge);
                this.setDebutValeurCritere(debutValeurCritere);
                this.setFinValeurCritere(finValeurCritere);
                this.setEtat(etat);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void setId(string id)
        {
            this.id = id;
        }
        public string getId()
        {
            return this.id;
        }
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public string getSexe()
        {
            return this.sexe;
        }
        public void setIdMaladie(string idMaladie)
        {
            this.idMaladie = idMaladie;
        }
        public string getIdMaladie()
        {
            return this.idMaladie;
        }
        public void setIdCritere(string idCritere)
        {
            this.idCritere = idCritere;
        }
        public string getIdCritere()
        {
            return this.idCritere;
        }
        public void setDebutAge(int debutAge)
        {
            this.debutAge = debutAge;
        }
        public int getDebutAge()
        {
            return this.debutAge;
        }
        public void setFinAge(int finAge)
        {
            this.finAge = finAge;
        }
        public int getFinAge()
        {
            return this.finAge;
        }
        public void setDebutValeurCritere(double debutValeurCritere)
        {
            this.debutValeurCritere = debutValeurCritere;
        }
        public double getDebutValeurCritere()
        {
            return this.debutValeurCritere;
        }
        public void setFinValeurCritere(double finValeurCritere)
        {
            this.finValeurCritere = finValeurCritere;
        }
        public double getFinValeurCritere()
        {
            return this.finValeurCritere;
        }
        public void setEtat(int etat)
        {
            this.etat = etat;
        }
        public int getEtat()
        {
            return this.etat;
        }
        public void setPourcentageAtteint(double pourcentageAtteint)
        {
            this.pourcentageAtteint = pourcentageAtteint;
        }
        public double getPourcentageAtteint()
        {
            return this.pourcentageAtteint;
        }
        //Calcul pourcentage si on est atteint
        public double calculPourcentage(double currResultatAnalyse)
        {
            try
            {
                double reponse = 0;
                //Valeur qui donne 100%
                double valCentPourCent = this.finValeurCritere - this.debutValeurCritere;
                double x = 0;
                Console.WriteLine("Current Etat=" + this.etat);
                //calcul de la reponse : si l'etat est 'en baisse'
                if (this.etat == 0)
                {
                    Console.WriteLine("Se calcul par le taux en baisse:");
                    x = this.finValeurCritere - currResultatAnalyse;
                    Console.WriteLine(" x = this.finValeurCritere - currResultatAnalyse=" + x);
                    reponse = (100 * x) / valCentPourCent;
                }
                //calcul de la reponse : si l'etat est 'en hausse'
                if (this.etat == 1)
                {
                    Console.WriteLine("Se calcul par le taux en hausse:");
                    x = currResultatAnalyse - this.debutValeurCritere;
                    reponse = (100 * x) / valCentPourCent;
                }
                return reponse;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        //Pourcentage de chance d'avoir le symptome de la maladie
        //[0]-> estMalade   (0->Non, PasMalade;   1->Oui, estMalade)
        public double[] getPourcentageAtteint(double currResultatAnalyse,CriteresAnalyse crCorrrespondant)         {
            try
            {
                double[] reponse = new double[2];
                //Prendre le critere d'analyse correspondant
                //CriteresAnalyse crAnalyse = new CriteresAnalyseDAO().findCriteresAnalyse(" where id=" + this.idCritere).ElementAt(0);
                reponse[0] = 0;
                reponse[1] = 0;
                //Si  la personne est en bonne sante( currResultat appartient a l'intervalle normale du critere)
                if((currResultatAnalyse>=crCorrrespondant.getDebutIntNormal())&&(currResultatAnalyse <= crCorrrespondant.getFinIntNormal()))
                {
                    reponse[0] = 0;
                    reponse[1] = 0;
                }

                //Si la personne verifie les criteres
                if ((currResultatAnalyse >= this.debutValeurCritere) && (currResultatAnalyse <= this.finValeurCritere))
                {
                    reponse[0] = 1;
                    reponse[1] = this.calculPourcentage(currResultatAnalyse);
                }


                return reponse;
            }
            catch (Exception ex)
            {
                throw new Exception("Pourcentage est Atteint: " + ex.Message);
            }
        }

        public void setPourcentageAtteint(double currResultatAnalyse, CriteresAnalyse crCorrrespondant)
        {
            try
            {
                Console.WriteLine("Curr Resultat Analyse="+currResultatAnalyse+ " et crCorrrespondant="+crCorrrespondant.getId() +" et this.Etat="+this.etat);
                double[] reponse = new double[2];
                //Prendre le critere d'analyse correspondant
                //CriteresAnalyse crAnalyse = new CriteresAnalyseDAO().findCriteresAnalyse(" where id=" + this.idCritere).ElementAt(0);
                reponse[0] = 0;
                reponse[1] = 0;
                //Si  la personne est en bonne sante( currResultat appartient a l'intervalle normale du critere)
                if ((currResultatAnalyse >= crCorrrespondant.getDebutIntNormal()) && (currResultatAnalyse <= crCorrrespondant.getFinIntNormal()))
                {
                    reponse[0] = 0;
                    reponse[1] = 0;
                }
               
                //Si la personne verifie les criteres
                if ((currResultatAnalyse >= this.debutValeurCritere) && (currResultatAnalyse <= this.finValeurCritere))
                {
                    reponse[0] = 1;
                    reponse[1] = this.calculPourcentage(currResultatAnalyse);
                }


                this.estMalade =(int) reponse[0];
                this.pourcentageAtteint = reponse[1];
            }
            catch (Exception ex)
            {
                throw new Exception("Pourcentage est Atteint: " + ex.Message);
            }
        }
        public int getEstMalade()
        {
            return this.estMalade;
        }
        
    }
}
