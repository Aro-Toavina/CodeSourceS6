﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class CriteresAnalyse
    {
        private string id;
        private string nomCritere;
        private string unite;
        private double debutIntNormal;
        private double finIntNormal;
        private double minValeur;
        private double maxValeur;
        public CriteresAnalyse(string id, string nomCritere,string unite, double debutIntNormal,double finIntNormal,double minValeur,double maxValeur)
        {
            try
            {
                this.id = id;
                this.nomCritere = nomCritere;
                this.unite = unite;
                this.debutIntNormal = debutIntNormal;
                this.finIntNormal = finIntNormal;
                this.minValeur = minValeur;
                this.maxValeur = maxValeur;

            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }
        public CriteresAnalyse(string nomCritere, string unite, double debutIntNormal, double finIntNormal, double minValeur, double maxValeur)
        {
            this.setNomCritere(nomCritere);
            this.setUnite(unite);
            this.setDebutIntNormal(debutIntNormal);
            this.setFinIntNormal(finIntNormal);
            this.setMinValeur(minValeur);
            this.setMaxValeur(maxValeur);

        }
        public void setId(string id)
        {
            this.id = id;
        }
        public string getId()
        {
            return this.id;
        }
        public void setNomCritere(string nomCritere)
        {
            this.nomCritere = nomCritere;
        }
        public string getNomCritere()
        {
            return this.nomCritere;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public string getUnite()
        {
            return this.unite;
        }
        public void setDebutIntNormal(double debutIntNormal)
        {
            this.debutIntNormal = debutIntNormal;
        }
        public double getDebutIntNormal()
        {
            return this.debutIntNormal;
        }
        public void setFinIntNormal(double finIntNormal)
        {
            this.finIntNormal = finIntNormal;
        }
        public double getFinIntNormal()
        {
            return this.finIntNormal;
        }
        public void setMinValeur(double minValeur)
        {
            this.minValeur = minValeur;
        }
        public double getMinValeur()
        {
            return this.minValeur;
        }
        public void setMaxValeur(double maxValeur) 
        {
            if (maxValeur < minValeur)
            {
                throw new Exception("Criteres d' analyse: La valeur maximum doit etre superieur a la valeur minimum");
            }
            this.maxValeur = maxValeur;
        }
        public double getMaxValeur()
        {
            return this.maxValeur;
        }

    }
}
