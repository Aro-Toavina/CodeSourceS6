﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Globalization;

namespace Diagnostic
{
    public class DetailsCritereMaladieDAO
    {
        public List<DetailsCritereMaladie> findDetailsCritereMaladie(string condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[DetailsCritereMaladie] " + condition, conn);
                conn.Open();
                read = command.ExecuteReader();
                List<DetailsCritereMaladie> pro = new List<DetailsCritereMaladie>();

                while (read.Read())
                {
                    //int id = int.Parse(read["id"].ToString());
                    String id = read["id"].ToString();
                    String sexe = read["sexe"].ToString();
                    String idMaladie = read["idMaladie"].ToString();
                    String idCritere = read["idCritere"].ToString();
                    int debutAge = int.Parse(read["debutAge"].ToString());
                    int finAge = int.Parse(read["finAge"].ToString());
                    double debutValeurCritere = double.Parse(read["debutValeurCritere"].ToString());
                    double finValeurCritere = double.Parse(read["finValeurCritere"].ToString());
                    int etat = int.Parse(read["etat"].ToString());
                    pro.Add(new DetailsCritereMaladie(id,sexe,idMaladie,idCritere,debutAge,finAge,debutValeurCritere,finValeurCritere,etat));
                }

                return pro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public string findIdDetailsCritereMaladie(string condition)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();
                //if(conn.State==ConnectionState.Open)
                conn.Open();
                //throw new  Exception("SELECT id FROM [dbo].[DetailsCritereMaladie]  " + condition);
                command = new SqlCommand("SELECT top 1 id FROM [dbo].[DetailsCritereMaladie]  " + condition + "", conn);

                read = command.ExecuteReader();
                string reponse = "";
                if (read != null)
                {
                    read.Read();
                    reponse = read["id"].ToString();
                }
                if (read != null) read.Close();
                if (conn != null) conn.Close();
                return reponse;

            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Id du DetailsCritereMaladie non trouve: " + ex.Message);

            }
            finally
            {
                //                if (read != null) read.Close();
                if (command != null) command.Dispose();
            }

        }

        public void insertDetailsCritereMaladie(DetailsCritereMaladie m)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();
                NumberFormatInfo nfi = new NumberFormatInfo();
                nfi.NumberDecimalSeparator = ".";
                command = new SqlCommand("INSERT INTO  [dbo].[DetailsCritereMaladie](sexe,idMaladie,idCritere,debutAge,finAge,debutValeurCritere,finValeurCritere,etat) VALUES('" + m.getSexe() + "',"+m.getIdMaladie()+","+m.getIdCritere()+","+m.getDebutAge()+","+m.getFinAge()+","+m.getDebutValeurCritere().ToString(nfi)+","+m.getFinValeurCritere().ToString(nfi)+","+m.getEtat()+")", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion du DetailsCritereMaladie : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
    }
}
