﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Diagnostic
{
    public class Resultat
    {
        private Axe[] axes;
        private string sexe;
        private string initialSexe;
        private int age;
        List<DetailsCritereMaladie> criteresMaladiesCorrespondant;//Les symptomes qui répondent aux criteres

        List<MaladieResultat> maladiesResultatCorrespondants;
        //Tri des maladiesResultatCorrespondants par ordre decroissant
        List<MaladieResultat> maladiesResultatCorrespondantDecroissant;


        List<int[]> lesMaladiesCorrespondants; //Liste de int[] => int[] represente [0]->idMaladie; [1]->nombre d'axe qui le valide
        List<double[]> pourcentageMaladiesCorrespondant;//Liste de double[] => [0]->idMaladie;[1]->pourcentageMaladie

        //Verification on a des resultats
        int estMalade; //1=>oui; 0=>non

        //La maladie qui correspond le plus, si estMalade est vrai
        private Maladie maladieResultat;
        private List<Maladie> maladies3Resultats;
        private string phraseResultat;

        //Pourcentage de chance d'etre atteint par cette maladie
        private double pourcentageAtteintMaladie;

        public Resultat(Axe[] axes,string sexe, string age)
        {
            try
            {
                //Initialisation des attributs
                this.axes = new Axe[2];
                this.sexe = "Masculin";
                this.initialSexe = "m";
                this.age = 0;
                this.criteresMaladiesCorrespondant = new List<DetailsCritereMaladie>();
                this.maladiesResultatCorrespondants = new List<MaladieResultat>();

                this.lesMaladiesCorrespondants = new List<int[]>();
                this.estMalade = 0;
                this.maladieResultat = new Maladie("maladie");
                this.maladies3Resultats = new List<Maladie>();
                this.phraseResultat = "Vous etes OK!";


                //Calcul un par un des valeurs
                this.setAxe(axes);
                //Console.WriteLine("Apres setAxe");
                this.setSexe(sexe);
                //Console.WriteLine("Apres setSexe");
                this.setAge(age);
               // Console.WriteLine("Apres setAge");
                this.setCriteresMaladies();
                // Console.WriteLine("Apres setCriteresMaladies");
                //this.setLesMaladiesCorrespondants();
                //Console.WriteLine("Apres setLesMaladiesCorrespondants");
                //this.setMaladieResultat();
                // Console.WriteLine("Apres setMaladieResultat");
                this.setMaladiesResultatCorrespondants();
                this.setPourcentagesMaladiesResultatsCorrespondants();
                this.setMaladiesResultatCorrespondantDecroissant();
                this.setMaladieResultat();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void setAxe(Axe[] axes)
        {
            this.axes = axes;
        }
        public Axe[] getAxe()
        {
            return this.axes;
        }
        public void setSexe(string sexe)
        {
            int sexeValide = 0;
            if (sexe.CompareTo("Masculin") == 0)
            {
                this.sexe = "Masculin";
                this.initialSexe = "m";
                sexeValide = 1;
            }
            if (sexe.CompareTo("Feminin") == 0)
            {
                this.sexe = "Feminin";
                this.initialSexe = "f";
                sexeValide = 1;
            }
            if (sexeValide == 0)
            {
                throw new Exception("Sexe invalide!");
            }
        }
        public string getSexe()
        {
            return this.sexe;
        }
        public void setAge(string age)
        {
            try
            {
                int agenow = int.Parse(age);
                if(agenow<0 || agenow > 200)
                {
                    throw new Exception("L'age doit etre compris entre 0 et 200!");
                }
                this.age = agenow;
            }
            catch(Exception ex)
            {
                throw new Exception("Age invalide!: " + ex.Message);
            }
        }
        public int getAge()
        {
            return this.age;
        }

        //Voir dans la base les criteres qui correspondent aux valeurs de chacun des axes
        public void setCriteresMaladies()
        {
            try
            {
               // Console.WriteLine("Les criteres correspondants");
                DetailsCritereMaladieDAO dcdao= new DetailsCritereMaladieDAO();
                int i = 0,j=0;
                List<DetailsCritereMaladie> criteresTemp;
                NumberFormatInfo nfi = new NumberFormatInfo();
                nfi.NumberDecimalSeparator = ".";
                //String lesCriteres = "(";
                for (i = 0; i < axes.Length; i++)
                {

                     criteresTemp = new List<DetailsCritereMaladie>();
                     double currValeurCritere = axes[i].getValeurDiagnostic();
                     string stringValeurCritere = currValeurCritere.ToString(nfi);
                    // Console.WriteLine("Valeur critere=" + stringValeurCritere);
                     criteresTemp = dcdao.findDetailsCritereMaladie(" where sexe='"+this.initialSexe+ "' and idCritere="+ axes[i].getIdCritere()+ " and debutAge<="+this.age+ " and finAge>"+ this.age+ " and debutValeurCritere<="+stringValeurCritere+ " and finValeurCritere>"+ stringValeurCritere);
                     //Console.WriteLine("Condition findDetailsCritereMaladie"+ " where sexe='" + this.initialSexe + "' and idCritere=" + axes[i].getIdCritere() + " and debutAge<=" + this.age + " and finAge>" + this.age + " and debutValeurCritere<=" + stringValeurCritere + " and finValeurCritere>" + stringValeurCritere);
                     if (criteresTemp.Count > 0)
                     {
                        //Console.WriteLine("CriteresTemp[0]=" + criteresTemp.ElementAt(0).getId() + " et Etat=" + criteresTemp.ElementAt(0).getEtat());
                         for(j=0;j< criteresTemp.Count; j++)
                         {
                            //On place le pourcentage de chance d'avoir attrape la maladie
                            Console.WriteLine("IdDetailsCriteres: " + criteresTemp.ElementAt(j).getIdCritere() + " Etat=" + criteresTemp.ElementAt(j).getEtat() + " - PourcentageAtteint:" + criteresTemp.ElementAt(j).getPourcentageAtteint() + " %");
                            criteresTemp.ElementAt(j).setPourcentageAtteint(axes.ElementAt(i).getValeurDiagnostic(), axes.ElementAt(i).getCurrCritere());
                            this.criteresMaladiesCorrespondant.Add(criteresTemp.ElementAt(j));
                           // Console.WriteLine("IdDetailsCriteres: " + criteresTemp.ElementAt(j).getIdCritere() + " Etat="+ criteresTemp.ElementAt(j).getEtat()+ " - PourcentageAtteint:" + criteresTemp.ElementAt(j).getPourcentageAtteint()+" %");
                         }
                     }
                    /*if (i != (axes.Length - 1))
                    {
                        lesCriteres += " idCritere=" + axes[i].getIdCritere() + " or ";
                    }
                    else
                    {
                        lesCriteres += " idCritere=" + axes[i].getIdCritere() + ") ";
                    }*/
                }
                //dcdao.findDetailsCritereMaladie(" where sexe='" + this.initialSexe + "' and idCritere=" + axes[i].getIdCritere() + " and debutAge<=" + this.age + " and finAge>" + this.age + " and debutValeurCritere<=" + stringValeurCritere + " and finValeurCritere>" + stringValeurCritere);

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        

        /*//Les maladies correspondants dans la base + nbAxes qui le valide
            //Fonction qui vérifie que la maladie est déjà dans la liste de maladie correspondant
        public int estDansMaladieCorrespondant(int idMaladie)//-1=>non; !=0 =>indice de sa presence dans lesMaladiesCorrespondants
        {
            try
            {
                int rep = -1;
                int i = 0;
                for (i = 0; i < lesMaladiesCorrespondants.Count; i++)
                {
                    if (lesMaladiesCorrespondants.ElementAt(i)[0] == idMaladie)
                    {
                        rep = i;
                        break;
                    }
                }
                return rep;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
           
            //Fonction qui la represente un resume des maladies qui correspondent aux criteres + nb axes qui les representent
        public void setLesMaladiesCorrespondants()
        {
            try
            {
                int i = 0;
               // Console.WriteLine("1");
                int maladiePresent = 0;
               // Console.WriteLine("2");
                int[] tableauTemporaire = new int[2];
               // Console.WriteLine("3");
                Console.WriteLine("criteresMaladiesCorrespondant.Count" + criteresMaladiesCorrespondant.Count);
                for (i=0;i< criteresMaladiesCorrespondant.Count; i++)
                {
                    maladiePresent = estDansMaladieCorrespondant(int.Parse(criteresMaladiesCorrespondant.ElementAt(i).getIdMaladie()));
                    Console.WriteLine("savoir si la maladie est dans la liste=" + maladiePresent);
                   // Console.WriteLine("4");
                    if (maladiePresent != (-1))
                    {
                        Console.WriteLine("maladie  est  Present");
                        lesMaladiesCorrespondants.ElementAt(maladiePresent)[1] = lesMaladiesCorrespondants.ElementAt(maladiePresent)[1] + 1;
                       // Console.WriteLine("5");
                    }
                    else
                    {
                        Console.WriteLine("maladie est pas Present");
                       // Console.WriteLine("6");
                        tableauTemporaire = new int[2];
                       // Console.WriteLine("7");
                        tableauTemporaire[0] = int.Parse(criteresMaladiesCorrespondant.ElementAt(i).getIdMaladie());
                       // Console.WriteLine("8");
                        tableauTemporaire[1] = 1;
                        //Console.WriteLine("9");
                        lesMaladiesCorrespondants.Add(tableauTemporaire);
                       // Console.WriteLine("10");
                    }
                }
                //Si la taille de lesMaladiesCorrespondants est==0->estMalade=0 , sinon estMalade=1;
                if (lesMaladiesCorrespondants.Count == 0)
                {
                    this.estMalade = 0;

                }
                else
                {
                    this.estMalade = 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/

        //Fonction qui represente les maladiesResultatCorrespondants
        //Voir si une maladie est déjà dans la liste des maladies resultats correspondants
        public int estDansMaladiesResultatCorrespondants(String idMaladie)//-1=>non; !=0 =>indice de sa presence dans lesMaladiesCorrespondants
        {
            try
            {
                int rep = -1;
                int i = 0;
                for (i = 0; i < maladiesResultatCorrespondants.Count; i++)
                {
                    if (maladiesResultatCorrespondants.ElementAt(i).getIdMaladie().CompareTo(idMaladie)==0)
                    {
                        rep = i;
                        break;
                    }
                }
                return rep;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void setMaladiesResultatCorrespondants()
        {
            try
            {
                int i = 0;
                int maladiePresent = 0;
                for (i = 0; i < criteresMaladiesCorrespondant.Count; i++)
                {
                    maladiePresent = estDansMaladiesResultatCorrespondants(criteresMaladiesCorrespondant.ElementAt(i).getIdMaladie());
                    if (maladiePresent != (-1))
                    {
                        maladiesResultatCorrespondants.ElementAt(maladiePresent).addCriteresCorrespondants(criteresMaladiesCorrespondant.ElementAt(i));
                    }
                    else
                    {
                        MaladieResultat ml = new MaladieResultat(criteresMaladiesCorrespondant.ElementAt(i).getIdMaladie(), this.initialSexe, this.age);
                        ml.addCriteresCorrespondants(criteresMaladiesCorrespondant.ElementAt(i));
                        this.maladiesResultatCorrespondants.Add(ml);
                        
                    }
                }
                //Si la taille de maladiesResultatCorrespondants est==0->estMalade=0 , sinon estMalade=1;
                if (maladiesResultatCorrespondants.Count == 0)
                {
                    this.estMalade = 0;

                }
                else
                {
                    this.estMalade = 1;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }

        //Mise en place des pourcentages pour avoir obtenu la maladie
        public void setPourcentagesMaladiesResultatsCorrespondants()
        {
            try
            {
                int i = 0;
                for(i=0;i< maladiesResultatCorrespondants.Count; i++)
                {
                    this.maladiesResultatCorrespondants.ElementAt(i).setPourcentageAtteintMaladie();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        //Tri des maladies trouves par ordre decroissant de pourcentage de chance
        public int triDecroissantTemp(List<MaladieResultat> listeAtrier)//Retourne 1 si le tri est fini et  sinon 0
        {
            int rep = 1;
            int i = 0;
   
            MaladieResultat mRTemp = new MaladieResultat();
            if (listeAtrier.Count >= 2)
            {
                for (i = 0; i < listeAtrier.Count - 1; i++)
                {
                    if (listeAtrier.ElementAt(i).getPourcentageAtteintMaladie() < listeAtrier.ElementAt(i + 1).getPourcentageAtteintMaladie())
                    {
                        rep = 0;
                        //Console.WriteLine(""+ listeAtrier.ElementAt(i).getPourcentageAtteintMaladie()+" < "+listeAtrier.ElementAt(i + 1).getPourcentageAtteintMaladie()+"");
                        mRTemp = listeAtrier.ElementAt(i);
                        //listeAtrier[listeAtrier.IndexOf(listeAtrier.ElementAt(i))] = listeAtrier.ElementAt(i + 1);
                        //listeAtrier[listeAtrier.IndexOf(listeAtrier.ElementAt(i + 1))] = mRTemp;
                        listeAtrier[i] = listeAtrier.ElementAt(i + 1);
                        listeAtrier[i + 1] = mRTemp;
                    }
                }
            }
            return rep;

        }
        public void setMaladiesResultatCorrespondantDecroissant()
        { 
            List<MaladieResultat> maladiesPourcentageDecroissant= this.maladiesResultatCorrespondants;
            int stopTri = 0;
            while (stopTri == 0)
            {
                stopTri = triDecroissantTemp(maladiesPourcentageDecroissant);
            }
            this.maladiesResultatCorrespondantDecroissant = maladiesPourcentageDecroissant;
        }
        public List<MaladieResultat> getMaladiesResultatCorrespondantDecroissant()
        {
            return this.maladiesResultatCorrespondantDecroissant;
        }




        /*//Comparer pour obtenir la maladie qui répond le plus aux criteres
        public void setMaladieResultat() {
            try
            {
                if (estMalade == 1)
                {
                    int i = 0;
                    int maxNbSymptomes = 0;
                    int idMaladie = 0;
                    for (i = 0; i < lesMaladiesCorrespondants.Count; i++)
                    {
                        if (lesMaladiesCorrespondants.ElementAt(i)[1] > maxNbSymptomes)
                        {
                            maxNbSymptomes = lesMaladiesCorrespondants.ElementAt(i)[1];
                            idMaladie = lesMaladiesCorrespondants.ElementAt(i)[0];
                        }
                    }
                    //On prend la maladie dans la base
                    this.maladieResultat = new MaladieDAO().findMaladie(" where id=" + idMaladie).ElementAt(0);

                    //On regarde le pourcentage de chance d'etre atteint par la maladie
                    this.setPourcentageAtteintMaladie();


                    //Le resultat qu'on va montrer + le pourcentage de chance d'etre atteint par la maladie
                    this.phraseResultat = "Maladie : " + this.maladieResultat.getNomMaladie() + "\n\nPourcentage de chance d'etre \natteint: " + this.pourcentageAtteintMaladie.ToString("00.00") + "%"; ;
                }
                else
                {
                    this.phraseResultat = "Vous êtes en parfaite santé!";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/
        //Prendre la maladie qui a le plus de pourcentage de chance d'etre attrapé
        public void setMaladieResultat()
        {
            try
            {
                if (estMalade == 1)
                {
                    Console.WriteLine("Ordre decroissant de pourcentage");
                    int i = 0,j=0;
                   // maladies3Resultats = null;
                    String idMaladies3 = "";
                    List<String> listeId3Maladies = new List<String>();
                    int limitesAAfficher = 3;
                    for (i=0;i< maladiesResultatCorrespondantDecroissant.Count; i++)
                    {
                        Console.WriteLine((i + 1) + "- idMaladie: " + maladiesResultatCorrespondantDecroissant.ElementAt(i).getIdMaladie() + " : " + maladiesResultatCorrespondantDecroissant.ElementAt(i).getPourcentageAtteintMaladie() + " %");
                        if (j < limitesAAfficher)
                        {
                            if(j== maladiesResultatCorrespondantDecroissant.Count)
                            {
                                break;
                            }
                            else
                            {
                                if (j == 0)
                                {
                                    idMaladies3 += " id=" + maladiesResultatCorrespondantDecroissant.ElementAt(i).getIdMaladie() + " ";
                                    listeId3Maladies.Add(maladiesResultatCorrespondantDecroissant.ElementAt(i).getIdMaladie());
                                }
                                else
                                {
                                    idMaladies3 += " or id=" + maladiesResultatCorrespondantDecroissant.ElementAt(i).getIdMaladie() + " ";
                                    listeId3Maladies.Add(maladiesResultatCorrespondantDecroissant.ElementAt(i).getIdMaladie());
                                }     
                            }
                        }
                        j++;

                    }


                    // this.maladieResultat = new MaladieDAO().findMaladie(" where id=" + maladiesResultatCorrespondantDecroissant.ElementAt(0).getIdMaladie()).ElementAt(0);
                    this.maladies3Resultats = new MaladieDAO().findMaladie(" where "+idMaladies3);
                    this.maladieResultat = maladies3Resultats.ElementAt(0);
                    //this.pourcentageAtteintMaladie = maladiesResultatCorrespondantDecroissant.ElementAt(0).getPourcentageAtteintMaladie();

                    //On prend les 3 resultats de maladie + ses pourcentages respectives
                    string maladiesEtPourcentages = "";
                    int k = 0;
                    for (i = 0; i < listeId3Maladies.Count; i++)
                    {
                        double currPourcentage = 0;
                        for(j=0;j< maladiesResultatCorrespondantDecroissant.Count; j++)
                        {
                            if (listeId3Maladies.ElementAt(i).CompareTo(maladiesResultatCorrespondantDecroissant.ElementAt(j).getIdMaladie()) == 0)
                            {
                                currPourcentage = maladiesResultatCorrespondantDecroissant.ElementAt(j).getPourcentageAtteintMaladie();
                            }
                        }
                        string currNomMaladie = "";
                        for(k=0;k< maladies3Resultats.Count; k++)
                        {
                            if (maladies3Resultats.ElementAt(k).getId().CompareTo(listeId3Maladies.ElementAt(i)) == 0) {
                                currNomMaladie = maladies3Resultats.ElementAt(k).getNomMaladie();
                            }
                        }
                        maladiesEtPourcentages += "\n- " +currNomMaladie + "  " + currPourcentage.ToString("00.00")+" %";
                    }

                    //Le resultat qu'on va montrer + le pourcentage de chance d'etre atteint par la maladie
                    //this.phraseResultat = "Maladie : " + this.maladieResultat.getNomMaladie() + "\n\nPourcentage de chance d'etre \natteint: " + this.pourcentageAtteintMaladie.ToString("00.00") + "%"; ;
                    this.phraseResultat = "Maladie(s) correspondante(s): \n" + maladiesEtPourcentages;

                }
                else
                {
                    this.phraseResultat = "Vous êtes en parfaite santé!";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string getPhraseResultat()
        {
            return this.phraseResultat;
        }

        /*//Pourcentage de chance d'obtenir cette maladie
        public void setPourcentageAtteintMaladie()
        {
            try
            {
                double pourcentage = 0;
                List<DetailsCritereMaladie> lesCriteresVerifiantMaladie = new List<DetailsCritereMaladie>();
                int i = 0;
                for (i = 0; i < criteresMaladiesCorrespondant.Count; i++)
                {
                    if (criteresMaladiesCorrespondant.ElementAt(i).getIdMaladie() == this.maladieResultat.getId())
                    {
                        lesCriteresVerifiantMaladie.Add(criteresMaladiesCorrespondant.ElementAt(i));
                    }
                }
                pourcentage = this.maladieResultat.getPourcentageSymptomesAtteint(lesCriteresVerifiantMaladie);
                this.pourcentageAtteintMaladie = pourcentage;

            }
            catch(Exception ex)
            {
                throw ex;
            }

        }*/
        public double getPourcentageAtteintMaladie()
        {
            return this.pourcentageAtteintMaladie;
        }




    }
}
