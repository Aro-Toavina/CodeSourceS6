﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Diagnostic
{
    public class MaladieDAO
    {
        public List<Maladie> findMaladie(string condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[Maladie] " + condition, conn);
                conn.Open();
                read = command.ExecuteReader();
                List<Maladie> pro = new List<Maladie>();

                while (read.Read())
                {
                    //int id = int.Parse(read["id"].ToString());
                    String id = read["id"].ToString();
                    String nomMaladie = (read["nomMaladie"].ToString());


                    pro.Add(new Maladie(id, nomMaladie));
                }
                
                return pro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public string findIdMaladie(string condition)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();
                //if(conn.State==ConnectionState.Open)
                conn.Open();
                //throw new  Exception("SELECT id FROM [dbo].[Maladie]  " + condition);
                command = new SqlCommand("SELECT top 1 id FROM [dbo].[Maladie]  " + condition + "", conn);

                read = command.ExecuteReader();
                string reponse = "";
                if (read != null)
                {
                    read.Read();
                    reponse = read["id"].ToString();
                }
                if (read != null) read.Close();
                if (conn != null) conn.Close();
                return reponse;

            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Id du Maladie non trouve: " + ex.Message);

            }
            finally
            {
                //                if (read != null) read.Close();
                if (command != null) command.Dispose();
            }

        }

        public void insertMaladie(Maladie m)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("INSERT INTO  [dbo].[Maladie](nomMaladie) VALUES('" + m.getNomMaladie() + "')", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion du Maladie : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

    }
}
