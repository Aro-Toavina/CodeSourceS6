﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diagnostic
{
    public partial class Form1 : Form
    {

        //Les criteres d'analyse
        List<CriteresAnalyse> lesCriteresAnalyse;

        //Labels: legende sur les axes
        int estPremiereEntree;
        Label[] legendes;
        //Axes
        private Point centreCercle; //origine de tous les axes
        private int rayon;
        private int unite;
        private int nbAxes;
        private int nbGraduationsAxe;
        private double uniteAngle;
        private Axe[] axes;

        //Utilisateur
        private string age;
        private string sexe;

        //Graphe
        private Point[] lesPointsGraphe;
        private Color couleurGraphe;
        private float epaisseurGraphe;

        private Fonctions fonctions;

        //Resultat
        private Resultat resultat;

        //Voir si le mouvement d'un souris est valide ou pas(changement de valeur)
        private Boolean validMouseMovement;

        public Form1()
        {
            InitializeComponent();
            try
            {
                this.estPremiereEntree = 0;
                fonctions = new Fonctions();
                //Les Criteres d'analyse
                this.lesCriteresAnalyse = new CriteresAnalyseDAO().findCriteresAnalyse("");

                //Legendes
                legendes = new Label[this.lesCriteresAnalyse.Count];
                //Axes
                this.rayon = this.panelGraphe.Width / 2;
                this.centreCercle = new Point(this.rayon, this.rayon);
                this.nbAxes = this.lesCriteresAnalyse.Count;
                this.nbGraduationsAxe = 5;
                this.uniteAngle = (2 * Math.PI) / this.nbAxes;
                this.unite = this.rayon / this.nbGraduationsAxe;
                this.axes = new Axe[this.nbAxes];
                //On definit les axes avec le critere d'analyse qu'il represente
                int i = 0;
                double mesureAngle = 0;
                for (i = 0; i < this.nbAxes; i++)
                {
                    mesureAngle = uniteAngle * i;
                    axes[i] = new Axe(lesCriteresAnalyse.ElementAt(i), this.centreCercle, mesureAngle, unite, this.nbGraduationsAxe);
                    //Positionnement des legendes
                    legendes[i] = new Label();
                    legendes[i].Text = lesCriteresAnalyse.ElementAt(i).getNomCritere();
                    //legendes[i].Location= axes[i].getPointsGraduations()[axes[i].getPointsGraduations().Length-1];
                    legendes[i].Location = axes[i].getPositionLabel();
                    legendes[i].BackColor = System.Drawing.Color.Transparent;
                    this.panelGraphe.Controls.Add(legendes[i]);
                }



                //Graphe
                this.lesPointsGraphe = new Point[this.nbAxes];
                couleurGraphe = Color.MidnightBlue;
                epaisseurGraphe = 4f;
                //Initialisation des sommets de la graphe
                int rayonInitGraphe = 2 * this.unite;
                for (i = 0; i < this.nbAxes; i++)
                {
                    axes[i].setPositionCourbe(fonctions.getCoordPoint(this.centreCercle, rayonInitGraphe, axes[i].getAngle()));
                }

                //Utilisateur
                this.initTextInformation();
                this.resultat = new Resultat(this.axes, this.sexe, this.age);
                this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Votre résultat s'affichera ici.", "");

                //Dire que le mouvement de la souris ne peut pas encore modifier la graphe
                this.validMouseMovement = false;
                //Mettre les listeners
                this.panelGraphe.MouseDown += new MouseEventHandler(onMouseDown);
                this.panelGraphe.MouseMove += new MouseEventHandler(onMouseMove);
                this.panelGraphe.MouseUp += new MouseEventHandler(onMouseUp);


                // panelGraphe.Refresh();
                this.Controls.Add(this.panelGraphe);
                this.estPremiereEntree = 1;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void drawGraduationsAxe(Graphics g)
        {
            try
            {
                SolidBrush b = new SolidBrush(Color.Gray);
                //Les coordonnees de chaque points pour la graduation + tracage
                int i = 0, j = 0;
                Point[] graduationsAxe;
                for (i = 0; i < this.nbAxes; i++)
                {
                    graduationsAxe = this.axes[i].getPointsGraduations();
                    for (j = 0; j < graduationsAxe.Length; j++)
                    {
                        g.FillEllipse(b, graduationsAxe[j].X, graduationsAxe[j].Y, 3, 3);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panelGraphe_Paint(object sender, PaintEventArgs e)
        {
            try
            {

                double angle = this.uniteAngle;
                Graphics gr = e.Graphics;
                int i = 0;
                //On trace les axes
                for (i = 0; i < this.nbAxes; i++)
                {
                    fonctions.tracerLigne(gr, axes[i].getPointOrigine(), this.rayon, axes[i].getAngle());
                }
                this.drawGraduationsAxe(gr);
                //On trace la graphe
                this.lesPointsGraphe = fonctions.setSommetsGraphe(axes);
                fonctions.tracerGraphe(gr, this.lesPointsGraphe, couleurGraphe, epaisseurGraphe);
                //Change les pourcentages inscrits sur le listBox
                this.actualiserListePourcentage();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // PaintEventArgs e1 = (PaintEventArgs)e;
            // panelGraphe_Paint( sender,  e1);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void labelSexe_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*try
            {
                this.age = this.textBoxAge.Text;
                this.sexe = this.comboBoxSexe.Text;
                this.resultat = new Resultat(this.axes, this.sexe, this.age);
                // this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Votre résultat s'affichera ici.", "");
                this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Resultat:", this.resultat.getPhraseResultat());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
            this.setResultat();
        }
        private void initTextInformation()
        {
            this.textBoxAge.Text = "30";
            this.comboBoxSexe.Items.Add("Feminin");
            this.comboBoxSexe.Items.Add("Masculin");
            this.age = textBoxAge.Text;
            //Console.WriteLine("Ici 1");
            this.sexe = "Masculin";
            // Console.WriteLine("Ici 2");
        }
        private void setTextResultat(String age, String sexe, String introResultat, String maladie)
        {
            this.labelAge.Text = age;
            this.labelSexe.Text = sexe;
            this.labelResultat.Text = introResultat;
            this.labelMaladie.Text = maladie;
        }

        /* private void panelGraphe_Click(object sender, EventArgs e)
         {
             try
             {
                 Point point = this.panelGraphe.PointToClient(Cursor.Position);
                 int[] axeCorrespondant = fonctions.axeCorrespondant(point, this.axes);
                 axes[axeCorrespondant[0]].setPositionCourbe(point);
                 this.resultat = new Resultat(this.axes, this.sexe, this.age);
                 this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Resultat:", this.resultat.getPhraseResultat());

                 this.panelGraphe.Refresh();

             }
             catch(Exception ex)
             {
                 MessageBox.Show(ex.Message);
             }
         }*/

        //Listeners de la souris sur le panel
        protected void onMouseDown(Object sender, MouseEventArgs e)
        {
            this.validMouseMovement = true;
        }
        private void onMouseMove(Object sender, MouseEventArgs e)
        {
            try
            {
                if (this.validMouseMovement)
                {

                    Point point = this.panelGraphe.PointToClient(Cursor.Position);
                    //Point point = new Point(e.X, e.Y);
                    int[] axeCorrespondant = fonctions.axeCorrespondant(point, this.axes);
                    axes[axeCorrespondant[0]].setPositionCourbe(point);

                    this.panelGraphe.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void onMouseUp(Object sender, MouseEventArgs e)
        {
            try
            {
                this.resultat = new Resultat(this.axes, this.sexe, this.age);
                this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Resultat:", this.resultat.getPhraseResultat());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.validMouseMovement = false;
        }
        //Fin Listener


        private void actualiserListePourcentage()
        {
            this.listBoxDiagnostic.Items.Clear();
            this.listBoxDiagnostic.Items.Add("");
            int i = 0;
            for (i = 0; i < this.axes.Length; i++)
            {
                this.listBoxDiagnostic.Items.Add("");
                this.listBoxDiagnostic.Items.Add((axes[i].getValeurDiagnostic()).ToString("00.00") + " " + axes[i].getUnite() + "\t(" + axes[i].getCurrCritere().getMinValeur().ToString("00") + " - " + axes[i].getCurrCritere().getMaxValeur().ToString("00") + ") " + axes[i].getNomAxe());
                // this.listBoxDiagnostic.Items.Add("\t    (" + axes[i].getCurrCritere().getMinValeur().ToString("00.00") + " - " + axes[i].getCurrCritere().getMaxValeur().ToString("00.00") + ") " + axes[i].getUnite());
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxSexe_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.setResultat();
        }
        public void setResultat()
        {
            try
            {
                if (this.estPremiereEntree != 0)
                {
                    this.age = this.textBoxAge.Text;
                    this.sexe = this.comboBoxSexe.Text;
                    this.resultat = new Resultat(this.axes, this.sexe, this.age);
                    // this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Votre résultat s'affichera ici.", "");
                    this.setTextResultat(this.resultat.getAge().ToString(), this.resultat.getSexe(), "Resultat:", this.resultat.getPhraseResultat());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBoxAge_TextChanged(object sender, EventArgs e)
        {
            if (this.comboBoxSexe.Text=="") {
                // this.initTextInformation();
                this.sexe = "Masculin";
            }
           // MessageBox.Show("curr sexe=" + this.sexe);
            this.setResultat();
        }
    }
}
