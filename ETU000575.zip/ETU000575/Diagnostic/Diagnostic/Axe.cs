﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Diagnostic
{
   // public partial class  Axe : Panel
    public class Axe 
    {
        //Le critere d'analyse représenté par l'axe
        private CriteresAnalyse currCritere;
        private string idCritere;
        private string nomCritere;
        private string unite;


        private Point positionLabel;

        //A propos de l'axe
        private string nomAxe;// qui n'est autre que le nomCritere
        private Point pointOrigine;
        private double angle;
        private int lengthUnite;
        private int nbGraduations;
        private Point[] pointsGraduations;
        private Point positionCourbe;
        private double valeurDiagnostic;
        private double pourcentageDiagnostic;
        private Point clickedPoint;

        private Fonctions fonctions;

        //Equation cartesienne de l'axe (=droite) => (D): y=a1*x+b1
        private double a1, b1;
        //Equation de la droite passant par positionCourbe et _|_ (D) (Projection orthogonale) => (D2): y=a2*x+b2
        private double a2, b2;

        //Si (D)//(yOy') et (D) passant par l'origine , on n'a plus besoin de calculer a1,b1,a2,b2 pour faire la projection car la projection sera(xOrigine,yClickedPoint)  
        int estParalleleOrdonnee;// 1=>oui; 0=>non

        public Axe() { }
        public Axe(CriteresAnalyse cr, Point pointOrigine,double angle,int lengthUnite,int nbGraduation)
        {
            try
            {
                //Les valeurs de criteres
                this.currCritere = cr;
                this.setIdCritere(cr.getId());
                this.setNomCritere(cr.getNomCritere());
                this.setUnite(cr.getUnite());

                //A propos de l'axe;
                fonctions = new Fonctions();
                this.setNomAxe(cr.getNomCritere());
                this.setPointOrigine(pointOrigine);
                this.setAngle(angle);
                this.setLengthUnite(lengthUnite);
                this.setNbGraduations(nbGraduation);
                this.setPointsGraduations();
                this.seta1();
                this.setb1();

                //Position label
                this.setPositionLabel();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void setCurrCritere(CriteresAnalyse currCritere)
        {
            this.currCritere = currCritere;
        }
        public CriteresAnalyse getCurrCritere()
        {
            return this.currCritere;
        }
        public void setNomAxe(string nomAxe)
        {
            this.nomAxe = nomAxe;
        }
        public string getNomAxe()
        {
            return this.nomAxe;
        }
        public void setPointOrigine(Point pointOrigine)
        {
            this.pointOrigine = pointOrigine;
        }
        public Point getPointOrigine()
        {
            return this.pointOrigine;
        }
        public void setAngle(double angle)
        {
            this.angle = angle;
        }
        public double getAngle()
        {
            return this.angle;
        }
        public void setLengthUnite(int lengthUnite)
        {
            this.lengthUnite = lengthUnite;
        }
        public int getLengthUnite()
        {
            return this.lengthUnite;
        }
        public void setNbGraduations(int nbGraduations)
        {
            this.nbGraduations = nbGraduations;
        }
        public int getNbGraduations()
        {
            return this.nbGraduations;
        }

        public void setPointsGraduations()
        {
            try
            {
                int j = 0;
                int distanceParRapportCentre = 0;
                this.pointsGraduations = new Point[this.nbGraduations];
                for (j = 1; j <= this.nbGraduations; j++)
                {
                    distanceParRapportCentre = this.lengthUnite * j;
                    this.pointsGraduations[j - 1] = fonctions.getCoordPoint(this.pointOrigine, distanceParRapportCentre, angle);
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Set Points Graduations: " + ex.Message);
            }
        }
        public Point[] getPointsGraduations()
        {
            return this.pointsGraduations;
        }

        public void setPositionCourbe(Point pointClique)
        {
            try
            {
                this.clickedPoint = pointClique;
                //L'ancien calcul sur la projection
                this.seta2();
                this.setb2();
                
                if (this.estParalleleOrdonnee == 1)
                {
                    this.positionCourbe = new Point(this.pointOrigine.X, this.clickedPoint.Y);
                }
                else
                {
                    double xProjection = ((this.b2 - this.b1) / (this.a1 - this.a2));
                    //int yProjection = (int)((this.a2 * xProjection) + this.b2);
                   // double xProjection = ((this.clickedPoint.X - this.b1 + (this.a1 * this.clickedPoint.Y)) / (1 + (this.a1 * this.a1)));
                    double yProjection =  (this.b1+(this.a1*(xProjection)));
                    this.positionCourbe = new Point((int)xProjection, (int)yProjection);
                }
                this.setEstHorsAxe();
                this.setValeurDiagnostic();
                this.setPourcentageDiagnostic();
                Console.WriteLine("Position PointGraphe:"+this.positionCourbe.ToString());
                Console.WriteLine(" ");
            
            }
            catch(Exception ex)
            {
                throw new Exception("Positionnement de la graphe: " + ex.Message);
            }
        }
        public Point getPositionCourbe()
        {
            return this.positionCourbe;
        }
        public void setValeurDiagnostic()
        {
            double longueurAxe = this.lengthUnite * this.nbGraduations;
            double valeurTotalAxe = currCritere.getMaxValeur() - currCritere.getMinValeur();
            //longueurPositionAxe Par rapport a l'origine
            double longueurPositionAxe = fonctions.distance2Points(this.pointOrigine, this.positionCourbe);
            //Valeur ou se trouve la position axe si l'origine de l'axe a pour valeur 0
            double valeurDiagnosticTemporaire = (longueurPositionAxe * valeurTotalAxe) / longueurAxe;
            //Valeur reelle de la position du point
            this.valeurDiagnostic = currCritere.getMinValeur() + valeurDiagnosticTemporaire;

        }
        public double getValeurDiagnostic()
        {
            return this.valeurDiagnostic;
        }
        public void setPourcentageDiagnostic()
        {
            try
            {
                double distanceOrigineEtPositionCourbe = fonctions.distance2Points(this.pointOrigine, this.positionCourbe);
                double longueurAxe = this.lengthUnite * this.nbGraduations;
                this.pourcentageDiagnostic = (100*distanceOrigineEtPositionCourbe)/longueurAxe;
                if (this.pourcentageDiagnostic > 100)
                {
                    this.pourcentageDiagnostic = 100;
                }

            }
            catch(Exception ex)
            {
                throw new Exception("Set pourcentage diagnostic: " + ex.Message);
            }
        }
        public void setPourcentageDiagnostic(double pourcentage)
        {
            this.pourcentageDiagnostic = pourcentage;
        }
        public double getPourcentageDiagnostic()
        {
            return this.pourcentageDiagnostic;
        }

        public void seta1()
        {
            try
            {
                //Prenons 2 points appartenant a (D)
                Point p1 = this.pointOrigine;
                Point p2 = this.pointsGraduations[0];
                // throw new Exception("Point1:" + p1.ToString() + " et Point2:" + p2.ToString());
                if ((p2.X - p1.X) == 0) {              
                    this.estParalleleOrdonnee = 1;
                    //On n'a pas besoin de a1
                    this.a1 = 0;
                    Console.WriteLine("Axe parallele axe (y'Oy)");
                    Console.WriteLine("Curr a1=" + this.a1);
                }
                else
                {
                    this.estParalleleOrdonnee = 0;
                    //Conversion des coordonnees en double
                    double p1X = System.Convert.ToDouble(p1.X);
                    double p1Y = System.Convert.ToDouble(p1.Y);
                    double p2X = System.Convert.ToDouble(p2.X);
                    double p2Y = System.Convert.ToDouble(p2.Y);

                    this.a1 = ((p2Y - p1Y) / (p2X - p1X));
                   // this.a1 = Math.Round(this.a1, 2);
                    
                    Console.WriteLine("Curr a1=(p2.Y - p1.Y) / (p2.X - p1.X) =>a1=("+p2.Y+" - "+p1.Y+") / ("+p2.X+" -"+ p1.X+")=" + this.a1);
                }
                
                
            }
            catch (Exception ex)
            {
                throw new Exception("Set a1: " + ex.Message);
            }
        }
        public double geta1()
        {
            return this.a1;
        }
        public void setb1()
        {
            try
            {
                if (this.estParalleleOrdonnee == 1)
                {
                    //On n'a pas besoin de b1
                    this.b1 = 0;
                    Console.WriteLine("Curr b1=" + this.b1);
                }
                else
                {
                    //this.b1 = this.pointOrigine.Y - (this.a1 * this.pointOrigine.X);
                    this.b1 = this.pointsGraduations[0].Y - (this.a1 * this.pointsGraduations[0].X);
                    // Console.WriteLine("Curr b1=this.pointOrigine.Y - (this.a1 * this.pointOrigine.X) =>b1="+this.pointOrigine.Y+" - ("+this.a1+" * "+this.pointOrigine.X+")=" + this.b1);
                    Console.WriteLine("curr b1=" + this.b1);
                }
                
            }
            catch(Exception ex)
            {
                throw new Exception("set b1: " + ex.Message);
            }
            
        }
        public double getb1()
        {
            return this.b1;
        }
        public void seta2()
        {
            try
            {
                if (this.estParalleleOrdonnee == 1)
                {
                    //On n'a pas besoin de a2
                    this.a2 = 0;
                    Console.WriteLine("Curr a2=" + this.a2);
                }
                else
                {
                    double numerateur = -1d;
                    this.a2 = numerateur / this.a1;
                    Console.WriteLine("Curr a2=numerateur / this.a1 => a2="+numerateur+" / "+this.a1+"="+ this.a2);
                }
               

            }
            catch (Exception ex)
            {
                throw new Exception("Set a2: " + ex.Message);
            }
        }
        public double geta2()
        {
            return this.a2;
        }
        public void setb2()
        {
            try
            {
                if (this.estParalleleOrdonnee == 1)
                {
                    //On n'a pas besoin de b2
                    this.b2 = 0;
                    Console.WriteLine("Curr b2=" + this.b2);
                }
                else
                {
                    this.b2 = this.clickedPoint.Y - (this.clickedPoint.X * this.a2);
                    Console.WriteLine("Curr b2=this.clickedPoint.Y - (this.clickedPoint.X * a2) => b2="+this.clickedPoint.Y+" - ("+this.clickedPoint.X +"*"+this.a2+")=" + this.b2);
                }
               

            }
            catch (Exception ex)
            {
                throw new Exception("Set b2: " + ex.Message);
            }
        }
        public double getb2()
        {
            return this.b2;
        }

        public void setEstHorsAxe()
        {
            try
            {
                double longueurAxe = fonctions.distance2Points(this.pointOrigine, this.pointsGraduations[this.pointsGraduations.Length - 1]);
                double distanceCliqueParRapportOrigine = fonctions.distance2Points(this.pointOrigine, this.positionCourbe);
                if (distanceCliqueParRapportOrigine > longueurAxe)
                {
                    this.positionCourbe = this.pointsGraduations[this.pointsGraduations.Length - 1];
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Set estHorsAxe: " + ex.Message);
            }
            
        }

        //Criteres d'analyse
        public void setIdCritere(string idCritere)
        {
            this.idCritere = idCritere;
        }
        public string getIdCritere()
        {
            return this.idCritere;
        }

        public void setNomCritere(string nomCritere)
        {
            this.nomCritere = nomCritere;
        }
        public string getNomCritere()
        {
            return this.nomCritere;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public string getUnite()
        {
            return this.unite;
        }

        public void setPositionLabel()
        {
            int distanceParRapportCentre =(int) (this.lengthUnite * (this.pointsGraduations.Length))-10;
            this.positionLabel = fonctions.getCoordPoint(this.pointOrigine, distanceParRapportCentre, angle);

           
        }
       public Point getPositionLabel()
        {
            return this.positionLabel;
        }





    }
}
