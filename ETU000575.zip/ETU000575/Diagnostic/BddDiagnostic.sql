/*Base de donnees avec les vrais unites*/
/*Base Base: BddDiagnostic2*/
Base Base: BddDiagnostic2

CREATE TABLE [dbo].[Maladie] (
    [id]  INT          IDENTITY (1, 1) NOT NULL,
    [nomMaladie] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);

1	Hepatite
2	Insufisance renale
3	Hypoglycemie
4	Diabete
5	Goutte
6	Insufisance hepatique
7	Syndrome de surcharge
8	Pancreatite
9	Presence d une inflammation
10	Rhumatisme Articulaire Aigu


CREATE TABLE [dbo].[CriteresAnalyse] (
    [id]  INT          IDENTITY (1, 1) NOT NULL,
    [nomCritere] VARCHAR (50) NULL,
    [unite] VARCHAR (20) NULL,
    [debutIntNormal] decimal(10,2) NULL,
    [finIntNormal] decimal(10,2) NULL,
    [minValeur] decimal(10,2) NULL,
    [maxValeur] decimal(10,2) NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);

1	Gamma GT	ui/L	0	55	0	100
2	Phosphatases alcalines	ui/L	53	128	0	200
3	Transaminases ASAT	u/L	0	35	0	100
4	Transaminases ALAT	u/L	0	45	0	100
5	Bilirubine conjuguee	umol/L	0	9	0	30
6	Bilirubine libre	umol/L	0	12	0	30
7	Creatininemie	umol/L	0	100	0	200
8	Glycemie	mmol/L	4	6	0	20
9	Uricemie	umol/L	200	410	200	500
10	Cholesterolemie 	mmol/L	3	6,2	0	20
11	Lipasemie	u/L	0	60	0	100
12	CRP	mg/L	0	10	0	50
13	Amylasemie	ui/L	0	55	0	100
14	ASLO	u/ml	100	200	100	300


CREATE TABLE [dbo].[DetailsCritereMaladie] (
    [id]  INT          IDENTITY (1, 1) NOT NULL,
    [sexe] VARCHAR (10) NULL,
    [idMaladie] int NULL,
    [idCritere] int NULL,
    [debutAge] int NULL,
    [finAge] int NULL,
    [debutValeurCritere] decimal(10,2) NULL,
    [finValeurCritere] decimal(10,2) NULL,
    [etat] int NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
	foreign key(idMaladie) references [dbo].[Maladie](id),
	foreign key(idCritere) references [dbo].[CriteresAnalyse](id)
);


1	m	1	1	0	100	55	100	1
2	m	1	2	0	100	128	200	1
3	m	1	3	0	100	35	100	1
4	m	1	4	0	100	45	100	1
5	m	1	5	0	100	9	30	1
6	m	1	6	0	100	12	30	1
7	m	2	7	0	100	100	200	1
8	m	3	8	0	100	0	4	0
9	m	4	8	0	100	6	20	1
10	m	5	9	0	100	410	500	1
11	m	6	10	0	100	0	3	0
12	m	7	10	0	100	6,2	20	1
13	m	8	11	0	100	60	100	1
14	m	9	13	0	100	55	100	1
15	m	10	14	0	100	200	300	1


/*0 bas, 1 hausse*/


