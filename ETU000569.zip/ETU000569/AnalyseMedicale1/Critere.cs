﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale1
{
   public class Critere
    {
        int id;
        string nomCritere;
        string unite;
        double debutIntervalle;
        double finIntervalle;
        double debutNormal;
        double finNormal;
        int age;
        string sexe;

        public Critere(int id,string nomCritere,string unite,double debutIntervalle,double finIntervalle,double debutNormal,double finNormal)
        {
            setId(id);
            setNomCritere(nomCritere);
            setUnite(unite);
            setDebutIntervalle(debutIntervalle);
            setFinIntervalle(finIntervalle);
            setDebutNormal(debutNormal);
            setFinIntervalle(finNormal);
            //setAge(age);
            //setSexe(sexe);
        }
        public Critere(string nomCritere, string unite, double debutIntervalle, double finIntervalle, double debutNormal, double finNormal)
        {
            
            setNomCritere(nomCritere);
            setUnite(unite);
            setDebutIntervalle(debutIntervalle);
            setFinIntervalle(finIntervalle);
            setDebutNormal(debutNormal);
            setFinIntervalle(finNormal);
            //setAge(age);
            //setSexe(sexe);
        }

        public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return this.id;
        }
        public void setNomCritere(string nomCritere)
        {
            this.nomCritere = nomCritere;
        }
        public string getNomCritere()
        {
            return this.nomCritere;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public string getUnite()
        {
            return this.unite;
        }
        public void setDebutIntervalle(double debutIntervalle)
        {
            this.debutIntervalle = debutIntervalle;
        }
        public double getFebutIntervalle()
        {
            return this.debutIntervalle;
        }
        public void setFinIntervalle(double finIntervalle)
        {
            this.finIntervalle = finIntervalle;
        }
        public double getFinIntervalle()
        {
            return this.finIntervalle;
        }
        public void setDebutNormal(double debutNormal)
        {
            this.debutNormal = debutNormal;
        }
        public double getDebutNormal()
        {
            return this.debutNormal;
        }
        public void setFinNormal(double finNormal)
        {
            this.finNormal = finNormal;
        }
        public double getFinNormal()
        {
            return this.finNormal;
        }
        public void setAge(int age)
        {
            this.age = age;
        }
        public int getAge()
        {
            return this.age;
        }
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public string getSexe()
        {
            return this.sexe;
        }
    }
}
