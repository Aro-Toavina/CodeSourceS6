﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AnalyseMedicale1
{
    class ResultatDAO
    {


        public List<Resultat> findResultat(String condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[Resultat] " + condition, conn);
                conn.Open();
                read = command.ExecuteReader();
                List<Resultat> soc = new List<Resultat>();

                while (read.Read())
                {
                    int id = int.Parse(read["id"].ToString());
                    string sexe = read["sexe"].ToString();
                    int debutIntervalleAge = int.Parse(read["debutIntervalleAge"].ToString());
                    int finIntervalleAge = int.Parse(read["finIntervalleAge"].ToString());
                    int idMaladie = int.Parse(read["idMaladie"].ToString());
                    int idCritere = int.Parse(read["idCritere"].ToString());
                    double debutIntervalleCritere = double.Parse(read["debutIntervalleCritere"].ToString());
                    double finIntervalleCritere = double.Parse(read["finIntervalleCritere"].ToString());



                    soc.Add(new Resultat(id, sexe,debutIntervalleAge,finIntervalleAge,idMaladie,idCritere,debutIntervalleCritere, finIntervalleCritere));
                }
                return soc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

        public void insertResultat(Resultat pe)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();

           
                //throw new Exception("INSERT INTO[dbo].[depreciation](idproduit, datedebut, datefin, prix) VALUES(" + pe.getIdproduit() + ", '" + year + "/" + month + "/" + day + " " + heure + ":" + minute + ":" + seconde + "', '" + year0 + "/" + month0 + "/" + day0 + " " + heure0 + ":" + minute0 + ":" + seconde + "', " + pe.getPrix() + ")");
                command = new SqlCommand("INSERT INTO  [dbo].[Resultat](sexe,debutIntervalleAge,finIntervalleAge,idMaladie,idCritere,debutIntervalleCritere,finIntervalleCritere) VALUES('" + pe.getSexe() + "'," + pe.getDebutIntervalleAge() + "," + pe.getFinIntervalleAge() + "," + pe.getIdMaladie() + "," + pe.getIdcritere() + "," + pe.getDebutIntervalleCritere() + "," + pe.getFinIntervalleCritere() + ")", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }


    }
}

