﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale1
{
    public partial class Affichage : Form
    {
        private int rayon;
        private int nbAxes;
        Point[] sommetpolygone;
        List<Axe> listeaxes;
        Point centre;
        Boolean down;
        List<String> leslabels;
        Double taux;
        Label lab;
        Label maladielab;


        private double divisionangle;

        public Affichage()
        {
            InitializeComponent();
            try
            {
                this.sexe.Items.Add("homme");
                this.sexe.Items.Add("femme");
                for (int i = 0; i < 100; i++)
                {
                    this.age.Items.Add(i);
                }



                this.rayon = this.panelGraphe.Width / 2;
                this.nbAxes = 14;
                Label lab = new Label();
                //lab.Text = "maladies";
                taux = 0;
                 maladielab = new Label();
                this.sommetpolygone = new Point[this.nbAxes];
                this.centre = new Point(this.rayon, this.rayon);
                down = false;
                divisionangle =( 2 * Math.PI) / nbAxes;
                listeaxes = new List<Axe>();
                Axe axe = null;
                leslabels = new List<string>();
                //MessageBox.Show("avant find="+ leslabels);
               // Initialisation des valeurs dans labels
                List<Critere> cr = new CritereDAO().findCritere("");
                
               // MessageBox.Show("c=" + cr.Count);
                for (int i = 0; i <this.nbAxes; i++)
                {
                    leslabels.Add(cr.ElementAt(i).getNomCritere());

                    Double currentangle = i * divisionangle;
                    Point currExtremite = getExtremite(currentangle);
                    axe = new AnalyseMedicale1.Axe(centre, currentangle, currExtremite,leslabels.ElementAt(i),cr.ElementAt(i));
                    listeaxes.Add(axe);
                    lab = new Label();
                    lab.Text = listeaxes.ElementAt(i).label;
                    lab.BackColor = Color.Transparent;
                    lab.Location = new Point(listeaxes.ElementAt(i).extremite.X, listeaxes.ElementAt(i).extremite.Y + 7);
                    panelGraphe.Controls.Add(lab);
                }

                this.panelGraphe.MouseDown += new MouseEventHandler(OnMouseDown);
                this.panelGraphe.MouseMove += new MouseEventHandler(OnMouseMove);
                this.panelGraphe.MouseUp += new MouseEventHandler(OnMouseUp);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        protected  void OnMouseDown(Object sender,MouseEventArgs e)
        {
            down = true;
        }
        protected  void OnMouseUp(Object sender, MouseEventArgs e)
        {
            down = false;
        }
        protected  void OnMouseMove(Object sender, MouseEventArgs e)
        {
            try
            {
                if (down == true)
                {
                    Point posSouris = new Point(e.X, e.Y);
                    int indiceAxe = indiceAxeProche(posSouris);
                    listeaxes.ElementAt(indiceAxe).positionSouris = posSouris;
                    listeaxes.ElementAt(indiceAxe).setA2();
                    listeaxes.ElementAt(indiceAxe).setB2();
                    listeaxes.ElementAt(indiceAxe).setPositionPolygone();
                    listeaxes.ElementAt(indiceAxe).setValeurDunPointCliqueSurAxe();
                    Point positionPolygone = listeaxes.ElementAt(indiceAxe).getPositionPolygone();
                    sommetpolygone[indiceAxe] = positionPolygone;

                    List<Critere> listeCritere = new CritereDAO().findCritere("");
                    List<Resultat> listeResultat = new ResultatDAO().findResultat("");
                    Fonction fonction = new Fonction();
                    int idmaladie = 0;

                    string nomMaladie = "";
                    List<String> lesmaladies = new List<String>();
                    List<String> lespourcentages = new List<String>();
                    List<Label> lespourcentageslabel = new List<Label>();
                    List<Label> lesmaladielabel = new List<Label>();
                    listeaxes.ElementAt(indiceAxe).setValeurDunPointCliqueSurAxe();
                    listeaxes.ElementAt(indiceAxe).getValeurDunPointCliqueSurAxe();

                    int agenew = int.Parse(age.Text);
                    String sexenew = sexe.Text;
                    List<Resultat> lr = new Fonction().reponse(agenew, sexenew);
                    List<Maladie> ma = new MaladieDAO().findMaladie("");
                    Valiny vl = new Valiny();
                    List<Valiny> maladie = listeaxes.ElementAt(indiceAxe).resultatMaladie(lr, agenew, sexenew, listeaxes.ElementAt(indiceAxe).getValeurDunPointCliqueSurAxe());
                    Maladie mal = new MaladieDAO().findMaladie(" where id=" + maladie.ElementAt(0).getIdMaladie()).ElementAt(0);
                   
                   // maladielab.Text = mal.getNomMaladie();
                   // Console.WriteLine("nom maladie" + ma.getNomMaladie());

                   label5.Text = mal.getNomMaladie()+ " "+ maladie.ElementAt(0).getTaux().ToString();
                    for (int j = 0; j < ma.Count(); j++)
                    {
                        Console.WriteLine("id maladie : "+ma[j].getId()+"taux :" + maladie[j]);
                    }
                    panelGraphe.Refresh();
                   
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
   
        public Double differenceEntre2points(Point p1,Point p2)
        {
            return Math.Sqrt(((p1.X - p2.X) * (p1.X - p2.X)) + ((p1.Y - p2.Y) * (p1.Y - p2.Y)));
           
        }
        public int indiceAxeProche(Point p)
        {
            int indice = 0;
            double differenceEntrePoints;
            try
            {
                if (listeaxes.Count>0)
                {
                    Double min = differenceEntre2points(listeaxes.ElementAt(0).extremite,p);
                    indice = 0;
                    for (int i = 1; i < listeaxes.Count; i++)
                    {
                        differenceEntrePoints= differenceEntre2points(listeaxes.ElementAt(i).extremite, p);
                        if (differenceEntrePoints < min)
                        {
                            min = differenceEntrePoints;
                            indice = i;
                        }
                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return indice;
        }
        private void panelGraphe_Paint(object sender, PaintEventArgs e)
        {
            try {
             double angle = (2 * Math.PI) / this.nbAxes;
             Graphics gr = e.Graphics;
             Pen pen1 = new Pen(Color.Green, 2F);
                Label[] labelAAfficher = new Label[this.nbAxes];
                Label lab ;
                for (int i = 0; i < this.nbAxes; i++)
                {
                    //angle = (2 * Math.PI / this.nbAxes) * i;
                    
                     this.tracerLigne(gr, listeaxes.ElementAt(i).extremite);
                     sommetpolygone[i]= listeaxes.ElementAt(i).positionPolygone;
                     gr.FillEllipse(new SolidBrush(Color.Red), sommetpolygone[i].X, sommetpolygone[i].Y, 10, 10);
                     
                }
             gr.DrawPolygon(pen1, sommetpolygone);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public Point getExtremite(Double angle)
        {
            int xfin = 0;
            int yfin = 0;
            try
            {
                 xfin = (int)(this.rayon + (Math.Sin(angle) * rayon));
                 yfin = (int)(this.rayon - (Math.Cos(angle) * rayon));
               
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return new Point(xfin, yfin);
        }
        private void tracerLigne(Graphics gr,Point pointExtremite)
        {
            
            try
            {
             
                Pen p = new Pen(Color.Black, 2);
                Point point1 = centre;
                Point point2 = pointExtremite ;
                gr.DrawLine(p, point1, point2);
              
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
