﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale1
{
   public class Axe
    {
        public double angle;
        public Point centre;//p1
        public Point extremite;//p2
        public String label;
        public Double a1, a2, b1, b2;
        public Point positionSouris, positionPolygone;
        Boolean paralleleOrdonnee;
        public Double differenceEntre2points;
        Double valeurDunPointCliqueSurAxe;
        Critere critere;

        public Axe(Point centre,Double angle,Point extremite,String label,Critere critere)
        {
            this.centre = centre;
            this.angle = angle;
            this.critere = critere;
            this.extremite = extremite;
            paralleleOrdonnee = false;
            this.label = label;
            positionPolygone = extremite;
            setA1();
            setB1();
           // setDifferenceEntre2points(centre, souris);
           // setValeurDunPointCliqueSurAxe(centre, souris, critere, p);
    
        }
        public void setA1()
        {
            try
            {
                if(centre.X - extremite.X == 0)
                {
                    this.a1 = 0;
                    paralleleOrdonnee = true;

                }

                else
                {
                    double centreX = double.Parse(centre.X.ToString());
                    double centreY = double.Parse(centre.Y.ToString());
                    double extremiteX = double.Parse(extremite.X.ToString());
                    double extremiteY = double.Parse(extremite.Y.ToString());
                    this.a1 = (centreY - extremiteY) / (centreX - extremiteX);
                }
                
            }
            catch(Exception ex)
            {
                throw new Exception("Venant de a1: "+ex.Message);
            }
        }
        public Double getA1()
        {
            return this.a1;
        }
        public void setB1()
        {
            double centreX = double.Parse(centre.X.ToString());
            double centreY = double.Parse(centre.Y.ToString());
            this.b1 = centreY - (a1*centreX);
        }
        public Double getdifferenceEntre2points(Point p1, Point p2)
        {
            differenceEntre2points= Math.Sqrt(((p1.X - p2.X) * (p1.X - p2.X)) + ((p1.Y - p2.Y) * (p1.Y - p2.Y)));
            return differenceEntre2points;
        }
       
        public void setValeurDunPointCliqueSurAxe()
        {
            Double distanceParRapportAuSouris  = getdifferenceEntre2points(centre, positionSouris);
            Double distanceParRapportExtremite  = getdifferenceEntre2points(centre, extremite);
            this.valeurDunPointCliqueSurAxe =(critere.getFinIntervalle()-critere.getFebutIntervalle())*distanceParRapportAuSouris/distanceParRapportExtremite ;
        }
        public Double getValeurDunPointCliqueSurAxe()
        {
            return valeurDunPointCliqueSurAxe;
        }
        public Double getB1()
        {
            return this.b1;
        }
        public void setA2()
        {
            if (this.paralleleOrdonnee)
            {
                a2 = 0;
            }
            else {
                this.a2 = -1f/a1;
            }
        }
        public Double getA2()
        {
            return this.a2;
        }
        public void setB2()
        {
            if (this.paralleleOrdonnee)
            {
                b2 = 0;
            }
            else {
                double positionSourisY = double.Parse(positionSouris.Y.ToString());
                double positionSourisX= double.Parse(positionSouris.X.ToString());
                this.b2 = positionSourisY-(a2* positionSourisX);
            }
        }
        public Double getB2()
        {
            return this.b2;
        }
        public void setPositionPolygone()
        {
            if (this.paralleleOrdonnee)
            {
                this.positionPolygone.X =centre.X;
                this.positionPolygone.Y = positionSouris.Y;
            }
            else { 
                this.positionPolygone.X = (int)((b2-b1)/(a1-a2));
                this.positionPolygone.Y = (int)((a2* positionPolygone.X)+b2);
            }
            if (this.verifHorsExtremite())
            {
                positionPolygone = this.extremite;
            } 
        }
        public Point getPositionPolygone()
        {
            return this.positionPolygone;
        }

        public Boolean verifHorsExtremite() {
            Boolean rep = false;
            Fonction f = new Fonction();
            double distanceEntreOrigineEtExtremite = f.differenceEntre2points(this.centre, this.extremite);
            double differenceEntrePositionpolygoneEtPointcentre=f.differenceEntre2points(this.centre,this.positionPolygone);
            if (distanceEntreOrigineEtExtremite< differenceEntrePositionpolygoneEtPointcentre)
            {
                rep = true;
            }
            return rep;
        }

        public List<Valiny> resultatMaladie(List<Resultat> liste, int age, string sexe, double valiny)
        {
            try
            {
                List<Valiny> reponse = new List<Valiny>();
                List<Critere> cr = new CritereDAO().findCritere("");
                List<Maladie> ma = new MaladieDAO().findMaladie("");
               // Double[] temp = new Double[100];
                for (int j = 0; j < ma.Count(); j++)
                {
                    valiny = valeurDunPointCliqueSurAxe;

                    double taux = 0;

                    Console.WriteLine("taille maladie :"+ma.Count);
                     List<Resultat> re = new ResultatDAO().findResultat("where idMaladie=" + ma[j].getId() + " and sexe='" + sexe + "'");
                   // List<Resultat> re = liste;
                    Console.WriteLine("taille resultat :" + re.Count);
                    for (int u = 0; u < re.Count; u++)
                    {

                      
                        for (int c = 0; c < cr.Count(); c++)
                        {
                            double finValeurNormal = cr.ElementAt(c).getDebutNormal();
                            double debutValeurNormal = cr.ElementAt(c).getFinNormal();
                            double debutIntervallle = cr.ElementAt(c).getFebutIntervalle();
                            double finIntervallle = cr.ElementAt(c).getFinIntervalle();
                            Console.WriteLine("idCritere :" + re[0].getIdcritere());
                            if (re[0].getIdcritere() == cr[c].getId())
                            {
                                if (valiny > debutValeurNormal && valiny < finValeurNormal)
                                {
                                    taux = taux + 0;

                                }
                                else if ((valiny < debutValeurNormal))
                                {
                                    taux = (((debutValeurNormal - valeurDunPointCliqueSurAxe) * 100) / (debutValeurNormal - debutIntervallle));
                                }
                                else if (valiny > finValeurNormal)
                                {
                                    taux = (((100) * (finIntervallle-finValeurNormal)) / (valeurDunPointCliqueSurAxe - finValeurNormal));
                                }
                            }
                        }
                        
                    }

                    //temp[0] = liste.ElementAt(j).getIdMaladie();
                    // temp[0] = ma.ElementAt(j).getId();
                    //temp[1] = taux;

                    Valiny v = new Valiny();
                    v.setIdMaladie(ma[j].getId());
                    v.setTaux(taux);
                    reponse.Add(v);
                    
                }
                return reponse;
            }

            catch (Exception ex)
            {
                throw new Exception("Erreur: " + ex.StackTrace);
            }
      }
    }
}
