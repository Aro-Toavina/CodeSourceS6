﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AnalyseMedicale1
{
    class CritereDAO
    {


        public List<Critere> findCritere(String condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[Critere] " + condition, conn);

                Console.WriteLine("SELECT * FROM [dbo].[Critere] " + condition);

                conn.Open();
                read = command.ExecuteReader();
                List<Critere> soc = new List<Critere>();

                while (read.Read())
                {
                    int id = int.Parse(read["id"].ToString());
                    //Console.WriteLine("id=" + id);
                    string nomCritere = read["nomCritere"].ToString();
                   // Console.WriteLine("nomCritere=" + nomCritere);
                    string unite = read["unite"].ToString();
                   // Console.WriteLine("unite=" + unite);
                    double debutIntervalle = double.Parse(read["debutIntervalle"].ToString());
                   // Console.WriteLine("debutIntervalle=" + debutIntervalle);
                    double finIntervalle = double.Parse(read["finIntervalle"].ToString());
                   // Console.WriteLine("finIntervalle=" + finIntervalle);
                    double debutNormal = double.Parse(read["debutNormal"].ToString());
                    //Console.WriteLine("debutNormal=" + debutNormal);
                    double finNormal = double.Parse(read["finNormal"].ToString());
                   // Console.WriteLine("finNormal=" + finNormal);
                   /* Console.WriteLine("Age dans la base: " + read["age"].ToString());
                    int age = int.Parse(read["age"].ToString());
                    Console.WriteLine("age=" + age);
                    string sexe = read["sexe"].ToString();
                    Console.WriteLine("sexe=" + sexe);*/

                    soc.Add(new Critere(id, nomCritere, unite, debutIntervalle, finIntervalle, debutNormal,finNormal));
                }
                return soc;
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur dans findCritere: "+ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

        public void insertCritere(Critere pe)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();


                //throw new Exception("INSERT INTO[dbo].[depreciation](idproduit, datedebut, datefin, prix) VALUES(" + pe.getIdproduit() + ", '" + year + "/" + month + "/" + day + " " + heure + ":" + minute + ":" + seconde + "', '" + year0 + "/" + month0 + "/" + day0 + " " + heure0 + ":" + minute0 + ":" + seconde + "', " + pe.getPrix() + ")");
                command = new SqlCommand("INSERT INTO  [dbo].[Critere](nomCritere,unite,debutIntervalle,finIntervalle,debutNormal,finNormal,age,sexe) VALUES('" + pe.getNomCritere() + "','"+pe.getUnite()+ "','" + pe.getFebutIntervalle() + "','" + pe.getFinIntervalle() + "','" + pe.getDebutNormal() + "','" + pe.getFinNormal() + "'," + pe.getAge() + ",'" + pe.getSexe() + "')", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }


    }
}

