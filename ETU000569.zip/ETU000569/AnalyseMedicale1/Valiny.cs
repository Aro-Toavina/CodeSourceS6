﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale1
{
  public  class Valiny
    {
        int idMaladie;
        double taux;
        public Valiny()
        {
            
        }
        public Valiny(int idMaladie, double taux)
        {
            setIdMaladie(idMaladie);
            setTaux(taux);
        }
        public void setIdMaladie(int idMaladie)
        {
            this.idMaladie = idMaladie;
        }
        public int getIdMaladie()
        {
            return this.idMaladie;
        }
        public void setTaux(double taux)
        {
            this.taux = taux;
        }
        public double getTaux()
        {
            return this.taux;
        }
    }
}  
