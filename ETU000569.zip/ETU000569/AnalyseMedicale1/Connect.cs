﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace AnalyseMedicale1
{
    class Connect
    {
        SqlConnection connex;
        public Connect()
        {
            try
            {
                connex = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Analasyse;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SqlConnection getConnect()
        {
            return connex;
        }
    }
}

