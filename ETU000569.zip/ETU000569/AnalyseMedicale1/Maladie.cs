﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale1
{
    public class Maladie
    {
        int id;
        String nomMaladie;
        public Maladie(int id,String nomMaladie)
        {
            setId(id);
            setNomMaladie(nomMaladie);
        }
        public Maladie(String nomMaladie)
        {
            setNomMaladie(nomMaladie);
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return this.id;
        }
        public void setNomMaladie(string nomMaladie)
        {
            this.nomMaladie = nomMaladie;
        }
        public string getNomMaladie()
        {
            return this.nomMaladie;
        }

    }
}
