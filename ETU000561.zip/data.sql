insert into Critere values(1, 'Globule rouge', 'millions/mm3', 3.2, 7);
insert into Critere values(2, 'Globule blanc', 'µl', 2000, 13000);
insert into Critere values(3, 'Plaquettes', 'mm3', 50000, 500000);
insert into Critere values(4, 'Lymphocytes', 'mm3', 500, 4500);
insert into Critere values(5, 'Monocytes', 'mm3', 0, 1100);
insert into Critere values(6, 'Vitesse de sédimentation', 'mn/h', 0, 30);
insert into Critere values(7, 'Volume globulaire moyen', 'micron3', 60, 115);
insert into Critere values(8, 'Polynucléaires neutrophiles', 'mm3', 500, 8200);
insert into Critere values(9, 'Polynucléaires éosinophiles', 'µl', 0, 900);
insert into Critere values(10, 'Polynucléaires basophiles', 'µl', 0, 75);
insert into Critere values(11, 'Triglycérides', 'g/L', 0, 2);
insert into Critere values(12, 'Choléstérol LDL', 'g/L', 0.7, 2);
insert into Critere values(13, 'Choléstérol HDL', 'g/L', 0.2, 0.7);
insert into Critere values(14, 'Glucose', 'mmol/L', 3, 6.5);

insert into ValeurNormale values(1, 1, 4.6, 6.2);
insert into ValeurNormale values(1, 2, 4.2, 5.4);
insert into ValeurNormale values(1, 3, 4.5, 5.4);

insert into ValeurNormale values(2, 0, 4000, 11000);

insert into ValeurNormale values(3, 0, 150000, 400000);

insert into ValeurNormale values(4, 0, 1000, 4000);

insert into ValeurNormale values(5, 0, 100, 1000);

insert into ValeurNormale values(6, 1, 0, 15);
insert into ValeurNormale values(6, 2, 0, 20);

insert into ValeurNormale values(7, 0, 80, 95);

insert into ValeurNormale values(8, 0, 1700, 7000);

insert into ValeurNormale values(9, 0, 50, 700);

insert into ValeurNormale values(10, 0, 10, 50);

insert into ValeurNormale values(11, 0, 0.40, 1.5);

insert into ValeurNormale values(12, 0, 0.8, 1.58);

insert into ValeurNormale values(13, 1, 0.4, 0.5);
insert into ValeurNormale values(13, 2, 0.5, 0.6);

insert into ValeurNormale values(14, 0, 4.04, 5.83);


-- Maladie
insert into Maladie values('DGN0001', 'Polyglobulie', 0, 0, 0, '');
insert into Maladie values('DGN0002', 'Anémie', 0, 0, 0, '');
insert into Maladie values('DGN0003', 'Leucémie aigüe', 0, 0, 0, '');
insert into Maladie values('DGN0004', 'Infection virale', 0, 0, 0, '');
insert into Maladie values('DGN0005', 'Cancer', 0, 0, 0, '');
insert into Maladie values('DGN0006', 'SIDA', 0, 0, 0, '');
insert into Maladie values('DGN0007', 'Hémorragie', 0, 0, 0, '');
insert into Maladie values('DGN0008', 'Thrombose', 0, 0, 0, '');
insert into Maladie values('DGN0009', 'Carence en fer', 0, 0, 0, '');
insert into Maladie values('DGN0010', 'Maladie du foie', 0, 0, 0, '');
insert into Maladie values('DGN0011', 'Grippe', 0, 0, 0, '');
insert into Maladie values('DGN0012', 'Aplasie médullaire', 0, 0, 0, '');
insert into Maladie values('DGN0013', 'Maladie d''Hodgkin', 0, 0, 0, '');
insert into Maladie values('DGN0014', 'Mononucléose', 0, 0, 0, '');
insert into Maladie values('DGN0015', 'Chlamydiose', 0, 0, 0, '');
insert into Maladie values('DGN0016', 'Inflammation', 0, 0, 0, '');
insert into Maladie values('DGN0017', 'Grossesse', 2, 13, 50, '');
insert into Maladie values('DGN0018', 'Microcytose', 0, 0, 0, '');
insert into Maladie values('DGN0019', 'Macrocytose', 0, 0, 0, '');
insert into Maladie values('DGN0020', 'Infarctus du myocarde', 0, 0, 0, '');
insert into Maladie values('DGN0021', 'Gale', 0, 0, 0, '');
insert into Maladie values('DGN0022', 'Allergie', 0, 0, 0, '');
insert into Maladie values('DGN0023', 'Hypertriglycériémie', 0, 0, 0, '');
insert into Maladie values('DGN0024', 'Hépatite', 0, 0, 0, '');
insert into Maladie values('DGN0025', 'Hyperthyroïdie', 0, 0, 0, '');
insert into Maladie values('DGN0026', 'Diabète', 0, 0, 0, '');
insert into Maladie values('DGN0027', 'Inuffisance surrénalienne', 0, 0, 0, '');


insert into Symptome values('DGN0001', 1, 1, 6.2, 7, '');
insert into Symptome values('DGN0001', 1, 2, 5.4, 7, '');
insert into Symptome values('DGN0001', 1, 3, 5.4, 7, '');

insert into Symptome values('DGN0002', 1, 1, 3.5, 4.6, '');
insert into Symptome values('DGN0002', 1, 2, 3.2, 4.2, '');
insert into Symptome values('DGN0002', 1, 3, 3.4, 4.5, '');
insert into Symptome values('DGN0002', 2, 0, 2000, 400, '');
insert into Symptome values('DGN0002', 5, 0, 1000, 1100, '');
insert into Symptome values('DGN0002', 7, 0, 60, 80, '');

insert into Symptome values('DGN0003', 2, 0, 11000, 13000, '');
insert into Symptome values('DGN0003', 3, 0, 50000, 150000, '');
insert into Symptome values('DGN0003', 4, 0, 4000, 4500, '');
insert into Symptome values('DGN0003', 8, 0, 500, 1700, '');
insert into Symptome values('DGN0003', 9, 0, 700, 900, '');

insert into Symptome values('DGN0004', 2, 0, 2000, 4000, '');
insert into Symptome values('DGN0004', 8, 0, 500, 1700, '');

insert into Symptome values('DGN0005', 2, 0, 2000, 4000, '');
insert into Symptome values('DGN0005', 3, 0, 400000, 500000, '');
insert into Symptome values('DGN0005', 8, 0, 7000, 8200, '');
insert into Symptome values('DGN0005', 9, 0, 700, 900, '');

insert into Symptome values('DGN0006', 2, 0, 2000, 4000, '');

insert into Symptome values('DGN0007', 3, 0, 50000, 150000, '');

insert into Symptome values('DGN0008', 3, 0, 400000, 500000, '');

insert into Symptome values('DGN0009', 3, 0, 400000, 500000, '');

insert into Symptome values('DGN0010', 3, 0, 400000, 500000, '');

insert into Symptome values('DGN0011', 4, 0, 4000, 4500, '');

insert into Symptome values('DGN0012', 4, 0, 500, 1000, '');
insert into Symptome values('DGN0012', 8, 0, 500, 1700, '');

insert into Symptome values('DGN0013', 4, 0, 500, 1000, '');
insert into Symptome values('DGN0013', 8, 0, 7000, 8200, '');

insert into Symptome values('DGN0014', 5, 0, 1000, 1100, '');

insert into Symptome values('DGN0015', 5, 0, 1000, 1100, '');

insert into Symptome values('DGN0016', 2, 0, 11000, 13000, '');
insert into Symptome values('DGN0016', 6, 1, 15, 30, '');
insert into Symptome values('DGN0016', 6, 2, 20, 30, '');

insert into Symptome values('DGN0017', 6, 2, 20, 45, '');

insert into Symptome values('DGN0018', 7, 0, 60, 80, '');

insert into Symptome values('DGN0019', 7, 0, 95, 115, '');

insert into Symptome values('DGN0020', 8, 0, 7000, 8200, '');

insert into Symptome values('DGN0021', 9, 0, 700, 900, '');

insert into Symptome values('DGN0022', 9, 0, 700, 900, '');
insert into Symptome values('DGN0022', 10, 0, 50, 75, '');

insert into Symptome values('DGN0023', 11, 0, 1.5, 2, '');

insert into Symptome values('DGN0024', 12, 0, 0.7, 0.8, '');

insert into Symptome values('DGN0025', 12, 0, 0.7, 0.8, '');

insert into Symptome values('DGN0026', 13, 1, 0.2, 0.4, '');
insert into Symptome values('DGN0026', 13, 2, 0.2, 0.5, '');
insert into Symptome values('DGN0026', 14, 0, 5.83, 6.5, '');

insert into Symptome values('DGN0027', 14, 0, 3, 4.04, '');