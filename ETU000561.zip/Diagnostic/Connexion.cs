﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connect
{
    public class Connexion
    {
        public static SqlConnection connect()
        {
            SqlConnection connection = null;
            try
            {
                string connectionString = null;
                connectionString = "Data Source=SH-TIANTSOA;Initial Catalog=Diagnostic;Integrated Security=False;User ID=tsotra;Password=tsotra;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                connection = new SqlConnection(connectionString);
                connection.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            return connection;
        }

        public static int beginTransaction(SqlConnection connection)
        {
            int result = 0;
            string query = "BEGIN TRANSACTION";

            SqlCommand command = new SqlCommand(query, connection);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }

        public static int commit(SqlConnection connection)
        {
            int result = 0;
            string query = "COMMIT";

            SqlCommand command = new SqlCommand(query, connection);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }

        public static int rollback(SqlConnection connection)
        {
            int result = 0;
            string query = "ROLLBACK";

            SqlCommand command = new SqlCommand(query, connection);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }
    }
}
