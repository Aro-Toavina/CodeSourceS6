﻿namespace Diagnostic
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.sexe = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.TextBox();
            this.diagnosticPanel = new System.Windows.Forms.Panel();
            this.diagnosticGrid = new System.Windows.Forms.DataGridView();
            this.nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pourcentage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.poids = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.personne = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.diagnosticPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagnosticGrid)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Informations";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sexe";
            // 
            // sexe
            // 
            this.sexe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sexe.FormattingEnabled = true;
            this.sexe.Location = new System.Drawing.Point(65, 76);
            this.sexe.Name = "sexe";
            this.sexe.Size = new System.Drawing.Size(121, 21);
            this.sexe.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Age";
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(65, 106);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(71, 20);
            this.age.TabIndex = 4;
            this.age.Text = "18";
            this.age.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // diagnosticPanel
            // 
            this.diagnosticPanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.diagnosticPanel.Controls.Add(this.diagnosticGrid);
            this.diagnosticPanel.Controls.Add(this.label7);
            this.diagnosticPanel.Location = new System.Drawing.Point(886, 318);
            this.diagnosticPanel.Name = "diagnosticPanel";
            this.diagnosticPanel.Size = new System.Drawing.Size(283, 281);
            this.diagnosticPanel.TabIndex = 5;
            // 
            // diagnosticGrid
            // 
            this.diagnosticGrid.AllowUserToAddRows = false;
            this.diagnosticGrid.AllowUserToDeleteRows = false;
            this.diagnosticGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.diagnosticGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nom,
            this.pourcentage});
            this.diagnosticGrid.Location = new System.Drawing.Point(17, 35);
            this.diagnosticGrid.Name = "diagnosticGrid";
            this.diagnosticGrid.ReadOnly = true;
            this.diagnosticGrid.Size = new System.Drawing.Size(246, 236);
            this.diagnosticGrid.TabIndex = 11;
            // 
            // nom
            // 
            this.nom.HeaderText = "Nom";
            this.nom.Name = "nom";
            this.nom.ReadOnly = true;
            // 
            // pourcentage
            // 
            this.pourcentage.HeaderText = "Pourcentage";
            this.pourcentage.Name = "pourcentage";
            this.pourcentage.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Diagnostics possibles";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1059, 658);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Réinitialiser";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // poids
            // 
            this.poids.Location = new System.Drawing.Point(65, 132);
            this.poids.Name = "poids";
            this.poids.Size = new System.Drawing.Size(71, 20);
            this.poids.TabIndex = 8;
            this.poids.Text = "40";
            this.poids.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Poids";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(142, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "kg";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.personne);
            this.panel2.Controls.Add(this.sexe);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.poids);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.age);
            this.panel2.Location = new System.Drawing.Point(886, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(283, 182);
            this.panel2.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Nom";
            // 
            // personne
            // 
            this.personne.Location = new System.Drawing.Point(65, 50);
            this.personne.Name = "personne";
            this.personne.Size = new System.Drawing.Size(186, 20);
            this.personne.TabIndex = 11;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1059, 251);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 31);
            this.button2.TabIndex = 11;
            this.button2.Text = "Verifier";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(1047, 605);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(122, 23);
            this.save.TabIndex = 12;
            this.save.Text = "Enregistrer";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 750);
            this.Controls.Add(this.save);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.diagnosticPanel);
            this.Name = "Form1";
            this.Text = "Diagnostic";
            this.diagnosticPanel.ResumeLayout(false);
            this.diagnosticPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagnosticGrid)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox sexe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.Panel diagnosticPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox poids;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox personne;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView diagnosticGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn pourcentage;
        private System.Windows.Forms.Button save;
    }
}

