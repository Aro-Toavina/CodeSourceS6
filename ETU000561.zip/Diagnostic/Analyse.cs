﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class Analyse
    {
        public static string NameSequence = "idanl";
        public static string IdSequence = "ANL";


        private string id;
        public string ID
        {
            get { return id; }
            set { id = value; }
        }

        private DateTime date;
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private string personne;
        public string Personne
        {
            get { return personne; }
            set { personne = value; }
        }

        private int sexe;
        public int Sexe
        {
            get { return sexe; }
            set { sexe = value; }
        }

        private int age;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        private int poids;
        public int Poids
        {
            get { return poids; }
            set { poids = value; }
        }

        public Analyse() { }
        public Analyse(string id, DateTime date, string personne, int sexe, int age, int poids)
        {
            this.ID = id;
            this.Date = date;
            this.Personne = personne;
            this.Sexe = sexe;
            this.Age = age;
            this.Poids = poids;
        }
    }
}
