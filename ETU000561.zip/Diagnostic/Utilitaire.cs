﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using Diagnostic;

namespace Utilitaires
{
    public class Utilitaire
    {
        public static Point getCenter(Point final, Point initial)
        {
            return new Point((final.X + initial.X) / 2, (final.Y + initial.Y) / 2);
        }

        public static double getDistance(Point point1, Point point2)
        {
            int X = point2.X - point1.X;
            int Y = point2.Y - point1.Y;
            return Math.Sqrt(X * X + Y * Y);
        }

        public static Point getIntersection(EquationDroite droite1, EquationDroite droite2)
        {
            int x = 0, y = 0;

            if (droite1.LHS == droite2.LHS)
            {
                double numerateur = droite2.B - droite1.B;
                double denominateur = droite1.A - droite2.A;
                x = (int)(numerateur / denominateur);
                y = (int)(droite1.A * x + droite1.B);
            }
            else if(droite1.LHS == EquationDroite.LSH_X)
            {
                x = (int)droite1.B;
                y = (int)(droite2.A * x + droite2.B);
            }
            else if (droite2.LHS == EquationDroite.LSH_X)
            {
                x = (int)droite2.B;
                y = (int)(droite1.A * x + droite1.B);
            }

            return new Point(x, y);
        }

        public static double getValue(double distance, double min, double max, int rayon)
        {
            return (distance * (max - min) / rayon) + min;
        }

        public static string formatValue(double value, int limit)
        {
            string stringValue = value.ToString();
            string beforeComma = ((int)value).ToString();

            int indexAfterComma = stringValue.IndexOf(",");
            string afterComma = indexAfterComma != -1 ? stringValue.Substring(indexAfterComma) : string.Empty;

            afterComma = afterComma.Length > (limit + 1) ? afterComma.Substring(0, limit + 1) : afterComma;

            return beforeComma + afterComma;
        }

        public static Point getPointSurAxe(EquationDroite axe, Point positionSouris)
        {
            return Utilitaire.getIntersection(axe, EquationDroite.getEquationPerpendiculaire(axe, positionSouris));
        }

        public static double getNormalValue(int axe, double minVal, double maxVal)
        {
            return (minVal + maxVal) / 2;
        }

        public static List<double> getListValeurs(List<NiveauPanel> niveaux)
        {
            List<double> result = new List<double>();

            foreach(NiveauPanel niveau in niveaux)
            {
                result.Add(niveau.Niveau.ActualValue);
            }

            return result;
        }

        public static string formatDouble(double number)
        {
            return number.ToString().Replace(',', '.');
        }

        public static string getSqlList(Dictionary<int, double> symptomes)
        {
            string result = "(";
            int count = 0;

            foreach(KeyValuePair<int, double> entry in symptomes)
            {
                result += entry.Key;

                count++;

                if (count < symptomes.Count)
                    result += ",";
            }

            result += ")";

            return result;
        }

        public static string getListSql(List<string> list)
        {
            string result = "(";
            int count = 0;

            foreach (string element in list)
            {
                result += "'" + element + "'";

                count++;

                if (count < list.Count)
                    result += ",";
            }

            result += ")";

            return result;
        }

        public static double getValueAtPercent(double percent, double min, double max)
        {
            double calcul1 = percent / 100;
            double calcul2 = max - min;
            double calcul3 = calcul1 * calcul2;

            return calcul3 + min;
        }

        public static double getMoyenne(List<double> valeurs, int nbreTotal)
        {
            double somme = 0;

            foreach (double valeur in valeurs)
                somme += valeur;

            Console.WriteLine(nbreTotal);
            return somme / nbreTotal;
        }
    }
}
