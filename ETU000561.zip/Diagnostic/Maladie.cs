﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class Maladie
    {
        private string id;
        public string ID
        {
            set { id = value; }
            get { return id; }
        }

        private string nom;
        public string Nom
        {
            set { nom = value; }
            get { return nom; }
        }

        private int cible;
        public int Cible
        {
            set { cible = value; }
            get { return cible; }
        }

        private int ageMin;
        public int AgeMin
        {
            set { ageMin = value; }
            get { return ageMin; }
        }

        private int ageMax;
        public int AgeMax
        {
            set { ageMax = value; }
            get { return ageMax; }
        }

        private string description;
        public string Description
        {
            set { description = value; }
            get { return description; }
        }

        public Maladie() { }
        public Maladie(string id, string nom, int cible, int ageMin, int ageMax, string description)
        {
            this.ID = id;
            this.Nom = nom;
            this.Cible = cible;
            this.AgeMin = ageMin;
            this.AgeMax = ageMax;
            this.Description = description;
        }
    }
}
