﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitaires
{
    public class EquationDroite
    {
        public static string LSH_Y = "y";
        public static string LSH_X = "x";

        private double a;
        public double A
        {
            get { return a; }
            set { a = value; }
        }

        private double b;
        public double B
        {
            get { return b; }
            set { b = value; }
        }

        private string lhs;
        public string LHS
        {
            get { return lhs; }
            set { lhs = value; }
        }


        public EquationDroite() { }
        public EquationDroite(double a, double b)
        {
            this.lhs = EquationDroite.LSH_Y;
            this.A = a;
            this.B = b;
        }
        public EquationDroite(double a, double b, string lhs)
        {
            this.lhs = lhs;
            this.A = a;
            this.B = b;
        }

        public override string ToString()
        {
            string result = string.Empty;

            if(this.lhs == EquationDroite.LSH_Y)
                result = "y = " + this.a + " x + " + this.b;

            else
                result = "x = " + this.a + " y + " + this.b;

            return result;
        }



        public static EquationDroite getEquationDroite(Point point1, Point point2)
        {
            double coeffDir = EquationDroite.getCoefficientDirecteur(point1, point2);

            double a = coeffDir;
            double b = point1.Y - (a * point1.X);
            string lhs = EquationDroite.LSH_Y;

            if (coeffDir == 0)
            {
                lhs = EquationDroite.LSH_X;
                b = point1.X;
            }  

            return new EquationDroite(a, b, lhs);
        }

        public static EquationDroite getEquationPerpendiculaire(EquationDroite equation, Point point)
        {
            string lhs = equation.LHS;

            double a = 0;

            if(equation.A == 0)
            {
                a = 0;
                lhs = equation.LHS == EquationDroite.LSH_Y ? EquationDroite.LSH_X : EquationDroite.LSH_Y;
            }
            else
            {
                a = -1 / equation.A;
            }


            double b = point.Y - (a * point.X);

            return new EquationDroite(a, b, lhs);
        }

        public static double getCoefficientDirecteur(Point point1, Point point2)
        {
            double result = 0;
            double numerateur   = point2.Y - point1.Y;
            double denominateur = point2.X - point1.X;

            try
            {
                if (denominateur == 0)
                    throw new Exception("Division par zéro");

                result =  numerateur / denominateur;
            }
            catch
            {
                result = 0;
            }

            return result;
        }
    }
}
