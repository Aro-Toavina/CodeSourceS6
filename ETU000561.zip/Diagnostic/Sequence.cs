﻿using Connect;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitaires
{
    public class Sequence
    {
        public static int GetNextValue(string seqName)
        {
            int result = 0;

            try
            {
                string query = "select val = next value for " + seqName;

                SqlConnection c = Connexion.connect();
                SqlCommand command = new SqlCommand(query, c);
                SqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                    result = reader.GetInt32(0);


                reader.Close();
                command.Dispose();
                c.Close();

            }
            catch (Exception e)
            {
                Console.Write("Erreur: " + e);
                result = -1;
            }
            return result;
        }


        public static int GetCurrentValue(string seqName)
        {
            int result = 0;
            try
            {
                string query = "select cast(current_value as int) as val from sys.sequences where name='" + seqName + "'";

                SqlConnection c = Connexion.connect();
                SqlCommand command = new SqlCommand(query, c);
                SqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                    result = reader.GetInt32(0);


                reader.Close();
                command.Dispose();
                c.Close();

            }
            catch (Exception e)
            {
                Console.Write("Erreur: " + e);
                result = -1;
            }
            return result;
        }

        public static string GetFullNext(string id, string seqName, int length)
        {
            String result = null;
            int value = Sequence.GetNextValue(seqName);

            if (value == -1)
                return result;

            String valueToString = Convert.ToString(value);
            int valueLength = valueToString.Length;

            result = id;
            while (valueLength < length)
            {
                result += "0";
                valueLength++;
            }
            result += valueToString;

            return result;
        }

        public static String GetFullCurrent(String id, String seqName, int length)
        {
            String result = null;
            int value = Sequence.GetCurrentValue(seqName);

            if (value == -1)
                return result;

            String valueToString = Convert.ToString(value);
            int valueLength = valueToString.Length;

            result = id;
            while (valueLength < length)
            {
                result += "0";
                valueLength++;
            }
            result += valueToString;

            return result;
        }
    }
}
