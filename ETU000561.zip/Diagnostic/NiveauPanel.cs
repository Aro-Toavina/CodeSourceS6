﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using Utilitaires;

namespace Diagnostic
{
    public class NiveauPanel : Panel
    {
        private int x;
        public int X
        {
            get { return x; }
            set { x = value; }
        }

        private int y;
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        private int axeLine;
        public int AxeLine
        {
            get { return axeLine; }
            set { axeLine = value; }
        }

        private Niveau niveau;
        public Niveau Niveau
        {
            get { return niveau; }
            set { niveau = value; }
        }

        private bool down;
        public bool Down
        {
            get { return down; }
            set { down = value; }
        }

        private EquationDroite equationAxe;
        public EquationDroite EquationAxe
        {
            get { return equationAxe; }
            set { equationAxe = value; }
        }

        private Point extremite;
        public Point Extremite
        {
            get { return extremite; }
            set { extremite = value; }
        }

        
        public NiveauPanel(){}

        public NiveauPanel(int x, int y, int axeLine, Niveau niveau)
        {
            this.X = x;
            this.Y = y;
            this.AxeLine = axeLine;
            this.Niveau = niveau;

            this.Location = new Point(this.x, this.y);
            this.Width = 50;
            this.Height = 30;
            this.BackColor = Color.Transparent;
            this.down = false;
        }
  

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.DarkBlue), 0, 0, 7, 7);
            g.DrawString(Utilitaire.formatValue(niveau.ActualValue, 2), new Font("Arial", 11), new SolidBrush(Color.DarkBlue), 0 - 3, 5);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (down)
            {      
                Point positionSouris = new Point(e.X + this.x, e.Y + this.y);
                Point pointSurAxe = Utilitaire.getPointSurAxe(this.equationAxe, positionSouris);

                double distancePointCentre    = Utilitaire.getDistance(Constant.CERCLE_CENTRE, pointSurAxe);
                double distancePointExtremite = Utilitaire.getDistance(this.Extremite, pointSurAxe);

                if (distancePointCentre <= Constant.CERCLE_RAYON && distancePointExtremite <= Constant.CERCLE_RAYON)
                {
                    this.x = pointSurAxe.X;
                    this.y = pointSurAxe.Y;
                    this.Location = new Point(this.x - 5, this.y);
                    this.niveau.ActualValue = Utilitaire.getValue(distancePointCentre, this.niveau.MinValue, this.niveau.MaxValue, Constant.CERCLE_RAYON);

                    ((Form1)this.Parent).updateNiveau(this);
                }
                else if(distancePointCentre > Constant.CERCLE_RAYON)
                {
                    this.x = this.Extremite.X;
                    this.y = this.Extremite.Y;
                    this.Location = new Point(this.x - 5, this.y);
                    this.niveau.ActualValue = Utilitaire.getValue(Constant.CERCLE_RAYON, this.niveau.MinValue, this.niveau.MaxValue, Constant.CERCLE_RAYON);

                    ((Form1)this.Parent).updateNiveau(this);
                }  
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;       
        }
    }
}
