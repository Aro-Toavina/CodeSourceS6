﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Utilitaires
{
    public class Constant
    {
        public static int SEQUENCE_LENGTH = 4;

        public static int CERCLE_RAYON = 300;
        public static int CERCLE_DECALAGE_X = 125;
        public static int CERCLE_DECALAGE_Y = 75;
        public static Point CERCLE_CENTRE = new Point(Constant.CERCLE_RAYON + Constant.CERCLE_DECALAGE_X, Constant.CERCLE_RAYON + Constant.CERCLE_DECALAGE_Y);

        public static int CIBLE_TOUS = 0;
        public static int CIBLE_HOMME = 1;
        public static int CIBLE_FEMME = 2;
        public static int CIBLE_ENFANT = 3;

        public static int AGE_ENFANT = 12;
        public static int POURCENT_MARGE_ANORMALE = 25;
    }
}
