﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class AnalyseDetail
    {
        private string analyse;
        public string Analyse
        {
            get { return analyse; }
            set { analyse = value; }
        }

        private string maladie;
        public string Maladie
        {
            get { return maladie; }
            set { maladie = value; }
        }

        private double pourcentage;
        public double Pourcentage
        {
            get { return pourcentage; }
            set { pourcentage = value; }
        }

        public AnalyseDetail() { }
        public AnalyseDetail(string analyse, string maladie, double pourcentage)
        {
            this.Analyse = analyse;
            this.Maladie = maladie;
            this.Pourcentage = pourcentage;
        }
    }
}
