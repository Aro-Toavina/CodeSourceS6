﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class CritereDAO
    {
        public Critere[] find(string condition, string table)
        {
            Critere[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public Critere[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "Critere";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<Critere> list = new List<Critere>();

            while (reader.Read())
                list.Add(new Critere(reader.GetByte(0), reader.GetString(1), reader.GetString(2), (double)reader.GetDecimal(3), (double)reader.GetDecimal(4)));


            reader.Close();
            command.Dispose();

            return list.ToArray();
        }
    }
}
