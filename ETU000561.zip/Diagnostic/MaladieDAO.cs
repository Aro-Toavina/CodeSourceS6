﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class MaladieDAO
    {
        public Maladie[] find(string condition, string table)
        {
            Maladie[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public Maladie[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "Maladie";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<Maladie> list = new List<Maladie>();

            while (reader.Read())
                list.Add(new Maladie(reader.GetString(0), reader.GetString(1), reader.GetByte(2), reader.GetByte(3), reader.GetByte(4), reader.GetString(5)));

            reader.Close();
            command.Dispose();

            return list.ToArray();
        }
    }
}
