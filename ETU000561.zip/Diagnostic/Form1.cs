﻿using DAO;
using Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utilitaires;

namespace Diagnostic
{
    public partial class Form1 : Form
    {
        List<Point> pointsExtremites;
        List<Point> pointsMilieu;
        List<Point> pointsValeurs;
        List<NiveauPanel> niveaux;
        List<Resultat> diagnostics;
       
        public Form1()
        {
            initListNiveauPanel();
            initPoints();
            InitializeComponent();
            initSexe();
            initNiveaux();

            diagnostics = new List<Resultat>();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int indexNext = 1;

            drawPolygon(g);
            drawNormalCircle(g);

            for(int i = 0; i < niveaux.Count; i++)
            {
                drawAxe(g, pointsExtremites[i], Constant.CERCLE_CENTRE);
                drawLibelle(niveaux[i].Niveau.Libelle, niveaux[i].Niveau.Unite, g, pointsExtremites[i]);

                indexNext++;

                if (indexNext == niveaux.Count)
                    indexNext = 0;       
            }
        }

        void drawNormalCircle(Graphics g)
        {
            g.DrawEllipse(new Pen(Color.LightGray, 2), Constant.CERCLE_DECALAGE_X + Constant.CERCLE_RAYON / 2, Constant.CERCLE_DECALAGE_Y + Constant.CERCLE_RAYON / 2, Constant.CERCLE_RAYON, Constant.CERCLE_RAYON);
            g.DrawEllipse(new Pen(Color.LightGray, 2), Constant.CERCLE_DECALAGE_X, Constant.CERCLE_DECALAGE_Y, Constant.CERCLE_RAYON * 2, Constant.CERCLE_RAYON * 2);
        }

        void drawPolygon(Graphics g)
        {
            g.FillPolygon(new SolidBrush(Color.FromArgb(0, 152, 220)), this.pointsValeurs.ToArray());
        }
        void drawConnector(Graphics g, Point final, Point initial)
        {
            g.DrawLine(new Pen(Color.Blue, 1), final, initial);
        }
        void drawAxe(Graphics g, Point final, Point initial)
        {
            g.DrawLine(new Pen(Color.Black, 1), final, Constant.CERCLE_CENTRE);
        }
        void drawLibelle(string libelle, string unite, Graphics g, Point position)
        {
            g.DrawString(libelle + " (" + unite + ")", new Font("Arial", 10), new SolidBrush(Color.Black), position.X + (position.X < Constant.CERCLE_RAYON ? -75 : 0), position.Y + (position.Y > Constant.CERCLE_RAYON ? 5 : -25));
        }

        private void initSexe()
        {
            this.sexe.Items.Add("Homme");
            this.sexe.Items.Add("Femme");
            this.sexe.SelectedIndex = 0;
        }

        private void initNiveaux()
        {
            for(int i = 0; i < niveaux.Count; i++)
            {
                this.Controls.Add(niveaux[i]);
            }
        }

        private void initPoints()
        {
            pointsExtremites = new List<Point>();
            pointsMilieu = new List<Point>();
            pointsValeurs = new List<Point>();

            int x = 0;
            int y = 0;
            double angle = 0;
            Point point;
            Point milieu;

            for (int i = 0; i < niveaux.Count; i++)
            {
                angle = (2 * Math.PI / niveaux.Count) * i;
                x = (int)(Constant.CERCLE_RAYON * (1 + Math.Sin(angle)));
                y = (int)(Constant.CERCLE_RAYON * (1 - Math.Cos(angle)));

                point  = new Point(x + Constant.CERCLE_DECALAGE_X, y + Constant.CERCLE_DECALAGE_Y);
                milieu = Utilitaire.getCenter(Constant.CERCLE_CENTRE, point);

                pointsExtremites.Add(point);
                pointsMilieu.Add(milieu);
                pointsValeurs.Add(milieu);

                niveaux[i].X = milieu.X;
                niveaux[i].Y = milieu.Y;
                niveaux[i].Extremite = point;       
                niveaux[i].EquationAxe = EquationDroite.getEquationDroite(Constant.CERCLE_CENTRE, point);
                niveaux[i].Location = new Point(milieu.X - 5, milieu.Y);
            }
        }

        private void initListNiveauPanel()
        {
            niveaux = new List<NiveauPanel>();

            Critere[] criteres = new CritereDAO().find("", "");

            for(int i = 0; i < criteres.Count(); i++)
            {
                niveaux.Add(new NiveauPanel(0, 0, i + 1, new Niveau(criteres[i].Libelle, criteres[i].Unite, criteres[i].MinVal, criteres[i].MaxVal, Utilitaire.getNormalValue(i + 1, criteres[i].MinVal, criteres[i].MaxVal))));
            }                  
        }

        public void updateNiveau(NiveauPanel changed)
        {
            this.pointsValeurs[changed.AxeLine - 1] = new Point(changed.X, changed.Y);
            this.Refresh();
        }

        public void reinitialiserNiveauPosition()
        {
            for(int i = 0; i < niveaux.Count; i++)
            {
                niveaux[i].X = pointsMilieu[i].X;
                niveaux[i].Y = pointsMilieu[i].Y;
                niveaux[i].Niveau.ActualValue = (niveaux[i].Niveau.MaxValue + niveaux[i].Niveau.MinValue) / 2;
                niveaux[i].Location = new Point(pointsMilieu[i].X - 5, pointsMilieu[i].Y);
                pointsValeurs[i] = new Point(pointsMilieu[i].X, pointsMilieu[i].Y);
            }
        }

        public void updateDiagnostics()
        {
            try
            {
                if (age.Text.Length == 0)
                    throw new Exception("Veuillez spécifier l'âge");

                if (poids.Text.Length == 0)
                    throw new Exception("Veuillez spécifier le poids");

                this.diagnostics = new Fonctions().getDiagnostic(Utilitaire.getListValeurs(this.niveaux), sexe.Text, age.Text);

                diagnosticGrid.Rows.Clear();

                foreach (Resultat resultat in diagnostics)
                {
                    diagnosticGrid.Rows.Add(resultat.Maladie.Nom, Utilitaire.formatValue(resultat.Pourcentage, 2) + "%");
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            reinitialiserNiveauPosition();
            diagnosticGrid.Rows.Clear();
            this.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.updateDiagnostics();
        }

        private void save_Click(object sender, EventArgs e)
        {
            try
            {
                int result = new Fonctions().saveAnalyse(diagnostics, niveaux, personne.Text, sexe.Text, age.Text, poids.Text);

                if (result != 0)
                    MessageBox.Show("Analyse insérée avec succès!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
