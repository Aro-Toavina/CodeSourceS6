﻿using Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class Resultat
    {
        private Maladie maladie;
        public Maladie Maladie
        {
            set { maladie = value; }
            get { return maladie; }
        }

        private double pourcentage;
        public double Pourcentage
        {
            set { pourcentage = value; }
            get { return pourcentage; }
        }


        public Resultat() { }
        public Resultat(Maladie maladie, double pourcentage)
        {
            this.Maladie = maladie;
            this.Pourcentage = pourcentage;
        }
    }
}
