﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitaires;
using Utilitaires;

namespace DAO
{
    public class AnalyseDAO
    {
        public Analyse[] find(string condition, string table)
        {
            Analyse[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public Analyse[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "Analyse";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<Analyse> list = new List<Analyse>();

            while (reader.Read())
                list.Add(new Analyse(reader.GetString(0), reader.GetDateTime(1), reader.GetString(2), reader.GetByte(3), reader.GetByte(4), reader.GetByte(5)));


            reader.Close();
            command.Dispose();

            return list.ToArray();
        }

        public int insert(Analyse el)
        {
            int result = 0;
            SqlConnection connect = Connexion.connect();

            result = insert(el, connect);

            connect.Close();
            return result;
        }

        public int insert(Analyse el, SqlConnection connect)
        {
            int result = 0;

            el.ID = Sequence.GetFullNext(Analyse.IdSequence, Analyse.NameSequence, Constant.SEQUENCE_LENGTH);

            string query = "insert into Analyse values('" + el.ID + "', '" + el.Date + "', '" + el.Personne + "', " + el.Sexe + ", " + el.Age + ", " + el.Poids + ")";

            SqlCommand command = new SqlCommand(query, connect);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }
    }
}
