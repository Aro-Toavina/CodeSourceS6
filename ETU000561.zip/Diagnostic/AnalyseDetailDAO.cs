﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitaires;

namespace DAO
{
    public class AnalyseDetailDAO
    {
        public AnalyseDetail[] find(string condition, string table)
        {
            AnalyseDetail[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public AnalyseDetail[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "AnalyseDetail";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<AnalyseDetail> list = new List<AnalyseDetail>();

            while (reader.Read())
                list.Add(new AnalyseDetail(reader.GetString(0), reader.GetString(1), (double)reader.GetDecimal(2)));


            reader.Close();
            command.Dispose();

            return list.ToArray();
        }

        public int insert(AnalyseDetail el)
        {
            int result = 0;
            SqlConnection connect = Connexion.connect();

            result = insert(el, connect);

            connect.Close();
            return result;
        }

        public int insert(AnalyseDetail el, SqlConnection connect)
        {
            int result = 0;

            string query = "insert into AnalyseDetail values('" + el.Analyse + "', '" + el.Maladie + "', " + Utilitaire.formatValue(el.Pourcentage, 2).Replace(',','.') + ")";

            SqlCommand command = new SqlCommand(query, connect);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }
    }
}
