﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class ValeurNormale
    {
        private int critere;
        public int Critere
        {
            set { critere = value; }
            get { return critere; }
        }

        private int cible;
        public int Cible
        {
            set { cible = value; }
            get { return cible; }
        }

        private double minVal;
        public double MinVal
        {
            set { minVal = value; }
            get { return minVal; }
        }

        private double maxVal;
        public double MaxVal
        {
            set { maxVal = value; }
            get { return maxVal; }
        }


        public ValeurNormale() { }
        public ValeurNormale(int critere, int cible, double minVal, double maxVal)
        {
            this.Critere = critere;
            this.Cible = cible;
            this.MinVal = minVal;
            this.MaxVal = maxVal;
        }
    }
}
