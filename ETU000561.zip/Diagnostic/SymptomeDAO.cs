﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class SymptomeDAO
    {
        public Symptome[] find(string condition, string table)
        {
            Symptome[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public Symptome[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "Symptome";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<Symptome> list = new List<Symptome>();

            while (reader.Read())
                list.Add(new Symptome(reader.GetString(0), reader.GetByte(1), reader.GetByte(2), (double)reader.GetDecimal(3), (double)reader.GetDecimal(4), reader.GetString(5)));

            reader.Close();
            command.Dispose();

            return list.ToArray();
        }
    }
}
