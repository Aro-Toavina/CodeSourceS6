﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class Critere
    {
        private int id;
        public int ID
        {
            set { id = value; }
            get { return id; }
        }

        private string libelle;
        public string Libelle
        {
            set { libelle = value; }
            get { return libelle; }
        }

        private string unite;
        public string Unite
        {
            set { unite = value; }
            get { return unite; }
        }

        private double minVal;
        public double MinVal
        {
            set { minVal = value; }
            get { return minVal; }
        }

        private double maxVal;
        public double MaxVal
        {
            set { maxVal = value; }
            get { return maxVal; }
        }



        public Critere() { }
        public Critere(int id, string libelle, string unite, double minVal, double maxVal)
        {
            this.ID = id;
            this.Libelle = libelle;
            this.Unite = unite;
            this.MinVal = minVal;
            this.MaxVal = maxVal;
        }
    }
}
