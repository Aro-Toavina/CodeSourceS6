﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitaires;

namespace DAO
{
    public class AnalyseDetailAxeDAO
    {
        public AnalyseDetailAxe[] find(string condition, string table)
        {
            AnalyseDetailAxe[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public AnalyseDetailAxe[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "AnalyseDetailAxe";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<AnalyseDetailAxe> list = new List<AnalyseDetailAxe>();

            while (reader.Read())
                list.Add(new AnalyseDetailAxe(reader.GetString(0), reader.GetByte(1), (double)reader.GetDecimal(2)));


            reader.Close();
            command.Dispose();

            return list.ToArray();
        }

        public int insert(AnalyseDetailAxe el)
        {
            int result = 0;
            SqlConnection connect = Connexion.connect();

            result = insert(el, connect);

            connect.Close();
            return result;
        }

        public int insert(AnalyseDetailAxe el, SqlConnection connect)
        {
            int result = 0;

            string query = "insert into AnalyseDetailAxe values('" + el.Analyse + "', " + el.Critere + ", " + Utilitaire.formatValue(el.Valeur, 2).Replace(',', '.') + ")";

            SqlCommand command = new SqlCommand(query, connect);

            result = command.ExecuteNonQuery();
            command.Dispose();

            return result;
        }
    }
}
