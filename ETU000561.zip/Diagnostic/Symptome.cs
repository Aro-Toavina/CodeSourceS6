﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class Symptome
    {
        private string maladie;
        public string Maladie
        {
            set { maladie = value; }
            get { return maladie; }
        }

        private int critere;
        public int Critere
        {
            set { critere = value; }
            get { return critere; }
        }

        private int cible;
        public int Cible
        {
            set { cible = value; }
            get { return cible; }
        }

        private double minVal;
        public double MinVal
        {
            set { minVal = value; }
            get { return minVal; }
        }

        private double maxVal;
        public double MaxVal
        {
            set { maxVal = value; }
            get { return maxVal; }
        }

        private string remarque;
        public string Remarque
        {
            set { remarque = value; }
            get { return remarque; }
        }


        public Symptome() { }
        public Symptome(string maladie, int critere, int cible, double minVal, double maxVal, string remarque)
        {
            this.Maladie = maladie;
            this.Critere = critere;
            this.Cible = cible;
            this.MinVal = minVal;
            this.MaxVal = maxVal;
            this.Remarque = remarque;
        }
    }
}
