﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapping
{
    public class AnalyseDetailAxe
    {
        private string analyse;
        public string Analyse
        {
            get { return analyse; }
            set { analyse = value; }
        }

        private int critere;
        public int Critere
        {
            get { return critere; }
            set { critere = value; }
        }

        private double valeur;
        public double Valeur
        {
            get { return valeur; }
            set { valeur = value; }
        }


        public AnalyseDetailAxe() { }
        public AnalyseDetailAxe(string analyse, int critere, double valeur)
        {
            this.Analyse = analyse;
            this.Critere = critere;
            this.Valeur = valeur;
        }
    }
}
