﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnostic
{
    public class Niveau
    {
        private string libelle;
        public string Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }

        private string unite;
        public string Unite
        {
            get { return unite; }
            set {unite = value; }
        }

        private double minValue;
        public double MinValue
        {
            get { return minValue; }
            set { minValue = value; }
        }

        private double maxValue;
        public double MaxValue
        {
            get { return maxValue; }
            set { maxValue = value; }
        }

        private double actualValue;
        public double ActualValue
        {
            get { return actualValue; }
            set { actualValue = value; }
        }

        public Niveau(){}

        public Niveau(string libelle, string unite, double minValue, double maxValue, double actualValue)
        {
            this.Libelle = libelle;
            this.Unite = unite;
            this.MinValue = minValue;
            this.MaxValue = maxValue;
            this.ActualValue = actualValue;
        }
    }
}
