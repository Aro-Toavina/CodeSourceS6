﻿using Connect;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class ValeurNormaleDAO
    {
        public ValeurNormale[] find(string condition, string table)
        {
            ValeurNormale[] result = null;
            SqlConnection connection = Connexion.connect();

            result = find(condition, table, connection);

            connection.Close();

            return result;
        }

        public ValeurNormale[] find(string condition, string table, SqlConnection connect)
        {
            if (table.Equals(""))
                table = "ValeurNormale";

            string query = "select * from " + table + " " + condition;

            SqlCommand command = new SqlCommand(query, connect);
            SqlDataReader reader = command.ExecuteReader();

            List<ValeurNormale> list = new List<ValeurNormale>();

            while (reader.Read())
                list.Add(new ValeurNormale(reader.GetByte(0), reader.GetByte(1), (double)reader.GetDecimal(2), (double)reader.GetDecimal(3)));


            reader.Close();
            command.Dispose();

            return list.ToArray();
        }
    }
}
