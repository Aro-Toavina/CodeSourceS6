﻿using Connect;
using DAO;
using Mapping;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utilitaires;

namespace Diagnostic
{
    public class Fonctions
    {
        public List<Resultat> getDiagnostic(List<double> valeurs, string sexe, string age)
        {
            List<Resultat> result = new List<Resultat>();
            SqlConnection connection = null;

            try
            {
                int iSexe = sexe.Equals("Homme") ? Constant.CIBLE_HOMME : Constant.CIBLE_FEMME;
                int iAge = Convert.ToInt32(age);

                connection = Connexion.connect();

                Dictionary<int, double> axesAnormales = this.getAnormalValues(valeurs, iSexe, iAge, connection);

                if(axesAnormales.Count > 0)
                {
                    int cible = iAge <= Constant.AGE_ENFANT ? Constant.CIBLE_ENFANT : iSexe;
                    Maladie[] maladiesConcernes = getMaladiesConcernes(axesAnormales, connection);
                    List<Maladie> maladiesPossibles = filteCibleAge(maladiesConcernes, iAge, iSexe);

                    SymptomeDAO sDAO = new SymptomeDAO();
                    Symptome[] symptomesMaladies = null;
                    Dictionary<int, double> symptomesIn = null;
                    double pourcentage = 0;

                    foreach (Maladie maladie in maladiesPossibles)
                    {
                        symptomesMaladies = sDAO.find("where IDMaladie = '" + maladie.ID + "' and (Cible = 0 or Cible = " + cible + ")", "");

                        symptomesIn =  getSymptomesIn(axesAnormales, symptomesMaladies);

                        pourcentage = getTotalPourcentage(maladie, symptomesIn, symptomesMaladies);

                        if(pourcentage > 0)
                            result.Add(new Resultat(maladie, pourcentage));          
                    }

                    result = result.OrderByDescending(element => element.Pourcentage).ToList();
                }        
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }

            return result;
        }

        public Dictionary<int, double> getAnormalValues(List<double> valeurs, int sexe, int age, SqlConnection connection)
        {
            Dictionary<int, double> anormales = new Dictionary<int, double>();

            int _sexe = age <= Constant.AGE_ENFANT ? Constant.CIBLE_ENFANT : sexe;
            
            ValeurNormaleDAO vDAO = new ValeurNormaleDAO();
            ValeurNormale[] _normale = null;
            double valueAtLimitMin = 0;
            double valueAtLimitMax = 0;

            for (int i = 0; i < valeurs.Count; i++)
            {
                _normale = vDAO.find("where IDCritere = " + (i + 1) + " and (Cible = 0 or Cible = " + _sexe + ")", "", connection);

                valueAtLimitMin = Utilitaire.getValueAtPercent(Constant.POURCENT_MARGE_ANORMALE, _normale[0].MinVal, _normale[0].MaxVal);
                valueAtLimitMax = Utilitaire.getValueAtPercent(100 - Constant.POURCENT_MARGE_ANORMALE, _normale[0].MinVal, _normale[0].MaxVal);

                if (valeurs[i] < valueAtLimitMin || valeurs[i] > valueAtLimitMax)
                {
                    anormales.Add(i + 1, valeurs[i]);
                }
            }

            return anormales;
        }

        public Maladie[] getMaladiesConcernes(Dictionary<int, double> axesAnormales, SqlConnection connection)
        {
            List<string> listIDMaladies = getIDMaladiesConcernes(axesAnormales, connection);

            if (listIDMaladies.Count == 0)
                return new Maladie[0];

            return new MaladieDAO().find("where ID in " + Utilitaire.getListSql(listIDMaladies), "", connection);
        }

        public List<string> getIDMaladiesConcernes(Dictionary<int, double> axesAnormales, SqlConnection connection)
        {
            string query = "select distinct(IDMaladie), CAST(0 as tinyint) as IDCritere, CAST(0 AS tinyint) as Cible, CAST(0 AS decimal(8, 2)) as MinVal, CAST(0 AS decimal(8, 2)) as MaxVal, '' as Remarque from Symptome where IDCritere in " + Utilitaire.getSqlList(axesAnormales);

            Symptome[] listDistinct = new SymptomeDAO().find("", "(" + query + ") t1", connection);

            List<string> result = new List<string>();

            foreach(Symptome symptome in listDistinct)
            {
                result.Add(symptome.Maladie);
            }

            return result;
        }

        public List<Maladie> filteCibleAge(Maladie[] maladies, int age, int sexe)
        {
            List<Maladie> result = new List<Maladie>();
            int cible = age <= Constant.AGE_ENFANT ? Constant.CIBLE_ENFANT : sexe;

            foreach (Maladie maladie in maladies)
            {
                if (maladie.Cible != Constant.CIBLE_TOUS)
                {
                    if (maladie.Cible != cible)
                        continue;
                }

                if (maladie.AgeMin != 0 || maladie.AgeMax != 0)
                {
                    if (maladie.AgeMax > 0)
                    {
                        if (age < maladie.AgeMin || age > maladie.AgeMax)
                            continue;
                    }
                    else
                    {
                        if (age < maladie.AgeMin)
                            continue;
                    }
                }

                result.Add(maladie);
            }

            return result;
        }
         
        public Dictionary<int, double> getSymptomesIn(Dictionary<int, double> anormales, Symptome[] symptomesMaladies)
        {
            Dictionary<int, double> result = new Dictionary<int, double>();

            foreach(KeyValuePair<int, double> entry in anormales)
            {
                foreach(Symptome symptome in symptomesMaladies)
                {
                    if (entry.Key == symptome.Critere)
                        result.Add(entry.Key, entry.Value);
                }
            }

            return result;
        }

        public double getTotalPourcentage(Maladie maladie, Dictionary<int, double> symptomesIn, Symptome[] symptomesTotal)
        {
            List<double> pourcentageAxe = new List<double>();

            foreach(KeyValuePair<int, double> entry in symptomesIn)
            {
                foreach(Symptome symptome in symptomesTotal)
                {
                    if(entry.Key == symptome.Critere)
                    {
                        pourcentageAxe.Add(getPourcentage(entry.Value, symptome));
                    }
                }
            }

            return Utilitaire.getMoyenne(pourcentageAxe, symptomesTotal.Length);
        }

        public double getPourcentage(double valeur, Symptome symptome)
        {
            double centre = (symptome.MaxVal + symptome.MinVal) / 2;
            double pourcent = 100 - Constant.POURCENT_MARGE_ANORMALE;
            double distanceCentreValeur = Math.Abs(centre - valeur);
            double distanceCentreMin = Math.Abs(centre - symptome.MinVal);

            double numerateur = pourcent * distanceCentreValeur;
            double resultat = 100 - (numerateur / distanceCentreMin);

            return resultat;
        }

        public int saveAnalyse(List<Resultat> resultats, List<NiveauPanel> niveaux, string personne, string sexe, string age, string poids)
        {
            if (personne.Length == 0)
                throw new Exception("Veuillez spécifier le nom");

            int iSexe = sexe.Equals("Homme") ? Constant.CIBLE_HOMME : Constant.CIBLE_FEMME;
            int iAge = Convert.ToInt16(age);
            int iPoids = (int)Convert.ToDouble(poids);

            return saveAnalyse(resultats, niveaux, personne, iSexe, iAge, iPoids);
        }

        public int saveAnalyse(List<Resultat> resultats, List<NiveauPanel> niveaux, string personne, int sexe, int age, int poids)
        {
            try
            {
                SqlConnection connection = Connexion.connect();   

                Analyse analyse = new Analyse("", DateTime.Now, personne, sexe, age, poids);

                int ins = new AnalyseDAO().insert(analyse, connection);

                if (ins == 0)
                    throw new Exception("Echec lors de l'insertion de l'analyse");

                AnalyseDetailDAO adDAO = new AnalyseDetailDAO();
                AnalyseDetail detail = null;
                AnalyseDetailAxeDAO axDAO = new AnalyseDetailAxeDAO();
                AnalyseDetailAxe axe = null;

                foreach(Resultat resultat in resultats)
                {
                    detail = new AnalyseDetail(analyse.ID, resultat.Maladie.ID, resultat.Pourcentage);

                    ins = adDAO.insert(detail, connection);
                    if (ins == 0)
                        throw new Exception("Echec lors de l'insertion de l'analyse détail");               
                }

                foreach (NiveauPanel niveau in niveaux)
                {
                    axe = new AnalyseDetailAxe(analyse.ID, niveau.AxeLine, niveau.Niveau.ActualValue);

                    ins = axDAO.insert(axe, connection);
                    if (ins == 0)
                        throw new Exception("Echec lors de l'insertion de l'analyse détail axe");
                }
            }
            catch(Exception e)
            {
                throw e;
            }

            return resultats.Count;
        }
    }
}
