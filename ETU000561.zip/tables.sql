create table Critere(
	ID tinyint primary key,
	Libelle varchar(50),
	Unite varchar(15),
	MinVal decimal(8, 2),
	MaxVal decimal(8, 2)
);

create table ValeurNormale(
	IDCritere tinyint,
	Cible tinyint,
	MinVal decimal(8, 2),
	MaxVal decimal(8, 2),
	foreign key(IDCritere) references Critere(ID)
);

create table Maladie(
	ID varchar(10) primary key,
	Nom varchar(50),
	Cible tinyint,
	AgeMin tinyint,
	AgeMax tinyint,
	Description varchar(255)
);

create table Symptome(
	IDMaladie varchar(10),
	IDCritere tinyint,
	Cible tinyint,
	MinVal decimal(8, 2),
	MaxVal decimal(8, 2),
	Remarque varchar(1000),
	foreign key (IDMaladie) references Maladie(ID),
	foreign key (IDCritere) references Critere(ID)
);

create table Analyse(
	ID varchar(10) primary key,
	Date datetime,
	Personne varchar(25),
	Sexe tinyint,
	Age tinyint,
	Poids tinyint
);

create table AnalyseDetail(
	IDAnalyse varchar(10),
	IDMaladie varchar(10),
	Pourcentage decimal(5, 2),
	foreign key(IDAnalyse) references Analyse(ID),
	foreign key(IDMaladie) references Maladie(ID)
);


create table AnalyseDetailAxe(
	IDAnalyse varchar(10),
	IDCritere tinyint,
	Valeur decimal(8, 2),
	foreign key(IDAnalyse) references Analyse(ID),
	foreign key(IDCritere) references Critere(ID)

);