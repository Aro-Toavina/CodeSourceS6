﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataPrediction
{
    class SymptomDAO
    {

        public List<Symptom> findSymptom(String condition)
        {
            List<Symptom> liste = new List<Symptom>();
            SqlCommand sqlcom;
            String sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select * from Symptoms where 1<2 " + condition;
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    liste.Add(new Symptom(myread["id"].ToString(), myread["iddisease"].ToString(), myread["idaxe"].ToString(), Convert.ToChar(myread["sexe"].ToString()), Convert.ToDouble(myread["minAge"].ToString()),Convert.ToDouble(myread["maxAge"].ToString()), Convert.ToDouble(myread["minValue"].ToString()),Convert.ToDouble(myread["maxValue"].ToString())));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Symptom" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
    }
}
