﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPrediction
{
    class Disease
    {
        private string id;
        private string name;
        private double pourcentage;
        public Disease()
        {
        }
        public Disease(string id, string name)
        {
            setId(id);
            setName(name);
        }
        public Disease(string id)
        {
            setId(id);
        }
        public Disease(string id, string name,double pourcentage)
        {
            setId(id);
            setName(name);
            setPourcentage(pourcentage);
        }
        // GETTERS
        public string getId()
        {
            return id;
        }
        public string getName()
        {
            return name;
        }
        public double getPourcentage()
        {
            return pourcentage;
        }

        // SETTERS

        public void setId(string id)
        {
            this.id = id;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public void setPourcentage(double pourcentage)
        {
            this.pourcentage = pourcentage;
        }
    }
}
