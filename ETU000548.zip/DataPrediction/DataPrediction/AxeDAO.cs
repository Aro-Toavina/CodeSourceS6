﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataPrediction
{
    class AxeDAO
    {

        public List<Axe> selectionAxe(String condition)
        {
            List<Axe> liste = new List<Axe>();
            SqlCommand sqlcom;
            String sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select * from axes " + condition;
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    double min = Convert.ToDouble(myread.GetDecimal(3));
                    double max = Convert.ToDouble(myread.GetDecimal(4));
                  
                    liste.Add(new Axe(myread.GetString(0),myread.GetString(1), myread.GetString(2),min,max,max));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Axe" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
    }
}
