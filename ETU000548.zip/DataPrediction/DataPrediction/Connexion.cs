﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPrediction
{
    class Connexion
    {
        public SqlConnection connect() //throw Exception
        {
            SqlConnection connection = null;
            string connectionString = null;

            connectionString = "Data Source=TSIKY;Initial Catalog=dataprediction;User ID=sa;Password=tsiky03";
            connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }
    }
}
