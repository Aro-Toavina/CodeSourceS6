﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataPrediction
{
    public partial class Form1 : Form
    {
        private Point centreGraph;
        private int rayon;
        private int ajustementX =100;
        private int ajustementY = 25;       
        private List<Point> sommet;
        private List<DotsPanel> listeDotsPanel;
        private List<Axe> listeAxe;
        private List<Equation> listeEquation;
        private int nombreInformation;
        public Form1()
        {
            InitializeComponent();
            initListeAxe();
            initAll();
            initNiveau();
            button1.Hide();
            /*  foreach(Equation eq in listeEquation)
            {
                MessageBox.Show(eq.getA()+" et "+eq.getB());
            }*/
        }

        //INITIALISATION
        private void initAll()
        {
            rayon = 280;
            centreGraph = new Point(rayon + ajustementX, rayon + ajustementY);
            listeDotsPanel = new List<DotsPanel>();
            listeEquation = new List<Equation>();
            sommet = new List<Point>();
            Fonction fonction = new Fonction();
            
            double radian = 2 * Math.PI / nombreInformation;
            double angle = 0;
            for (int i = 0; i < nombreInformation; i++)
            {
                angle = radian * i;
                int x = (int)(rayon * (1 + Math.Sin(angle)));
                int y = (int)(rayon * (1 - Math.Cos(angle)));
                Point point2 = new Point(x + ajustementX, y + ajustementY);
                listeDotsPanel.Add(new DotsPanel(point2.X, point2.Y, i, listeAxe[i]));
                sommet.Add(point2);
                // Initialize equation : y = mx+p
                Equation equation = fonction.getEquationDroite(centreGraph, point2);

                listeEquation.Add(equation);
            }
        }

        private void initListeAxe()
        {
            AxeDAO axedao = new AxeDAO();
            listeAxe = axedao.selectionAxe("");
            nombreInformation = listeAxe.Count();
           /* listeAxe = new List<Axe>();
            listeAxe.Add(new Axe("Globule Blanc1", "unit", 0, 45, 45));
            listeAxe.Add(new Axe("Globule Blanc2", "Mg2", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc3", "Mg", 10, 20, 20));
            listeAxe.Add(new Axe("Globule Blanc4", "Mg", 0, 90, 90));
            listeAxe.Add(new Axe("Globule Blanc5", "Mg6", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc6", "Mg", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc7", "Mg", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc8", "Mg", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc9", "Mg8", 50, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc10", "Mg9", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc11", "Mg6", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc12", "Mg", 20, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc13", "Mg87", 0, 100, 100));
            listeAxe.Add(new Axe("Globule Blanc14", "Mg1", 0, 100, 100));*/
        }

        private void initNiveau()
        {
            for (int i = 0; i < listeDotsPanel.Count; i++)
            {
                graph_pan.Controls.Add(listeDotsPanel[i]);
            }
        }
        //FONCTION
        private void Form1_Load(object sender, EventArgs e)
        {
            //sexe_cmb.Items.Add("Enfant");
            sexe_cmb.Items.Add("Femme");
            sexe_cmb.Items.Add("Homme");
            sexe_lab.Text = sexe_cmb.Text;

            for(int i = 0; i < 130; i++)
            {
                age_cmb.Items.Add(i);
            }
            age_lab.Text = age_cmb.Text;
        }
        private void graph_pan_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Draw Polygone
            drawPolygoneLimit(g);
            drawPolygone(g);

            // Draw Line
            for (int i = 0; i < sommet.Count; i++)
            {
                drawLine(g, sommet[i]);
                g.DrawString(listeDotsPanel[i].getAxe().getLibelle().ToString()+":"+ listeDotsPanel[i].getAxe().getUnite().ToString(), new Font("Arial", 10), new SolidBrush(Color.Black), sommet[i].X - 25, sommet[i].Y - 25);
            }
        }
        private void drawLine(Graphics g, Point point2)
        {
            Pen p = new Pen(Color.Black, 2);
            g.DrawLine(p, centreGraph, point2);
        }
        public void drawPolygone(Graphics g)
        {
            SolidBrush blueBrush = new SolidBrush(Color.MistyRose);
            Point[] allPoint = new Point[nombreInformation];
            for (int i = 0; i < listeDotsPanel.Count; i++)
            {
                allPoint[i] = new Point(listeDotsPanel[i].getX(), listeDotsPanel[i].getY());
            }
           // Pen p = new Pen(Color.Chocolate, 2);
           // g.DrawPolygon(p, allPoint);
           g.FillPolygon(blueBrush, allPoint);
        }

        private void drawPolygoneLimit(Graphics g)
        {
            SolidBrush blueBrush = new SolidBrush(Color.Gainsboro);
            Point[] allPoint = new Point[nombreInformation];
            for (int i = 0; i < sommet.Count; i++)
            {
                allPoint[i] = new Point(sommet[i].X, sommet[i].Y);
            }
            g.FillPolygon(blueBrush, allPoint);
        }


        //GETTERS
        public Point getPointCentre()
        {
            return this.centreGraph;
        }

        public List<Equation> getListeEquation()
        {
            return this.listeEquation;
        }

        public int getAjustementX()
        {
            return this.ajustementX;
        }

        public int getAjustementY()
        {
            return this.ajustementY;
        }

        public List<Point> getSommet()
        {
            return this.sommet;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NormalValueDAO ndao = new NormalValueDAO();
            char s= sexe_lab.Text[0];
            if (s != 'F' && s != 'M')
                s = 'A';
            MessageBox.Show(s+"");
            List<NormalValue> ln=ndao.findNormalValue(s,Convert.ToDouble(age_lab.Text));
            // MessageBox.Show("capacité= "+ln.Count);


            this.listeDotsPanel[0].getAxe().setCurrValue(10);
            this.listeDotsPanel[0].setX(10);
            this.listeDotsPanel[0].setY(10);
           // this.sommet[0] = new Point(10, 10);
            MessageBox.Show(" Test capacité= " + ln.Count+" et "+ listeDotsPanel[0].getAxe().getLibelle());
            this.Refresh();
        }

        private void sexe_lab_Click(object sender, EventArgs e)
        {

        }

        private void sexe_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            sexe_lab.Text = sexe_cmb.Text;
        }

        private void age_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            age_lab.Text = age_cmb.Text;
        }
        private void age_num_ValueChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                Connexion con = new Connexion();
                SqlConnection conn=con.connect();

                List<Symptom> listSymptomes = new List<Symptom>();
                List<DotsPanel> axesanormale = new List<DotsPanel>();
                List<Disease> listmaladies = new List<Disease>();
                List<NormalValue> ln = new List<NormalValue>();

                NormalValueDAO ndao = new NormalValueDAO();
                DiseaseDAO ddao = new DiseaseDAO();
                SymptomDAO sdao = new SymptomDAO();
                listSymptomes = sdao.findSymptom("");

                //Listes des Valeurs Normales
                try
                {
                    char s = sexe_lab.Text[0];
                    ln = ndao.findNormalValue(s, Convert.ToDouble(age_lab.Text));
                }
                catch (Exception ex)
                {
                    throw new Exception("Veuillez choisir les Propriétés ages et sexe!");
                }

                //Listes les axes anormales
                foreach (DotsPanel dot in listeDotsPanel)
                {
                    foreach (NormalValue lnn in ln)
                    {
                        if (lnn.getIdaxe() == dot.getAxe().getId())
                        {
                            if (dot.getAxe().getCurrValue() > lnn.getMaxValue() || dot.getAxe().getCurrValue() < lnn.getMinValue())
                            {
                                axesanormale.Add(dot);
                            }
                        }
                    }

                }

                //Prend la liste les id maladies
                string requete = "";
                foreach (DotsPanel data in axesanormale)
                {
                    requete = requete + " or idaxe='" + data.getAxe().getId() + "'";
                }
                requete = requete.Remove(0, 3);
                requete = " and " + requete;
                listmaladies = ddao.findIdDiseaseAnormal(requete);

                foreach (Disease d in listmaladies)
                {
                    foreach (NormalValue l in ln)
                    {
                        if (d.getId() == l.getIdaxe())
                        {
                        }
                    }
                }
                //calculs pourcentages

                    foreach (Disease d in listmaladies)
                    {
                        double probss = 0;
                        int denmoyenne = 0;

                        double valuenorm = 0;
                    //entre 2 maladies
                        double maxcent = 0;
                        double valuecurrent = 0;
                        foreach (Symptom ss in listSymptomes)
                        {
                            if(d.getId() == ss.getIddisease())
                            {                              

                                foreach (NormalValue varr in ln)
                                {
                                    if (varr.getIdaxe()==ss.getIdaxe())
                                    {

                                        valuenorm = (varr.getMinValue()+ varr.getMaxValue())/2;
                                     //   maxcent =( ss.getMinValue()+ss.getMaxValue())/2;
                                        if (valuenorm<= ss.getMinValue())
                                        {
                                            maxcent = ss.getMaxValue();
                                        }else {
                                            maxcent = ss.getMinValue();
                                        }
                                        
                                  //      MessageBox.Show("Axe= " + ss.getIdaxe() + "Valeurs= norm " + valuenorm + "et curr " + valuecurrent + "et max 100% " + maxcent);
                                       
                                    }
                                }
                                foreach (DotsPanel axean in axesanormale)
                                {
                                    if (axean.getAxe().getId() == ss.getIdaxe())
                                        valuecurrent = axean.getAxe().getCurrValue();
                                }
                            double probss1 = ((valuecurrent- valuenorm) * 100) / (maxcent- valuenorm);
                      //      double probss2 = ((valuecurrent - valuenorm) * 0) / (maxcent- valuenorm);
                          //  MessageBox.Show("symptom= " + ss.getId() + "maxcent= " + maxcent + " ,valuecurrent " + valuecurrent + "et valuenorm " + valuenorm + "et probabilités " + probss1 + "et probabilités2 " + probss1);
                            probss = probss + probss1;
                            denmoyenne++;
                                //MessageBox.Show("id= " + d.getId() + "pourcentage= " + d.getPourcentage());
                            }
                    }
                    double probdis = probss / denmoyenne;
                    d.setPourcentage(probdis);
                   // MessageBox.Show("probss= " + probss + "probdis= " + probdis + "denmoyenne= " + denmoyenne);
                }
                // listmaladies.Sort();

                listmaladies = listmaladies.OrderByDescending(element => element.getPourcentage()).ToList();
                foreach (Disease dd in listmaladies)
                {
                  ddao.findIdDisease(dd,conn);
                    if (dd.getPourcentage()>0)
                    dataGridView1.Rows.Add(dd.getId(), dd.getPourcentage(),dd.getName());
                }
                Maladie.Text = listmaladies[0].getName();
                //dataGridView1.Sort();
                // MessageBox.Show(listSymptomes.Count.ToString());
                conn.Close();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
