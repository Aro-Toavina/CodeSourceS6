﻿using System;

namespace DataPrediction
{
    public class Equation
    {
        private double a;
        private double b;

        public Equation()
        {

        }

        public Equation(double a, double b)
        {
            setA(a);
            setB(b);

        }
        //GETTERS
        public double getA()
        {
            return this.a;
        }
        public double getB()
        {
            return this.b;
        }
        //SETTERS
        public void setA(double aa)
        {
            this.a = aa;
        }
        public void setB(double bb)
        {
            this.b = bb;
        }
    }
}