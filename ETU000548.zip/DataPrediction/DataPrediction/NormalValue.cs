﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPrediction
{
    class NormalValue
    {
        private string id;
        private string idaxe;
        private char sexe;
        private double minAge;
        private double maxAge;
        private double minValue;
        private double maxValue;
        public NormalValue(string id,string idaxe,char sexe,double minAge,double maxAge,double minValue,double maxValue)
        {
            setId(id);
            setIdaxe(idaxe);
            setSexe(sexe);
            setMinAge(minAge);
            setMaxAge(maxAge);
            setMinValue(minValue);
            setMaxValue(maxValue);
        }

        //GETTERS
        public string getId()
        {
            return id;
        }
        public string getIdaxe()
        {
            return idaxe;
        }
        public char getSexe()
        {
            return sexe;
        }
        public double getMinAge()
        {
            return minAge;
        }
        public double getMaxAge()
        {
            return maxAge;
        }
        public double getMinValue()
        {
            return minValue;
        }
        public double getMaxValue()
        {
            return maxValue;
        }

        //SETTERS
        public void setId(string id)
        {
            this.id=id;
        }
        public void setIdaxe(string idaxe)
        {
            this.idaxe=idaxe;
        }
        public void setSexe(char sexe)
        {
            this.sexe=sexe;
        }
        public void setMinAge(double minage)
        {
            this.minAge=minage;
        }
        public void setMaxAge(double maxage)
        {
            this.maxAge=maxage;
        }
        public void setMinValue(double minval)
        {
            this.minValue=minval;
        }
        public void setMaxValue(double maxval)
        {
            this.maxValue=maxval;
        }


    }
}
