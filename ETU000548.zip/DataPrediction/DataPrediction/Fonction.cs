﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DataPrediction
{
    public class Fonction
    {
        public Fonction()
        {
        }
        // Equation
        //le coefficient directeur de deux droites perpendiculaires = -1
        public Equation getEquationPerpendiculaire(Equation equationDroite, int x, int y)
        {
            double aDroite = -1 / (double)equationDroite.getA();
            double bDroite = y - (double)(aDroite * x);
          //  MessageBox.Show(aDroite + "and" + bDroite);
            return new Equation(aDroite, bDroite);
        }
        public Equation getEquationDroite(Point pointCentre, Point point2)
        {
            Equation equation = new Equation();
            if (point2.X == pointCentre.X)
            {
                //afaka atao ze tiana satria tsisy mx+p
                equation.setA(pointCentre.X);
                equation.setB( pointCentre.Y);
              
            }
            else if (point2.Y == pointCentre.Y)
            {
                //afaka atao ze tiana satria tsisy mx+p
                equation.setA(0);
                equation.setB(0);

            }
            else
            {
                double numerateur = point2.Y - pointCentre.Y;
                double denominateur = point2.X - pointCentre.X;
                double a = numerateur / denominateur;
                double b = point2.Y - (a * point2.X);
                equation.setA(a);
                equation.setB(b);
            }
            return equation;
        }

        public double getDistancePoints(Point point1, Point point2)
        {
            double result = 0;
            result = Math.Sqrt((point2.X - point1.X) * (point2.X - point1.X) + (point2.Y - point1.Y) * (point2.Y - point1.Y));
            return result;
        }
    }
}