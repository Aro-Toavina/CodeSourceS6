﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace DataPrediction
{
    public class DotsPanel : Panel
    {
        private int x;
        private int y;
        private int numeroAxe;
        private Axe axe;
        private Boolean down = false;

        public DotsPanel()
        {

        }

        public DotsPanel(int x, int y, int numeroAxe, Axe axe)
        {
            setX(x);
            setY(y);
            setNumeroAxe(numeroAxe);
            setAxe(axe);

            this.Width = 120;
            this.Height = 20;
            //-10 pour bien positionner le point
            this.Location = new Point(this.x-10, this.y-10);
            this.BackColor = Color.FromArgb(0,0,0,0);
        }

        //FUNCTIONS

        // peinture des points
        protected override void OnPaint(PaintEventArgs e)
        {     
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Red), 0, 0, 20, 20);
            g.DrawString(this.getAxe().getCurrValue().ToString(), new Font("Arial", 10), new SolidBrush(Color.Black), 0, 0);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            try
            {
                //sur le clic de la souris
                if (down)
                {
                    
                    Panel panel1 = (Panel)Parent;
                    Panel panel2 = (Panel)panel1.Parent;
                    Form1 form1 = (Form1)panel2.Parent;
                    // Get Parent
                   // Panel panel1 = (Panel)Parent;
                   // Form1 form1 = (Form1)panel1.Parent;

                    Point pointCentre = form1.getPointCentre();
                    List<Equation> listeEquation = form1.getListeEquation();
                    List<Point> sommet = form1.getSommet();

                    Fonction fonction = new Fonction();

                    //mampietsika anle souris
                    int xPanel = this.Location.X + e.X;
                    int yPanel = this.Location.Y + e.Y;
                
                    //trois cas
                    //x miova ,y miova, xy miova
                        if (listeEquation[this.numeroAxe].getA() == pointCentre.X)
                        {
                            xPanel = this.x;
                        }
                        else if (listeEquation[this.numeroAxe].getA() == 0)
                        {
                            yPanel = this.y;
                        }
                        else
                        {
                            Equation equationPerpendiculaire = fonction.getEquationPerpendiculaire(listeEquation[this.numeroAxe], xPanel, yPanel);
                       // MessageBox.Show(xPanel+"and"+yPanel);
                    //    MessageBox.Show("perp:" + (double)equationPerpendiculaire.getA() + " et " + (double)equationPerpendiculaire.getB());
                            // (d1) y = listLine[this.getAxeLine()-1][0] * x + listLine[this.getAxeLine()-1][1]
                            // (d2) y = mDroite * x + pDroite
                            double numerateur = (double)listeEquation[this.numeroAxe].getB() - (double)equationPerpendiculaire.getB();
                            double denominateur = (double)equationPerpendiculaire.getA() - (double)listeEquation[this.numeroAxe].getA();
                            //double numerateur = (double)equationPerpendiculaire.getB() - (double)listeEquation[this.numeroAxe].getB();
                            // double denominateur = (double)listeEquation[this.numeroAxe].getA() - (double)equationPerpendiculaire.getA();
                            xPanel = (int)(numerateur / denominateur);
                            //yPanel = (int)((double)listeEquation[this.numeroAxe].getA() * (double)xPanel + (double)listeEquation[this.numeroAxe].getA());
                            yPanel = (int)((double)listeEquation[this.numeroAxe].getA() * (double)xPanel + (double)listeEquation[this.numeroAxe].getB());

                        }
                    this.x = xPanel;
                    this.y = yPanel;
                    this.Location = new Point(xPanel-10 , yPanel-10);
                    
                    //limite droite %distance
                    Point pointTemp = new Point(xPanel, yPanel);
                    double distanceTempCentre = fonction.getDistancePoints(pointCentre, pointTemp);
                    double distanceTempSommet = fonction.getDistancePoints(sommet[this.numeroAxe], pointTemp);

                    double distanceCentreSommet = fonction.getDistancePoints(pointCentre, sommet[this.numeroAxe]);

                    if (distanceCentreSommet >= distanceTempCentre && distanceCentreSommet >= distanceTempSommet)
                    {
                        this.Location = new Point(xPanel - 10, yPanel - 10);
                        this.x = xPanel;
                        this.y = yPanel;
                        //double règle de trois
                        double pourcentage = distanceTempCentre * 100 / distanceCentreSommet;
                        double differenceValueMinMax = axe.getMaxValue() - axe.getMinValue();
                        double resultPourcentage = differenceValueMinMax * pourcentage / 100;
                        axe.setCurrValue((float)(axe.getMinValue() + resultPourcentage));
                    }
                    else
                    //fixation de valeur 
                    {
                        if (distanceCentreSommet <= distanceTempCentre)
                        {
                            this.Location = new Point(sommet[this.numeroAxe].X - 10, sommet[this.numeroAxe].Y - 10);
                            this.x = sommet[this.numeroAxe].X;
                            this.y = sommet[this.numeroAxe].Y;
                            axe.setCurrValue(axe.getMaxValue());
                        }
                        if (distanceCentreSommet <= distanceTempSommet)
                        {
                            this.Location = new Point(pointCentre.X - 10, pointCentre.Y - 10);
                            this.x = pointCentre.X;
                            this.y = pointCentre.Y;

                            axe.setCurrValue(axe.getMinValue());
                        }
                        //throw new ExceptionMedical();
                    }           

                    form1.Refresh();
                }
            }
            catch (Exception exception)
            {
                //String message = exception.valueMinMax();
                //MessageBox.Show(message);
                down = false;
            }
        }

       
        // GETTERS

        public int getX()
        {
            return x;
        }
        public int getY()
        {
            return y;
        }
        public int getNumeroAxe()
        {
            return numeroAxe;
        }
        public Axe getAxe()
        {
            return axe;
        }

        // SETTERS
        public void setX(int x)
        {
            this.x = x;
        }
        public void setY(int y)
        {
            this.y = y;
        }
        public void setNumeroAxe(int numeroAxe)
        {
            this.numeroAxe = numeroAxe;
        }
        public void setAxe(Axe axe)
        {
            this.axe = axe;
        }
    }
}
