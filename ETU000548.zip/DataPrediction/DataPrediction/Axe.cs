﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPrediction
{
    public class Axe
    {
        private string id;
        private string libelle;
        private string unite;
        private double minValue;
        private double maxValue;
        private double currValue;

        public Axe()
        {

        }

        public Axe(string id,string libelle, string unite, double minValue, double maxValue, double currValue)
        {

            setId(id);
            setLibelle(libelle);
            setUnite(unite);
            setMinValue(minValue);
            setMaxValue(maxValue);
            setCurrValue(currValue);
        }

        // GETTERS

        public string getId()
        {
            return id;
        }
        public string getLibelle()
        {
            return libelle;
        }
        public string getUnite()
        {
            return unite;
        }
        public double getMinValue()
        {
            return minValue;
        }
        public double getMaxValue()
        {
            return maxValue;
        }
        public double getCurrValue()
        {
            return currValue;
        }

        // SETTERS

        public void setId(string id)
        {
            this.id = id;
        }
        public void setLibelle(string libelle)
        {
            this.libelle = libelle;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public void setMinValue(double minValue)
        {
            this.minValue = minValue;
        }
        public void setMaxValue(double maxValue)
        {
            this.maxValue = maxValue;
        }
        public void setCurrValue(double currValue)
        {
            this.currValue = currValue;
        }
    }
}
