﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataPrediction
{
    class NormalValueDAO
    {
        public List<NormalValue> findNormalValue(char sexe, double age)
        {
            List<NormalValue> liste = new List<NormalValue>();
            SqlCommand sqlcom;
            String sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select * from normalValue where sexe = 'A' or sexe = '"+ sexe + "' and minAge< "+ age + " and maxAge> "+ age + " order by idaxe";
                
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    liste.Add(new NormalValue(myread["id"].ToString(), myread["idaxe"].ToString(), Convert.ToChar(myread["sexe"].ToString()), Convert.ToDouble(myread["minAge"].ToString()), Convert.ToDouble(myread["maxAge"].ToString()), Convert.ToDouble(myread["minValue"].ToString()), Convert.ToDouble(myread["maxValue"].ToString())));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Valeurs Normales" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
        public List<NormalValue> findAllNormalValue(String condition)
        {
            List<NormalValue> liste = new List<NormalValue>();
            SqlCommand sqlcom;
            String sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select * from normalValue " + condition;
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    liste.Add(new NormalValue(myread["id"].ToString(), myread["idaxe"].ToString(), Convert.ToChar(myread["sexe"].ToString()), Convert.ToDouble(myread["minAge"].ToString()), Convert.ToDouble(myread["maxAge"].ToString()), Convert.ToDouble(myread["minValue"].ToString()), Convert.ToDouble(myread["maxValue"].ToString())));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des NormalValue" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
    }
}
