﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataPrediction
{
    class DiseaseDAO
    {

        public void findIdDisease(Disease d, SqlConnection connexion)
        {
          //  String res="";
          //  MessageBox.Show(d.getId() );
            SqlCommand sqlcom;
            String sql;
            SqlDataReader myread = null;
            try
            {
                sql = "select name from Diseases where id='" +d.getId()+"'";
              
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    d.setName(myread["name"].ToString());
                  //  res = myread["name"].ToString();
                   // MessageBox.Show(d.getId()+ " et "+ myread["name"].ToString());
                }
               
            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Symptom" + e.Message);
            }
            finally
            {
                myread.Close();
            }
        }
        public List<Disease> findIdDiseaseAnormal(String condition)
        {
            List<Disease> liste = new List<Disease>();
            SqlCommand sqlcom;
            String sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select distinct(iddisease) from symptoms where 1<2 " + condition;
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    liste.Add(new Disease(myread["iddisease"].ToString()));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Symptom" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
        public List<Disease> findDisease(String condition)
        {
            List<Disease> liste = new List<Disease>();
            SqlCommand sqlcom;
            string sql;
            Connexion connect;
            SqlConnection connexion = null;
            SqlDataReader myread = null;
            try
            {
                connect = new Connexion();
                sql = "select * from Diseases " + condition;
                connexion = connect.connect();
                sqlcom = new SqlCommand(sql, connexion);
                myread = sqlcom.ExecuteReader();

                while (myread.Read())
                {
                    double min = Convert.ToDouble(myread.GetDecimal(3));
                    double max = Convert.ToDouble(myread.GetDecimal(4));

                    liste.Add(new Disease(myread.GetString(0), myread.GetString(1)));
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Erreur sur la selection des Disease" + e.Message);
            }
            finally
            {
                connexion.Close();
            }
            return liste;
        }
    }
}
