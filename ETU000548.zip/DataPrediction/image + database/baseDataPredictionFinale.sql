/* base sqlserver dataprediction */

create table axes(
	id varchar(7) primary key,
	component varchar(35),
	unit varchar(7),
	axeMin decimal(15,5),
	axeMax decimal(15,5)
);
insert into axes values('AXE1','Hémoglobine','g/100ml',0,50);
insert into axes values('AXE2','Hématocrites','%',0,100);
insert into axes values('AXE3','Leucocytes','/mm3',100,50000);
insert into axes values('AXE4','Plaquette','mm3',50000,750000);
insert into axes values('AXE5','Glycémie','mmol/l',0,15);
insert into axes values('AXE6','Acide Urique','mg/l',0,1000);
insert into axes values('AXE7','Cholestérol','g/l',0,15);
insert into axes values('AXE8','Créatinine','mmol/l',0,200);
insert into axes values('AXE9','Potassium','mmol/l',0,15);
insert into axes values('AXE10','Hématies','mm3',1000000,10000000);
insert into axes values('AXE11','Bilirubine Conjuguée','µmol/l',50,200);
insert into axes values('AXE12','Sodium','mmol/l',0,15);
insert into axes values('AXE13','Gamma GT','UI/l',0,100);
insert into axes values('AXE14','Phosphates Alcalines','mg/l',0,200);

create table normalValue(
	id varchar(7) primary key,	
	idaxe varchar(7),
	sexe char(1),
	minAge decimal(5,2),
	maxAge decimal(5,2),
	minValue decimal(15,5), 
	maxValue decimal(15,5),
    foreign key (idaxe) references axes(id)
);
/* sexe: A=all F:femme H:homme */
insert into normalValue values('NOR1','AXE1','A',0,130,13,18);
insert into normalValue values('NOR2','AXE2','A',0,130,37,50);
insert into normalValue values('NOR3','AXE3','A',0,130,4000,10000);
insert into normalValue values('NOR4','AXE4','A',0,130,150000,450000);
insert into normalValue values('NOR5','AXE5','A',0,130,4,6);
insert into normalValue values('NOR6','AXE6','A',0,130,0,410);
insert into normalValue values('NOR7','AXE7','A',0,130,3,6.2);
insert into normalValue values('NOR8','AXE8','H',0,130,0,120);
insert into normalValue values('NOR9','AXE8','F',0,130,0,100);
insert into normalValue values('NOR10','AXE9','A',0,130,3.6,5);
insert into normalValue values('NOR11','AXE10','A',0,130,4200000,6200000);
insert into normalValue values('NOR12','AXE11','A',0,130,0,9);
insert into normalValue values('NOR13','AXE12','A',0,130,137,145);
insert into normalValue values('NOR14','AXE13','A',0,130,0,55);
insert into normalValue values('NOR15','AXE14','A',0,130,53,128);


create table diseases(
	id varchar(7) primary key,
	name varchar(35),
	sexe char(1),
	minAge decimal(5,2),
	maxAge decimal(5,2)
);

insert into diseases values('ILL1','Anémie','A',0,130);
insert into diseases values('ILL2','Polyglobuline','A',0,130);
insert into diseases values('ILL3','Leucopénie','A',0,130);
insert into diseases values('ILL4','Hyperleucocytose','A',0,130);
insert into diseases values('ILL5','Thrombopénie','A',0,130);
insert into diseases values('ILL6','Thrombocytose','A',0,130);
insert into diseases values('ILL7','Hypoglycémie','A',0,130);
insert into diseases values('ILL8','Hyperglycémie','A',0,130);
insert into diseases values('ILL9','Goutte','A',0,130);
insert into diseases values('ILL10','Insuffisance Hépatique','A',0,130);
insert into diseases values('ILL11','Maladie Cardio-Vasculaire','A',0,130);
insert into diseases values('ILL12','Insuffisance rénale','A',0,130);
insert into diseases values('ILL13','Hypokaliémie','A',0,130);
insert into diseases values('ILL14','Hyperkaliémie','A',0,130);
insert into diseases values('ILL15','Hépatite','A',0,130);
insert into diseases values('ILL16','Héponatrémie','A',0,130);
insert into diseases values('ILL17','Hypernatrémie','A',0,130);


create table symptoms(
	id varchar(7) primary key,
	iddisease	varchar(7),
	idaxe	varchar(7),	
	sexe char(1),
	minAge decimal(5,2),
	maxAge decimal(5,2),
	minValue decimal(15,5), 
	maxValue decimal(15,5),
	foreign key (iddisease) references diseases(id),	
	foreign key (idaxe) references axes(id)
	
);
/* anémie*/
insert into symptoms values('SYM1','ILL1','AXE1','A',0,130,0,12);
insert into symptoms values('SYM2','ILL1','AXE2','A',0,130,0,36);
insert into symptoms values('SYM3','ILL1','AXE10','A',0,130,6210000,10000000);

/* Polyglobuline */
insert into symptoms values('SYM4','ILL2','AXE1','A',0,130,19,50);
insert into symptoms values('SYM5','ILL2','AXE2','A',0,130,51,100);
insert into symptoms values('SYM6','ILL2','AXE10','A',0,130,1000000,4150000);

/* Leucopénie */
insert into symptoms values('SYM7','ILL3','AXE3','A',0,130,100,3950);

/*Hyperleucocytose*/
insert into symptoms values('SYM8','ILL4','AXE3','A',0,130,10050,50000);

/*Thrombopénie*/
insert into symptoms values('SYM9','ILL5','AXE4','A',0,130,45000,150000);

/*Thrombocytose*/
insert into symptoms values('SYM10','ILL6','AXE4','A',0,130,460000,750000);

/*Hypoglycémie*/
insert into symptoms values('SYM11','ILL7','AXE5','A',0,130,0,3);

/*Hyperglycémie*/
insert into symptoms values('SYM12','ILL8','AXE5','A',0,130,7,15);

/*Goutte*/
insert into symptoms values('SYM13','ILL9','AXE6','A',0,130,475,1000);

/*Insuffisance Hépatique*/
insert into symptoms values('SYM14','ILL10','AXE7','A',0,130,0,2.5);

/*Maladie Cardio-vasculaire*/
insert into symptoms values('SYM15','ILL11','AXE7','A',0,130,6.5,15);

/*Insuffisance rénale*/
insert into symptoms values('SYM16','ILL12','AXE8','F',0,130,101,15);
insert into symptoms values('SYM17','ILL12','AXE8','H',0,130,121,15);

/*Hypokaliémie*/
insert into symptoms values('SYM18','ILL13','AXE9','A',0,130,0,3.5);

/*Hyperkaliémie*/
insert into symptoms values('SYM19','ILL14','AXE9','A',0,130,5.5,15);

/*Hépatite*/
insert into symptoms values('SYM20','ILL15','AXE11','A',0,130,10,15);
insert into symptoms values('SYM21','ILL15','AXE13','A',0,130,58,100);
insert into symptoms values('SYM22','ILL15','AXE14','A',0,130,130,200);


/*Hyponatrémie*/
insert into symptoms values('SYM23','ILL13','AXE12','A',0,130,50,136);

/*Hypernatrémie*/
insert into symptoms values('SYM24','ILL14','AXE12','A',0,130,146,200);



/* *********  Requette ***** */

select * from normalValue where sexe='A' or sexe='M' and minAge<30 and maxAge>30 order by idaxe;


