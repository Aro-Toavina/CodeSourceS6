/*SEQUENCE */
CREATE sequence seq_Patient  start with 1 increment by 1;
CREATE sequence seq_Critere  start with 1 increment by 1;
CREATE sequence seq_Unite  start with 1 increment by 1;
CREATE sequence seq_Maladie start with 1 increment by 1;
CREATE sequence seq_MaladieDetail start with 1 increment by 1;

/*TABLE*/
create table Patient(
	id varchar(20) primary key,
	nom varchar(50), 
	dateNaissance date,
	sexe int,
	mdp varchar(100)
);

create table Unite(
	id varchar(20) primary key,
	libelle varchar(20), 
	indice varchar(5)
);

create table Critere(
	id varchar(20) primary key,
	nom varchar(50),
	idUnite varchar(20),
	foreign key (idUnite) references Unite(id));
	
create table CritereDetail(
	id varchar(20) primary key,
	idCritere varchar(20),
	valeurNormalmin float,
	valeurNormalmax float,
	sexeSpecifique int,
	foreign key (idCritere) references Critere(id));
	
create table Maladie(
	id varchar(20) primary key,
	nom varchar(50));
	
create table MaladieDetail(
	id varchar(20) primary key,
	idMaladie varchar(20),
	idCritere varchar(20),
	sexe int,
	typeCause int,
	valeurMin float,
	valeurMax float,
	
	foreign key (idMaladie) references Maladie(id),
	foreign key (idCritere) references Critere(id));
		
INSERT INTO Patient values('USR0001','Angelo lock', '31-08-1996', 1, 'azerty');
INSERT INTO Patient values('USR0002','Julio lock', '17-06-1988', 1, 'azerty');

INSERT INTO Unite values('UNIT0001','Millions', 'M');
INSERT INTO Unite values('UNIT0002','Pourcentage', '%');
INSERT INTO Unite values('UNIT0003','Micro mètre cube', 'µ3');
INSERT INTO Unite values('UNIT0004','Milli-mètre cube', 'mm3');
INSERT INTO Unite values('UNIT0005','gramme par litre', 'g/l');	
	
INSERT INTO Critere values('CTR0001','Globule rouge', 'UNIT0001');
INSERT INTO Critere values('CTR0002','Hématocrite', 'UNIT0002');
INSERT INTO Critere values('CTR0003','Volume globulaire moyen', 'UNIT0003');
INSERT INTO Critere values('CTR0004','Leucocytes', 'UNIT0004');
INSERT INTO Critere values('CTR0005','Polynucléaire neutrophiles', 'UNIT0004');
INSERT INTO Critere values('CTR0006','Lymphocytes', 'UNIT0004');
INSERT INTO Critere values('CTR0007','Monocytes(globule blanc)', 'UNIT0004');
INSERT INTO Critere values('CTR0008','Les plaquettes', 'UNIT0004');
INSERT INTO Critere values('CTR0009','Les triglycérides', 'UNIT0005');
INSERT INTO Critere values('CTR0010','Le cholestérol', 'UNIT0005');
INSERT INTO Critere values('CTR0011','cholestérol LDL', 'UNIT0005');
INSERT INTO Critere values('CTR0011','cholestérol LDL', 'UNIT0005');
INSERT INTO Critere values('CTR0011','cholestérol LDL', 'UNIT0005');
INSERT INTO Critere values('CTR0012','cholestérol HDL', 'UNIT0005');
INSERT INTO Critere values('CTR0013','Glycémie', 'UNIT0005');
INSERT INTO Critere values('CTR0014','Glucose', 'UNIT0005');


INSERT INTO CritereDetail values('CTRDET001','CTR0001', '4.6', '6.2', 1);
INSERT INTO CritereDetail values('CTRDET002','CTR0001', '4.2', '5.4', 0);

INSERT INTO CritereDetail values('CTRDET003','CTR0002', '40', '52', 1);
INSERT INTO CritereDetail values('CTRDET004','CTR0002', '37', '48', 0);

INSERT INTO CritereDetail values('CTRDET005','CTR0003', '80', '103', 1);
INSERT INTO CritereDetail values('CTRDET006','CTR0003', '81', '102', 0);

INSERT INTO CritereDetail values('CTRDET007','CTR0004', '4000', '10000', 1);
INSERT INTO CritereDetail values('CTRDET008','CTR0004', '4000', '10000', 0);

INSERT INTO CritereDetail values('CTRDET009','CTR0005', '1800', '7000', 1);
INSERT INTO CritereDetail values('CTRDET010','CTR0005', '1800', '7000', 0);

INSERT INTO CritereDetail values('CTRDET011','CTR0006', '1000', '4000', 1);
INSERT INTO CritereDetail values('CTRDET012','CTR0006', '1000', '4000', 0);

INSERT INTO CritereDetail values('CTRDET013','CTR0007', '80', '1000', 1);
INSERT INTO CritereDetail values('CTRDET014','CTR0007', '80', '1000', 0);

INSERT INTO CritereDetail values('CTRDET015','CTR0008', '150000', '400000', 1);
INSERT INTO CritereDetail values('CTRDET016','CTR0008', '150000', '400000', 0);

INSERT INTO CritereDetail values('CTRDET017','CTR0009', '0.40', '1.50', 1);
INSERT INTO CritereDetail values('CTRDET018','CTR0009', '0.40', '1.50', 0);

INSERT INTO CritereDetail values('CTRDET019','CTR0010', '1.5', '2.5', 1);
INSERT INTO CritereDetail values('CTRDET020','CTR0010', '1.5', '2.5', 0);

INSERT INTO CritereDetail values('CTRDET021','CTR0011', '0.9', '1.58', 1);
INSERT INTO CritereDetail values('CTRDET022','CTR0011', '0.9', '1.58', 0);

INSERT INTO CritereDetail values('CTRDET023','CTR0012', '0.4', '0.5', 1);
INSERT INTO CritereDetail values('CTRDET024','CTR0012', '0.5', '0.6', 0);

INSERT INTO CritereDetail values('CTRDET025','CTR0013', '0.74', '1.06', 1);
INSERT INTO CritereDetail values('CTRDET026','CTR0013', '0.74', '1.06', 0);

INSERT INTO CritereDetail values('CTRDET027','CTR0014', '4.5', '5', 1);
INSERT INTO CritereDetail values('CTRDET028','CTR0014', '4.5', '5', 0);


	
	
INSERT INTO Maladie values('MAL0001', 'Polyglobulie');
INSERT INTO Maladie values('MAL0002', 'Anémie');
INSERT INTO Maladie values('MAL0003', 'Leucémie aigüe');
INSERT INTO Maladie values('MAL0004', 'Infection virale');
INSERT INTO Maladie values('MAL0005', 'Cancer');
INSERT INTO Maladie values('MAL0006', 'SIDA');
INSERT INTO Maladie values('MAL0007', 'Hémorragie');
INSERT INTO Maladie values('MAL0008', 'Thrombose');
INSERT INTO Maladie values('MAL0009', 'Carence en fer');
INSERT INTO Maladie values('MAL0010', 'Maladie du foie');
INSERT INTO Maladie values('MAL0011', 'Grippe');
INSERT INTO Maladie values('MAL0012', 'Aplasie médullaire');
INSERT INTO Maladie values('MAL0013', 'Maladie d Hodgkin');
INSERT INTO Maladie values('MAL0014', 'Mononucléose');
INSERT INTO Maladie values('MAL0015', 'Chlamydiose');
INSERT INTO Maladie values('MAL0016', 'Inflammation');
INSERT INTO Maladie values('MAL0017', 'Microcytose');
INSERT INTO Maladie values('MAL0018', 'Macrocytose');
INSERT INTO Maladie values('MAL0019', 'Infarctus du myocarde');
INSERT INTO Maladie values('MAL0020', 'Hépatite');
INSERT INTO Maladie values('MAL0021', 'Hyperthyroïdie');
INSERT INTO Maladie values('MAL0022', 'Diabète');
INSERT INTO Maladie values('MAL0023', 'Inuffisance surrénalienne');


INSERT INTO MaladieDetail values('MALDET0001', 'MAL0001','CTR0001', 1, 1, '6.2', '9');
INSERT INTO MaladieDetail values('MALDET0002', 'MAL0001','CTR0001', 0, 1, '5.4', '9');

INSERT INTO MaladieDetail values('MALDET0003', 'MAL0002','CTR0001', 1, 0, '1.5', '4.6');
INSERT INTO MaladieDetail values('MALDET0004', 'MAL0002','CTR0001', 0, 0, '1.2', '4.2');
INSERT INTO MaladieDetail values('MALDET0005', 'MAL0002','CTR0004', 1, 0, '500', '4000');
INSERT INTO MaladieDetail values('MALDET0006', 'MAL0002','CTR0007', 1, 1, '1000', '2000');
INSERT INTO MaladieDetail values('MALDET0007', 'MAL0002','CTR0005', 1, 0, '10', '80');

INSERT INTO MaladieDetail values('MALDET0008', 'MAL0003','CTR0004', 1,1, '11000', '15000');
INSERT INTO MaladieDetail values('MALDET0009', 'MAL0003','CTR0008', 1,0, '10000', '150000');
INSERT INTO MaladieDetail values('MALDET0010', 'MAL0003','CTR0006', 1,1, '4000', '7000');
INSERT INTO MaladieDetail values('MALDET0011', 'MAL0003','CTR0005', 1,0, '100', '1700');

INSERT INTO MaladieDetail values('MALDET0012', 'MAL0004','CTR0004', 1,0, '500', '4000');
INSERT INTO MaladieDetail values('MALDET0013', 'MAL0004','CTR0005', 1,0, '100', '1700');

INSERT INTO MaladieDetail values('MALDET0014', 'MAL0005','CTR0004', 1,0, '500', '4000');
INSERT INTO MaladieDetail values('MALDET0015', 'MAL0005','CTR0008', 1,1, '400000', '600000');
INSERT INTO MaladieDetail values('MALDET0016', 'MAL0005','CTR0005', 1,1, '7000', '9000');

INSERT INTO MaladieDetail values('MALDET0017', 'MAL0006','CTR0004', 1,0, '500', '4000');

INSERT INTO MaladieDetail values('MALDET0018', 'MAL0007','CTR0008', 1,0, '20000', '150000');


	
	

CREATE VIEW GetMaladie AS select malDet.id, mal.nomMaladieBaisse, mal.nomMaladieHausse, crit.nom, malDet.tauxNormalmin, malDet.tauxNormalmax, unit.indice from MaladieDetail malDet 
join maladie mal
on malDet.idMaladie = mal.id 
join Critere crit
on crit.id = mal.idCritere
join Unite unit
on unit.id = mal.idUnite;


	
	
	
	
	
	
	
	
	