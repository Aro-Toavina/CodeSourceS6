﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class MaladieDetail
    {
        string _id;
        string _idMaladie;
        string _idCritere;
        int _sexe;
        int _typeCause;
        double _valeurMin;
        double _valeurMax;
        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string IdMaladie
        {
            set { this._idMaladie = value; }
            get { return this._idMaladie; }
        }
        public string IdCritere
        {
            set { this._idCritere = value; }
            get { return this._idCritere; }

        }
        public int TypeCause
        {
            set { this._typeCause = value; }
            get { return this._typeCause; }
        }
        public int Sexe
        {
            set { this._sexe = value; }
            get { return this._sexe; }
        }
        public double ValeurMin
        {
            set { this._valeurMin = value; }
            get { return this._valeurMin; }
        }

        public double ValeurMax
        {
            set { this._valeurMax = value; }
            get { return this._valeurMax; }
        }

        public MaladieDetail() { }
        public MaladieDetail(string id, string idMaladie, string idCritere, int sexe, int typeCause, double min, double max)
        {
            this.Id = id;
            this.IdMaladie = idMaladie;
            this.IdCritere = idCritere;
            this.Sexe = sexe;
            this.TypeCause = typeCause;
            this.ValeurMin = min;
            this.ValeurMax = max;
        }
        public MaladieDetail(string idMaladie, string idCritere, int typeCause)
        {
            this.IdMaladie = idMaladie;
            this.IdCritere = idCritere;
            this.TypeCause = typeCause;
        }
        public MaladieDetail(string idCritere,int sexe, int typeCause, double min, double max)
        {
            this.IdCritere = idCritere;
            this.Sexe = sexe;
            this.TypeCause = typeCause;
            this.ValeurMin = min;
            this.ValeurMax = max;
        }
    }
}
