﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Controller
    {
        private Critere[] critereList = null;
        private CritereDetail[] critereDetailList = null;
        private Unite[] uniteList = null;
        private Maladie[] maladieList = null;
        private MaladieDetail[] maladieDetailList = null;
        Utilitaire outil = new Utilitaire();
        public Controller() { }
        public Controller(Critere[] crit, Unite[] unite, Maladie[] mal, MaladieDetail[] malDet, CritereDetail[] critereDetail)
        {
            this.critereList = crit;
            this.uniteList = unite;
            this.maladieList = mal;
            this.maladieDetailList = malDet;
            this.critereDetailList  = critereDetail;
        }
        public Patient verifUser(string pseudo, string mdp, Patient[] patient)
        {
            //string retour = "";
            if (patient.Length == 0)
            {
                throw new Exception("Erreur : tableau patient vide!!!");
            }
            foreach (Patient pat in patient)
            {
                string temp = pat.Nom.Split(' ').Length != 0 ? pat.Nom.Split(' ')[0] : pat.Nom;

                if (pseudo.ToUpper().Equals(temp.ToUpper()) && mdp.Equals(pat.Mdp))
                {
                    return pat;

                }
            }
            return null;
        }
        /*public int checkCritereHausseOuBas(string idCritere)
        {
            if (maladieList.Length == 0)
            {
                throw new Exception("Erreur : tableau maladie vide!!!");
            }
            bool doesNotExist = false;
            foreach (Maladie mal in maladieList)
            {
                
                if (idCritere.Equals(mal.IdCritere) && !mal.NomMaladieHausse.Equals("") && mal.NomMaladieBaisse.Equals(""))
                {
                    return 1;
                }
                else if (idCritere.Equals(mal.IdCritere) && mal.NomMaladieHausse.Equals("") && !mal.NomMaladieBaisse.Equals(""))
                {
                    return 2;
                }
                if (!idCritere.Equals(mal.IdCritere))
                {
                    doesNotExist = true;
                }

            }
            return !doesNotExist ? 0 : -1;
        }*/
        public double[] getValeurMinMax(string idCritere, int sexe)
        {
            double[] ret = new double[2];
            string idCritereDet = "";
            
            foreach (CritereDetail crit in critereDetailList)
            {
                if (crit.IdCritere.Equals(idCritere))
                {
                    idCritereDet = crit.Id;
                    if ( crit.SexeSpecifique == sexe)
                    {
                        ret[0] = crit.ValeurNormalmin;
                        ret[1] = crit.ValeurNormalmax;
                    }
                }
                
            }
            return ret;
        }
        /*public string valeurVariationParPourcentage(string idCritere, int sexe, double valeurPourcentage)
        {
            string ret = ""; //Math.Round(this.getPoucentage(distanceOM), 2).ToString();
            double[] minMax = this.getValeurMinMax(idCritere, sexe);
            double centPourcent = minMax[1] - minMax[0];
            ret = Math.Round((centPourcent * valeurPourcentage) / 100, 2).ToString();
            return ret;
        }*/
        public double getMoins15PourCent(double valeur)
        {

            double ret = 0;
            double pourcentageMin = 15;
            ret = Math.Round((valeur * pourcentageMin) / (double)100, 2);
            return ret;
        }
        public string valeurVariationParPourcentage(string idCritere, int sexe, double valeurPourcentage)
        {
            Console.WriteLine("VALEUR########################### pourcentage = "+ valeurPourcentage);
            string ret = ""; //Math.Round(this.getPoucentage(distanceOM), 2).ToString();
            double pourcentageMax = 75;
            double[] minMax = this.getValeurMinMax(idCritere, sexe);

            double centPourcent = minMax[1] - getMoins15PourCent(minMax[0]);   //Max - 15%deMin
            ret = Math.Round((centPourcent * valeurPourcentage) / pourcentageMax, 2).ToString();
            return ret;
        }
        public string getUniteByIdUnite(string idUnite)
        {           
            if (idUnite.Equals(""))
            {
                throw new Exception("Erreur : idMaladie introuvable!!!");
            }
            foreach (Unite unit in uniteList)
            {
                Console.WriteLine("unite = "+ idUnite +":"+ unit.Id);
                if (idUnite.Equals(unit.Id))
                {
                    return unit.Indice;
                }
            }
            return null;
        }
        public string getIdMaladieDetailByIdMaladie(string idMaladie)
        {
            
            foreach (MaladieDetail mal in maladieDetailList)
            {
                if (idMaladie.Equals(mal.IdMaladie))
                {
                    return mal.Id;
                }
            }   
            return null;
        }
        public CritereDetail[] getValeurNormalePersonne(Patient patient)
        {
            List<CritereDetail> ret = new List<CritereDetail>();
            foreach (CritereDetail temp in critereDetailList)
            {
                if (temp.SexeSpecifique == patient.Sexe)
                {
                    ret.Add(temp);
                }
            }
            return ret.ToArray();
        }
        public string getNomMaladie(string id)
        {
            foreach (Maladie mal in maladieList)
            {
                if (id.Equals(mal.Id))
                {
                    return mal.Nom;
                }
            }
            return "null";
        }
        public int getIndice(CritereDetail[] tableau, string idCritere)
        {
            for (int i = 0; i < tableau.Length; i++)
            {
                if (tableau[i].IdCritere.Equals(idCritere))
                {
                    return i;
                }
            }
            return -1;
        }
        public int checkCritereNormale(string idCritere, double valeurObtenu, Patient patient)
        {
            CritereDetail[] ret = this.getValeurNormalePersonne(patient);
            foreach (CritereDetail temp in ret)
            {
                if (temp.IdCritere.Equals(idCritere))
                {
                    if (valeurObtenu > 0 && valeurObtenu < temp.ValeurNormalmin)
                    {
                        return -1; //en dessous de la valeur Normal
                    }
                    else if (valeurObtenu >= temp.ValeurNormalmin && valeurObtenu <= temp.ValeurNormalmax)
                    {
                        return 0; //entre la valeur Normal
                    }
                    else if (valeurObtenu>temp.ValeurNormalmax)
                    {
                        return 1; //au dessus de la valeur Normal
                    }
                }
            }
            
            return 0;
        }
        /*CritereDetail[] ret = this.getValeurNormalePersonne(patient);
            List<double> retour = new List<double>();
            foreach (MaladieDetail mal in maladieDetailList)
            {
                for (int i = 0; i < tabs.Length; i++)
                {
                    string idCritere = ret[tabs[i].IndiceCritere].IdCritere;
                    if(mal.IdCritere.Equals(idCritere))
                    {

                        retour.Add
                    }
                }
            }
            */
        public MaladieDetail[] getListCritereByIdMaladie(string idMaladie)
        {
            List<MaladieDetail> temp = new List<MaladieDetail>();
            foreach (MaladieDetail mal in maladieDetailList)
            {
                if (mal.IdMaladie.Equals(idMaladie))
                {
                    temp.Add(new MaladieDetail(mal.IdCritere, mal.Sexe, mal.TypeCause, mal.ValeurMin, mal.ValeurMax));
                }
            }
            if (temp.Count==0)
            {
               // throw new Exception("Exception : idMaladie invalide!!!");
            }
            return temp.ToArray();
        }
        public bool isInArray(string idCritere, MaladieDetail[] tabs)
        {
            foreach (MaladieDetail val in tabs)
            {
                if (val.IdCritere.Equals(idCritere))
                {
                    return true;
                }
            }
            return false;
        }
        public double getValeurMaladie(string idCritere, double valeur, Patient patient, int type)
        {
            double ret = 0;
            foreach (MaladieDetail mal in maladieDetailList)
            {
                if (mal.IdCritere.Equals(idCritere))
                {
                    if (patient.Sexe == mal.Sexe && type == 1)
                    {
                        double max = mal.ValeurMax;
                        double min = mal.ValeurMin;
                        Console.WriteLine("max : " + max + " >= valeur:" + valeur + " && min: " + min + " <= valeur: " + valeur);
                        if (max >= valeur && min <=valeur)
                        {
                        
                            Console.WriteLine("valeur = " + valeur);
                            Console.WriteLine("max = " + max + " min = " + min);
                            double demi = (max + min) / (double)2;
                            ret = valeur * (double)100 / demi;
                            Console.WriteLine("ret1 = " + ret);
                            break;
                        }
                       
                    }
                    else if (patient.Sexe == mal.Sexe && type == 0)
                    {
                        double max = mal.ValeurMin;
                        double min = mal.ValeurMax;
                        Console.WriteLine("max : " + max+" >= valeur:"+valeur+" && min: "+min+" <= valeur: "+valeur);
                        if (max >= valeur && min <= valeur)
                        {
                            Console.WriteLine("max2 = " + max + " min2 = " + min);
                            double demi = (max + min) / (double)2;
                            ret = valeur * (double)100 / demi;
                            if (ret > 100)
                            {
                                ret = (double)100 - (ret - (double)100);
                            }
                            Console.WriteLine("ret2 = " + ret);
                            break;
                        }
                    }
                }
            }
            return ret;
        }
        public MaladieRisque[] getPourcentageDeRisque(ValeurCritere[] tabs, Patient patient)
        {
            List<MaladieRisque> ret = new List<MaladieRisque>();
           
            foreach (Maladie mal in maladieList)
            {
                MaladieDetail[] temp = this.getListCritereByIdMaladie(mal.Id);
               // Console.WriteLine("IdMaladie = "+mal.Id);
                int compteur = 0;
                double sommeMaladie = 0;
                string idMaladie = mal.Id;

                for (int k = 0; k < tabs.Length; k++)
                {
                    string idCritere = critereList[tabs[k].IndiceCritere].Id;

                    for (int i = 0; i < temp.Length; i++)
                    {
                        if (temp[i].IdCritere.Equals(idCritere) && temp[i].TypeCause == tabs[k].Type && temp[i].Sexe==patient.Sexe)
                        {

                            double var = getValeurMaladie(idCritere, tabs[i].Valeur, patient, tabs[k].Type);
                            
                            sommeMaladie += var;
                            compteur++;
                            break;
                        }
                    }            
                }
                

               /* for (int i = 0; i < temp.Length; i++)
                {
                    for (int k = 0; k < tabs.Length; k++)
                    {
                        string idCritere = critereList[tabs[k].IndiceCritere].Id;
                        //if (temp[i].IdCritere.Equals(idCritere) && temp[i].TypeCause == tabs[k].Type)
                        if (temp[i].IdCritere.Equals(idCritere) && temp[i].TypeCause == tabs[k].Type)
                        {
                            sommeMaladie += tabs[i].Valeur;
                            compteur++;
                            break;
                        }
                    }
                }*/

                if (compteur!=0)
                {
                    double calcul = sommeMaladie / (double)compteur;
                    ret.Add(new MaladieRisque(idMaladie, calcul));
                }
            }
            return ret.ToArray();
        }
        /* public MaladiePredit getValeurNormalePersonne(Critere[] deja, Patient patient)
         {
             MaladiePredit valeurNormalPersonne = new MaladiePredit();
             if (deja.Length == 0)
             {
                 throw new Exception("La taille du tableau Critère est nulle");
             }
             Critere[] normalPersonne = new Critere[deja.Length];
             int i = 0;
             foreach (Critere critere in deja)
             {
                 double[] minMax = this.getValeurMinMax(critere.Id, patient.Sexe);
                 normalPersonne[i] = new Critere(critere.Id, critere.Nom, this.outil.getValeurMoyenne(minMax[0], minMax[1]));
                 i++;
             }
             valeurNormalPersonne.TableauCritere = normalPersonne;

             return valeurNormalPersonne;
         }*/
    }
}
