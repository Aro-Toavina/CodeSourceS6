﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class EquationDroite
    {
        private float a;
        private float b;

        public float A
        {
            set { this.a = value; }
            get { return this.a; }
        }
        public float B
        {
            set { this.b = value; }
            get { return this.b; }
        }
        public EquationDroite() { }
        public EquationDroite(float a, float b)
        {
            this.A = a;
            this.B = b;
        }

        public string getEquation(string d)
        {
            return " y("+d+") = ("+this.A+")x + ("+this.B+ ") ";
        }

    }
}
