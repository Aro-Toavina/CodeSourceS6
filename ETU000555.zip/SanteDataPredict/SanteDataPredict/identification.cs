﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SanteDataPredict
{
    public partial class identification : Form
    {
        Controller cont = new Controller();
        PatientDAO patientDao = new PatientDAO();
        Patient[] patientList = null;
        public identification()
        {
            patientList = patientDao.findPatient("Patient", "5<9");
           
            InitializeComponent();
            this.pseudo.Text = "angelo";
            this.password.Text = "azerty";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Patient ret = cont.verifUser(this.pseudo.Text, this.password.Text, patientList);

            if (ret!=null)
            {
                Form1 f1 = new Form1(ret);
                f1.Show();
            }
            else {
                MessageBox.Show("Identifiant incorrect !!!");
            }

        }
    }
}
