﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Configuration
    {
        public static int TAILLE_PANEL = 370;
        public static int NOMBRE_AXE = 14;
        public static int DECALE = 90;
       

      
    }
}
