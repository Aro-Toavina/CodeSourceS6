﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Critere
    {
        string _id;
        string _nom;
        string _idUnite;
        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string Nom
        {
            set { this._nom = value; }
            get { return this._nom; }
        }
        public string IdUnite
        {
            set { this._idUnite = value; }
            get { return this._idUnite; }
        }
        public Critere() { }
        public Critere(string id, string nom, string idUnite)
        {
            this.Id = id;
            this.Nom = nom;
            this.IdUnite = idUnite;
        }
        public Critere(string id, string nom)
        {
            this.Id = id;
            this.Nom = nom;
        }
        public Critere(string nom)
        {
            this.Nom = nom;
        }



    }
}
