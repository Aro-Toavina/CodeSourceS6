﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class ValeurCritere
    {
        int _indiceCritere;
        double _valeur;
        int _type;
        public int IndiceCritere
        {
            set { this._indiceCritere = value; }
            get { return this._indiceCritere; }
        }
        public int Type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public double Valeur
        {
            set { this._valeur = value; }
            get { return this._valeur; }
        }
        public ValeurCritere() { }
        public ValeurCritere(int indice, double value)
        {
            this.IndiceCritere = indice;
            this.Valeur = value;
            
        }
        public ValeurCritere(int indice, double value, int type)
        {
            this.IndiceCritere = indice;
            this.Valeur = value;
            this.Type = type;
        }
        
    }
}
