﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class PatientDAO
    {
        string pre = "USR";
        public string Pre
        {
            get { return pre; }
            set { pre = value; }
        }
        public Patient[] findPatient(SqlConnection con, string table, string where)
        {
            Patient[] tabMed;
            List<Patient> listProd = new List<Patient>();
            string sql = null;
            SqlCommand command;
            SqlDataReader dataReader;
            try
            {
                sql = "select * from " + table + " where 1<2 and " + where;

                con.Open();

                command = new SqlCommand(sql, con);

                dataReader = command.ExecuteReader();
                // Utilitaire getdat = new Utilitaire();
                while (dataReader.Read())
                {
                    string id = Convert.ToString(dataReader.GetValue(0));
                    string nom = Convert.ToString(dataReader.GetValue(1));
                    string dateNaissance = Convert.ToString(dataReader.GetValue(2));
                    int sexe = Convert.ToInt16(dataReader.GetValue(3));
                    string mdp = Convert.ToString(dataReader.GetValue(4));
                    Patient temp = new Patient(id, nom, dateNaissance, sexe, mdp);

                    listProd.Add(temp);
                }
                dataReader.Close();
                // command.ExecuteNonQuery();
                command.Dispose();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }

            }
            tabMed = new Patient[listProd.Count];
            tabMed = listProd.ToArray();
            return tabMed;

        }
        public Patient[] findPatient(string table, string where)
        {
            Patient[] listProd = null;
            Connexion cnn = new Connexion();
            SqlConnection con = cnn.ConnectDB();
            try
            {
                listProd = this.findPatient(con, table, where);
                // return listProd;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return listProd;
        }

        public void insertPatient(SqlConnection con, Patient ajout)
        {
            SqlCommand command;
            string sql = null;
            Fonction fon = new Fonction();
            try
            {
                sql = "insert into Patient  values('" + fon.getSeq(pre, "seq_Patient") + "','" + ajout.Nom + "','" + ajout.DateNaissance + "','" + ajout.Sexe + "','" + ajout.Mdp + "')";
                Console.WriteLine(sql);
                con.Open();

                command = new SqlCommand(sql, con);

                command.ExecuteNonQuery();
                command.Dispose();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }

        }
        public void insertPatient(Patient ajout)
        {
            Connexion temp = new Connexion();
            SqlConnection connex = temp.ConnectDB();
            try
            {
                insertPatient(connex, ajout);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (connex != null)
                {
                    connex.Close();
                }
            }
        }
    }
}
