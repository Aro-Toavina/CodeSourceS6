﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SanteDataPredict
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        /// 
        /*public static void Main(string[] args)
        {
            Connexion con = new Connexion();
            SqlConnection co =  con.ConnectDB();

           // Controller cont = new Controller();
            Utilitaire outil = new Utilitaire();
            MaladieDAO dao = new MaladieDAO();
            Maladie[] list = dao.findMaladie("Maladie", "2<5");
            MaladieDetailDAO MaladieDetailDao = new MaladieDetailDAO();
            MaladieDetail[] list2 = MaladieDetailDao.findMaladieDetail("MaladieDetail", "idMaladie = 'MAL0002' and typeCause = 0");
            try
            {
                foreach (Maladie temp in list)
                {
                    Console.WriteLine("id: "+temp.Id+ " Libelle: " + temp.Nom );
                }
                Console.WriteLine("############## Maladie: " );
                foreach (MaladieDetail temp in list2)
                {
                    Console.WriteLine("id: " + temp.Id + " Libelle: " + temp.IdCritere + " | " + temp.TypeCause);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        } */
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new identification());
        }
       
    }
}
