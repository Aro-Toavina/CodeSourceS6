﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class MaladieDAO
    {
        string pre = "MLD";
        public string Pre
        {
            get { return pre; }
            set { pre = value; }
        }
        public Maladie[] findMaladie(SqlConnection con, string table, string where)
        {
            Maladie[] tabMed;
            List<Maladie> listProd = new List<Maladie>();
            string sql = null;
            SqlCommand command;
            SqlDataReader dataReader;
            try
            {
                sql = "select * from " + table + " where 1<2 and " + where;

                con.Open();

                command = new SqlCommand(sql, con);

                dataReader = command.ExecuteReader();
                // Utilitaire getdat = new Utilitaire();
                while (dataReader.Read())
                {
                    string id = Convert.ToString(dataReader.GetValue(0));
                    string nom = Convert.ToString(dataReader.GetValue(1));
                    
                    Maladie temp = new Maladie(id, nom);

                    listProd.Add(temp);
                }
                dataReader.Close();
                // command.ExecuteNonQuery();
                command.Dispose();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }

            }
            tabMed = new Maladie[listProd.Count];
            tabMed = listProd.ToArray();
            return tabMed;

        }
        public Maladie[] findMaladie(string table, string where)
        {
            Maladie[] listProd = null;
            Connexion cnn = new Connexion();
            SqlConnection con = cnn.ConnectDB();
            try
            {
                listProd = this.findMaladie(con, table, where);
                // return listProd;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return listProd;
        }

        public void insertMaladie(SqlConnection con, Maladie ajout)
        {
            SqlCommand command;
            string sql = null;
            Fonction fon = new Fonction();
            try
            {
                sql = "insert into Maladie  values('" + fon.getSeq(pre, "seq_Maladie") + "','" + ajout.Nom + "')";
                Console.WriteLine(sql);
                con.Open();

                command = new SqlCommand(sql, con);

                command.ExecuteNonQuery();
                command.Dispose();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }

        }
        public void insertMaladie(Maladie ajout)
        {
            Connexion temp = new Connexion();
            SqlConnection connex = temp.ConnectDB();
            try
            {
                insertMaladie(connex, ajout);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (connex != null)
                {
                    connex.Close();
                }
            }
        }
    }
}
