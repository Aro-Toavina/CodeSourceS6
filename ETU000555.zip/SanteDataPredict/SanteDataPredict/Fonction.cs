﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Fonction
    {
        public string GetNumberMonth(string text)
        {
            string retour = "";

            switch (text)
            {
                case "Janvier":
                    retour = "01";
                    break;
                case "Février":
                    retour = "02";
                    break;
                case "Mars":
                    retour = "03";
                    break;
                case "Avril":
                    retour = "04";
                    break;
                case "Mai":
                    retour = "05";
                    break;
                case "Juin":
                    retour = "06";
                    break;
                case "Juillet":
                    retour = "07";
                    break;
                case "Août":
                    retour = "08";
                    break;
                case "Septembre":
                    retour = "09";
                    break;
                case "Octobre":
                    retour = "10";
                    break;
                case "Novembre":
                    retour = "11";
                    break;
                case "Décembre":
                    retour = "12";
                    break;
                default:
                    throw new Exception("Erreur de mois");
            }
            return retour;
        }
        public string GetMonth(int text)
        {
            string retour = "";

            switch (text)
            {
                case 1:
                    retour = "Janvier";
                    break;
                case 2:
                    retour = "Février";
                    break;
                case 3:
                    retour = "Mars";
                    break;
                case 4:
                    retour = "Avril";
                    break;
                case 5:
                    retour = "Mai";
                    break;
                case 6:
                    retour = "Juin";
                    break;
                case 7:
                    retour = "Juillet";
                    break;
                case 8:
                    retour = "Août";
                    break;
                case 9:
                    retour = "Septembre";
                    break;
                case 10:
                    retour = "Octobre";
                    break;
                case 11:
                    retour = "Novembre";
                    break;
                case 12:
                    retour = "Décembre";
                    break;
                default:
                    throw new Exception("Erreur de mois");
            }
            return retour;
        }

        public void dropSeq(SqlConnection con, string seq)
        {
            string sql = null;

            SqlCommand command;

            try
            {
                sql = "drop sequence " + seq;
                con.Open();
                command = new SqlCommand(sql, con);
                command.ExecuteNonQuery();
                command.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        public void initSeq(SqlConnection con, string seq)
        {
            string sql = null;

            SqlCommand command;

            try
            {
                sql = "create sequence " + seq + " start with 1 increment by 1";
                con.Open();
                command = new SqlCommand(sql, con);
                command.ExecuteNonQuery();
                command.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        public string concat(string pre, string valeur)
        {
            int val = Convert.ToInt32(valeur);
            string retour = null;
            if (val < 10)
            {
                retour = pre + "000" + val;
            }
            else if (val >= 10 && val < 100)
            {
                retour = pre + "00" + val;
            }
            else if (val >= 100 && val < 1000)
            {
                retour = pre + "0" + val;
            }
            return retour;
        }
        public string getSeq(SqlConnection con, string pre, string seq)
        {
            string sql = null;
            int retour = 0;
            string retour1 = null;
            SqlCommand command;
            SqlDataReader dataReader;
            try
            {
                sql = "select next value for " + seq;
                con.Open();
                command = new SqlCommand(sql, con);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    retour = Convert.ToInt32(dataReader.GetValue(0));
                    Console.WriteLine("Anaty boucle = " + retour); break;
                }
                Console.WriteLine("First = " + retour);
                retour1 = concat(pre, "" + retour);
                Console.WriteLine("Second = " + retour);
                dataReader.Close();
                //command.ExecuteNonQuery();
                command.Dispose();
                return retour1;
                //dataReader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return retour1;
        }
        public string getSeq(string pre, string seq)
        {
            string retour = null;

            Connexion temp = new Connexion();
            SqlConnection con = temp.ConnectDB();
            try
            {
                retour = getSeq(con, pre, seq);//Console.WriteLine("NY Tokony ho azo === " +retour);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return retour;
        }

    }
}
