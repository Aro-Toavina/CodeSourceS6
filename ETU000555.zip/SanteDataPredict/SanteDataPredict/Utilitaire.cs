﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Utilitaire
    {
        public Point getPointIntersection(EquationDroite d, Point a)
        {
            float xC = 0;
            float yC = 0;
            EquationDroite f = getEquationPerpendiculaire(d, a);
            if (((float)f.A - (float)d.A) == 0 || (float)f.A == 0 || (float)d.A == 0)
            {
                throw new Exception("getPointfloatersection = Erreur avec division par Zéro!!!");
            }
            /*if (((float)d.A * (float)f.A) != -1)
            {
                throw new Exception("Les deux droites ne sont pas perpendiculaire( "+d.getEquation("d")+" et "+f.getEquation("f")+" ) ");
            }*/
           
            float num = (float)d.B - (float)f.B;
            float denom = (float)f.A - (float)d.A;
            xC = num / denom;
            yC = (float)f.A * xC + (float)f.B;

            return new Point(Convert.ToInt16(xC), Convert.ToInt16(yC));
        }
        public EquationDroite getEquationPerpendiculaire(EquationDroite d, Point a)
        {
            if ((float)d.A == 0)
            {
                d.A = (float)Configuration.TAILLE_PANEL/ (float)2;
               // throw new Exception("getEquationPerpendiculaire = Erreur avec division par Zéro!!!");
            }
            float coeff = (float)-1 / (float)d.A;  //aF
            float constant = (float)a.Y - ((float)coeff * (float)a.X) ;
            return new EquationDroite(coeff, constant);
        }
        public EquationDroite getEquationDroiteD(Point a, Point b)
        {
            float constante = 0;
            float coeff = getCoefficientDirecteur(a, b);

            constante = (float)b.Y - ((float)coeff * (float)b.X);

            return new EquationDroite(coeff, constante);
        }
        public float getCoefficientDirecteur(Point a, Point b)
        {
            float retour = 0;
            float numerateur = ((float)b.Y - (float)a.Y);
            float denominateur = ((float)b.X - (float)a.X);
            Console.WriteLine("bX - aX = " + ((float)b.X)+" - "+ ((float)a.X));
            Console.WriteLine("denominateur = " + denominateur);
            if (denominateur == 0)
            {
                throw new Exception("getCoefficientDirecteur = Erreur avec division par Zéro!!!");
            }
            
            retour = numerateur / denominateur;
            

            return retour;
        }
        public float calculDistanceEntreDeuxPoints(Point a, Point b)
        {
            double retour = 0;
          
            retour = Math.Sqrt(Math.Pow((double)b.X - (double)a.X, 2) + Math.Pow((double)b.Y - (double)a.Y, 2));

            return (float)retour;
        }
        public double getValeurMoyenne(double min, double max)
        {
            double ret = 0;
            ret = (max + min)/(double)2;
            return ret;
        }
        
    }
}
