﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Connexion
    {
        SqlConnection cnx;
        public SqlConnection Cnx
        {
            get { return cnx; }
            set { cnx = value; }
        }

        public SqlConnection ConnectDB()
        {
            string connect = null;
            SqlConnection cnn;
            connect = "Data Source=DESKTOP-OT8HRVQ\\ITU;Initial Catalog=santelast1;Integrated Security=True;";
            cnn = new SqlConnection(connect);
           // Console.WriteLine("Connexion etablie");
            cnx = cnn;
            return cnn;
        }
        public SqlConnection ConnectDB(string dataSource, string database, string name, string pwd)
        {
            string connect = null;
            SqlConnection cnn;
            connect = "Data Source="+ dataSource + ";Initial Catalog="+ database + ";Integrated Security=True;User Id=" + name+";Password="+pwd+";";
            cnn = new SqlConnection(connect);
            cnx = cnn;
            return cnn;
        }
    }
}
