﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Patient
    {
        string _id;
        string _nom;
        string _dateNaissance;
        int _sexe;
        string _mdp;
        
        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string Nom
        {
            set { this._nom = value; }
            get { return this._nom; }
        }
        public string DateNaissance
        {
            set { this._dateNaissance = value; }
            get { return this._dateNaissance; }
        }
        public int Sexe
        {
            set { this._sexe = value; }
            get { return this._sexe; }
        }
        public string Mdp
        {
            set { this._mdp = value; }
            get { return this._mdp; }
        }
        public Patient() { }
        public Patient(string id, string nom, string date, int sexe, string mdp)
        {
            this._id = id;
            this.Nom = nom;
            this.DateNaissance = date;
            this.Sexe = sexe;
            this.Mdp = mdp;
        }
        public Patient( string nom, string date, int sexe, string mdp)
        {
            this.Nom = nom;
            this.DateNaissance = date;
            this.Sexe = sexe;
            this.Mdp = mdp;
        }
    }
}
