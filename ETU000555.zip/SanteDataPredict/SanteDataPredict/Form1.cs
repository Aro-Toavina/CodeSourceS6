﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SanteDataPredict
{
    public partial class Form1 : Form
    {
        //MODEL
        private Patient user;
        private CritereDAO critereDAO = new CritereDAO();
        private CritereDetailDAO critereDetailDAO = new CritereDetailDAO();
        private UniteDAO uniteDAO = new UniteDAO();
        private MaladieDAO maladieDAO = new MaladieDAO();
        private MaladieDetailDAO maladieDetailDAO = new MaladieDetailDAO();
        private PatientDAO patientDAO = new PatientDAO();
        private MaladiePredit personneNormal = new MaladiePredit();
        //VARIABLE
        private Critere[] critereList = null;
        private CritereDetail[] critereDetailList = null;
        private CritereDetail[] normalePatient = null;
        private Unite[] uniteList = null;
        private Maladie[] maladieList = null;
        private MaladieDetail[] maladieDetailList = null;

        private ValeurCritere[] tableauDesValeurs = new ValeurCritere[Configuration.NOMBRE_AXE];
        private List<ValeurCritere> critereTsyNormale = null;
        //CONTROLLER
        private Controller controller = null;

        private int widthForm;
        private int heightForm;
        private int rayon;

        private int pointMiovaX = 0;
        private int pointMiovaY = 0;
        private List<Point> points;
        private List<Point> lines;
        private Point[] listePoints;
        private Point[] listeLines;
        private Label[] listeLabel;

        private float[] tableauCritere;
        private bool validPoint = false;
        private int indiceCLick = -2;
        private Point origine = new Point(400, 400);
        private Point origine2 = new Point(Configuration.TAILLE_PANEL / 2 + Configuration.DECALE, Configuration.TAILLE_PANEL / 2 + Configuration.DECALE);
        Utilitaire outil = new Utilitaire();
        private string[] informationCritere;
        public Form1(Patient ret)
        {
            this.user = ret;
            this.critereList = critereDAO.findCritere("Critere", "2<3");

            this.uniteList = uniteDAO.findUnite("Unite", "2<3");
            this.maladieList = maladieDAO.findMaladie("Maladie", "2<3");
            this.maladieDetailList = maladieDetailDAO.findMaladieDetail("MaladieDetail", "2<3");
            this.critereDetailList = critereDetailDAO.findCritereDetail("CritereDetail", "2<3");
            this.controller = new Controller(this.critereList, this.uniteList, this.maladieList, this.maladieDetailList, this.critereDetailList);

            this.normalePatient = this.controller.getValeurNormalePersonne(user);
            //this.personneNormal = controller.getValeurNormalePersonne(this.critereList, this.user);


            InitializeComponent();//////////////////:***************:////////////////////

            DateTime daty = Convert.ToDateTime(user.DateNaissance);
            this.Nom.Text = user.Nom;
            int age = DateTime.Now.Year - daty.Year;
            this.Age.Text = age.ToString() + " ans";
            // MessageBox.Show("votre sexe : "+ user.Sexe);
            this.SexeInfo.Text = user.Sexe == 1 ? "Mâle" : "Femele";

            this.widthForm = Configuration.TAILLE_PANEL + Configuration.DECALE;
            this.heightForm = Configuration.TAILLE_PANEL + Configuration.DECALE;
            listePoints = new Point[Configuration.NOMBRE_AXE];
            listeLines = new Point[Configuration.NOMBRE_AXE];
            tableauCritere = new float[Configuration.NOMBRE_AXE];
            points = new List<Point>();
            lines = new List<Point>();
            rayon = this.widthForm / 2;

            /*try
             {
                 //EquationDroite d = outil.getEquationDroiteD(new Point(-3, 5), new Point(4, -2));
                 //EquationDroite f = outil.getEquationPerpendiculaire(d, new Point(-1, 5));
                 float i = outil.calculDistanceEntreDeuxPoints(new Point(1, 1), new Point(1, 4));
                 float r = outil.calculDistanceEntreDeuxPoints(new Point(1, 4), new Point(1, 1));
                 MessageBox.Show(" distance entre "+ new Point(1, 1) +" à "+ new Point(1, 4) +" =  " + i +"\n distance entre " + new Point(1, 4) + " à " + new Point(1, 1) + " =  " + i);
             }
             catch (Exception e)
             {
                 MessageBox.Show(e.Message);
             }
             */


        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen repere = new Pen(Color.Black);
            Pen cercleLimite = new Pen(Color.Blue, 1);
            Pen graphe = new Pen(Color.Red, 1);

            int myWidth = widthForm;//+ 138;
            int myHeight = heightForm;//+ 103;

            // this.initLines(g);
            // setPointTest2(g);
            this.initPoints(g);

            initListLabel();


            g.Dispose();
        }
        public int getIndicePoints(Point pt)
        {
            for (int i = 0; i < listePoints.Length; i++)
            {
                if (listePoints[i] == pt)
                {
                    return i;
                }
            }
            return -1;
        }
        public Point[] insertAtListePoints(List<Point> liste, Point pt, int indice)
        {
            List<Point> nouveau = new List<Point>();
            for (int i = 0; i < liste.Count; i++)
            {
                nouveau.Add(liste[i]);
                if (indice == i)
                {
                    nouveau.Add(pt);
                }
            }
            return nouveau.ToArray();
        }
        public void initListLabel()
        {
            this.informationCritere = initInformation();
            // 
            // label1
            // 
            this.listeLabel = new Label[Configuration.NOMBRE_AXE];
            for (int i = 0; i < Configuration.NOMBRE_AXE; i++)
            {
                listeLabel[i] = new Label();
                this.listeLabel[i].AutoSize = true;
                //this.listeLabel[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 10, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                this.listeLabel[i].Location = new System.Drawing.Point(points[i].X <= rayon ? points[i].X - 80 : points[i].X + 10, points[i].Y <= rayon ? points[i].Y - 15 : points[i].Y + 10);
                this.listeLabel[i].Name = "information" + (i + 1);
                //this.label1.Size = new System.Drawing.Size(220, 25);
                //this.label1.TabIndex = 0;
                this.listeLabel[i].Text = informationCritere[i];
                //this.listeLabel[i].Click += new System.EventHandler(this.label1_Click);

                this.panel3.Controls.Add(listeLabel[i]);
            }


        }
        public string[] initInformation()
        {
            List<string> list = new List<string>();
            foreach (Critere mal in critereList)
            {
                list.Add(mal.Nom);
            }
            return list.ToArray();
        }

        public EquationDroite getDroiteD(Point pasOrigine)
        {
            Point origine = new Point(this.widthForm / 2 + Configuration.DECALE, this.heightForm / 2 + Configuration.DECALE);
            Console.WriteLine("Point Origine = " + origine);
            Console.WriteLine("EquationDroite (d)" + outil.getEquationDroiteD(origine, pasOrigine).getEquation("D"));
            return outil.getEquationDroiteD(origine, pasOrigine);
        }

        public void initPoints(Graphics g)
        {
            //MessageBox.Show("point = "+points);
            if (points.Count == 0)
            {
                int x1 = rayon + Configuration.DECALE;
                int y1 = rayon + Configuration.DECALE;
                // Console.WriteLine("Hello World1!!! ");
                for (int i = 0; i < Configuration.NOMBRE_AXE; i++)
                {

                    setPointTest(g, new Pen(Color.Black, 1), i);
                    Console.WriteLine("Point = " + points.ElementAt(i));

                    listePoints[i] = points.ElementAt(i);

                    float distanceOM = outil.calculDistanceEntreDeuxPoints(points.ElementAt(i), new Point(this.widthForm / 2 + Configuration.DECALE, this.heightForm / 2 + Configuration.DECALE));
                   //Console.WriteLine("Pourcentage = "+this.getPoucentage(distanceOM));
                   // double valeur = this.getPoucentage(distanceOM);
                    double valeur = Convert.ToDouble(this.controller.valeurVariationParPourcentage(this.critereList.ElementAt(i).Id, user.Sexe, Math.Round(this.getPoucentage(distanceOM), 2)));
                    tableauDesValeurs[i] = new ValeurCritere(i, valeur);


                }
                listeLines = lines.ToArray();
                g.FillPolygon(new SolidBrush(Color.Gold), listePoints);
                //relierPoints(g);
                for (int i = 0; i < Configuration.NOMBRE_AXE; i++)
                {

                    int k = i + 1;

                    if (k > Configuration.NOMBRE_AXE - 1)
                    {
                        k = 0;

                    }
                    g.DrawLine(new Pen(Color.WhiteSmoke, 2), listePoints[i].X, listePoints[i].Y, listePoints.ElementAt(k).X, listePoints.ElementAt(k).Y);


                    g.DrawLine(new Pen(Color.Black, 1), x1, y1, listePoints[i].X, listePoints[i].Y);
                    // g.FillEllipse(Brushes.Red, listePoints[i].X - 5, listePoints[i].Y - 2, 10, 10);
                }
                //myfunction();
            }
            else
            {

                if (indiceCLick >= 0)
                {
                    //validPoint = true;
                    Point miova = new Point(pointMiovaX, pointMiovaY);
                    EquationDroite d = null;
                    EquationDroite f = null;
                    double[] minmax = new double[2];
                    try
                    {
                        Console.WriteLine("Points voa cliquer  = " + listePoints[indiceCLick]);
                        d = this.getDroiteD(listePoints[indiceCLick]);

                        f = outil.getEquationPerpendiculaire(d, miova);

                        miova = this.outil.getPointIntersection(d, miova);

                        Console.WriteLine("Distance entre deux pts = " + outil.calculDistanceEntreDeuxPoints(origine2, miova));
                        this.nomCritere.Text = this.informationCritere[indiceCLick];

                        listePoints[indiceCLick] = miova;

                        float distanceOM = outil.calculDistanceEntreDeuxPoints(miova, new Point(this.widthForm / 2 + Configuration.DECALE, this.heightForm / 2 + Configuration.DECALE));
                        //double valeur = this.getPoucentage(distanceOM);
                        double valeur = Convert.ToDouble(this.controller.valeurVariationParPourcentage(this.critereList.ElementAt(indiceCLick).Id, user.Sexe, Math.Round(this.getPoucentage(distanceOM), 2)));
                        tableauDesValeurs[indiceCLick] = new ValeurCritere(indiceCLick, valeur);

                        // MessageBox.Show("Voici l'indice modifier = " + indiceCLick + "\n\t puis pointNiova(" + new Point(pointMiovaX, pointMiovaY) + ")");

                        g.FillPolygon(new SolidBrush(Color.Gold), listePoints);
                        int x1 = rayon + Configuration.DECALE;
                        int y1 = rayon + Configuration.DECALE;
                        // Console.WriteLine("Hello World1!!! ");
                        for (int i = 0; i < Configuration.NOMBRE_AXE; i++)
                        {

                            int k = i + 1;

                            if (k > 13)
                            {
                                k = 0;

                            }
                            g.DrawLine(new Pen(Color.WhiteSmoke, 2), listePoints[i].X, listePoints[i].Y, listePoints.ElementAt(k).X, listePoints.ElementAt(k).Y);


                            g.DrawLine(new Pen(Color.Black, 1), x1, y1, listePoints[i].X, listePoints[i].Y);
                            // g.FillEllipse(Brushes.Red, listePoints[i].X - 5, listePoints[i].Y - 2, 10, 10);
                        }
                        //myfunction();
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message);
                    }
                }

            }


        }
        public void controllerDistance(Point miova, Point origine)
        {

            float distanceOM = outil.calculDistanceEntreDeuxPoints(miova, origine);
            if (distanceOM < 20 || distanceOM > (this.widthForm / 2) - 3)
            {

                this.validPoint = false;
            }

        }
        public double calculCoordY(int height, int rayon, double angle)
        {
            double retour = 0;
            double hauteur = Convert.ToDouble(height);
            double r = Convert.ToDouble(rayon);

            retour = (hauteur / Convert.ToDouble(2)) - r * Math.Sin(angle);

            return retour;
        }
        public double calculCoordX(int width, int rayon, double angle)
        {
            double retour = 0;
            double hauteur = Convert.ToDouble(width);
            double r = Convert.ToDouble(rayon);

            retour = (hauteur / Convert.ToDouble(2)) + r * Math.Cos(angle);

            return retour;
        }



        public void setPointTest(Graphics g, Pen pen, int fois)
        {

            int rayon1 = Convert.ToInt32(rayon);
            int rayon2 = Convert.ToInt32(rayon);
            double angle = Convert.ToDouble(Math.PI * 2) / Convert.ToDouble(Configuration.NOMBRE_AXE);
            angle += angle * Convert.ToDouble(fois);
            //Console.WriteLine("this.widthForm = "+this.heightForm);

            int x1 = rayon + Configuration.DECALE;
            int y1 = rayon + Configuration.DECALE;
            int x2 = Convert.ToInt32(calculCoordX(this.heightForm, rayon1, angle));
            int y2 = Convert.ToInt32(calculCoordY(this.widthForm, rayon2, angle));
            Console.WriteLine(x2 + " = " + y2);


            points.Add(new Point(x2 + Configuration.DECALE, y2 + Configuration.DECALE));

            if (lines.Count != Configuration.NOMBRE_AXE)
            {
                lines.Add(new Point(x2 + Configuration.DECALE, y2 + Configuration.DECALE));
            }


        }
        public void setPointTest2(Graphics g)
        {

            int rayon1 = Convert.ToInt32(this.widthForm / 2);
            int rayon2 = Convert.ToInt32(this.heightForm / 2);
            double angle = Convert.ToDouble(Math.PI) / Convert.ToDouble(7);

            for (int i = 0; i < listeLines.Length; i++)
            {
                angle += angle * Convert.ToDouble(Configuration.NOMBRE_AXE);
                Console.WriteLine("this.widthForm = " + this.heightForm);

                int x1 = this.widthForm / 2;
                int y1 = this.heightForm / 2;
                int x2 = Convert.ToInt32(calculCoordX(this.heightForm, rayon1, angle));
                int y2 = Convert.ToInt32(calculCoordY(this.widthForm, rayon2, angle));

                g.DrawLine(new Pen(Color.Black, 1), x1, y1, listeLines[i].X, listeLines[i].Y);
            }


        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (this.validPoint)
            {
                pointMiovaX = e.X;
                pointMiovaY = e.Y;
                this.controllerDistance(new Point(pointMiovaX, pointMiovaY), new Point(this.widthForm / 2 + Configuration.DECALE, this.heightForm / 2 + Configuration.DECALE));
                float distanceOM = outil.calculDistanceEntreDeuxPoints(new Point(pointMiovaX, pointMiovaY), new Point(this.widthForm / 2 + Configuration.DECALE, this.heightForm / 2 + Configuration.DECALE));

                //poucentage.Text = Math.Round(this.getPoucentage(distanceOM), 2).ToString();

                double[] minmax = new double[2];
                minmax = this.controller.getValeurMinMax(this.critereList.ElementAt(indiceCLick).Id, user.Sexe);
                this.valeurNormaleMin.Text = minmax[0].ToString();
                this.valeurNormaleMax.Text = minmax[1].ToString();
                this.poucentage.Text = this.controller.valeurVariationParPourcentage(this.critereList.ElementAt(indiceCLick).Id, user.Sexe, Math.Round(this.getPoucentage(distanceOM), 2));
                this.unite.Text = this.controller.getUniteByIdUnite(this.critereList.ElementAt(indiceCLick).IdUnite);
                this.unite2.Text = this.controller.getUniteByIdUnite(this.critereList.ElementAt(indiceCLick).IdUnite);
                // MessageBox.Show("Min - max = " + minmax[0] + " - " + minmax[1]);
                
                this.panel3.Refresh();
            }

        }

        public int betweenPointEvent(MouseEventArgs e, Point[] lists)
        {
            int x = e.X;
            int y = e.Y;

            for (int i = 0; i < lists.Length; i++)
            {
                if (x - 10 <= lists[i].X && x + 10 > lists[i].X && y - 10 <= lists[i].Y && y + 10 > lists[i].Y)
                {
                    return i;
                }
            }
            return -1;
        }
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {

            int indice = betweenPointEvent(e, listePoints);
            if (indice != -1)
            {

                Console.WriteLine("Click point IN");
                Console.WriteLine("\t >> point (" + pointMiovaX + " ," + pointMiovaY + ")");
                this.indiceCLick = indice;

                this.validPoint = true;
            }
            else
            {
                Console.WriteLine("Click point OUT");
            }

        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            indiceCLick = -1;
            this.validPoint = false;
        }

        public float getPoucentage(float distance)
        {
            float num = (float)100 * distance;
            float denom = (float)rayon;
            float ret = num / denom;
            return ret >= 100 ? 100 : ret <= 10 ? 10 : ret;
        }

        private void nomCritere_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void analyserButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("L'analyse a été lancée!!!");
            critereTsyNormale = new List<ValeurCritere>();

            foreach (ValeurCritere val in this.tableauDesValeurs)
            {
                int indice = controller.getIndice(normalePatient, normalePatient[val.IndiceCritere].IdCritere);
                if (indice == val.IndiceCritere)
                {
                    //Console.WriteLine("if checkCritere = "+ this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user));
                    if (this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user) == 1)
                    {
                        critereTsyNormale.Add(new ValeurCritere(val.IndiceCritere, val.Valeur, 1));
                    }
                    if (this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user) == -1)
                    {
                        critereTsyNormale.Add(new ValeurCritere(val.IndiceCritere, val.Valeur, 0));
                    }
                }

                Console.WriteLine("Critere::" + critereList[val.IndiceCritere].Nom + "\t | \ttableauDesValeurs[" + val.IndiceCritere + "] = " + val.Valeur);
            }
            MaladieRisque[] egale = controller.getPourcentageDeRisque(critereTsyNormale.ToArray(), this.user);

            egale = egale.ToList().OrderByDescending(element => element.PourcentageRisque).ToArray();
            Console.WriteLine("TAILLE =====> "+egale.Length);
            foreach (MaladieRisque val in egale)
            {
                Console.WriteLine("===\t Pourcentage maladie =  "+ controller.getNomMaladie(val.IdMaladie) + " | \t = " + val.PourcentageRisque + " % ");
            }
            this.risque1.Text = controller.getNomMaladie(egale[0].IdMaladie);
                this.valeurRisque1.Text = Math.Round(egale[0].PourcentageRisque, 2).ToString();
            this.risque2.Text = controller.getNomMaladie(egale[1].IdMaladie);
                this.valeurRisque2.Text = Math.Round(egale[1].PourcentageRisque, 2).ToString();
            this.risque3.Text = controller.getNomMaladie(egale[2].IdMaladie);
                this.valeurRisque3.Text = Math.Round(egale[2].PourcentageRisque, 2).ToString();

        }
        public void myfunction()
        {
            critereTsyNormale = new List<ValeurCritere>();

            foreach (ValeurCritere val in this.tableauDesValeurs)
            {
                int indice = controller.getIndice(normalePatient, normalePatient[val.IndiceCritere].IdCritere);
                if (indice == val.IndiceCritere)
                {
                    //Console.WriteLine("if checkCritere = "+ this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user));
                    if (this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user) == 1)
                    {
                        critereTsyNormale.Add(new ValeurCritere(val.IndiceCritere, val.Valeur, 1));
                    }
                    if (this.controller.checkCritereNormale(normalePatient[val.IndiceCritere].IdCritere, val.Valeur, this.user) == -1)
                    {
                        critereTsyNormale.Add(new ValeurCritere(val.IndiceCritere, val.Valeur, 0));
                    }
                }

                Console.WriteLine("Critere::" + critereList[val.IndiceCritere].Nom + "\t | \ttableauDesValeurs[" + val.IndiceCritere + "] = " + val.Valeur);
            }
            MaladieRisque[] egale = controller.getPourcentageDeRisque(critereTsyNormale.ToArray(), this.user);
            foreach (MaladieRisque val in egale)
            {
                Console.WriteLine("===\t Pourcentage maladie =  " + controller.getNomMaladie(val.IdMaladie) + " | \t = " + val.PourcentageRisque + " % ");
            }
            this.risque1.Text = controller.getNomMaladie(egale[0].IdMaladie);
            this.valeurRisque1.Text = Math.Round(egale[0].PourcentageRisque, 2).ToString();
            this.risque2.Text = controller.getNomMaladie(egale[2].IdMaladie);
            this.valeurRisque2.Text = Math.Round(egale[2].PourcentageRisque, 2).ToString();
            this.risque3.Text = controller.getNomMaladie(egale[4].IdMaladie);
            this.valeurRisque3.Text = Math.Round(egale[4].PourcentageRisque, 2).ToString();
        }
    }
}
