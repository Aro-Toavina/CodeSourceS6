﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class MaladieRisque
    {
        private string _idMaladie;
        private double _pourcentageRisque;

        public string IdMaladie
        {
            set { this._idMaladie = value; }
            get { return this._idMaladie; }
        }
        public double PourcentageRisque
        {
            set { this._pourcentageRisque = value; }
            get { return this._pourcentageRisque; }
        }
        public MaladieRisque() { }
        public MaladieRisque(string idMaladie, double risque)
        {
            this.IdMaladie = idMaladie;
            this.PourcentageRisque = risque;
        }
    }
}
