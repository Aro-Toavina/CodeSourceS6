﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class CritereDetail
    {
        string _id;
        string _idCritere;
        double _valeurNormalmin;
        double _valeurNormalmax;
        int _sexe;
        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string IdCritere
        {
            set { this._idCritere = value; }
            get { return this._idCritere; }
        }
        public double ValeurNormalmin
        {
            set {
                if (value >= 0)
                {
                    this._valeurNormalmin = value;
                }
                else
                {
                    throw new Exception("Valeur Normal min negatif!!!");
                }
            }
            get { return this._valeurNormalmin; }
        }
        public double ValeurNormalmax
        {
            set
            {
                if (value >= 0)
                {
                    this._valeurNormalmax = value;
                }
                else
                {
                    throw new Exception("Valeur Normal max negatif!!!");
                }
            }
            get { return this._valeurNormalmax; }
        }
        public int SexeSpecifique
        {
            set { this._sexe = value; }
            get { return this._sexe; }
        }
        public CritereDetail(string id, string idCritere, double valeurMin, double valeurMax, int sexe)
        {
            this.Id = id;
            this.IdCritere = idCritere;
            this.ValeurNormalmin = valeurMin;
            this.ValeurNormalmax = valeurMax;
            this.SexeSpecifique = sexe;
        }
        public CritereDetail( string idCritere, double valeurMin, double valeurMax, int sexe)
        {
            this.IdCritere = idCritere;
            this.ValeurNormalmin = valeurMin;
            this.ValeurNormalmax = valeurMax;
            this.SexeSpecifique = sexe;
        }
    }
}
