﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class MaladiePredit
    {
        private Critere[] _tableauCritere;
                
        public Critere[] TableauCritere
        {
            set {
                if (value.Length!=0) {
                    this._tableauCritere = value;
                }
                else
                {
                    throw new Exception("le tableau des criteres est vide!!!");
                }
            }
            get
            {
                return this._tableauCritere;
            }
        }
      
        public MaladiePredit() { }
        public MaladiePredit(Critere[] tableauCritere)
        {
          
            this.TableauCritere = tableauCritere;
       
        }
    }
}
