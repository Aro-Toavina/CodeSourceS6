﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Unite
    {
        string _id;
        string _libelle;
        string _indice;
        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string Libelle
        {
            set { this._libelle = value; }
            get { return this._libelle; }
        }
        public string Indice
        {
            set { this._indice = value; }
            get { return this._indice; }
        }
        public Unite() { }
        public Unite(string id, string libelle, string indice)
        {
            this.Id = id;
            this.Libelle = libelle;
            this.Indice = indice;
        }
        public Unite(string libelle, string indice)
        {
            this.Libelle = libelle;
            this.Indice = indice;
        }
    }
}
