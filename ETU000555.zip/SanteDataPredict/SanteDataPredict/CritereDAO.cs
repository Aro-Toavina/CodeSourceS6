﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class CritereDAO
    {
        string pre = "CTR";
        public string Pre
        {
            get { return pre; }
            set { pre = value; }
        }
        public Critere[] findCritere(SqlConnection con, string table, string where)
        {
            Critere[] tabMed;
            List<Critere> listProd = new List<Critere>();
            string sql = null;
            SqlCommand command;
            SqlDataReader dataReader;
            try
            {
                sql = "select * from " + table + " where 1<2 and " + where;

                con.Open();

                command = new SqlCommand(sql, con);

                dataReader = command.ExecuteReader();
                // Utilitaire getdat = new Utilitaire();
                while (dataReader.Read())
                {
                    string id = Convert.ToString(dataReader.GetValue(0));
                    string nom = Convert.ToString(dataReader.GetValue(1));
                    string idUnite = Convert.ToString(dataReader.GetValue(2));
                    Critere temp = new Critere(id, nom, idUnite);

                    listProd.Add(temp);
                }
                dataReader.Close();
                // command.ExecuteNonQuery();
                command.Dispose();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
            finally
            {
                if (con!=null)
                {
                    con.Close();
                }
               
            }
            tabMed = new Critere[listProd.Count];
            tabMed = listProd.ToArray();
            return tabMed;

        }
        public Critere[] findCritere(string table, string where)
        {
            Critere[] listProd = null;
            Connexion cnn = new Connexion();
            SqlConnection con = cnn.ConnectDB();
            try
            {
                listProd = this.findCritere(con, table, where);
                // return listProd;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return listProd;
        }

        public void insertCritere(SqlConnection con, Critere ajout)
        {
            SqlCommand command;
            string sql = null;
            Fonction fon = new Fonction();
            try
            {
                sql = "insert into Critere  values('" + fon.getSeq(pre, "seq_Critere") + "','" + ajout.Nom + "','" + ajout.IdUnite + "')";
                Console.WriteLine(sql);
                con.Open();

                command = new SqlCommand(sql, con);

                command.ExecuteNonQuery();
                command.Dispose();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }

        }
        public void insertCritere(Critere ajout)
        {
            Connexion temp = new Connexion();
            SqlConnection connex = temp.ConnectDB();
            try
            {
                insertCritere(connex, ajout);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (connex != null)
                {
                    connex.Close();
                }
            }
        }

    }
}
