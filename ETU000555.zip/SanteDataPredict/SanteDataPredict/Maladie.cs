﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanteDataPredict
{
    public class Maladie
    {
        string _id;
        string _nom;
        

        public string Id
        {
            set { this._id = value; }
            get { return this._id; }
        }
        public string Nom
        {
            set { this._nom = value; }
            get { return this._nom; }
        }
       

        public Maladie() { }
        public Maladie(string id, string nom)
        {
            this.Id = id;
            this.Nom = nom;
        }
        public Maladie( string nom)
        {
            this.Nom = nom;
        }
     
    }
}
