﻿using System;
using System.Linq;
using System.Windows.Forms;
// ...

namespace Sante
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Boolean mouve = false;
        double angle=0;
        double angle_inverse = 0;
      
        private void Form1_Load(object sender, EventArgs e) {

            chart1.ChartAreas[0].AxisY.Maximum = 200;
            chart1.Series["series1"].Points.AddY(30);
            chart1.Series["series1"].Points.ElementAt(0).AxisLabel = "Hématies(globules rouges)";
            chart1.Series["series1"].Points.AddY(75.54);
            chart1.Series["series1"].Points.ElementAt(1).AxisLabel = "Leucocytes(globules blancs)";
            chart1.Series["series1"].Points.AddY(60.45);    
            chart1.Series["series1"].Points.ElementAt(2).AxisLabel = "Plaquettes";
            chart1.Series["series1"].Points.AddY(34.73);
            chart1.Series["series1"].Points.ElementAt(3).AxisLabel = "Gamma GT";
            chart1.Series["series1"].Points.AddY(85.42);
            chart1.Series["series1"].Points.ElementAt(4).AxisLabel = "Phosphatases alcalines";
            chart1.Series["series1"].Points.AddY(55.9);
            chart1.Series["series1"].Points.ElementAt(5).AxisLabel = "Créatininémie";
            chart1.Series["series1"].Points.AddY(63.6);
            chart1.Series["series1"].Points.ElementAt(6).AxisLabel = "Glycémie(taux de sucre dans le sang)";
            chart1.Series["series1"].Points.AddY(55.2);
            chart1.Series["series1"].Points.ElementAt(7).AxisLabel = "Uricémie(taux d'acide urique dans le sang)";
            chart1.Series["series1"].Points.AddY(77.1);
            chart1.Series["series1"].Points.ElementAt(8).AxisLabel = "Cholestérolémie totale";
            chart1.Series["series1"].Points.AddY(50.8);
            chart1.Series["series1"].Points.ElementAt(9).AxisLabel = "Lipasémie";
            chart1.Series["series1"].Points.AddY(180.5);
            chart1.Series["series1"].Points.ElementAt(10).AxisLabel = "Soduim";
            chart1.Series["series1"].Points.AddY(80.2);
            chart1.Series["series1"].Points.ElementAt(11).AxisLabel = "CRP(C.reactive protein)";
            chart1.Series["series1"].Points.AddY(40);
            chart1.Series["series1"].Points.ElementAt(12).AxisLabel = "Amylasémie";
            chart1.Series["series1"].Points.AddY(111);
            chart1.Series["series1"].Points.ElementAt(13).AxisLabel = "ASLO(Anti-Streptolysine)";

            // ControlExtension.Draggable(, true);
            //ControlExtension.Draggable(, true);
        }

        private void chart1_Click(object sender, EventArgs e)
        {

          
        }


        private void chart1_MouseDown(object sender, MouseEventArgs e)

        {
            mouve = true;
        }

        private void chart1_MouseUp(object sender, MouseEventArgs e)

        {
            mouve = false;
        }

        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouve)
            {
                //math.sqrt(((e.X)^2)*((e.Y)^2))
                double Ysourie = (e.Y - 272) * (-1);
                double Xsourie = (e.X - 485) * (-1);

           
                double Yinverse = (e.Y - 272);
                double Xinverse = (e.X - 485);

                double hyp = Math.Sqrt((Math.Abs(Xsourie * Xsourie)) + (Math.Abs(Ysourie * Ysourie)));

                angle_inverse = (Xinverse / Yinverse);
                angle = Xsourie / Ysourie;
                
               /*sourie.Text = e.Y.ToString();
                label45.Text = ((e.Y - 243) * (-1)).ToString();*/
               //inverse.Text = String.Concat(String.Concat("coordonée ",Yinverse.ToString(), " , "), String.Concat(" abscise ", Xinverse.ToString(), " , "));
                //sourie.Text ="sourie  "+ angle.ToString();
               // inverse.Text = "inverse"+ angle_inverse.ToString();
                try
                {
                    double[] tableY = new double[15];
                    tableY[0] = hyp;

                    double[] unite = new double[15];
                    unite[0] = (e.Y - 270) * (-1) * 50000; //max 10.000.000
                    unite[1] = (e.Y - 270) * (-1) * 100;//max 20.000
                    unite[2] = (e.Y - 270) * (-1) * 5000;//max 1.000.000
                    unite[3]= (e.Y - 270) * (-1) * 2;//max 200
                    unite[4] = (e.Y - 270) * 5;//max 200
                    unite[5] = (e.Y - 270)* 2;//max 200
                    unite[6] = (e.Y - 270) / 10;//max 10
                    unite[7] = (e.Y - 270) * 5;//max 1000
                    unite[8] = (e.Y - 270) / 12.5 ;// max 10
                    unite[9] = (e.Y - 270);// max 10
                    unite[10]= (e.Y - 270)*5;//max 200
                    unite[11] = (e.Y - 270)*(-1) / 2;//max 20
                    unite[12] = (e.Y - 270) * (-1);//max 200
                    unite[13] = (e.Y - 270) * (-1)* 2;//max 500

                    double[] axe = new double[45];
                    axe[0] = e.Y - 186;
                    axe[1] = ((e.Y - 146) * (-1));
                    axe[2] = e.Y - 230;
                    axe[3] = (e.Y - 170) * (-1);
                    axe[4] = e.Y - 240;
                    axe[5] = (e.Y - 180) * (-1);
                    axe[6] = (e.Y - 243) * (-1);
                    axe[7] = (e.Y - 295);
                    axe[8] = (e.Y - 330);
                    axe[9] = (e.Y - 318) * (-1);
                    axe[10] = (e.Y - 330);
                    axe[11] = (e.Y - 352);
                    axe[12] = (e.Y - 308) * (-1);
                    axe[13] = (e.Y - 348);
                    axe[14] = (e.Y - 330);
                    axe[15] = (e.Y - 297) * (-1);
                    axe[16] = (e.Y - 299);
                    axe[17] = (e.Y - 249) * (-1);
                    axe[18] = (e.Y - 215) * (-1);
                    axe[19] = (e.Y - 170) * (-1);
                   
                    double[] pourcentages = new double[45];
                    pourcentages[0]= 0;
                    pourcentages[1]= Math.Round(((axe[0] * 100) / 78), 2);
                    pourcentages[2]= Math.Round(((axe[1] * 100) / 73), 2);
                    pourcentages[3]= Math.Round(((axe[2] * 100) / 34), 2);
                    pourcentages[4]= Math.Round(((axe[3] * 100) / 78), 2);
                    pourcentages[5]= Math.Round(((axe[4] * 100) / 24), 2);
                    pourcentages[6] = Math.Round(((axe[5] * 100) / 47), 2);
                    pourcentages[7]= Math.Round(((axe[6] * 100) / 13), 2);
                    pourcentages[8]= Math.Round(((axe[7] * 100) / 23), 2);
                    pourcentages[9]= Math.Round(((axe[8] * 100) / 70), 2);
                    pourcentages[10] = Math.Round(((axe[9] * 100) / 36), 2);
                    pourcentages[11] = Math.Round(((axe[10] * 100) / 123), 2);
                    pourcentages[12]= Math.Round(((axe[11] * 100) / 137), 2);
                    pourcentages[13] = Math.Round(((axe[12] * 100) / 27), 2);
                    pourcentages[14]= Math.Round(((axe[13] * 100) / 110), 2);
                    pourcentages[15]= Math.Round(((axe[14] * 100) / 69), 2);
                    pourcentages[16]= Math.Round(((axe[15] * 100) / 23), 2);
                    pourcentages[17] = Math.Round(((axe[16] * 100) / 20), 2);
                    pourcentages[18]= Math.Round(((axe[17] * 100) / 16), 2);
                    pourcentages[19]= Math.Round(((axe[18] * 100) / 64), 2);
                    pourcentages[20]= Math.Round(((axe[19] * 100) / 76), 2);

                   

                    if (angle < 0.375 && angle > 0.013 && Yinverse < 0)
                   {
                            chart1.Series["series1"].Points.ElementAt(0).YValues = tableY;
                            X_mouse.Text = String.Concat(String.Concat(unite[0].ToString(), " /mm3 "));

                       
                            if (unite[0] >= 4200000 && unite[0] <= 6200000)
                            {
                                label17.Text = "Normal";
                                label31.Text = pourcentages[0].ToString() + " %";
                            }
                            if (unite[0] < 4200000)
                            {
                                label17.Text = "Anémie";
                            
                            if (pourcentages[1] > 100)
                            {
                                label31.Text = pourcentages[0].ToString();
                            }
                            else
                            {
                                label31.Text = pourcentages[1].ToString() + " %";
                            }
                            }
                            if (unite[0] > 6200000)
                            {
                                label17.Text = "Polyglobulie";

                            if (pourcentages[2] > 100)
                            {
                                label31.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label31.Text = pourcentages[2].ToString() + " %";
                            }

                            }
                        
                    }
                    if (angle > -0.47 && angle < 0 && Xinverse > 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(1).YValues = tableY;
                        label4.Text = String.Concat(String.Concat(unite[1].ToString(), " /mm3 "));

                        if (unite[1] >= 4000 && unite[1] <= 10000)
                        {
                            label18.Text = "Normal";
                            label32.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[1] < 4000)
                        {
                            label18.Text = "Leucopénie";
                            
                            if (pourcentages[3] > 100)
                            {
                                label32.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label32.Text = pourcentages[3].ToString() + " %";
                            }
                        }
                        if (unite[1] > 10000)
                        {
                            if (pourcentages[4] > 100)
                            {
                                label32.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label18.Text = "Hyperleucocytose";                              
                                label32.Text = pourcentages[4].ToString() + " %";
                            }

                        }
                    }
                    if (angle > -1.25 && angle < -0.71 && Xinverse > 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(2).YValues = tableY;
                        label5.Text = String.Concat(String.Concat(unite[2].ToString(), " /mm3 "));

                        if (unite[2] >= 150000 && unite[2] <= 450000)
                        {
                            label19.Text = "Normal";
                            label33.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[2] < 150000)
                        {
                            label19.Text = "Hypoplaquettose";
                           
                            if (pourcentages[5] > 100)
                            {
                                label33.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label33.Text = pourcentages[5].ToString() + " %";
                            }
                        }
                        if (unite[2] > 450000)
                        {
                            label19.Text = "Hyperplaquettose";
                            
                            if (pourcentages[6] > 100)
                            {
                                label33.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                           
                                label33.Text = pourcentages[6].ToString() + " %";
                            }

                        }
                    }
                    if (angle > -8.23 && angle < -1.66 && Xinverse > 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(3).YValues = tableY;
                        label6.Text = String.Concat(String.Concat(unite[3].ToString(), " UI/L "));

                        if (unite[3] < 55)
                        {
                            label20.Text = "Normal";
                            label34.Text = pourcentages[0].ToString() + " %";
                        }
                   
                        if (unite[3] > 55)
                        {
                            label20.Text = "Hépatite(ou maladie de foie)";
                          
                            if (pourcentages[7] > 100)
                            {
                                label34.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label34.Text = pourcentages[7].ToString() + " %";
                            }

                        }

                    }
                    if (angle > 1.5 && angle < 4.57 && Xinverse > 0  && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(4).YValues = tableY;
                        label7.Text = String.Concat(String.Concat(unite[4].ToString(), " UI/L "));

                        if (unite[4] >=53 && unite[4] <= 128)
                        {
                            label21.Text = "Normal";
                            label35.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[4] > 128)
                        {
                            label21.Text = "Hépatite";
                           
                            if (pourcentages[8] > 100)
                            {
                                label35.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label35.Text = pourcentages[8].ToString() + " %";
                            }

                        }
                    }
                    if (angle > 0.6 && angle < 1.26 && Xinverse > 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(5).YValues = tableY;
                        label8.Text = String.Concat(String.Concat(unite[5].ToString(), " µmol/l "));

                        //pour homme
                        if (unite[5] < 120)
                        {
                            label22.Text = "Normal";
                            label36.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[5] > 120)
                        {
                            label22.Text = "Insuffisance rénale";
                 
                            if (pourcentages[9] > 100)
                            {
                                label36.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label36.Text = pourcentages[9].ToString() + " %";
                            }
                        
                        }
                        //pour femme


                    }
                    if (angle > 0.125 && angle < 0.51 && Xinverse > 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(6).YValues = tableY;
                        label9.Text = String.Concat(String.Concat(unite[6].ToString(), " mmol/l "));

                        if (unite[6] >= 4 && unite[6] <= 6)
                        {
                            label23.Text = "Normal";
                            label37.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[6] < 4)
                        {
                            label23.Text = "Hypoglycémie";
                            if (pourcentages[10] > 100)
                            {
                                label37.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label37.Text = pourcentages[10].ToString() + " %";
                            }

                        }

                        if (unite[6] > 6)
                        {
                            label23.Text = "Hyperglycémie(ou Diabète)";
                            if (pourcentages[11] > 100)
                            {
                                label37.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                              label37.Text = pourcentages[11].ToString() + " %";
                            }
                        }
                    }

                    if (angle < -0.024 && angle > -0.33 && Xinverse < 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(7).YValues = tableY;
                        label10.Text = String.Concat(String.Concat(unite[7].ToString(), " µmol/l "));

                        if (unite[7] < 410)
                        {
                            label24.Text = "Normal";
                            label38.Text = pourcentages[0].ToString() + " %";
                        }
                      
                        if (unite[7] > 410)
                        {
                            label24.Text = "Goutte";
                         
                            if (pourcentages[12] > 100)
                            {
                                label38.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label38.Text = pourcentages[12].ToString() + " %";
                            }

                        }
                    }
                    if (angle > -0.61 && angle < -0.45 && Xinverse < 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(8).YValues = tableY;
                        label11.Text = String.Concat(String.Concat(unite[8].ToString(), " mmol/l "));

                        if (unite[8] >=3 && unite[8] <= 6.2)
                        {
                            label25.Text = "Normal";
                            label39.Text = pourcentages[0].ToString() + " %";
                        }
                        if (unite[8] < 3)
                        {
                            label25.Text = "Insuffisance hépatique";
                            if (pourcentages[13] > 100)
                            {
                                label39.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label39.Text = pourcentages[13].ToString() + " %";
                            }

                        }

                        if (unite[8] > 6.2)
                        {
                            label25.Text = "Syndrome de surcharge";
                            if (pourcentages[14] > 100)
                            {
                                label39.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label39.Text = pourcentages[14].ToString() + " %";
                            }

                        }
                    }
                    if (angle < -0.56 && angle > -1.38 && Xinverse < 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(9).YValues = tableY;
                        label12.Text = String.Concat(String.Concat(unite[9].ToString(), " U/L "));

                        if (unite[9] < 60)
                        {
                            label26.Text = "Normal";
                            label40.Text = pourcentages[0].ToString() + " %";
                        }

                        if (unite[9] > 60)
                        {
                            label26.Text = "Pancréatite";
                            if (pourcentages[15] > 100)
                            {
                                label40.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label40.Text = pourcentages[15].ToString() + " %";
                            }

                        }
                    }
                    if (angle < -4.26 && angle > -5.5 && Xinverse < 0 && Yinverse > 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(10).YValues = tableY;
                        label13.Text = String.Concat(String.Concat(unite[10].ToString(), " mmol/l "));

                        if (unite[10] >=137 && unite[10] <= 145)
                        {
                            label27.Text = "Normal";
                            label41.Text = pourcentages[0].ToString() + " %";
                        }

                        if (unite[10] < 137)
                        {
                            label27.Text = "Hyponatrémie";
                            if (pourcentages[16] > 100)
                            {
                                label41.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            { 
                                label41.Text = pourcentages[16].ToString() + " %";
                            }

                        }

                        if (unite[10] > 145)
                        {
                            label27.Text = "Hypernatrémie";
                            if (pourcentages[17] > 100)
                            {
                                label41.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label41.Text = pourcentages[17].ToString() + " %";
                            }

                        }
                    }
                    if (angle > 4.66 && angle < 5.53 && Xinverse < 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(11).YValues = tableY;
                        label14.Text = String.Concat(String.Concat(unite[11].ToString(), " mg/L "));

                        if (unite[11] < 10)
                        {
                            label28.Text = "Normal";
                            label42.Text = pourcentages[0].ToString() + " %";
                        }

                        if (unite[11] > 10)
                        {
                            label28.Text = "Présence d'une inflammation";
                            if (pourcentages[18] > 100)
                            {
                                label42.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label42.Text = pourcentages[18].ToString() + " %";
                            }

                        }
                    }

                    if (angle < 2.33 && angle > 1.28 && Xinverse < 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(12).YValues = tableY;
                        label15.Text = String.Concat(String.Concat(unite[12].ToString(), " UI/L"));

                        if (unite[12] < 55)
                        {
                            label29.Text = "Normal";
                            label43.Text = pourcentages[0].ToString() + " %";
                        }

                        if (unite[12] > 55)
                        {
                            label29.Text = "Pancréatite";
                            if (pourcentages[19] > 100)
                            {
                                label43.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label43.Text = pourcentages[19].ToString() + " %";
                            }

                        }
                    }
                   
                    if (angle > 0.49 && angle < 0.8 && Xinverse < 0 && Yinverse < 0)
                    {
                        chart1.Series["series1"].Points.ElementAt(13).YValues = tableY;
                        label16.Text = String.Concat(String.Concat(unite[13].ToString(), " U/ml "));


                        if (unite[13] <= 200 )
                        {
                            label30.Text = "Normal";
                            label44.Text = pourcentages[0].ToString() + " %";
                        }

                        if (unite[13] > 200)
                        {
                            label30.Text = "Rhumatisme";
                            if (pourcentages[20] > 100)
                            {
                                label44.Text = pourcentages[0].ToString() + " %";
                            }
                            else
                            {
                                label44.Text = pourcentages[20].ToString() + " %";
                            }

                        }
                    }



                    Maximuim max = new Maximuim();

                  /*  label49.Text = max.plusGrand(pourcentages, 21).ToString() + " %";
                    label50.Text = max.plusGrand2(pourcentages, 21).ToString() + " %";
                    label51.Text = max.plusGrand3(pourcentages, 21).ToString() + " %";

                  /*  if (label49.Text == pourcentages[0].ToString() + " %")
                    {
                        label46.Text = "Normal";
                    }
                    if (label50.Text == pourcentages[0].ToString() + " %")
                    {
                        label47.Text = "Normal";
                    }
                    if (label51.Text == pourcentages[0].ToString() + " %")
                    {
                        label48.Text = "Normal";
                    }

                    if (label49.Text == pourcentages[1].ToString() + " %")
                    {
                        label46.Text = "Anémie";
                    }
                    if (label50.Text == pourcentages[1].ToString() + " %")
                    {
                        label47.Text = "Anémie";
                    }
                    if (label51.Text == pourcentages[1].ToString() + " %")
                    {
                        label48.Text = "Anémie";
                    }


                    if (label49.Text == pourcentages[2].ToString() + " %")
                    {
                        label46.Text = "Polyglobulie";
                    }
                    if (label50.Text == pourcentages[2].ToString() + " %")
                    {
                        label47.Text = "Polyglobulie";
                    }
                    if (label51.Text == pourcentages[2].ToString() + " %")
                    {
                        label48.Text = "Polyglobulie";
                    }


                    if (label49.Text == pourcentages[3].ToString() + " %")
                    {
                        label46.Text = "Leucopénie";
                    }
                    if (label50.Text == pourcentages[3].ToString() + " %")
                    {
                        label47.Text = "Leucopénie";
                    }
                    if (label51.Text == pourcentages[3].ToString() + " %")
                    {
                        label48.Text = "Leucopénie";
                    }


                    if (label49.Text == pourcentages[4].ToString() + " %")
                    {
                        label46.Text = "Hyperleucocytose";
                    }
                    if (label50.Text == pourcentages[4].ToString() + " %")
                    {
                        label47.Text = "Hyperleucocytose";
                    }
                    if (label51.Text == pourcentages[4].ToString() + " %")
                    {
                        label48.Text = "Hyperleucocytose";
                    }


                    if (label49.Text == pourcentages[5].ToString() + " %")
                    {
                        label46.Text = "Hypoplaquettose";
                    }
                    if (label50.Text == pourcentages[5].ToString() + " %")
                    {
                        label47.Text = "Hypoplaquettose";
                    }
                    if (label51.Text == pourcentages[5].ToString() + " %")
                    {
                        label48.Text = "Hypoplaquettose";
                    }


                    if (label49.Text == pourcentages[6].ToString() + " %")
                    {
                        label46.Text = "Hyperplaquettose";
                    }
                    if (label50.Text == pourcentages[6].ToString() + " %")
                    {
                        label47.Text = "Hyperplaquettose";
                    }
                    if (label51.Text == pourcentages[6].ToString() + " %")
                    {
                        label48.Text = "Hyperplaquettose";
                    }


                    if (label49.Text == pourcentages[7].ToString() + " %")
                    {
                        label46.Text = "Hépatite(ou maladie de foie)";
                    }
                    if (label50.Text == pourcentages[7].ToString() + " %")
                    {
                        label47.Text = "Hépatite(ou maladie de foie)";
                    }
                    if (label51.Text == pourcentages[7].ToString() + " %")
                    {
                        label48.Text = "Hépatite(ou maladie de foie)";
                    }


                    if (label49.Text == pourcentages[8].ToString() + " %")
                    {
                        label46.Text = "Hépatite";
                    }
                    if (label50.Text == pourcentages[8].ToString() + " %")
                    {
                        label47.Text = "Hépatite";
                    }
                    if (label51.Text == pourcentages[8].ToString() + " %")
                    {
                        label48.Text = "Hépatite";
                    }


                    if (label49.Text == pourcentages[9].ToString() + " %")
                    {
                        label46.Text = "Insuffisance rénale";
                    }
                    if (label50.Text == pourcentages[9].ToString() + " %")
                    {
                        label47.Text = "Insuffisance rénale";
                    }
                    if (label51.Text == pourcentages[9].ToString() + " %")
                    {
                        label48.Text = "Insuffisance rénale";
                    }


                    if (label49.Text == pourcentages[10].ToString() + " %")
                    {
                        label46.Text = "Hypoglycémie";
                    }
                    if (label50.Text == pourcentages[10].ToString() + " %")
                    {
                        label47.Text = "Hypoglycémie";
                    }
                    if (label51.Text == pourcentages[10].ToString() + " %")
                    {
                        label48.Text = "Hypoglycémie";
                    }


                    if (label49.Text == pourcentages[11].ToString() + " %")
                    {
                        label46.Text = "Hyperglycémie(ou Diabète)";
                    }
                    if (label50.Text == pourcentages[11].ToString() + " %")
                    {
                        label47.Text = "Hyperglycémie(ou Diabète)";
                    }
                    if (label51.Text == pourcentages[11].ToString() + " %")
                    {
                        label48.Text = "Hyperglycémie(ou Diabète)";
                    }


                    if (label49.Text == pourcentages[12].ToString() + " %")
                    {
                        label46.Text = "Goutte";
                    }
                    if (label50.Text == pourcentages[12].ToString() + " %")
                    {
                        label47.Text = "Goutte";
                    }
                    if (label51.Text == pourcentages[12].ToString() + " %")
                    {
                        label48.Text = "Goutte";
                    }


                    if (label49.Text == pourcentages[13].ToString() + " %")
                    {
                        label46.Text = "Insuffisance hépatique";
                    }
                    if (label50.Text == pourcentages[13].ToString() + " %")
                    {
                        label47.Text = "Insuffisance hépatique";
                    }
                    if (label51.Text == pourcentages[13].ToString() + " %")
                    {
                        label48.Text = "Insuffisance hépatique";
                    }


                    if (label49.Text == pourcentages[14].ToString() + " %")
                    {
                        label46.Text = "Syndrome de surcharge";
                    }
                    if (label50.Text == pourcentages[14].ToString() + " %")
                    {
                        label47.Text = "Syndrome de surcharge";
                    }
                    if (label51.Text == pourcentages[14].ToString() + " %")
                    {
                        label48.Text = "Syndrome de surcharge";
                    }


                    if (label49.Text == pourcentages[15].ToString() + " %")
                    {
                        label46.Text = "Pancréatite";
                    }
                    if (label50.Text == pourcentages[15].ToString() + " %")
                    {
                        label47.Text = "Pancréatite";
                    }
                    if (label51.Text == pourcentages[15].ToString() + " %")
                    {
                        label48.Text = "Pancréatite";
                    }


                    if (label49.Text == pourcentages[16].ToString() + " %")
                    {
                        label46.Text = "Hyponatrémie";
                    }
                    if (label50.Text == pourcentages[16].ToString() + " %")
                    {
                        label47.Text = "Hyponatrémie";
                    }
                    if (label51.Text == pourcentages[16].ToString() + " %")
                    {
                        label48.Text = "Hyponatrémie";
                    }


                    if (label49.Text == pourcentages[17].ToString() + " %")
                    {
                        label46.Text = "Hypernatrémie";
                    }
                    if (label50.Text == pourcentages[17].ToString() + " %")
                    {
                        label47.Text = "Hypernatrémie";
                    }
                    if (label51.Text == pourcentages[17].ToString() + " %")
                    {
                        label48.Text = "Hypernatrémie";
                    }


                    if (label49.Text == pourcentages[18].ToString() + " %")
                    {
                        label46.Text = "Présence d'une inflammation";
                    }
                    if (label50.Text == pourcentages[18].ToString() + " %")
                    {
                        label47.Text = "Présence d'une inflammation";
                    }
                    if (label51.Text == pourcentages[18].ToString() + " %")
                    {
                        label48.Text = "Présence d'une inflammation";
                    }


                    if (label49.Text == pourcentages[19].ToString() + " %")
                    {
                        label46.Text = "Pancréatite";
                    }
                    if (label50.Text == pourcentages[19].ToString() + " %")
                    {
                        label47.Text = "Pancréatite";
                    }
                    if (label51.Text == pourcentages[19].ToString() + " %")
                    {
                        label48.Text = "Pancréatite";
                    }


                    if (label49.Text == pourcentages[20].ToString() + " %")
                    {
                        label46.Text = "Rhumatisme";
                    }
                    if (label50.Text == pourcentages[20].ToString() + " %")
                    {
                        label47.Text = "Rhumatisme";
                    }
                    if (label51.Text == pourcentages[20].ToString() + " %")
                    {
                        label48.Text = "Rhumatisme";
                    }*/


                }
                catch
                {

                }
                finally
                {

                }
            }
        }



        private void Titre_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void X_ligne_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void sourie_Click(object sender, EventArgs e)
        {

        }

        private void inverse_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

      

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label47_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Toute est dans la base");
        }
    }
}
