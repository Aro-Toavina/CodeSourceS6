﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sante
{
   public class Maximuim
    {
        public Maximuim()
        {

        }
        public double plusGrand(double[] T, int N)
        {
            double max;
            max = T[0];
            for (int i = 0; i < N; i++)
            {
                if (T[i] > max)
                {
                    max = T[i];
                }
            }
            return max;
        }

        public double plusGrand2(double[] T, int N)
        {
            double max = T[0];
            double max1 = T[0];
            for (int i = 0; i < N; i++)
            {
                if (T[i] > max)
                {
                    max = T[i];
                }
                if (max != T[i])
                {
                    if (T[i] > max1)
                    {
                        max1 = T[i];
                    }
                }

            }
            return max1;
        }

        public double plusGrand3(double[] T, int N)
        {
            double max = T[0];
            double max1 = T[0];
            double max2 = T[0];
            for (int i = 0; i < N; i++)
            {
                if (T[i] > max)
                {
                    max = T[i];
                }
                if (max != T[i])
                {
                    if (T[i] > max1)
                    {
                        max1 = T[i];
                    }
                }
                if (max != T[i] && max1 != T[i])
                {
                    if (T[i] > max2)
                    {
                        max2 = T[i];
                    }
                }


            }
            return max2;
        }
}
}
