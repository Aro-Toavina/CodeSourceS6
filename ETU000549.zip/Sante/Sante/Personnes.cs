﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sante
{
   public class Personnes
    {
        
        string nom;
        string prenom;
        string sexe;
        string stade;
        public Personnes() { }
        public Personnes(string nom, string prenom, string sexe, string stade)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.sexe = sexe;
            this.stade = stade;
        }

        public string Nom
        {
            get
            {
                return nom;
            }

            set
            {
                nom = value;
            }
        }

        public string Prenom
        {
            get
            {
                return prenom;
            }

            set
            {
                prenom = value;
            }
        }

        public string Sexe
        {
            get
            {
                return sexe;
            }

            set
            {
                sexe = value;
            }
        }

        public string Stade
        {
            get
            {
                return stade;
            }

            set
            {
                stade = value;
            }
        }
    }
}
