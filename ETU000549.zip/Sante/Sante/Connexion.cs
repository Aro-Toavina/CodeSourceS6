﻿using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Connexion
/// </summary>
namespace Sante
{
    public class Connexion
    {
        public Connexion()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        string ConnectionString = "Data Source=ZHOU-GOUPIL\\SQLEXPRESS;Initial Catalog=Sante;Integrated Security=True";
        public SqlConnection con;

        public void OuvrirConnexion()
        {
            try
            {
                con = new SqlConnection(ConnectionString);
                con.Open();
                Console.WriteLine("Connecter " + con);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Tsy connecter " + ex);
            }
        }


        public void FermerConnexion()
        {
            try
            {
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        public void LaCommendeExecute(string table)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(table, con);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Commende mandea " + cmd);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Commende tsy mandea " + ex);
            }
        }


        public SqlDataReader Resultat(string table)
        {
            SqlCommand cmd = new SqlCommand(table, con);
            SqlDataReader rs = cmd.ExecuteReader();
            return rs;
        }


        public object ShowDataInGridView(string Query_)
        {
            SqlDataAdapter dr = new SqlDataAdapter(Query_, ConnectionString);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            object dataum = ds.Tables[0];
            return dataum;
        }

    }
}