﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sante
{
    public partial class Personne : Form
    {
        Connexion conex = new Connexion();
        PersonnesDAO PDAO = new PersonnesDAO();
        Personnes p = new Personnes();
        public Personne()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 analyse = new Form1();
            analyse.Show();
            inserer();
        }

        private void Personne_Load(object sender, EventArgs e)
        {
            
            
        }

        public void inserer()
        {
            PDAO.insert(conex, p);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            p.Nom = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            p.Prenom = textBox2.Text;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            p.Sexe = comboBox1.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            p.Stade = comboBox2.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
