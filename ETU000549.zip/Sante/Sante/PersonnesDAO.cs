﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Sante
{
   public class PersonnesDAO
    {
        public PersonnesDAO()
        {

        }
        public void insert(Connexion Con, Personnes stE)
        {

            if (stE == null)
            {
                Exception e = new Exception("Tsy mety mandea ny insertion");
                throw e;
            }
            else
            {
                SqlCommand cmd = null;
                String requete = null;
                requete = "insert into personne values ('" + stE.Nom + "','" + stE.Prenom + "','" + stE.Sexe + "','" + stE.Stade + "')";
                Console.WriteLine(requete);
                try
                {
                    Con.OuvrirConnexion();
                    cmd = new SqlCommand(requete, Con.con);
                    SqlDataReader r;
                    r = cmd.ExecuteReader();
                    Con.FermerConnexion();
                    // cmd.ExecuteNonQuery();
                    int a = cmd.ExecuteNonQuery();


                    cmd.Dispose();

                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
            }
        }

        public List<Personnes> find(Connexion Con, string table, string where)
        {

            String requete = null;

            requete = "SELECT * FROM " + table + where;
            Console.WriteLine(requete);
            SqlDataReader result;
            Con.OuvrirConnexion();
            SqlCommand cmd;
            cmd = new SqlCommand(requete, Con.con);
            result = cmd.ExecuteReader();
            List<Personnes> listePersonne = new List<Personnes>();
            try
            {

                while (result.Read())
                {
                    Personnes stE = new Personnes() ;
                    // on prend les colonnes un par un
                    string nom = Convert.ToString(result.GetValue(0));
                    string prenom = Convert.ToString(result.GetValue(1));
                    string sexe = Convert.ToString(result.GetValue(2));
                    string stade = Convert.ToString(result.GetValue(3));

                    // init de l'objet
                    stE = new Personnes(nom, prenom, sexe, stade);
                    // ajout dans la liste
                    listePersonne.Add(stE);

                }

                result.Close();
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                Con.FermerConnexion();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Tsy mety " + ex.Message);
            }

            return listePersonne;

        }


    }
}
