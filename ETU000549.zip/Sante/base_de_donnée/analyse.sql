/*==============================================================*/
/* Nom de SGBD :  Microsoft SQL Server 2008                     */
/* Date de cr�ation :  23/04/2018 15:17:56                      */
/*==============================================================*/


if exists (select 1
            from  sysindexes
           where  id    = object_id('BILAN_SANGUINS')
            and   name  = 'ASSOCIATION_2_FK'
            and   indid > 0
            and   indid < 255)
   drop index BILAN_SANGUINS.ASSOCIATION_2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('BILAN_SANGUINS')
            and   name  = 'ASSOCIATION_1_FK'
            and   indid > 0
            and   indid < 255)
   drop index BILAN_SANGUINS.ASSOCIATION_1_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BILAN_SANGUINS')
            and   type = 'U')
   drop table BILAN_SANGUINS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MALADIE')
            and   type = 'U')
   drop table MALADIE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PERSONNE')
            and   name  = 'ASSOCIATION_4_FK'
            and   indid > 0
            and   indid < 255)
   drop index PERSONNE.ASSOCIATION_4_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PERSONNE')
            and   type = 'U')
   drop table PERSONNE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RESULTAT')
            and   type = 'U')
   drop table RESULTAT
go

/*==============================================================*/
/* Table : BILAN_SANGUINS                                       */
/*==============================================================*/
create table BILAN_SANGUINS (
   ID_BS                numeric              identity,
   ID_MAL               numeric              not null,
   MAL_ID_MAL           numeric              not null,
   BILAN_SANGUIN        varchar(225)         null,
   VALEURS_NORMALES     numeric              null,
   INF_VN               numeric              null,
   SUP_VN               numeric              null,
   constraint PK_BILAN_SANGUINS primary key nonclustered (ID_BS)
)
go

/*==============================================================*/
/* Index : ASSOCIATION_1_FK                                     */
/*==============================================================*/
create index ASSOCIATION_1_FK on BILAN_SANGUINS (
ID_MAL ASC
)
go

/*==============================================================*/
/* Index : ASSOCIATION_2_FK                                     */
/*==============================================================*/
create index ASSOCIATION_2_FK on BILAN_SANGUINS (
MAL_ID_MAL ASC
)
go

/*==============================================================*/
/* Table : MALADIE                                              */
/*==============================================================*/
create table MALADIE (
   ID_MAL               numeric              identity,
   MAL_INF_VN           varchar(225)         null,
   MAL_SUP_VN           varchar(225)         null,
   constraint PK_MALADIE primary key nonclustered (ID_MAL)
)
go

/*==============================================================*/
/* Table : PERSONNE                                             */
/*==============================================================*/
create table PERSONNE (
   ID_PERS              numeric              identity,
   ID_MAL               numeric              not null,
   NOM                  text                 null,
   PRENOM               text                 null,
   SEXE                 char(50)             null,
   STADE                char(50)             null,
   constraint PK_PERSONNE primary key nonclustered (ID_PERS)
)
go

/*==============================================================*/
/* Index : ASSOCIATION_4_FK                                     */
/*==============================================================*/
create index ASSOCIATION_4_FK on PERSONNE (
ID_MAL ASC
)
go

/*==============================================================*/
/* Table : RESULTAT                                             */
/*==============================================================*/
create table RESULTAT (
   ID_RESULT            numeric              identity,
   MALADIE              text                 null,
   POURCENTAGE_         numeric              null,
   constraint PK_RESULTAT primary key nonclustered (ID_RESULT)
)
go

