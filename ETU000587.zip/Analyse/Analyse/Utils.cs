﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Utils
    {
        public int difference(int a,int b)
        {
            int diff =a-b;
            if (diff > 0)
                return diff;
            else
                return Math.Abs(diff);

        }
        //diff entre limite axe et val max ou min
        public int calculPourcentage(int valeur,int axe ,int valeur_maladie)
        {
            //select limite_axe where id_axe = i
            //int limite;
            double resy = (valeur * 100) / valeur_maladie;
            double tmp = Math.Ceiling(resy)+1;
            int res = int.Parse(tmp.ToString());
           
            return res;
            

        }
    }
}
