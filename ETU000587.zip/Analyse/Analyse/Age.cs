﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Age
    {
        string id;
        int age_debut;
        int age_fin;
        public Age() { }
        public Age(string id,int age_debut,int age_fin)
        {
            this.id = id;
            this.age_debut = age_debut;
            this.age_fin = age_fin;
        }
        public Age(int age_debut, int age_fin)
        {
            this.age_debut = age_debut;
            this.age_fin = age_fin;
        }

        public void setAgeFin(int age_fin)
        {
            if (age_fin < 0 || age_fin > 100)
                throw new Exception("age trop grande");
            else
            this.age_fin = age_fin;

        }
        public void setAgeDebut(int age_debut)
        {
            if (age_debut < 0 )
                throw new Exception("age invalide");
            else
                this.age_debut = age_debut;
        }
        public string getId()
        {
            return this.id;
        }
        public int getAgeFin()
        {
            return this.age_fin;
        }
        public int getAgeDebut()
        {
            return this.age_debut;
        }
    }
}
