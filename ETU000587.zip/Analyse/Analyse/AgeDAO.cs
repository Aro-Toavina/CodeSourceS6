﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class AgeDAO
    {
        public string getIdAge(int num)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select id from age where age_debut<= '"+num+"' and age_fin>='"+num+"'   ", conn);

                read = command.ExecuteReader();

                read.Read();



                string numero = read["id"].ToString();
                return numero;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
    }
}
