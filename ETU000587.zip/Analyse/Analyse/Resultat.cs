﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Resultat
    {
        string id;
        string nom;
        string sexe;
        int age;
        string res_maladie;
        int pourcentage;
        public Resultat() { }
        public Resultat(string id,string nom,string sexe,int age,string res_maladie,int pourcentage)
        {
            this.id = id;
            this.nom = nom;
            this.sexe = sexe;
            this.age = age;
            this.pourcentage = pourcentage;
            this.res_maladie = res_maladie;

        }
        public void setId(string id)
        {
            this.id = id;
        }
        public void setNom(string nom)
        {
            this.nom = nom;
        }
        public void setAge(int age)
        {
            if(age<=0)
                throw new Exception("age ne peut pas etre negatif ou 0");
            else
            this.age = age;
        }
        public void setResNom(string res_maladie)
        {
            this.res_maladie = res_maladie;
        }
        public void setPourcentage(int pourcentage)
        {
            if(pourcentage<0 || pourcentage>100)
                throw new Exception("pourcentage ne peut pas etre negatif");
            else
            this.pourcentage = pourcentage;
        }
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public string getId() { return this.id; }
        public string getNom() { return this.nom; }
        public int getAge() { return this.age; }
        public int getPourcentage() { return this.pourcentage; }
        public string getSexe() { return this.sexe; }
        public string getResNom() { return this.res_maladie; }
    }
    
}
