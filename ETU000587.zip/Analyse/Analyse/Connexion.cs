﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Connexion
    {
        public SqlConnection getConnect()
        {

            SqlConnection sqlConne;
            String sconnect;
            sconnect = "Persist Security Info=False;Integrated Security=SSPI;database=analyse2;server=DESKTOP-KTR8LVJ";
            sqlConne = new SqlConnection(sconnect);
            sqlConne.Open();
            return sqlConne;
        }
    }
}
