﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Axe
    {
        int numero_axe;
        string nom_axe;
        int limite_axe;
        public Axe() { }
        public Axe(int numero_axe,string nom_axe,int limite_axe)
        {
            this.numero_axe = numero_axe;
            this.nom_axe = nom_axe;
            this.limite_axe = limite_axe;
        }
        public void setNumero(int numero)
        {
            if (numero < 0)
            {
                throw new Exception("numero axe ne peut pas etre negatif");
            }
            else
                this.numero_axe = numero_axe;
        }
        public void setLimite(int limite_axe)
        {
            if (limite_axe < 0)
            {
                throw new Exception("valeur de l axe ne peut pas etre negatif");
            }
            else
                this.limite_axe = limite_axe;
        }
        public void setNom(string nom_axe)
        {
            this.nom_axe = nom_axe;
        }
        public int getNumero()
        {
            return this.numero_axe;
        }
        public string getNom()
        {
            return this.nom_axe;
        }
        public int getLimite()
        {
            return this.limite_axe;
        }
    }
}
