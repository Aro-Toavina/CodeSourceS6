﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    public partial class Form1 : Form
    {
        private int nbVar = 14;
       
       
        private int MaxY = 120;
        private int countCursor = 0;
        private double[][] valInit = null;
        double[] valeur_axe = new double[14];
        public Form1()
        {
            InitializeComponent();
            AxeDAO axedao = new AxeDAO();
            List<Axe> listeAxe = axedao.listeNomAxe();
            Graph.ChartAreas[0].AxisY.Maximum = MaxY;

            for (int i = 0; i < nbVar; i++)
            {
                Graph.Series["Series1"].Points.AddY(50);
                Graph.Series["Series1"].Points.ElementAt(i).AxisLabel = listeAxe.ElementAt(i).getNom();
            }

           

            saveValues();
           

        }
        private void initValues()
        {
            for (int i = 0; i < nbVar; i++)
            {
                Graph.Series["Series1"].Points.ElementAt(i).YValues = valInit[i];

            }

        }
        private void saveValues()
        {
            valInit = new double[nbVar][];
            for (int i = 0; i < nbVar; i++)
            {
                valInit[i] = new double[1];
                valInit[i] = Graph.Series["Series1"].Points.ElementAt(i).YValues;
            }
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            double[] yvalues = new double[1];
            // centre du point
            double x = this.Graph.Size.Width - this.Graph.Location.X;
            double y = this.Graph.Size.Height - this.Graph.Location.Y;
            x = 234; y = 181;
           

            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);

            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
            string wid = mEvent.Y.ToString();
            string hei = mEvent.X.ToString();
          //  MessageBox.Show("centre x=" + hei + "centre y=" + wid);
           // MessageBox.Show("graph width" + this.Graph.Size.Width.ToString()+ "x location"+ this.Graph.Location.X.ToString());
          //  MessageBox.Show("graph height" + this.Graph.Size.Height.ToString() + "y location" + this.Graph.Location.Y.ToString());
            //   MessageBox.Show(msgA + "\n" + msgB + "\n" + msgC + "\n" + msgD);
            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                  //  MessageBox.Show(yvalues[0].ToString());
                    Graph.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
                  
                    valeur_axe[1] =setValue( Math.Ceiling(yvalues[0]*0.26),1);

                }
                else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                 //   MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[8] =setValue( Math.Ceiling(yvalues[0]*0.1),8);
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                   // MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[2] = setValue(Math.Ceiling(yvalues[0]*0.12),2);
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[9] = setValue(Math.Ceiling(yvalues[0]*1.66),9);
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[3] =setValue( Math.Ceiling(yvalues[0]*250),3);
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[10] =setValue( Math.Ceiling(yvalues[0]*0.075),10);
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[4] = setValue(Math.Ceiling(yvalues[0]*5000),4);

                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[11] = setValue(Math.Ceiling(yvalues[0]*1.25),11);

                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[5] = setValue(Math.Ceiling(yvalues[0]*0.41),5);
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[12] = setValue(Math.Ceiling(yvalues[0]*0.16),12);
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[6] = setValue(Math.Ceiling(yvalues[0]*0.5),6);
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[13] = setValue(Math.Ceiling(yvalues[0]*0.66),13);
                }




                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[0] = setValue(Math.Ceiling(yvalues[0]*0.26),0);
                }
                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                    //MessageBox.Show(yvalues[0].ToString());
                    valeur_axe[7] = setValue(Math.Ceiling(yvalues[0]*0.16),7);

                }

//                MessageBox.Show("yvalues=" + yvalues[0]);
            }


            saveValues();

            

        }
     
        private void changeValueAxe(int indexAxe, double newValue)
        {
            double[] yvalues = new double[1];
            yvalues[0] = newValue;
            Graph.Series["Series1"].Points.ElementAt(indexAxe).YValues = yvalues;
        }
        private static double calculHypotenuse(double x, double y)
        {
            // 10 sur l'echelle equivaut a 12px
            return Math.Sqrt(x * x + y * y) * 10.0 / 10;
        }
        private void Graph_MouseMove(object sender, EventArgs e)
        {

            double x = this.Graph.Size.Width - this.Graph.Location.X;
            double y = this.Graph.Size.Height - this.Graph.Location.Y;
            x = 234; y = 181;
            double[] yvalues = new double[1];
            Random rdn = new Random();
            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);

            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
       
            initValues();
            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
             
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }



                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();

                }
                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    Graph.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                    label4.Text = yvalues[0].ToString();
                }
            }
            else
            {
                //Console.WriteLine("Reinitialized = " + valInit[0][0]);
                initValues();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AxeDAO ax = new AxeDAO();
            MaladieDAO malDAO = new MaladieDAO();
            Utils utils = new Utils();
            CompositionDAO compDAO = new CompositionDAO();
            List<Composition> comp = compDAO.listeComposition();
            AgeDAO ageDAO = new AgeDAO();
            string sexe = comboBox1.Text;
            string sex;
            if (sexe == "Homme")
                sex = "H";
            else
                sex = "F";
            MessageBox.Show(sex);
            int age = int.Parse(textBox2.Text);
            string idAge =ageDAO.getIdAge(age);
           
           
            
            int[][] res = new int[14][];
            
            for(int i = 0; i < valeur_axe.Length; i++)
            {
                Console.WriteLine("Valeurs : " + valeur_axe.Length);
                for(int u=0;u<comp.Count();u++)
                {
                    if (i == ax.getNumAxe(comp[u].getAxe()))
                    {
                        if (valeur_axe[i] > comp[u].getMin() && valeur_axe[i] < comp[u].getMax())
                        {
                            int m = comp[u].getMaladieSup();
                            //res[m][i]= 0;
                        }
                        else if (valeur_axe[i] < comp[u].getMin() && sex==comp[u].getSexe() && idAge==comp[u].getAge())
                        {
                            int vals = (int)valeur_axe[i];
                            Composition comps =compDAO.oneCompositionMin(idAge,sex,vals);
                            //   int m = malDAO.getIdMaladie(i);
                            /*
                            int m = comp[u].getMaladieInf();
                            int idM = malDAO.getIdMaladieInf(m);
   */
                            int m = comps.getMaladieInf();
                            int idM = malDAO.getIdMaladieInf(m);
                            //     MessageBox.Show(Convert.ToInt32(valeur_axe[0]).ToString());
                            res[m] = new int[50];
                           res[m][i]= utils.calculPourcentage(Convert.ToInt32(valeur_axe[i]), i, comp[u].getMin());
                      

                        }
                        else if (valeur_axe[i] > comp[u].getMax() && sex == comp[u].getSexe() && idAge == comp[u].getAge())
                        {
                            // 
                            int vals = (int)valeur_axe[i];
                            Composition comps = compDAO.oneCompositionMax(idAge, sex, vals);
                            int m = malDAO.getIdMaladie(i);
                            //int m = comp[u].getMaladieSup();
                            //int idM = malDAO.getIdMaladieSup(m);
                            res[m] = new int[50];
                            int diff = utils.difference(comp[u].getMax(), Convert.ToInt32(valeur_axe[i]));
                      
                             res[m][i] = utils.calculPourcentage(Convert.ToInt32(valeur_axe[i]), i, diff);
                         //   Console.WriteLine(malDAO.malad(m));
                           

                        }
                    }
                  //  listeInt.Add(res);
                    else
                    {


                    }

                }
            }

            
            int[] val = new int[res.Length];
          for(int j = 1; j < res.Length; j++)
            {
                if (res[j] == null)
                {
                   
                    Console.WriteLine("dans boucle"); continue;
                }
                val[j] = 0;
                Console.WriteLine("taille" + res[j].Length);
                int count = 0;
                for(int k = 0; k < res[j].Length; k++)
                {
                    if (res[j][k] == 0)
                        continue;
                    else
                    {
                        count++;
                        Console.WriteLine("teste" + res[j][k]);
                        val[j] += res[j][k];
                    }    
                }
               
                 val[j] = (int)Math.Ceiling((double)(val[j] / res[j].Length));

            }
            
            for(int i = 0; i < val.Length; i++) { 
              Console.Write(val[i]+"sdg");
                if (val[i] == 0)
                {
                    continue;
                }
                else
                    label5.Text += malDAO.malad(i) + " " + val[i] + "% \r\n";
                      //MessageBox.Show("indice:" + i);
              }
              /*
              // string ml=malDAO.malad(val[1]);
              // label5.Text =ml.ToString();
              label[2].Text = malDAO.malad(2);
              */
           
        }

        public double setValue(double val,int ind)
        {
            this.valeur_axe[ind] = val;
            return valeur_axe[ind];
        }
    }
}
