﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Composition
    {
        string id;
        int maladie_inf;
        int maladie_sup;
        string axe;
        int min;
        int max;
        string age;
        string sexe;
        public Composition() { }
        public Composition(string id,int maladie_inf,int maladie_sup, string axe,int min,int max,string age,string sexe)
        {
            this.id = id;
            this.maladie_inf = maladie_inf;
            this.maladie_sup = maladie_sup;
            this.axe = axe;
            this.min = min;
            this.max = max;
            this.age = age;
            this.sexe = sexe;
        }
        public Composition(int maladie_inf, int maladie_sup, string axe, int min, int max,string age, string sexe)
        {
            this.maladie_inf = maladie_inf;
            this.maladie_sup = maladie_sup;
            this.axe = axe;
            this.min = min;
            this.max = max;
            this.age = age;
            this.sexe = sexe;
        }
        public void setMaladieInf(int maladie_inf)
        {
            this.maladie_inf = maladie_inf;
        }
        public void setMaladieSup(int maladie_sup)
        {
            this.maladie_sup = maladie_sup;
        }
        public void setAxe(string axe)
        {
            this.axe = axe;
        }
        public void setMin(int min)
        {
            this.min = min;
        }
        public void setAge(string age)
        {
            this.age = age;
        }
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public void setMax(int max)
        {
            this.max = max;
        }
        public string getId()
        {
            return this.id;
        }
        public int getMaladieInf()
        {
            return this.maladie_inf;
        }
        public int getMaladieSup()
        {
            return this.maladie_sup;
        }
        public string getAxe()
        {
            return this.axe;
        }
        public int getMin()
        {
            return this.min;
        }
        public int getMax()
        {
            return this.max;
        }
        public string getAge()
        {
            return this.age;
        }
        public string getSexe()
        {
            return this.sexe;
        }
    }
}
