﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class CompositionDAO
    {
        public List<Composition> listeComposition()
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select * from comp_maladie", conn);

                read = command.ExecuteReader();
                List<Composition> axe = new List<Composition>();

                while (read.Read())
                {



                    string id = read["id"].ToString();
                    int nom_inf = int.Parse(read["maladie_inf"].ToString());
                    int nom_sup = int.Parse(read["maladie_sup"].ToString());
                    string axes = read["axe"].ToString();
                    int min =int.Parse( read["val_min"].ToString());
                    int max = int.Parse(read["val_max"].ToString());
                    string age = read["age"].ToString();
                    string sexe = read["sexe"].ToString();

                    axe.Add(new Composition(id, nom_inf,nom_sup, axes,min,max,age,sexe));
                }
                return axe;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public Composition oneCompositionMin(string ages,string sexes,int valeur)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            Composition comp = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select * from comp_maladie where age='"+ ages+"' and sexe='"+sexes+"' and val_min> '"+ valeur+"'", conn);

                read = command.ExecuteReader();
              
                while (read.Read())
                {



                    string id = read["id"].ToString();
                    int nom_inf = int.Parse(read["maladie_inf"].ToString());
                    int nom_sup = int.Parse(read["maladie_sup"].ToString());
                    string axes = read["axe"].ToString();
                    int min = int.Parse(read["val_min"].ToString());
                    int max = int.Parse(read["val_max"].ToString());
                    string age = read["age"].ToString();
                    string sexe = read["sexe"].ToString();

                    comp= new Composition(id, nom_inf, nom_sup, axes, min, max, age, sexe);
                }
                return comp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public Composition oneCompositionMax(string ages, string sexes, int valeur)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            Composition comp = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select * from comp_maladie where age='" + ages + "' and sexe='" + sexes + "' and val_max< '" + valeur + "'", conn);

                read = command.ExecuteReader();

                while (read.Read())
                {



                    string id = read["id"].ToString();
                    int nom_inf = int.Parse(read["maladie_inf"].ToString());
                    int nom_sup = int.Parse(read["maladie_sup"].ToString());
                    string axes = read["axe"].ToString();
                    int min = int.Parse(read["val_min"].ToString());
                    int max = int.Parse(read["val_max"].ToString());
                    string age = read["age"].ToString();
                    string sexe = read["sexe"].ToString();

                    comp = new Composition(id, nom_inf, nom_sup, axes, min, max, age, sexe);
                }
                return comp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
    }
}
