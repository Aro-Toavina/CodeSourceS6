﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class MaladieDAO
    {
        public List<Maladie> listeMaladie()
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select * from maladie", conn);

                read = command.ExecuteReader();
                List<Maladie> axe = new List<Maladie>();

                while (read.Read())
                {



                    int id = int.Parse(read["id"].ToString());
                    string nom = read["nom_aretina"].ToString();
                    /*
                    string  sexe = read["sexe"].ToString();
                    string age = read["age"].ToString();
                    */

                    //                    axe.Add(new Maladie(id, nom, sexe,age));
                    axe.Add(new Maladie(id, nom));
                }
                return axe;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public int getIdMaladie(int num)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select maladie.id as id from maladie ,axe, comp_maladie where maladie.id=comp_maladie.maladie_inf and axe.id =comp_maladie.axe and axe.numero_axe='"+num+"'", conn);

                read = command.ExecuteReader();

                read.Read();



                int numero = int.Parse(read["id"].ToString());
                return numero;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

        public int getIdMaladieInf(int num)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select maladie .id from maladie,comp_maladie where maladie.id=comp_maladie.maladie_inf and comp_maladie.maladie_inf='"+num+"'", conn);

                read = command.ExecuteReader();

                read.Read();



                int numero = int.Parse(read["id"].ToString());
                return numero;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }
        public string malad(int num)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select nom_aretina from maladie where id='"+num+"'", conn);

                read = command.ExecuteReader();

               // read.Read();
                string re = "";
                if (read.Read() == null)
                    return re;
                else
                {
                    string numero =(string)read["nom_aretina"];
                    //  Maladie m = new Maladie(numero);
                    return numero;
                }
            
            
        }
        public int getIdMaladieSup(int num)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connexion c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connexion();
                conn = c.getConnect();

                command = new SqlCommand("select maladie .id from maladie,comp_maladie where maladie.id=comp_maladie.maladie_inf and comp_maladie.maladie_sup='" + num + "'", conn);

                read = command.ExecuteReader();

                read.Read();



                int numero = int.Parse(read["id"].ToString());
                return numero;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

    }
}
