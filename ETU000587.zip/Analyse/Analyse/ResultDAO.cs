﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class ResultDAO
    {
        public void insertDetaille(string nom, string sexe,int age,string res,int pourc)
        {
            Connexion c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            c = new Connexion();
            conn = c.getConnect();

            string query = "insert into resultat values(concat('Rs',next value for dbo.seqRes),'" + nom + "','" + sexe + "','" + age + "','"+res+"','"+pourc+"' )";
            command = new SqlCommand(query, conn);

            command.ExecuteNonQuery();
        }
       
    }
}
