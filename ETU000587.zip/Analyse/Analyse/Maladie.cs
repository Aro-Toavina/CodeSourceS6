﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class Maladie
    {
        int id;
        string nomAretina;
        /*
        string sexe;
        string age;
    */    
    public Maladie() { }
        /*
        public Maladie(int id,string nomAretina,string sexe,string age)
        {
            this.id = id;
            this.nomAretina = nomAretina;
            this.sexe = sexe;
            this.age=age;
        }
        public Maladie(string nomAretina, string sexe, string age)
        {
            this.nomAretina = nomAretina;
            this.sexe = sexe;
            this.age = age;
        }
        */
        public Maladie(int id, string nomAretina)
        {
            this.id = id;
            this.nomAretina = nomAretina;
          
        }
        public Maladie(string nomAretina)
        {
            this.nomAretina = nomAretina;
          
        }
        public void setNomAretina(string nomAretina)
        {
            this.nomAretina = nomAretina;
        }
        /*
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public void setAge(string age)
        {
            this.age = age;
        }
        */
        public int getId()
        {
            return this.id;
        }
        public string getNom()
        {
            return this.nomAretina;
        }
        /*
        public string getSexe()
        {
            return this.sexe;
        }
        public string getAge()
        {
            return this.age;
        }
        */
    }
}
