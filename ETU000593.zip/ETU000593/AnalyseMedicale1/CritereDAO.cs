﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AnalyseMedicale1
{
    class CritereDAO
    {


        public List<Critere> findCritere(String condition)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            Connect c = null;
            SqlDataReader read = null;
            try
            {
                c = new Connect();
                conn = c.getConnect();

                command = new SqlCommand("SELECT * FROM [dbo].[Critere] " + condition, conn);
                conn.Open();
                read = command.ExecuteReader();
                List<Critere> soc = new List<Critere>();

                while (read.Read())
                {
                    int id = int.Parse(read["id"].ToString());
                    string nom = read["nomCritere"].ToString();
                    string unite = read["unite"].ToString();
                    double debutIntervalle = double.Parse(read["debutIntervalle"].ToString());
                    double finIntervalle = double.Parse(read["finIntervalle"].ToString());
                    double debutNormal = double.Parse(read["debutNormal"].ToString());
                    double finNormal = double.Parse(read["finNormal"].ToString());




                    soc.Add(new Critere(id, nom,unite, debutIntervalle, finIntervalle, debutNormal,finNormal));
                }
                return soc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }

        public void insertCritere(Critere pe)
        {
            Connect c = null;
            SqlConnection conn = null;
            SqlCommand command = null;
            SqlDataReader read = null;

            try
            {
                c = new Connect();
                conn = c.getConnect();


                //throw new Exception("INSERT INTO[dbo].[depreciation](idproduit, datedebut, datefin, prix) VALUES(" + pe.getIdproduit() + ", '" + year + "/" + month + "/" + day + " " + heure + ":" + minute + ":" + seconde + "', '" + year0 + "/" + month0 + "/" + day0 + " " + heure0 + ":" + minute0 + ":" + seconde + "', " + pe.getPrix() + ")");
                command = new SqlCommand("INSERT INTO  [dbo].[Critere](nomCritere,unite,debutIntervalle,finIntervalle,debutNormal,finNormal) VALUES('" + pe.getNomCritere() + "','"+pe.getUnite()+ "','" + pe.getFebutIntervalle() + "','" + pe.getFinIntervalle() + "','" + pe.getDebutNormal() + "','" + pe.getFinNormal() + "')", conn);
                conn.Open();
                read = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new NotImplementedException("Echec de l'insertion : " + ex.Message);
                //Console.Error.WriteLine(ex.Message);
            }
            finally
            {
                if (read != null) read.Close();
                if (command != null) command.Dispose();
                if (conn != null) conn.Close();
            }
        }


    }
}

