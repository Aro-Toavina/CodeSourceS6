﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale1
{
    public class Resultat
    {
        int id;
        string sexe;
        int debutIntervalleAge;
        int finIntervalleAge;
        int idMaladie;
        int idcritere;
        double debutIntervalleCritere;
        double finIntervalleCritere;
        public Resultat(int id,string sexe,int debutIntervalleAge,int finIntervalleAge,int idMaladie,int idCritere,double debutIntervalleCritere,double finIntervalleCritere)
        {
            setId(id);
            setSexe(sexe);
            setDebutIntervalleAge(debutIntervalleAge);
            setFinIntervalleAge(finIntervalleAge);
            setIdMaladie(idMaladie);
            setCritere(idCritere);
            setDebutIntervalleCritere(debutIntervalleCritere);
            setFinIntervalleCritere(finIntervalleCritere);
        }
        public Resultat(string sexe, int debutIntervalleAge, int finIntervalleAge, int idMaladie, int idCritere, double debutIntervalleCritere, double finIntervalleCritere)
        {
            setSexe(sexe);
            setDebutIntervalleAge(debutIntervalleAge);
            setFinIntervalleAge(finIntervalleAge);
            setIdMaladie(idMaladie);
            setCritere(idCritere);
            setDebutIntervalleCritere(debutIntervalleCritere);
            setFinIntervalleCritere(finIntervalleCritere);
        }

        public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return this.id;
        }
        public void setSexe(string sexe)
        {
            this.sexe = sexe;
        }
        public string getSexe()
        {
            return this.sexe;
        }
        public void setDebutIntervalleAge(int debutIntervalleAge)
        {
            this.debutIntervalleAge = debutIntervalleAge;
        }
        public int getDebutIntervalleAge()
        {
            return this.debutIntervalleAge;
        }
        public void setFinIntervalleAge(int finIntervalleAge)
        {
            this.finIntervalleAge = finIntervalleAge;
        }
        public int getFinIntervalleAge()
        {
            return this.finIntervalleAge;
        }
        public int getIdcritere()
        {
            return this.idcritere;
        }
        public void setCritere(int idcritere)
        {
            this.idcritere = idcritere;
        }
        public int getCritere()
        {
            return this.idcritere;
        }
        public void setDebutIntervalleCritere(double debutIntervalleCritere)
        {
            this.debutIntervalleCritere = debutIntervalleCritere;
        }
        public double getDebutIntervalleCritere()
        {
            return this.debutIntervalleCritere;
        }
        public void setFinIntervalleCritere(double finIntervalleCritere)
        {
            this.finIntervalleCritere = finIntervalleCritere;
        }
        public double getFinIntervalleCritere()
        {
            return this.finIntervalleCritere;
        }
        public void setIdMaladie(int idMaladie)
        {
            this.idMaladie = idMaladie;
        }
        public int getIdMaladie()
        {
            return this.idMaladie;
        }
    }
}
