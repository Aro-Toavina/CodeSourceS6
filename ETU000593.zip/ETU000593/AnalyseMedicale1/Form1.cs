﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale1
{
    public partial class Form1 : Form
    {
        private int rayon;
        private int nbAxes;
        Point[] sommetpolygone;
        List<Axe> listeaxes;
        Point centre;
        Double uniteangle;
        Boolean down;
        List<String> leslabels;
        Double taux;
        Label lab;
        Label label;

        public Form1()
        {
            InitializeComponent();
            try
            {
                label = new Label();
                this.sexe.Items.Add("h");
                this.sexe.Items.Add("f");
                this.sexe.Text = "f";
                age.Text = "30";
               



                this.rayon = this.panelGraphe.Width / 2;
                this.nbAxes = 14;
                Label lab = new Label();
                //lab.Text = "maladies";
                taux = 0;

                this.sommetpolygone = new Point[this.nbAxes];
                this.centre = new Point(this.rayon, this.rayon);
                down = false;
                uniteangle =( 2 * Math.PI) / nbAxes;
                listeaxes = new List<Axe>();
                Axe axe = null;
                leslabels = new List<string>();
                //Initialisation des valeurs dans labels
                List<Critere> cr = new CritereDAO().findCritere("");
                
               // MessageBox.Show("c=" + cr.Count);
                for (int i = 0; i <this.nbAxes; i++)
                {
                    leslabels.Add(cr.ElementAt(i).getNomCritere());

                    Double currentangle = i * uniteangle;
                    Point currExtremite = getExtremite(currentangle);
                    axe = new AnalyseMedicale1.Axe(centre, currentangle, currExtremite,leslabels.ElementAt(i),cr.ElementAt(i));
                    listeaxes.Add(axe);
                    lab = new Label();
                    lab.Text = listeaxes.ElementAt(i).label;
                    lab.BackColor = Color.Transparent;
                    lab.Location = new Point(listeaxes.ElementAt(i).extremite.X, listeaxes.ElementAt(i).extremite.Y + 7);
                    panelGraphe.Controls.Add(lab);
                }

                this.panelGraphe.MouseDown += new MouseEventHandler(OnMouseDown);
                this.panelGraphe.MouseMove += new MouseEventHandler(OnMouseMove);
                this.panelGraphe.MouseUp += new MouseEventHandler(OnMouseUp);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        protected  void OnMouseDown(Object sender,MouseEventArgs e)
        {
            down = true;
        }
        protected  void OnMouseUp(Object sender, MouseEventArgs e)
        {
            down = false;
        }
        protected  void OnMouseMove(Object sender, MouseEventArgs e)
        {
            try
            {
                if (down == true)
                {
                    Point posSouris = new Point(e.X, e.Y);
                    int indiceAxe = indiceAxeProche(posSouris);
                    listeaxes.ElementAt(indiceAxe).positionSouris = posSouris;
                    listeaxes.ElementAt(indiceAxe).setA2();
                    listeaxes.ElementAt(indiceAxe).setB2();
                    listeaxes.ElementAt(indiceAxe).setPositionPolygone();
                    listeaxes.ElementAt(indiceAxe).setValeurDunPointCliqueSurAxe();
                    Point positionPolygone = listeaxes.ElementAt(indiceAxe).getPositionPolygone();
                    sommetpolygone[indiceAxe] = positionPolygone;

                    List<Critere> listeCritere = new CritereDAO().findCritere("");
                    List<Resultat> listeResultat = new ResultatDAO().findResultat("");
                    Fonction fonction = new Fonction();
                    int idmaladie = 0;
                   
                    string nomMaladie="";
                    List<String> lesmaladies= new List<String>() ;
                    List<String> lespourcentages= new List<String>();
                    List<Label> lespourcentageslabel =new List<Label>();
                    List<Label> lesmaladielabel = new List<Label>();
                    Double valeurObtenu=listeaxes.ElementAt(indiceAxe).getValeurDunPointCliqueSurAxe();
                   
                    int ageObtenu = int.Parse(age.Text);
                    Console.WriteLine("lesResultatsActuel");
                    List<Resultat> lesResultatsActuel = fonction.lesResultatsActuel(ageObtenu, sexe.Text, listeaxes, valeurObtenu);
                  
                    List<Double[]> ld=fonction.calculPourcentage(lesResultatsActuel, ageObtenu, sexe.Text, listeaxes, valeurObtenu);
                    Console.WriteLine("lesDouble"+ ld.Count);
                    int id = 0;
                    
                    Double max = ld.ElementAt(0)[1];
                    int idMaladieMax = int.Parse(ld.ElementAt(0)[0].ToString());




                    for (int i = 0; i < ld.Count; i++)
                    {
                       if (ld.ElementAt(i)[1] > max)
                        {
                            max = ld.ElementAt(i)[1];
                            idMaladieMax= int.Parse(ld.ElementAt(i)[0].ToString());
                          }

                       
                    }
                    Console.WriteLine("max=" + max);
                    Console.WriteLine("id=" + idMaladieMax);
                    maladie.Text = new MaladieDAO().findMaladie(" where id=" + idMaladieMax).ElementAt(0).getNomMaladie();
                    label7.Text = max.ToString("00.00");
                    if (sexe.Text == "f")
                    {
                        resultsexe.Text = sexe.Text+"emme";
                    }
                    if (sexe.Text == "h")
                    {
                        resultsexe.Text = sexe.Text + "omme";
                    }
                    resultage.Text = age.Text+" Ans";
                   // maladie1.Text = new MaladieDAO().findMaladie(" where id=" + idMaladieMax).ElementAt(0).getNomMaladie();
                    resultsexe.Text = sexe.Text;
                    // label.Text = new MaladieDAO().findMaladie(" where id=" + idMaladieMax).ElementAt(0).getNomMaladie() + "=" + max + "%";
                    //lesmaladielabel.Add(label);
                    Console.WriteLine("maladie" + new MaladieDAO().findMaladie(" where id=" + idMaladieMax).ElementAt(0).getNomMaladie() + "=" + max + "%");
                   
                    Console.WriteLine("nb=" + lesmaladielabel.Count);
            
                    panelGraphe.Refresh();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        public Double differenceEntre2points(Point p1,Point p2)
        {
            return Math.Sqrt(((p1.X - p2.X) * (p1.X - p2.X)) + ((p1.Y - p2.Y) * (p1.Y - p2.Y)));
           
        }
        public int indiceAxeProche(Point p)
        {
            int indice = 0;
            double differenceEntrePoints;
            try
            {
                if (listeaxes.Count>0)
                {
                    Double min = differenceEntre2points(listeaxes.ElementAt(0).extremite,p);
                    indice = 0;
                    for (int i = 1; i < listeaxes.Count; i++)
                    {
                        differenceEntrePoints= differenceEntre2points(listeaxes.ElementAt(i).extremite, p);
                        if (differenceEntrePoints < min)
                        {
                            min = differenceEntrePoints;
                            indice = i;
                        }
                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return indice;
        }
        private void panelGraphe_Paint(object sender, PaintEventArgs e)
        {
            try {
                double angle = (2 * Math.PI) / this.nbAxes;
                Graphics gr = e.Graphics;
                Pen pen1 = new Pen(Color.Brown, 3F);
                Label[] labelAAfficher = new Label[this.nbAxes];
                Label lab ;
                for (int i = 0; i < this.nbAxes; i++)
                {
                     this.tracerLigne(gr, listeaxes.ElementAt(i).extremite);
                     sommetpolygone[i]= listeaxes.ElementAt(i).positionPolygone;
                     gr.FillEllipse(new SolidBrush(Color.Orange), sommetpolygone[i].X, sommetpolygone[i].Y, 10, 10);
                     
                }
             gr.DrawPolygon(pen1, sommetpolygone);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public Point getExtremite(Double angle)
        {
            int xfin = 0;
            int yfin = 0;
            try
            {
                 xfin = (int)(this.rayon + (Math.Sin(angle) * rayon));
                 yfin = (int)(this.rayon - (Math.Cos(angle) * rayon));
               
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return new Point(xfin, yfin);
        }
        private void tracerLigne(Graphics gr,Point pointExtremite)
        {
            
            try
            {
             
                Pen p = new Pen(Color.DimGray, 3);
                Point point1 = centre;
                Point point2 = pointExtremite ;
                gr.DrawLine(p, point1, point2);
                /*gr.FillEllipse(new SolidBrush(Color.Orange), xfin, yfin, 8, 8);
                Label lab = new Label();
                lab.Text = "test(" + xfin + ";" + yfin + ")";
                lab.BackColor = Color.Transparent;
                lab.Location = new Point(xfin, yfin + 10);
                panelGraphe.Controls.Add(lab);*/

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
