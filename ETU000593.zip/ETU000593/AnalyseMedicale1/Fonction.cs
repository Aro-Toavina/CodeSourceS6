﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale1
{

    public class Fonction
    {
        public Maladie m;
        List<Resultat> lesResultats;
        public Double differenceEntre2points(Point p1, Point p2)
        {
            return Math.Sqrt(((p1.X - p2.X) * (p1.X - p2.X)) + ((p1.Y - p2.Y) * (p1.Y - p2.Y)));

        }
        public List<Resultat> lesResultatsActuel(int age,string sexe,List<Axe> lesAxes,Double valeur)
        {
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberDecimalSeparator = ".";
            List<Resultat> lr = new List<Resultat>();
            Console.WriteLine("lr=" + lesAxes.Count);
            for(int i = 0; i < lesAxes.Count; i++)
            {

                List<Resultat> liste = new ResultatDAO().findResultat(" where debutIntervalleAge<=" + age + " and finIntervalleAge>=" + age + " and sexe='" + sexe + "' and debutIntervalleCritere<=" + valeur.ToString(nfi) + " and finIntervalleCritere>=" + valeur.ToString(nfi));
                for (int j = 0; j < liste.Count; j++) {
                   lr.Add(liste.ElementAt(j));
                }

                   
            }
            Console.WriteLine("Fin lesResultatsActuel");
            return lr;
         }
       
        public List<Double[]> calculPourcentage(List<Resultat> lr, int age, string sexe, List<Axe> lesAxes, Double valeur)
        {
            List<Double[]> lesDoubles = new List<Double[]>();
            Double[] pourcentageTemp = new Double[2];

            Double taux = 0;
            for(int i = 0; i < lr.Count; i++)
            {
               if (valeur>lr.ElementAt(i).getDebutIntervalleCritere())
                {
                    taux = (100 * (valeur - lr.ElementAt(i).getDebutIntervalleCritere()) )/ (lr.ElementAt(i).getFinIntervalleCritere() - lr.ElementAt(i).getDebutIntervalleCritere());
                }
                else if(valeur <lr.ElementAt(i).getDebutIntervalleCritere())
                {
                    taux =(100*(lr.ElementAt(i).getFinIntervalleCritere()-valeur))/(lr.ElementAt(i).getFinIntervalleCritere()- lr.ElementAt(i).getDebutIntervalleCritere());

                }
                else
                {
                    taux = 0;
                }
                pourcentageTemp[0] = lr.ElementAt(i).getIdMaladie();//Id de resultat
                pourcentageTemp[1] = taux;//taux correspondant au resultat
                lesDoubles.Add(pourcentageTemp);
            }
            return lesDoubles;
        }


        public Double getValeurDunPointCliqueSurAxe(Point p1,Point p2,Critere critere,Panel p)
        {
            double rep=0;
            rep = ((critere.getFebutIntervalle() -critere.getFinIntervalle()) * differenceEntre2points(p1, p2))/(p.Width/2);
            return rep;
        }
        public Double calculPourcentageSurUnAxe(Point p1, Point p2, Critere critere, Panel p,Resultat resultat)
        {
            double taux = 0;
            double intervalleMaladie = 0;
            double temp = 0;
            
            intervalleMaladie = (resultat.getDebutIntervalleCritere() + resultat.getFinIntervalleCritere()) / 2;
          
            temp = getValeurDunPointCliqueSurAxe(p1,p2,critere,p);
            m = new Maladie(2,"");
            m.setId(resultat.getIdMaladie());
            MessageBox.Show("id=" + resultat.getIdMaladie());
            Console.WriteLine("C1 taux=" + critere.getDebutNormal());
            if (temp < critere.getDebutNormal() && temp > critere.getFinNormal())
            {
                taux = 0;
                Console.WriteLine("C1 taux=" + taux);
            }
            else
            {
                if(temp<resultat.getDebutIntervalleCritere() && temp > resultat.getFinIntervalleCritere())
                {
                    if(temp< intervalleMaladie)
                    {
                        taux = (temp * 100) / intervalleMaladie;
                        Console.WriteLine("C2 taux=" + taux);
                    }
                    else if(temp > intervalleMaladie)
                    {
                        taux = 100 - (temp - 100);
                        Console.WriteLine("C3 taux=" + taux);
                    }
                    else
                    {
                        taux = 0;
                        Console.WriteLine("C4 taux=" + taux);
                    }
                }
            }

          
            return taux;
          

        }
         

    }
}
