﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale1
{
   public class Critere
    {
        int id;
        string nomCritere;
        string unite;
        double debutIntervalle;
        double finIntervalle;
        double debutNormal;
        double finNormal;

        public Critere(int id,string nomCritere,string unite,double debutIntervalle,double finIntervalle,double debutNormal,double finNormal)
        {
            setId(id);
            setNomCritere(nomCritere);
            setUnite(unite);
            setDebutIntervalle(debutIntervalle);
            setFinIntervalle(finIntervalle);
            setDebutNormal(debutNormal);
            setFinIntervalle(finNormal);
        }
        public Critere(string nomCritere, string unite, double debutIntervalle, double finIntervalle, double debutNormal, double finNormal)
        {
            
            setNomCritere(nomCritere);
            setUnite(unite);
            setDebutIntervalle(debutIntervalle);
            setFinIntervalle(finIntervalle);
            setDebutNormal(debutNormal);
            setFinIntervalle(finNormal);
        }

        public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return this.id;
        }
        public void setNomCritere(string nomCritere)
        {
            this.nomCritere = nomCritere;
        }
        public string getNomCritere()
        {
            return this.nomCritere;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public string getUnite()
        {
            return this.unite;
        }
        public void setDebutIntervalle(double debutIntervalle)
        {
            this.debutIntervalle = debutIntervalle;
        }
        public double getFebutIntervalle()
        {
            return this.debutIntervalle;
        }
        public void setFinIntervalle(double finIntervalle)
        {
            this.finIntervalle = finIntervalle;
        }
        public double getFinIntervalle()
        {
            return this.finIntervalle;
        }
        public void setDebutNormal(double debutNormal)
        {
            this.debutNormal = debutNormal;
        }
        public double getDebutNormal()
        {
            return this.debutNormal;
        }
        public void setFinNormal(double finNormal)
        {
            this.finNormal = finNormal;
        }
        public double getFinNormal()
        {
            return this.finNormal;
        }
    }
}
