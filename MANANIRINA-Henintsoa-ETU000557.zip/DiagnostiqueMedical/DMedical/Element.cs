﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Element
    {

        int id;
        string description;
        double currval;
        double minval;
        double maxval;
        double minnormval;
        double maxnormval;
        string unite;

        public Element()
        {

        }
        public Element(int id, string desc, double currval, double minval, double maxval, string unite)
        {
            this.setid(id);
            this.setdesc(desc);
            this.setcurrval(currval);
            this.setminval(minval);
            this.setmaxval(maxval);
            this.setunite(unite);
        }
        public Element(int id, string desc, string unite, double minval, double maxval)
        {

            this.setid(id);
            this.setdesc(desc);
            this.setminval(minval);
            this.setmaxval(maxval);
          
            this.setunite(unite);
        }
      /*  public Diagnostique(int id, string desc, double currval, double minval, double maxval, string unite)
        {

            this.setdesc(desc);
            this.setcurrval(currval);
            this.setminval(minval);
            this.setmaxval(maxval);
            this.setminnormval(minnormval);
            this.setmaxnormval(maxnormval);
            this.setunite(unite);
        }*/
        public int getid()
        {
            return id;
        }
        public string getdesc()
        {
            return description;
        }
        public double getcurrval()
        {
            return currval;
        }
        public double getminval()
        {
            return minval;
        }
        public double getmaxval()
        {
            return maxval;
        }
        public string getunite()
        {
            return unite;
        }

        public void setid(int id)
        {
            this.id = id;
        }
        public void setdesc(string desc)
        {
            this.description = desc;
        }
        public void setcurrval(double currval)
        {
            this.currval = currval;
        }
        public void setminval(double minval)
        {
            this.minval = minval;
        }
        public void setmaxval(double maxval)
        {
            this.maxval = maxval;
        }

  
        public void setunite(string unite)
        {
            this.unite = unite;
        }


        public List<Element> findElement(String critere)
        {
            List<Element> liste = new List<Element>();
            List<int> id = new List<int>();
            List<string> desc = new List<string>();
            List<Double> minval = new List<Double>();
            List<Double> maxval = new List<Double>();
            List<string> unite = new List<string>();

            Element ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            try
            {
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Element]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Element] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                        // Console.WriteLine("miditra boucle1");
                        id.Add(read.GetByte(0));

                        desc.Add(read.GetString(1));
                        unite.Add(read.GetString(2));
                        maxval.Add(read.GetDouble(3));
                        minval.Add(read.GetDouble(4));
                        //Console.WriteLine("mivoka boucle1");
                      
                       

                    }


                    for (int k = 0; k < id.Count; k++)
                    {
                        ma = new Element(id.ElementAt(k), desc.ElementAt(k), unite.ElementAt(k), minval.ElementAt(k), maxval.ElementAt(k));
                        liste.Add(ma);

                    }


                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connexion.Close();
            }

            return liste;
        }
    }
}
