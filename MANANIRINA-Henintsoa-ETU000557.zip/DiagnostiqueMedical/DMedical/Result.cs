﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    class Result
    {
        public String maladie;
        public Double pourcentage;

        public Result()
        {

        }
        public Result(string maladie, double prct)
        {
            this.setmaladie(maladie);
            this.setprctg(prct);
        }
        public string getmaladie()
        {
            return maladie;
        }
        public double getprctg()
        {
            return pourcentage;
        }

        public void setmaladie(string mld)
        {
            this.maladie = mld;
        }
        public void setprctg(double p)
        {
            this.pourcentage = p;
        }
    }
}
