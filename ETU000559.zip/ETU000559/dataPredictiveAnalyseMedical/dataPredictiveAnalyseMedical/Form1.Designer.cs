﻿namespace dataPredictiveAnalyseMedical
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.radarChart = new System.Windows.Forms.Panel();
            this.dataInsert = new System.Windows.Forms.Panel();
            this.ageValueNumeriqueBox = new System.Windows.Forms.NumericUpDown();
            this.AnalyseButton = new System.Windows.Forms.Button();
            this.sexeLabel = new System.Windows.Forms.Label();
            this.sexeComboBox = new System.Windows.Forms.ComboBox();
            this.ageLabel = new System.Windows.Forms.Label();
            this.dataDiagnostic = new System.Windows.Forms.Panel();
            this.diagnosticDataGridView = new System.Windows.Forms.DataGridView();
            this.reference = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elementDiagnostic = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valeurTaux = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maxValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titreLabel = new System.Windows.Forms.Label();
            this.resultatProbabilitePanel = new System.Windows.Forms.Panel();
            this.resultatDataGridView = new System.Windows.Forms.DataGridView();
            this.maladie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.probabilite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultatlabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataInsert.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ageValueNumeriqueBox)).BeginInit();
            this.dataDiagnostic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagnosticDataGridView)).BeginInit();
            this.resultatProbabilitePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultatDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // radarChart
            // 
            this.radarChart.Location = new System.Drawing.Point(32, 27);
            this.radarChart.Name = "radarChart";
            this.radarChart.Size = new System.Drawing.Size(483, 481);
            this.radarChart.TabIndex = 0;
            this.radarChart.Paint += new System.Windows.Forms.PaintEventHandler(this.radarChart_Paint);
            // 
            // dataInsert
            // 
            this.dataInsert.Controls.Add(this.ageValueNumeriqueBox);
            this.dataInsert.Controls.Add(this.AnalyseButton);
            this.dataInsert.Controls.Add(this.sexeLabel);
            this.dataInsert.Controls.Add(this.sexeComboBox);
            this.dataInsert.Controls.Add(this.ageLabel);
            this.dataInsert.Location = new System.Drawing.Point(557, 12);
            this.dataInsert.Name = "dataInsert";
            this.dataInsert.Size = new System.Drawing.Size(166, 144);
            this.dataInsert.TabIndex = 1;
            // 
            // ageValueNumeriqueBox
            // 
            this.ageValueNumeriqueBox.Location = new System.Drawing.Point(57, 15);
            this.ageValueNumeriqueBox.Name = "ageValueNumeriqueBox";
            this.ageValueNumeriqueBox.Size = new System.Drawing.Size(100, 20);
            this.ageValueNumeriqueBox.TabIndex = 0;
            this.ageValueNumeriqueBox.ValueChanged += new System.EventHandler(this.ageValueTextBox_ValueChanged);
            // 
            // AnalyseButton
            // 
            this.AnalyseButton.Location = new System.Drawing.Point(82, 104);
            this.AnalyseButton.Name = "AnalyseButton";
            this.AnalyseButton.Size = new System.Drawing.Size(75, 23);
            this.AnalyseButton.TabIndex = 4;
            this.AnalyseButton.Text = "Analyser";
            this.AnalyseButton.UseVisualStyleBackColor = true;
            this.AnalyseButton.Click += new System.EventHandler(this.AnalyseButton_Click);
            // 
            // sexeLabel
            // 
            this.sexeLabel.AutoSize = true;
            this.sexeLabel.Location = new System.Drawing.Point(3, 50);
            this.sexeLabel.Name = "sexeLabel";
            this.sexeLabel.Size = new System.Drawing.Size(29, 13);
            this.sexeLabel.TabIndex = 3;
            this.sexeLabel.Text = "sexe";
            // 
            // sexeComboBox
            // 
            this.sexeComboBox.FormattingEnabled = true;
            this.sexeComboBox.Location = new System.Drawing.Point(57, 50);
            this.sexeComboBox.Name = "sexeComboBox";
            this.sexeComboBox.Size = new System.Drawing.Size(100, 21);
            this.sexeComboBox.TabIndex = 2;
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(16, 15);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(35, 13);
            this.ageLabel.TabIndex = 0;
            this.ageLabel.Text = "Age : ";
            // 
            // dataDiagnostic
            // 
            this.dataDiagnostic.Controls.Add(this.diagnosticDataGridView);
            this.dataDiagnostic.Controls.Add(this.titreLabel);
            this.dataDiagnostic.Location = new System.Drawing.Point(557, 214);
            this.dataDiagnostic.Name = "dataDiagnostic";
            this.dataDiagnostic.Size = new System.Drawing.Size(391, 294);
            this.dataDiagnostic.TabIndex = 2;
            // 
            // diagnosticDataGridView
            // 
            this.diagnosticDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.diagnosticDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.reference,
            this.elementDiagnostic,
            this.valeurTaux,
            this.minValue,
            this.maxValue});
            this.diagnosticDataGridView.Location = new System.Drawing.Point(6, 33);
            this.diagnosticDataGridView.Name = "diagnosticDataGridView";
            this.diagnosticDataGridView.Size = new System.Drawing.Size(372, 258);
            this.diagnosticDataGridView.TabIndex = 1;
            // 
            // reference
            // 
            this.reference.HeaderText = "Reference";
            this.reference.Name = "reference";
            // 
            // elementDiagnostic
            // 
            this.elementDiagnostic.HeaderText = "Element Diagnostic";
            this.elementDiagnostic.Name = "elementDiagnostic";
            // 
            // valeurTaux
            // 
            this.valeurTaux.HeaderText = "valeur du Taux";
            this.valeurTaux.Name = "valeurTaux";
            // 
            // minValue
            // 
            this.minValue.HeaderText = "Valeur min du taux normal";
            this.minValue.Name = "minValue";
            // 
            // maxValue
            // 
            this.maxValue.HeaderText = "Valeur max du Taux normal";
            this.maxValue.Name = "maxValue";
            // 
            // titreLabel
            // 
            this.titreLabel.AutoSize = true;
            this.titreLabel.Location = new System.Drawing.Point(16, 17);
            this.titreLabel.Name = "titreLabel";
            this.titreLabel.Size = new System.Drawing.Size(123, 13);
            this.titreLabel.TabIndex = 0;
            this.titreLabel.Text = "les valeurs du diagnostic";
            // 
            // resultatProbabilitePanel
            // 
            this.resultatProbabilitePanel.Controls.Add(this.resultatDataGridView);
            this.resultatProbabilitePanel.Controls.Add(this.resultatlabel);
            this.resultatProbabilitePanel.Location = new System.Drawing.Point(729, 12);
            this.resultatProbabilitePanel.Name = "resultatProbabilitePanel";
            this.resultatProbabilitePanel.Size = new System.Drawing.Size(231, 144);
            this.resultatProbabilitePanel.TabIndex = 3;
            // 
            // resultatDataGridView
            // 
            this.resultatDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultatDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maladie,
            this.probabilite});
            this.resultatDataGridView.Location = new System.Drawing.Point(3, 34);
            this.resultatDataGridView.Name = "resultatDataGridView";
            this.resultatDataGridView.Size = new System.Drawing.Size(228, 107);
            this.resultatDataGridView.TabIndex = 1;
            // 
            // maladie
            // 
            this.maladie.HeaderText = "Maladie";
            this.maladie.Name = "maladie";
            // 
            // probabilite
            // 
            this.probabilite.HeaderText = "Probabilité";
            this.probabilite.Name = "probabilite";
            // 
            // resultatlabel
            // 
            this.resultatlabel.AutoSize = true;
            this.resultatlabel.Location = new System.Drawing.Point(14, 12);
            this.resultatlabel.Name = "resultatlabel";
            this.resultatlabel.Size = new System.Drawing.Size(192, 13);
            this.resultatlabel.TabIndex = 0;
            this.resultatlabel.Text = "les maladies susceptibles d\'être atteinte";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(557, 162);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(391, 46);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 65);
            this.label1.TabIndex = 5;
            this.label1.Text = "Pour initialiser le graphe et les valeurs du diagnostic ,\r\nveuillez entrer l\'age " +
    "et le sexe  avant de commencer l\'analyse.\r\nPar defaut, la valeur de chaque axe e" +
    "st normale\r\n\r\n\r\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 520);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.resultatProbabilitePanel);
            this.Controls.Add(this.dataDiagnostic);
            this.Controls.Add(this.dataInsert);
            this.Controls.Add(this.radarChart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.dataInsert.ResumeLayout(false);
            this.dataInsert.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ageValueNumeriqueBox)).EndInit();
            this.dataDiagnostic.ResumeLayout(false);
            this.dataDiagnostic.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diagnosticDataGridView)).EndInit();
            this.resultatProbabilitePanel.ResumeLayout(false);
            this.resultatProbabilitePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultatDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel radarChart;
        private System.Windows.Forms.Panel dataInsert;
        private System.Windows.Forms.Label ageLabel;
        public System.Windows.Forms.Panel dataDiagnostic;
        private System.Windows.Forms.Label titreLabel;
        private System.Windows.Forms.Panel resultatProbabilitePanel;
        private System.Windows.Forms.Label resultatlabel;
        private System.Windows.Forms.Label sexeLabel;
        private System.Windows.Forms.ComboBox sexeComboBox;
        private System.Windows.Forms.Button AnalyseButton;
        private System.Windows.Forms.DataGridView resultatDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn maladie;
        private System.Windows.Forms.DataGridViewTextBoxColumn probabilite;
        public System.Windows.Forms.DataGridView diagnosticDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn reference;
        private System.Windows.Forms.DataGridViewTextBoxColumn elementDiagnostic;
        private System.Windows.Forms.DataGridViewTextBoxColumn valeurTaux;
        private System.Windows.Forms.DataGridViewTextBoxColumn minValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn maxValue;
        private System.Windows.Forms.NumericUpDown ageValueNumeriqueBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}

