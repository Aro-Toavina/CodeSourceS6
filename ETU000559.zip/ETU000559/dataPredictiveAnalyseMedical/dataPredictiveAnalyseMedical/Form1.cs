﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.dao;
using System.Data.SqlClient;

namespace dataPredictiveAnalyseMedical
{
    public partial class Form1 : Form
    {
        private Point centre;
        List<PointValueAxe> pointValueAxePanelList;
        List<DosageDiagnosticView> dosageDiagnosticList= new List<DosageDiagnosticView> ();
        List<utilitaire.AboutMaladie> maladieList=new List<utilitaire.AboutMaladie>();
        int rayon=0;
        Point margeConteneur;
        Boolean firstInit = true;
        int nbrAxes      = 0;

        public Form1()
        {
            
            InitializeComponent();

            int xc = radarChart.Width / 2;
            int yc = radarChart.Width / 2;
            this.centre = new Point(xc, yc);

             rayon = radarChart.Width / 2;
            Console.WriteLine(" rayonnnnnnn " + rayon);
            //init element
            sexeComboBox.Items.Add(0);
            sexeComboBox.Items.Add(1);
            sexeComboBox.SelectedIndex = 0;

            DiagnosticDAO diagnosticdao     = new DiagnosticDAO();
            List<Diagnostic> diagnosticList = diagnosticdao.findDiagnostic(" ");
            this.nbrAxes                     = diagnosticList.Count;

            int angle           = 360;
            Utilitaire util     = new Utilitaire();
            double angleRadian  = util.DegreeToRadian(angle) / nbrAxes;
            initializePoint( angleRadian, rayon, diagnosticList);
            this.fillTableau(pointValueAxePanelList);


            initializePointPanel();
            this.margeConteneur = new Point(128, 27);

            //test projection orthogonal
            /* utilitaire.Point projete;
             utilitaire.Point[] pointList = new utilitaire.Point[2];
             pointList[0] = new utilitaire.Point(centre.X, centre.Y);
             pointList[1] = new utilitaire.Point(pointValueAxePanelList[0].getX(), pointValueAxePanelList[0].getY());
             projete = util.projectionOrthogonal(pointList, new utilitaire.Point(434, 154));

             Console.WriteLine("resultat projection "+ projete.xAcces+ "y " + projete.yAcces);*/

            //test echelle
            //double mesure=util.echelle(2, 4, 3, 6, 1, 1);
            //Console.WriteLine(" mesure " + mesure);

            //test Probabilite Maladie d'un diagnostic
            double probabilite = util.probabiliteMaladieByQuantite(3, 6, 4, 1);
           // double probabilite = util.probabiliteMaladieByQuantite(5.3, 6.6, 5.637, 1);

            Console.WriteLine(" probabilite "+ probabilite);

            //test finLists
           /* SqlConnection connection = null;
            try
            {

                utilitaire.Connect connex = new utilitaire.Connect();
                 connection = connex.getConnexion();
                MaladieAtteinteDAO maladieAtteinteDao = new MaladieAtteinteDAO();
                List<MaladieAtteinteView> maladieAtteinteList = maladieAtteinteDao.findMaladieAtteinteView(" ", connection);
                MaladieAtteinteView maladie = maladieAtteinteList.Find(uneMaladie => uneMaladie.idMaladieAcces == "MAL15");
                Console.WriteLine(" total critere " + maladie.getId());
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null) connection.Close();
            }*/
        }

        private void radarChart_Paint(object sender, PaintEventArgs e)
        {
            if (this.firstInit == true)
            {

                int xc = radarChart.Width / 2;
                int yc = radarChart.Width / 2;
                this.centre = new Point(xc, yc);

                int rayon = radarChart.Width / 2;
                int nbrAxes = this.nbrAxes;
                int angle = 360;
                Utilitaire utilitaire = new Utilitaire();
                double angleRadian = utilitaire.DegreeToRadian(angle) / nbrAxes;

                //int x = 2 * rayon;
                //int y = rayon;
                // Point p = new Point(x, y);
                Graphics g = e.Graphics;

                drawAxes(g, nbrAxes, angleRadian, rayon);
                //initializePoint();
                //this.firstInit = false;
                //Console.WriteLine("nbr");
                // MessageBox.Show(" nbr");
            }

        }
        

        private void drawAxe(Graphics g, Point p, double angleRadian)
        {
            Pen pen = new Pen(Color.Black, 2);
            g.DrawLine(pen, this.centre, p);
        }

        private void drawAxes(Graphics g, int nbrAxes, double angleRadian, int rayon)
        {

           double angle;
/*nbr*/            for (int axe = 0; axe < nbrAxes; axe++)
            {
               // MessageBox.Show(" nbr" + axe);
                //Console.WriteLine(" nbr" + axe);
                angle = (angleRadian) * axe;
                int x = (int)(centre.X+(rayon * Math.Cos(angle)));
                int y = (int)(centre.Y-(rayon * Math.Sin(angle)));

               Point p = new Point(x, y);

                //MessageBox.Show("centre  "+centre+" nbr :" + axe + " coord" + p + " angle " + angle+ " pi"+ angleRadian);
                this.drawAxe(g, p, angleRadian);
                
                /* double x = (p.X - rayon) * Math.Cos(angleRadian) - (p.Y - rayon)* Math.Sin(angleRadian) +rayon;
                 double y= (p.X - rayon) * Math.Sin(angleRadian) - (p.Y - rayon) * Math.Cos(angleRadian) + rayon;
                 */

                //MessageBox.Show("y  " + rayon * Math.Sin(angle) + " y int " + y);

            }
        }

        public void drawPolygone(Graphics g, PointValueAxe pointValueAxePanel)
        {
            Pen p = new Pen(Color.Purple, 2);
/*nbr*/            Point[] allPoint = new Point[nbrAxes];

            for (int i = 0; i < pointValueAxePanelList.Count; i++)
            {
                if (pointValueAxePanelList[i].numeroAxeAcces == pointValueAxePanel.numeroAxeAcces)
                {
                    pointValueAxePanelList[i].setX(pointValueAxePanel.getX());
                    pointValueAxePanelList[i].setY(pointValueAxePanel.getY());
                }
                allPoint[i] = new Point(pointValueAxePanelList[i].getX(), pointValueAxePanelList[i].getY() );
            }
            g.DrawPolygon(p, allPoint);
        }

        public void initializePoint( double angleRadian, int rayon, List<Diagnostic> diagnosticList)
        {

            //BDD
            int nbrAxes                                 = diagnosticList.Count;
            
            List<PointValueAxe> pointValueAxePanelListe = new List<PointValueAxe>();
            double angle;
/*nbr*/     for (int axe = 0; axe < nbrAxes; axe++)
            {
                angle   = (angleRadian) * axe;
                int x   = (int)( centre.X + (rayon * Math.Cos(angle)) );
                int y   = (int)( centre.Y - (rayon * Math.Sin(angle)) );

                int xCentreAxe = (centre.X + x) / 2;
                int yCentreAxe = (centre.Y + y) / 2;
                Point p = new Point(xCentreAxe, yCentreAxe);
                pointValueAxePanelListe.Add(new PointValueAxe(p.X, p.Y, 10 ,axe + 1, new DosageDiagnosticView("id", diagnosticList[axe].getId(), diagnosticList[axe].getId()+ ":"+axe , diagnosticList[axe].mesureAcces, 0, 0, 0), margeConteneur,centre,p, rayon));
               // pointValueAxePanelListe.ElementAt(axe).MouseUp += new MouseEventHandler(pointValueAxePanelListe.ElementAt(axe).pointAxe_OnMouseUp);


            }
            this.pointValueAxePanelList = pointValueAxePanelListe;
        }

        public void initializePointPanel() {

            for (int i = 0; i < this.pointValueAxePanelList.Count; i++)
            {
                radarChart.Controls.Add(pointValueAxePanelList[i]);
            }
        }

        public void fillTableau(List<PointValueAxe> pointValueAxePanelListe)
        {
            int nbr = 1;
            //string[] row;
            this.diagnosticDataGridView.Rows.Clear();
            foreach (PointValueAxe pointValueAxePanel in pointValueAxePanelListe) {
                string[] row = { nbr.ToString() , pointValueAxePanel.diagnosticAxeAcces.getIntitule(), pointValueAxePanel.diagnosticAxeAcces.getCurrentQuantite().ToString() ,pointValueAxePanel.diagnosticAxeAcces.getMinQuantite().ToString() , pointValueAxePanel.diagnosticAxeAcces.getMaxQuantite().ToString() };
                this.diagnosticDataGridView.Rows.Add(row);
                nbr++;
          }
        }

        private void ageValueTextBox_ValueChanged(object sender, EventArgs e)
        {
            //Console.WriteLine(" age changed " ); 

             utilitaire.Analyse analyse = new utilitaire.Analyse();
            this.dosageDiagnosticList=analyse.getNewDosageDiagnosticList(Convert.ToDouble( this.ageValueNumeriqueBox.Value),Convert.ToInt32( this.sexeComboBox.SelectedItem) );
           // Console.WriteLine("oooooooooooooooo" + this.pointValueAxePanelList.ElementAt(0).diagnosticAxeAcces.getIntitule());
            this.pointValueAxePanelList=analyse.updateDiagnosticCaracteristique(this.pointValueAxePanelList, this.dosageDiagnosticList );
            this.fillTableau(this.pointValueAxePanelList);


        }

        private void AnalyseButton_Click(object sender, EventArgs e)
        {

            Console.WriteLine(" button changed " ); 
            this.resultatDataGridView.Rows.Clear();
            utilitaire.Analyse analyse = new utilitaire.Analyse();
            this.maladieList.Clear();
            this.maladieList = analyse.Resultat( this.pointValueAxePanelList, this.maladieList, new utilitaire.Point(this.centre.X, this.centre.Y), this.rayon );
            fillTableauResultatMaladie(this.maladieList);
        }


        public void fillTableauResultatMaladie(List<utilitaire.AboutMaladie> maladieList)
        {
            int nbr = 1;
            //string[] row;
            this.resultatDataGridView.Rows.Clear();
            foreach (utilitaire.AboutMaladie maladie in maladieList)
            {
                string[] row = { maladie.nomAcces, maladie.pourcentageAcces.ToString()};
                this.resultatDataGridView.Rows.Add(row);
                nbr++;
            }
        }

        /*private void ageValueTextBox_TextChanged(object sender, EventArgs e)
        {
         }*/
    }

}
