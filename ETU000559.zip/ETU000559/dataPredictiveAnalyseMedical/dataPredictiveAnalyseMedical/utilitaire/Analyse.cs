﻿using dataPredictiveAnalyseMedical.dao;
using dataPredictiveAnalyseMedical.data;
using dataPredictiveAnalyseMedical.model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.utilitaire
{
    public class Analyse
    {
        public void initializeDataChart(List<PointValueAxe> pointValueAxePanelList,  double age, int sexe, Point centrePanel, int rayon)
        {

        }

        public List<AboutMaladie>  Resultat(List<PointValueAxe> pointValueAxePanelList, List<AboutMaladie> maladieList,  Point centrePanel, int rayon)
        {
            SqlConnection connection = null;
            try
            {
                Connect connex                          = new Connect();
                connection                              = connex.getConnexion();
                MaladieAtteinteDAO maladieAtteinteDao   = new MaladieAtteinteDAO();
                String conditionQuery                   = " ";
                int statut                              = 2;

                //          = new List<AboutMaladie>();
               // DosageDiagnosticDAO DosageDiagnosticdao = new DosageDiagnosticDAO();
               // dosageDiagnosticList                    = DosageDiagnosticdao.findDosageDiagnosticView(" and  minAge<" + age + " and maxAge>" + age + " and sexe=" + sexe);

                Utilitaire utilitaire                   = new Utilitaire();
                int nbrAxes                             = pointValueAxePanelList.Count;
                Console.WriteLine(" count " + nbrAxes);

                
                for (int axe = 0; axe < nbrAxes; axe++)
                {
                    
                    //double distance = ;
                    /*double currentDistance  = utilitaire.distanceBetween2Point(centrePanel, new Point(pointValueAxePanelList[axe].getX(), pointValueAxePanelList[axe].getY()));
                    double currentValue     = utilitaire.echelle(pointValueAxePanelList[axe].distanceAcces, rayon, pointValueAxePanelList[axe].diagnosticAxeAcces.getMinQuantite(), pointValueAxePanelList[axe].diagnosticAxeAcces.getMaxQuantite(), Configuration.longBeforeAxeOfNormalValue, Configuration.longAfterAxeOfNormalValue);// 1 longeur sur graphe = ? sur mesure reel
                    pointValueAxePanelList[axe].diagnosticAxeAcces.setCurrentQuantite(currentValue);
                    */
                    statut = utilitaire.getInterpretationValue(pointValueAxePanelList[axe].diagnosticAxeAcces.getMinQuantite(), pointValueAxePanelList[axe].diagnosticAxeAcces.getMaxQuantite(), pointValueAxePanelList[axe].diagnosticAxeAcces.getCurrentQuantite());

                    if (statut != 2)
                    {
                        Console.WriteLine(" status " + statut);
                        conditionQuery = " and statut=" + statut + " and idDiagnostic='" + pointValueAxePanelList[axe].diagnosticAxeAcces.idDiagnosticAcces + "'";

                        List < MaladieAtteinteView > maladieAtteinteList = maladieAtteinteDao.findMaladieAtteinteView( conditionQuery, connection);
                        utilitaire.diseaseProbability( maladieList, maladieAtteinteList, utilitaire.getMargeMin(pointValueAxePanelList[axe].diagnosticAxeAcces.getMinQuantite(), pointValueAxePanelList[axe].diagnosticAxeAcces.getMaxQuantite(), statut), utilitaire.getMargeMax(pointValueAxePanelList[axe].diagnosticAxeAcces.getMinQuantite(), pointValueAxePanelList[axe].diagnosticAxeAcces.getMaxQuantite(), statut), pointValueAxePanelList[axe].diagnosticAxeAcces.getCurrentQuantite() );
                        Console.WriteLine(" count " + maladieList[0].pourcentageAcces);
                    }
                   /* else
                    {
                        maladieList.Add( new AboutMaladie(" 1 ", "2", 3) );
                    }*/
                    //echelle(double distanceX, double rayon, double minQuantite, double maxQuantite, int longBefore, int longAfter )
                }

                AtteinteDAO atteintedao = new AtteinteDAO();
                int nbrDiagnostic = 0;
                foreach (AboutMaladie maladie in maladieList)
                {
                    nbrDiagnostic = atteintedao.nbrDiagnosticByMaladie ( maladie.getId(), connection );
                    maladie.pourcentageAcces = maladie.pourcentageAcces / nbrDiagnostic;
                }
                return  ( maladieList.OrderByDescending(maladie => maladie.pourcentageAcces).ToList() );
            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null) connection.Close();
            }
        }

        public List<DosageDiagnosticView> getNewDosageDiagnosticList( double age, int sexe)
        {
            SqlConnection connection = null;
            try
            {
                DosageDiagnosticDAO DosageDiagnosticdao = new DosageDiagnosticDAO();
                return DosageDiagnosticdao.findDosageDiagnosticView(" and  minAge<" + age + " and maxAge>" + age + " and (sexe=" + sexe +" or sexe=2)");
               
                // dosageDiagnosticList.ForEach(x => Console.WriteLine(" taaaaaaaaaaaaaaaaaa" + x.idDiagnosticAcces));
                //Console.WriteLine(" taaaaaaaaaaaaaaaaaa"+ dosageDiagnosticList.ElementAt(0).getId());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                throw e;
            }
            finally
            {
                if (connection != null) connection.Close();
            }
        }

        public List<PointValueAxe> updateDiagnosticCaracteristique(List<PointValueAxe> pointValueAxePanelListe, List<DosageDiagnosticView> dosageDiagnosticList)
        {
            
            foreach (PointValueAxe pointValueAxePanel in pointValueAxePanelListe)
            {
                foreach (DosageDiagnosticView dosageDiagnostic in dosageDiagnosticList)
                {
                    Console.WriteLine(pointValueAxePanel.diagnosticAxeAcces.idDiagnosticAcces + " taaaaaaaaaaaaaaaaaa"+ dosageDiagnostic.idDiagnosticAcces);
                    if (pointValueAxePanel.diagnosticAxeAcces.idDiagnosticAcces.Equals(dosageDiagnostic.idDiagnosticAcces)) {

                        double currentValue = (  ((dosageDiagnostic.getMaxQuantite() - dosageDiagnostic.getMinQuantite()) / 2) + dosageDiagnostic.getMinQuantite() );
                        dosageDiagnostic.setCurrentQuantite(currentValue);


                        Console.WriteLine(" taaaaaaaaaaaaaaaaaa");
                        pointValueAxePanel.diagnosticAxeAcces = dosageDiagnostic;
                        break;
                    }
                }
            }
            return pointValueAxePanelListe;
        }
    }
}
