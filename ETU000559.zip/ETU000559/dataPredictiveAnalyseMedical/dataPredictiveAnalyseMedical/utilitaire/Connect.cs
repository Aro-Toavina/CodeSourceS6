﻿using System;
using  System.Data.SqlClient;

namespace dataPredictiveAnalyseMedical.utilitaire
{
    public class Connect
    {
        public Connect()
        {
        }
        
        public SqlConnection getConnexion()
        {
            SqlConnection connection = null;
            try
            {
                String connex = "Data Source=(local);Initial Catalog=analyseMedical;Integrated Security=True";
                connection = new SqlConnection(connex);
                connection.Open();
                return connection;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                //connection.Close();
            }
        }
    }
}