﻿using dataPredictiveAnalyseMedical.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.utilitaire
{
    public class AboutMaladie: Maladie
    {

        public AboutMaladie(string id, string nom, double pourcentage)
        {
            this.setIdSelect(id);
            nomAcces         = nom;
            pourcentageAcces = pourcentage;
        }
        

        private double pourcentage;

        public double pourcentageAcces
        {
            get { return pourcentage; }
            set { pourcentage = value; }
        }


    }
}
