﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.utilitaire
{
    public class Point
    {
        public Point(double x, double y)
        {
            this.xAcces = x;
            this.yAcces = y;
        }
        private double x;

        public double xAcces
        {
            get { return x; }
            set { x = value; }
        }

        private double y;

        public double yAcces
        {
            get { return y; }
            set { y = value; }
        }


    }
}
