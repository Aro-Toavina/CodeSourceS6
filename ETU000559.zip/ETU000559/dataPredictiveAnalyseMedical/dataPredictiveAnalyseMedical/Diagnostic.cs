﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class Diagnostic : BaseModel
    {
        public Diagnostic(string id, string intitule, string mesure)
        {
            this.setIdSelect(id);
            this.intituleAcces  = intitule;
            this.mesureAcces    = mesure;
        }
        private string intitule;

        public string intituleAcces
        {
            get { return intitule; }
            set { intitule = value; }
        }

        private string mesure;

        public string mesureAcces
        {
            get { return mesure; }
            set { mesure = value; }
        }


    }
}
