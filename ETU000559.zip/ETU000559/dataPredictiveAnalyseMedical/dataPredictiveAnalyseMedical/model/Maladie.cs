﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class Maladie : BaseModel
    {

        private string nom;

        public string nomAcces
        {
            get { return nom; }
            set { nom = value; }
        }


    }
}
