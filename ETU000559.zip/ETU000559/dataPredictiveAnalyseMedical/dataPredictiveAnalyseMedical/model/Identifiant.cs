﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class Identifiant
    {
        private String predicat;
        private String currentNumber;
        private  String nom;

        

        public String predicatAcces
        {
            get { return predicat; }
            set { predicat = value; }
        }

        public String currentNumberAcces
        {
            get { return currentNumber; }
            set { currentNumber = value; }
        }

        public String nomAcces
        {
            get { return nom; }
            set { nom = value; }
        }

    }
}
