﻿using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class BaseModel
    {
        public String predicat;
        protected String id;

        

        public String getId()
        {
            return id;
        }
        public void setIdSelect(String i)
        {
            id = i;
        }



        public int getSequence(string predicat)
        {
            Connect connex = null;
            SqlConnection connection = null;

            try
            {
                connex = new Connect();
                connection = connex.getConnexion();
                return getSequence(predicat, connection);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {

                if (connection != null) connection.Close();
            }
        }

        public int getSequence(string predicat, SqlConnection connection)
        {
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                String query = "select next value for " + predicat;
                command = new SqlCommand(query, connection);
                reader = command.ExecuteReader();
                int id = 0;
                while (reader.Read())
                {
                    id = Convert.ToInt32(reader.GetInt64(0));
                }
                return id;

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }

        }

        public string getIdBySequence(string predicat)
        {
            string id = predicat + Convert.ToString(getSequence(predicat));
            return id;

        }
        public void setIdBySequence(string predicat)
        {
            id = getIdBySequence(predicat);
        }

    }
}
