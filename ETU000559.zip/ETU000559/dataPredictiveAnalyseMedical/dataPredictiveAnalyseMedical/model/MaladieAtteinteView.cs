﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class MaladieAtteinteView : Atteinte
    {
        public MaladieAtteinteView(string id, int status, string idMaladie, string idDiagnostic, String nom) : base(id, status, idMaladie, idDiagnostic)
        {
            this.nomAcces = nom;
        }

        private String nom;

        public String nomAcces
        {
            get { return nom; }
            set { nom = value; }
        }

    }
}
