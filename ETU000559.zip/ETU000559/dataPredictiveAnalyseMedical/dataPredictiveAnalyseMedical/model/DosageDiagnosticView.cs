﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class DosageDiagnosticView : BaseModel
    {
        private string  idDiagnostic;
        private string intitule;
        private string mesure;
        private double minQuantite;
        private double maxQuantite;
        private double currentQuantite;

        public DosageDiagnosticView(string id, string idDiagnostic, string intitule, string mesure, double minQtt, double maxQtt)
        {
            this.setIdSelect(id);
            this.idDiagnosticAcces = idDiagnostic;
            this.setIntitule(intitule);
            this.setMesure(mesure);
            this.setMinQuantite(minQtt);
            this.setMaxQuantite(maxQtt);
        }

        public DosageDiagnosticView(string id, string idDiagnostic, string intitule, string mesure, double minQtt, double maxQtt, double currentDefaultQuantite)
        {
            this.setIdSelect(id);
            this.idDiagnosticAcces = idDiagnostic;
            this.setIntitule(intitule);
            this.setMesure(mesure);
            this.setMinQuantite(minQtt);
            this.setMaxQuantite(maxQtt);
            this.setCurrentQuantite(currentDefaultQuantite);
        }

        public String idDiagnosticAcces
        {
            get { return idDiagnostic; }
            set { idDiagnostic = value; }
        }

        public string  getIntitule()
        {
            return this.intitule;
        }

        public void setIntitule( string intitule)
        {
            this.intitule = intitule;
        }

        public string  getMesure()
        {
            return this.mesure;
        }

        public void setMesure(string mesure)
        {
            this.mesure = mesure;
        }

        public double getMinQuantite( )
        {
            return this.minQuantite;
        }

        public void setMinQuantite(double minQuantite)
        {
            this.minQuantite = minQuantite;
        }

        public double getMaxQuantite()
        {
            return this.maxQuantite;
        }

        public void setMaxQuantite(double maxQuantite)
        {
            this.maxQuantite = maxQuantite;
        }

        public double getCurrentQuantite()
        {
            return currentQuantite;
        }

        public void setCurrentQuantite( double currentQuantite)
        {
            this.currentQuantite = currentQuantite;
        }


    }
}
