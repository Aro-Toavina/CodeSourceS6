﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.model
{
    public class Atteinte : BaseModel 
    {
        public Atteinte(String id, int status, String idMaladie, String idDiagnostic)
        {
            this.setIdSelect(id);
            this.statutAcces        = status;
            this.idMaladieAcces     = idMaladie;
            this.idDiagnosticAcces  = idDiagnostic;

        }
        protected int statut;

        public int statutAcces
        {
            get { return statut; }
            set { statut = value; }
        }


        protected String idMaladie;

        public String idMaladieAcces
        {
            get { return idMaladie; }
            set { idMaladie = value; }
        }

        protected String idDiagnostic;

        public String idDiagnosticAcces
        {
            get { return idDiagnostic; }
            set { idDiagnostic = value; }
        }




    }
}
