﻿using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical
{
    class Utilitaire
    {
        public double DegreeToRadian(double angle)
        {
            return Math.PI * angle / 180.0;
        }

        public double longueurToMesureValue( double min, double max, double longueurAxe, double longueurValueMoyen)
        {
            //double marge=0.5;
            double moyenneIntervalle=( ( ( (max - min) + 1) / 2 ) + (0.5) );
            double valueMesureAxe = longueurAxe* moyenneIntervalle / longueurValueMoyen;
            return valueMesureAxe;

        }

        public  Point projectionOrthogonal(Point[] droite, Point aProjete)
        {
            double x = droite[0].xAcces;
            double y = droite[0].yAcces;
            if ((droite[0].yAcces - droite[1].yAcces) == 0)
            {
                x = aProjete.xAcces;
            }
            else if ((droite[0].xAcces - droite[1].xAcces) == 0)
            {
                y = aProjete.yAcces;
            }
            else
            {
                double p1 = (droite[0].yAcces - droite[1].yAcces) / (droite[0].xAcces - droite[1].xAcces);

                Console.WriteLine(" centre " + droite[0].xAcces + " " + droite[0].yAcces);
                Console.WriteLine(" point " + droite[1].xAcces + " " + droite[1].yAcces);
                Console.WriteLine("p1 " + (droite[0].yAcces - droite[1].yAcces) + " / " + (Convert.ToDouble(droite[0].xAcces - droite[1].xAcces)) + " =" + p1);


                double p2 = Convert.ToDouble(-1) / p1;

                Console.WriteLine(" p2 " + p2);

                double b1 = droite[0].yAcces - p1 * droite[0].xAcces;
                double b2 = aProjete.yAcces - p2 * aProjete.xAcces;


                Console.WriteLine(" b1 " + b1 + " b2 " + b2);

                 x = (b2 - b1) / (p1 - p2);
                 y = p2 * x + b2;

            }
            return new Point((int)x, (int)y); 
        }

        public double echelle(double distanceX, double rayon, double minQuantite, double maxQuantite, int longBefore, int longAfter )// 1 longeur sur graphe = ? sur mesure reel
        {
            double longIntervalle = rayon - (longBefore + longAfter);
            double mesure = maxQuantite - minQuantite;
            double echellePour1Long = mesure / longIntervalle;

            double longX = distanceX - longBefore;
            double mesureX = longX * echellePour1Long;
            Console.WriteLine("distqnceX " + distanceX + " rayon " + rayon + " minQuantite" + minQuantite + " maxQuantite" + maxQuantite + " longBefore " + longBefore + " longAfter " + longAfter);
            return mesureX + minQuantite;
        }

        public double probabiliteMaladieByQuantite(double minQuantite, double maxQuantite, double quantiteDiagnostic, int referenceMaladie)//probabilite d'atteintes des  maladies pour un diagnostic
        {
            double probabilite               = 0;
            double longeurMesure             = maxQuantite - minQuantite;
            double longeurQuantiteDiagnostic = maxQuantite - quantiteDiagnostic;
            if (referenceMaladie == 0)
            {
                probabilite = longeurQuantiteDiagnostic * 100 / longeurMesure;
            }
            else
            {
                longeurQuantiteDiagnostic = longeurMesure - (/*maxQuantite - */longeurQuantiteDiagnostic);
                probabilite = longeurQuantiteDiagnostic * 100 / longeurMesure;
            }
            return probabilite;
        }

        public double distanceBetween2Point(Point a, Point b)
        {
           return  Math.Sqrt((b.xAcces-a.xAcces)*(b.xAcces - a.xAcces) + (b.yAcces-b.yAcces)* (b.yAcces - b.yAcces));
        }

        public Point centre2Point(Point a, Point b)
        {
            double xCentre = (a.xAcces + b.xAcces) / 2;
            double yCentre = (a.yAcces + b.yAcces) / 2;
            return new Point(xCentre, yCentre);
        }

        public int getInterpretationValue(double minValue, double maxValue, double value)// is value : normal,  <normal or sup normal
        {
            if (value <= maxValue && value >= minValue) {
                return 2;
            }
            else if(value < maxValue)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        public void diseaseProbability(List<AboutMaladie> maladieList, List<MaladieAtteinteView> maladieAtteinteList, double beginInterval, double endInterval, double quantiteDiagnostic)
        {
            foreach(MaladieAtteinteView maladieAtteinte in maladieAtteinteList) {
                Console.WriteLine(" issssssssssssssssssssssssssss" + maladieList.Count);
                AboutMaladie maladie    = maladieList.Find(uneMaladie => uneMaladie.getId() == maladieAtteinte.idMaladieAcces);

                double probabilite      = this.probabiliteMaladieByQuantite(beginInterval, endInterval, quantiteDiagnostic, maladieAtteinte.statutAcces);
                Console.WriteLine(" min " + beginInterval + " max " + endInterval + " current quantite " + quantiteDiagnostic+" status " + maladieAtteinte.statutAcces);
                if ( maladie == null )
                {
                    maladieList.Add(new AboutMaladie(maladieAtteinte.idMaladieAcces, maladieAtteinte.nomAcces, probabilite));
                }
                else
                {
                    Console.WriteLine(" mis vvvvvvvvvvvvvvvvvvvvvv");
                    maladie.pourcentageAcces += probabilite;
                }
            }
        }

        public double getMargeMin(double minQuantite, double maxQuantite, int status)
        {

            if (status == 0)
                return minQuantite - (maxQuantite - minQuantite);

            else
                return maxQuantite;

        }
        
        public double getMargeMax(double minQuantite, double maxQuantite, int status)
        {
            if (status == 0)
                return minQuantite;

            else
                return maxQuantite + (maxQuantite - minQuantite);

        }
    }
}
