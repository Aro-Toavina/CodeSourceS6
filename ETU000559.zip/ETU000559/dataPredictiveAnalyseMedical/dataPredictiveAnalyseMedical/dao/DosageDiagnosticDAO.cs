﻿using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.dao
{
    public class DosageDiagnosticDAO
    {

        public List<DosageDiagnosticView> findDosageDiagnosticView(String reqap)
        {
            Connect connex = null;
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                connex = new Connect();
                connection = connex.getConnexion();
                string query = "Select * from dosageDiagnostic where 1<2 " + reqap;
                Console.WriteLine(query);
                command = new SqlCommand(query, connection);
                reader = command.ExecuteReader();
                List<DosageDiagnosticView> dosageDiagnosticViewList = new List<DosageDiagnosticView>();
                
                while (reader.Read())
                {
                    dosageDiagnosticViewList.Add(new DosageDiagnosticView(reader["ID"].ToString(), reader["IDDIAGNOSTIC"].ToString(), reader["INTITULE"].ToString(), reader["MESURE"].ToString(), System.Convert.ToDouble(reader["MINQUANTITE"].ToString()), System.Convert.ToDouble(reader["MAXQUANTITE"].ToString()) ));
                }
                return dosageDiagnosticViewList;

            }
            catch (Exception e)
            {
               
                Console.WriteLine(e.StackTrace);
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }
        }
    }
}
