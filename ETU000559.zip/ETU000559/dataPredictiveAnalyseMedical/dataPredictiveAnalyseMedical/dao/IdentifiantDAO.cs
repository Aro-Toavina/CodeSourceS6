﻿using connexion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.dao
{
    public class IdentifiantDAO
    {
        public String getCurrentNumber(String predicat)
        {
            Connect connex = null;
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                connex = new Connect();
                connection = connex.getConnexion();
                command = new SqlCommand("Select CURRENTNUMBER from identifiant where predicat='" + predicat + "'", connection);
                reader = command.ExecuteReader();

                String nombre = reader["CURRENTNUMBER"].ToString();
                return nombre;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }
        }

        public void insertIdentifiant(Identifiant identifiant) { 
            Connect connex = null;
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {   
                connex = new Connect();
                connection = connex.getConnexion();
                command = new SqlCommand("insert into  IDENTIFIANT values ('" + identifiant.predicatAcces+ "'," + identifiant.currentNumberAcces+ ",'" + identifiant.nomAcces + "');", connection);
                reader = command.ExecuteReader();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }
        }
        public void update( Identifiant un) {
            Connect connex = null;
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                connex = new Connect();
                connection = connex.getConnexion();
                String newValue = (un.currentNumberAcces + 1).ToString();
                command = new SqlCommand(" update set CURRENTNUMBER="+ newValue + "where predicat='" + un.predicatAcces + "'", connection);
                reader = command.ExecuteReader();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }
        }
    }
}
