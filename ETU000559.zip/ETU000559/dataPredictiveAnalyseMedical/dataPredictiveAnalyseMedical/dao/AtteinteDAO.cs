﻿using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.dao
{
    public class AtteinteDAO
    {
        public List<Atteinte> findAtteinteWithConnection(String reqap)
        {
            SqlConnection connection = null;

            try
            {
                Connect connex = new Connect();
                connection = connex.getConnexion();
                return this.findAtteinte(reqap, connection);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null) connection.Close();
            }
        }

        public List<Atteinte> findAtteinte(String reqap, SqlConnection connection)
        {
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                String query = "Select * from  maladieAtteinte  where 1<2 " + reqap;
                Console.WriteLine(query);
                command = new SqlCommand(query, connection);
                reader = command.ExecuteReader();
                List<Atteinte> atteinteList = new List<Atteinte>();

                while (reader.Read())
                {
                    atteinteList.Add(new Atteinte(reader["ID"].ToString(), (int)reader["STATUT"], reader["IDMALADIE"].ToString(), reader["IDDIAGNOSTIC"].ToString()));
                }
                return atteinteList;

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
            }
        }

        public int nbrDiagnosticByMaladie(string idMaladie, SqlConnection connection)
        {
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                String query = "Select count(idDiagnostic) as  nbrDiagnostic from   diagMaladie  where idMaladie='"+ idMaladie + "' ";

 
                Console.WriteLine(query);
                command = new SqlCommand(query, connection);
                reader = command.ExecuteReader();
                int nbrDiagnostic = 0;
                while (reader.Read())
                {
                    nbrDiagnostic = reader.GetInt32(0);
                }
                return nbrDiagnostic;

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
            }
        }
    }
}
