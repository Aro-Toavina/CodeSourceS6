﻿using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.dao
{
    public class DiagnosticDAO
    {
        public List<Diagnostic> findDiagnostic(String reqap)
        {
            Connect connex = null;
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                connex = new Connect();
                connection = connex.getConnexion();
                command = new SqlCommand("Select * from diagnostic where 1<2 " + reqap, connection);
                reader = command.ExecuteReader();
                List<Diagnostic> diagnosticList = new List<Diagnostic>();

                while (reader.Read())
                {
                    diagnosticList.Add( new Diagnostic(reader["ID"].ToString(), reader["INTITULE"].ToString(), reader["MESURE"].ToString()) );
                }
                return diagnosticList;

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
                if (connection != null) connection.Close();
            }
        }

    }
}
