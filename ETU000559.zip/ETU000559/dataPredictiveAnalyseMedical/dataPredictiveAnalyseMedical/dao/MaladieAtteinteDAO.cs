﻿using dataPredictiveAnalyseMedical.model;
using dataPredictiveAnalyseMedical.utilitaire;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.dao
{
    public class MaladieAtteinteDAO
    {
        public List<MaladieAtteinteView> findMaladieAtteinteViewWithConnection(String reqap)
        {
            SqlConnection connection = null;

            try
            {
                Connect connex = new Connect();
                connection = connex.getConnexion();
                return this.findMaladieAtteinteView(reqap, connection);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null) connection.Close();
            }
        }

        public List<MaladieAtteinteView> findMaladieAtteinteView(String reqap, SqlConnection connection)
        {
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                String query = "Select * from  maladieAtteinte  where 1<2 " + reqap;
                Console.WriteLine(query);
                command = new SqlCommand(query, connection);
                reader = command.ExecuteReader();
                List<MaladieAtteinteView> maladieAtteinteViewList = new List<MaladieAtteinteView>();

                while (reader.Read())
                {
                    maladieAtteinteViewList.Add(new MaladieAtteinteView(reader["ID"].ToString(), (int)reader["STATUT"], reader["IDMALADIE"].ToString(), reader["IDDIAGNOSTIC"].ToString(), reader["NOM"].ToString()));
                }
                return maladieAtteinteViewList;

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (reader != null) reader.Close();
                if (command != null) command.Dispose();
            }
        }
    }
}
