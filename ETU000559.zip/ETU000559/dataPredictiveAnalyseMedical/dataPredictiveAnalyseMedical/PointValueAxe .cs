﻿using dataPredictiveAnalyseMedical.data;
using dataPredictiveAnalyseMedical.model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dataPredictiveAnalyseMedical
{
    public class PointValueAxe : Panel
    {
        private int x;
        private int y;
        private int rayon;
        private int numeroAxe;
        private double distance;
        private Boolean down = false;
        private DosageDiagnosticView diagnosticAxe;
        private Point margeConteneur;
        private Point centreRadar;
        private Point locationInitial;
        private double rayonAxe;

        


        public PointValueAxe(int x, int y,int rayon, int numeroAxe, DosageDiagnosticView diagnosticAxe, Point margeConteneur, Point centreRadar, Point locationInitial, double rayonAxe)
        {
            rayonAcces      = rayon;
            int diametre    = rayon * 2;
            this.Width      = diametre;
            this.Height     = diametre;
            this.setX(x - this.rayonAcces);
            this.setY(y - this.rayonAcces);
            this.Location               = new Point(this.x, this.y);
            this.BackColor              = Color.FromArgb(0, 0, 0, 0);
            this.numeroAxeAcces         = numeroAxe;
            //this.distanceAcces          = distance;
            this.diagnosticAxeAcces     = diagnosticAxe;
            this.margeConteneurAcces    = margeConteneur;
            this.centreRadar            = centreRadar;
            this.locationInitial        = locationInitial;
            this.rayonAxeAcces          = rayonAxe;

        }

        public int getX()
        {
            return x;
        }

        public void setX(int x)
        {
            this.x = x;
        }

        public int getY()
        {
            return y;
        }

        

        public void setY(int y)
        {
            this.y = y;
        }

        
        public int numeroAxeAcces
        {
            get { return numeroAxe; }
            set { numeroAxe = value; }
        }

        public Boolean downAcces
        {
            get { return down; }
            set { down = value; }
        }

        public DosageDiagnosticView diagnosticAxeAcces
        {
            get { return diagnosticAxe; }
            set { diagnosticAxe = value; }
        }
        

        public Point margeConteneurAcces
        {
            get { return margeConteneur; }
            set { margeConteneur = value; }
        }
        

        public int rayonAcces
        {
            get { return rayon; }
            set { rayon = value; }
        }

        

        public double distanceAcces
        {
            get { return distance; }
            set { distance = value; }
        }

        public double rayonAxeAcces
        {
            get { return rayonAxe; }
            set { rayonAxe = value; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Turquoise), 0, 0, 20, 20);
            g.DrawString(numeroAxeAcces+ " : " + diagnosticAxeAcces.getIntitule(), new Font("Arial", 10), new SolidBrush(Color.Black), 0, 0);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (down)
            {

                Console.WriteLine("x "+ (this.Location.X + e.X - rayonAcces) + " y " + (this.Location.Y + e.Y - rayonAcces));
                this.Location = new Point(this.Location.X + e.X - rayonAcces, this.Location.Y + e.Y - rayonAcces);

                
                setX(this.Location.X + e.X - rayonAcces);
                setY(this.Location.Y + e.Y - rayonAcces);
               
                Graphics g = CreateGraphics();
                Panel radarChart = (Panel)Parent;
                Form1 form1 = (Form1)radarChart.Parent;
                form1.drawPolygone(g, this);
                form1.Refresh();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
            utilitaire.Point projete;
            Utilitaire util = new Utilitaire();
            utilitaire.Point[] pointList = new utilitaire.Point[2];
            pointList[0] = new utilitaire.Point(this.centreRadar.X, this.centreRadar.Y);
            pointList[1] = new utilitaire.Point(this.locationInitial.X, this.locationInitial.Y);
            projete= util.projectionOrthogonal(pointList,new utilitaire.Point(this.getX(),this.getY()));


            setX((int)projete.xAcces- rayonAcces);
            setY((int)projete.yAcces- rayonAcces);
            this.Location = new Point(this.getX(), this.getY());

            //currentValue
            Utilitaire utilitaire   = new Utilitaire();
            double currentDistance  = utilitaire.distanceBetween2Point(new utilitaire.Point(this.centreRadar.X, this.centreRadar.Y), new utilitaire.Point(this.getX(), this.getY()));
            this.distanceAcces      = currentDistance;
            double currentValue     = utilitaire.echelle(this.distanceAcces, rayonAxeAcces, this.diagnosticAxeAcces.getMinQuantite(), this.diagnosticAxeAcces.getMaxQuantite(), Configuration.longBeforeAxeOfNormalValue, Configuration.longAfterAxeOfNormalValue);
            //Console.WriteLine("xxxxxxxxxxxxxxxx "+ rayon);
            this.diagnosticAxeAcces.setCurrentQuantite(currentValue);

            Panel radarChart = (Panel)Parent;
            Form1 form1 = (Form1)radarChart.Parent;

            form1.diagnosticDataGridView.Rows[this.numeroAxe-1].Cells[2].Value = currentValue;

            form1.Refresh();

            Console.WriteLine("projection x " + (projete.xAcces) + " y " + projete.yAcces);

        }

        public void pointAxe_OnMouseUp(object sender, EventArgs e)
        {
            ToolStripMenuItem ClickedItem = (ToolStripMenuItem)sender;
            MessageBox.Show(ClickedItem.Text);
        }
    }
}
