﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataPredictiveAnalyseMedical.data
{
    public static class Configuration
    {
        
        public static readonly int longBeforeAxeOfNormalValue  = 241/3;
        public static readonly int longAfterAxeOfNormalValue   = longBeforeAxeOfNormalValue;

    }
}
