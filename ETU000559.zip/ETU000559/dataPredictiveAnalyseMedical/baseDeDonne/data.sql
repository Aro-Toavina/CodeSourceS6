create database analyseMedical;

create table diagnostic(
	id varchar(7) primary key,
	intitule varchar(35) ,
	mesure	varchar(15)
);

create table dosage(
	id varchar(7) primary key,
	idDiagnostic varchar(7), 
	minAge decimal(6,3),
	maxAge decimal(6,3),
	minQuantite decimal(13,3),
	maxQuantite decimal(13,3),
	sexe int,
    foreign key (idDiagnostic) references diagnostic(id)
);

create table maladie(
	id varchar(7) primary key,
	nom varchar(35)
);

create table atteinte(
	id varchar(7) primary key,
	statut	int,
	idMaladie	varchar(7),
	idDiagnostic	varchar(7),
	foreign key (idDiagnostic) references diagnostic(id),
	foreign key (idMaladie) references maladie(id)
	
);
create view dosageDiagnostic as ( select dos.id,dos.idDiagnostic, d.intitule,d.mesure,dos.minAge, dos.maxAge, dos.minQuantite, dos.maxQuantite, dos.sexe from diagnostic d join dosage dos on d.id=dos.idDiagnostic );

create view maladieAtteinte as ( select a.id, a.statut, a.idMaladie, a.idDiagnostic, mal.nom from atteinte a join maladie mal on a.idMaladie=mal.id);


create view diagMaladie as (select distinct idMaladie,idDiagnostic from atteinte) 

insert into diagnostic values('DIAG1','Hématies ','millions/mm3');
insert into diagnostic values('DIAG2','Leucocytes ','/mm3x1000');
insert into diagnostic values('DIAG3','plaquette','/mm3');
insert into diagnostic values('DIAG4','vitesse de sedimentation','mm');
insert into diagnostic values('DIAG5','Acide Urique','mg/l');
insert into diagnostic values('DIAG6','Cholestérol','g/l');
insert into diagnostic values('DIAG7','Créatine','UI/l');
insert into diagnostic values('DIAG8','Potassium','mEq/L');
/*insert into diagnostic values('DIAG9','Sodium','');
insert into diagnostic values('DIAG10','Chlore','');
insert into diagnostic values('DIAG11','Triglycéride','');*/


insert into dosage values('DOS5','DIAG1',3,10,4.0,5.4,2);
insert into dosage values('DOS6','DIAG1',11,100,4.0,5.3,0);
insert into dosage values('DOS7','DIAG1',11,100,4.2,5.7,1);

insert into dosage values('DOS8','DIAG2',3,10,5000,11000,2);
insert into dosage values('DOS9','DIAG2',11,100,4000,10000,2);

insert into dosage values('DOS11','DIAG3',1,4,160,500,2);
insert into dosage values('DOS12','DIAG3',5,10,160,450,2);
insert into dosage values('DOS13','DIAG3',11,15,160,400,2);
insert into dosage values('DOS14','DIAG3',16,100,160,350,2);


insert into dosage values('DOS15','DIAG4',0,100,0,7,2);/*after 1h*/

insert into dosage values('DOS16','DIAG5',0,0.08,20,35,2);
insert into dosage values('DOS17','DIAG5',0.09,8,20,50,2);
insert into dosage values('DOS18','DIAG5',8,100,25,60,0);
insert into dosage values('DOS19','DIAG5',8,100,35,70,1);

insert into dosage values('DOS20','DIAG6',0,4,1.60,2.20,0);
insert into dosage values('DOS21','DIAG6',0,4,1.55,2.15,1);
insert into dosage values('DOS22','DIAG6',5,14,1.60,2.30,0);
insert into dosage values('DOS23','DIAG6',5,14,1.60,2.20,1);
insert into dosage values('DOS24','DIAG6',15,19,1.50,2.15,2);
insert into dosage values('DOS25','DIAG6',20,59,1.30,2.30,0);
insert into dosage values('DOS26','DIAG6',20,59,1.55,2.50,1);
insert into dosage values('DOS27','DIAG6',60,100,1.40,2.65,2);

insert into dosage values('DOS28','DIAG7',0,100,0,170,0);
insert into dosage values('DOS29','DIAG7',0,100,0,195,1);

insert into dosage values('DOS130','DIAG8',0,100,3.5,4.9,2);

/*insert into dosage values('DOS','DIAG',,,,,);*/


insert into maladie values('MAL3','hémopathie');
insert into maladie values('MAL4','cancer');
insert into maladie values('MAL5','psoriasis');
insert into maladie values('MAL6','hypoxie');
insert into maladie values('MAL7','glycogénose');

insert into maladie values('MAL8','insuffisance rénale chronique');
insert into maladie values('MAL9','déshydratation');
insert into maladie values('MAL10','diabète insipide');
insert into maladie values('MAL11','acido-cétose diabétique');

insert into maladie values('MAL12','polyglobulie');
insert into maladie values('MAL13','maladie de Vaquez');

insert into maladie values('MAL14','anémies');
insert into maladie values('MAL15','leucémie');
insert into maladie values('MAL18','hemorragie');

insert into maladie values('MAL16','infection bactérienne');
insert into maladie values('MAL17','infection parasitaire ');

insert into maladie values('MAL28','maladie inflammatoire');
insert into maladie values('MAL19','collagénose');
insert into maladie values('MAL20','pancreatite');


insert into maladie values('MAL21','atteinte thyroïdienne');
insert into maladie values('MAL22','diabete');

insert into maladie values('MAL23','atteinte musculaire');
insert into maladie values('MAL24','atteinte cardiaque');

insert into maladie values('MAL25','hypertension artérielle ');
insert into maladie values('MAL26','Diarrhées');
insert into maladie values('MAL27','Insuffisance rénale');

insert into maladie values('MAL','');

insert into maladie values('MAL','maladies cardio-vasculaires ');
insert into maladie values('MAL','maladies dermatologiques');


insert into maladie values('MAL','');
insert into maladie values('MAL','');
insert into maladie values('MAL','');

insert into maladie values('MAL18','');


insert into atteinte values('ATT3',1,'MAL3','DIAG5');
insert into atteinte values('ATT4',1,'MAL4','DIAG5');
insert into atteinte values('ATT5',1,'MAL5','DIAG5');
insert into atteinte values('ATT6',1,'MAL6','DIAG5');
insert into atteinte values('ATT7',1,'MAL7','DIAG5');
insert into atteinte values('ATT8',0,'MAL8','DIAG5');
insert into atteinte values('ATT9',0,'MAL9','DIAG5');
insert into atteinte values('ATT10',0,'MAL10','DIAG5');
insert into atteinte values('ATT11',0,'MAL11','DIAG5');

insert into atteinte values('ATT12',1,'MAL12','DIAG1');
insert into atteinte values('ATT13',1,'MAL13','DIAG1');
insert into atteinte values('ATT14',0,'MAL14','DIAG1');
insert into atteinte values('ATT15',0,'MAL15','DIAG1');
insert into atteinte values('ATT16',0,'MAL4','DIAG1');
insert into atteinte values('ATT17',0,'MAL18','DIAG1');

insert into atteinte values('ATT18',1,'MAL16','DIAG2');
insert into atteinte values('ATT19',1,'MAL15','DIAG2');
insert into atteinte values('ATT20',1,'MAL4','DIAG2');
insert into atteinte values('ATT21',1,'MAL17','DIAG2');
insert into atteinte values('ATT22',0,'MAL14','DIAG2');
insert into atteinte values('ATT23',0,'MAL15','DIAG2');


insert into atteinte values('ATT24',1,'MAL4','DIAG3');
insert into atteinte values('ATT25',1,'MAL16','DIAG3');
insert into atteinte values('ATT26',1,'MAL28','DIAG3');
insert into atteinte values('ATT27',0,'MAL17','DIAG3');
insert into atteinte values('ATT28',0,'MAL19','DIAG3');

insert into atteinte values('ATT29',1,'MAL16','DIAG4');
insert into atteinte values('ATT30',1,'MAL17','DIAG4');
insert into atteinte values('ATT31',1,'MAL4','DIAG4');
insert into atteinte values('ATT32',1,'MAL20','DIAG4');
insert into atteinte values('ATT33',0,'MAL12','DIAG4');
insert into atteinte values('ATT34',0,'MAL13','DIAG4');
insert into atteinte values('ATT35',0,'MAL14','DIAG4');

insert into atteinte values('ATT36',1,'MAL20','DIAG6');
insert into atteinte values('ATT37',1,'MAL21','DIAG6');
insert into atteinte values('ATT38',1,'MAL22','DIAG6');
insert into atteinte values('ATT39',0,'MAL4','DIAG6');
insert into atteinte values('ATT40',0,'MAL16','DIAG6');
insert into atteinte values('ATT41',0,'MAL21','DIAG6');

insert into atteinte values('ATT42',1,'MAL4','DIAG7');
insert into atteinte values('ATT43',1,'MAL7','DIAG7');
insert into atteinte values('ATT44',1,'MAL21','DIAG7');
insert into atteinte values('ATT45',1,'MAL23','DIAG7');
insert into atteinte values('ATT46',1,'MAL24','DIAG7');

insert into atteinte values('ATT47',1,'MAL14','DIAG8');
insert into atteinte values('ATT48',1,'MAL22','DIAG8');
insert into atteinte values('ATT49',1,'MAL23','DIAG8');
insert into atteinte values('ATT50',1,'MAL24','DIAG8');
insert into atteinte values('ATT51',1,'MAL27','DIAG8');
insert into atteinte values('ATT52',0,'MAL21','DIAG8');
insert into atteinte values('ATT53',0,'MAL25','DIAG8');
insert into atteinte values('ATT54',0,'MAL26','DIAG8');

/*insert into atteinte values('ATT',,'MAL','DIAG');



CREATE SEQUENCE [dbo].[INV]
		AS BIGINT
		START WITH 1
		INCREMENT BY 1
		NO MAXVALUE
		NO CYCLE
		CACHE 10;	*/