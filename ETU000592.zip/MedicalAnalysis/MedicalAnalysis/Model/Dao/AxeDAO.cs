﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace MedicalAnalysis.Model.Dao {

    class AxeDAO {

        // ATTRIBUTES :

        private SqlConnection connection;

        // CONSTRUCTS :

        public AxeDAO(SqlConnection connection) {

            this.connection = connection;

        }

        // PROPERTIES :



        // METHODS :

        public List<Axe> Select(string cond) {

            List<Axe> result = null;

            if (connection.State == ConnectionState.Open)
                connection = new SqlConnection(connection.ConnectionString + "Password=itu");
            connection.Open();
            using (SqlCommand cmd = connection.CreateCommand()) {

                string condition = "";
                if (cond != null)
                    condition = " " + cond;
                cmd.CommandText = "SELECT * FROM Axe" + condition;
                using (SqlDataReader reader = cmd.ExecuteReader()) {

                    result = new List<Axe>();
                    while (reader.Read()) {

                        float lowerX = float.Parse(reader["lowerX"].ToString());
                        float upperX = float.Parse(reader["upperX"].ToString());
                        float lowerNormal = float.Parse(reader["lowerNormal"].ToString());
                        float upperNormal = float.Parse(reader["upperNormal"].ToString());
                        Axe axe = new Axe(reader["id"].ToString(), reader["name"].ToString(), lowerX, upperX, lowerNormal, upperNormal, reader["unit"].ToString());
                        result.Add(axe);

                    }

                }

            } connection.Close();

            return result;

        }

        // STATIC METHODS :



    }

}
