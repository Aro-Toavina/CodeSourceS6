﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalAnalysis.Model.Dao {
    class DAOException : Exception {

        public DAOException(String message) : base(message){}

    }
}
