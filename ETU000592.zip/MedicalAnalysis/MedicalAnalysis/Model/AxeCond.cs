﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalAnalysis.Model {

    class AxeCond {

        // ATTRIBUTES :

        private String id;
        private int code;

        // CONSTRUCTS :

        public AxeCond(String id, int code) {

            this.Id = id;
            this.Code = code;

        }

        // PROPERTIES :

        public String Id {

            get { return this.id; }
            set { this.id = value; }

        }

        public int Code {

            get { return this.code; }
            set {

                if (value == 1 || value == 2)
                    this.code = value;
                else
                    throw new ModelException("Invalid code for axe condition : " + value + " !");

            }

        }

        // METHODS :

        public override String ToString() {

            return "(dd.axe='" + this.Id + "' AND dd.code=" + this.Code + ")";

        }

        // STATIC METHODS :


    
    }

}
