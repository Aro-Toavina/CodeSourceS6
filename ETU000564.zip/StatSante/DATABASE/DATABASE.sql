/*==============================================================*/
/* Nom de SGBD :  Microsoft SQL Server 2008                     */
/* Date de création :  30/04/2018 10:08:38                      */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('DISEASE')
            and   type = 'U')
   drop table DISEASE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_SEXE_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_SEXE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_UNITE_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_UNITE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_ELEMENT_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASE_DISEASEDETAIL_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASE_DISEASEDETAIL_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('DISEASEDETAIL')
            and   type = 'U')
   drop table DISEASEDETAIL
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ELEMENT')
            and   type = 'U')
   drop table ELEMENT
go

if exists (select 1
            from  sysobjects
           where  id = object_id('GENDER')
            and   type = 'U')
   drop table GENDER
go

if exists (select 1
            from  sysobjects
           where  id = object_id('UNIT')
            and   type = 'U')
   drop table UNIT
go

/*==============================================================*/
/* Table : DISEASE                                              */
/*==============================================================*/
create table DISEASE (
   ID      				int IDENTITY(1,1)    not null,
   IDDISEASE      AS 'DIS' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEDISEASE          varchar(25)          not null,
   constraint PK_DISEASE primary key nonclustered (IDDISEASE)
)
go

/*==============================================================*/
/* Table : DISEASEDETAIL                                        */
/*==============================================================*/
create table DISEASEDETAIL (
   ID      				int IDENTITY(1,1)    not null,
   IDDISEASEDETAIL      AS 'DSD' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   IDUNIT               char(6)              not null,
   IDGENDER             char(6)              not null,
   IDELEMENT            char(6)              not null,
   IDDISEASE            char(6)              not null,
   QUANTITYMIN          decimal(5,3)         not null,
   QUANTITYMAX          decimal(5,3)         not null,
   AGEMIN               smallint             null,
   AGEMAX               smallint             null,
   constraint PK_DISEASEDETAIL primary key nonclustered (IDDISEASEDETAIL)
)
go

/*==============================================================*/
/* Index : DISEASE_DISEASEDETAIL_FK                             */
/*==============================================================*/
create index DISEASE_DISEASEDETAIL_FK on DISEASEDETAIL (
IDDISEASE ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_ELEMENT_FK                             */
/*==============================================================*/
create index DISEASEDETAIL_ELEMENT_FK on DISEASEDETAIL (
IDELEMENT ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_UNITE_FK                               */
/*==============================================================*/
create index DISEASEDETAIL_UNITE_FK on DISEASEDETAIL (
IDUNIT ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_SEXE_FK                                */
/*==============================================================*/
create index DISEASEDETAIL_SEXE_FK on DISEASEDETAIL (
IDGENDER ASC
)
go

/*==============================================================*/
/* Table : ELEMENT                                              */
/*==============================================================*/
create table ELEMENT (
   ID      				int IDENTITY(1,1)    not null,
   IDELEMENT      AS 'ELT' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEELEMENT          varchar(25)          not null,
   constraint PK_ELEMENT primary key nonclustered (IDELEMENT)
)
go

/*==============================================================*/
/* Table : GENDER                                               */
/*==============================================================*/
create table GENDER (
   ID      				int IDENTITY(1,1)    not null,
   IDGENDER      AS 'GEN' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   SIGNGENDER           char(1)              not null,
   constraint PK_GENDER primary key nonclustered (IDGENDER)
)
go

/*==============================================================*/
/* Table : UNIT                                                 */
/*==============================================================*/
create table UNIT (
   ID      				int IDENTITY(1,1)    not null,
   IDUNIT      AS 'UNT' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEUNIT             varchar(10)          not null,
   constraint PK_UNIT primary key nonclustered (IDUNIT)
)
go

/*INSERTION*/

INSERT INTO UNIT VALUES('U/L');
INSERT INTO UNIT VALUES('mol/L');

INSERT INTO GENDER VALUES('H');
INSERT INTO GENDER VALUES('F');
INSERT INTO GENDER VALUES('M');

INSERT INTO ELEMENT VALUES('Gamma GT');
INSERT INTO ELEMENT VALUES('Phosphatases alcalines');
INSERT INTO ELEMENT VALUES('Transamines ASAT');
INSERT INTO ELEMENT VALUES('Transamines ALAT');
INSERT INTO ELEMENT VALUES('Bilirubine conjuguée');
INSERT INTO ELEMENT VALUES('Bilirubine libre');
INSERT INTO ELEMENT VALUES('Créatinémie');
INSERT INTO ELEMENT VALUES('Glycémie');
INSERT INTO ELEMENT VALUES('Lipasémie');
INSERT INTO ELEMENT VALUES('Uricémie');
INSERT INTO ELEMENT VALUES('Cholestérolémie totale');
INSERT INTO ELEMENT VALUES('Hémoglobine');
INSERT INTO ELEMENT VALUES('Potassium');
INSERT INTO ELEMENT VALUES('Amylasémie');

INSERT INTO DISEASE VALUES('Diabète');
INSERT INTO DISEASE VALUES('Hépatite');
INSERT INTO DISEASE VALUES('Insuffisance Rénale');
INSERT INTO DISEASE VALUES('Goutte');
INSERT INTO DISEASE VALUES('Syndrome de surcharge');
INSERT INTO DISEASE VALUES('Pancréatite');
INSERT INTO DISEASE VALUES('Polyglobulie');
INSERT INTO DISEASE VALUES('Hyperkialémie');

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT008', 'DIS001', 6, 15, 18, 30);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT001', 'DIS002', 55, 65, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT002', 'DIS002', 53, 60, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT003', 'DIS002', 35, 140, 18, 40);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT004', 'DIS002', 45, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT005', 'DIS002', 9, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT006', 'DIS002', 12, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT001', 'DIS002', 55, 65, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT002', 'DIS002', 53, 60, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT003', 'DIS002', 35, 140, 18, 40);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT004', 'DIS002', 45, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT005', 'DIS002', 9, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT006', 'DIS002', 12, 140, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT007', 'DIS003', 80, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT007', 'DIS003', 90, 140, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT010', 'DIS004', 95, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT010', 'DIS004', 95, 140, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT011', 'DIS005', 3, 6, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT011', 'DIS005', 3, 6, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT009', 'DIS006', 60, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT009', 'DIS006', 60, 140, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT014', 'DIS006', 55, 140, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT014', 'DIS006', 45, 140, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT012', 'DIS007', 13, 18, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT012', 'DIS007', 13, 18, NULL, NULL);

INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN002', 'ELT013', 'DIS008', 3.6, 5, NULL, NULL);
INSERT INTO DISEASEDETAIL VALUES('UNT001', 'GEN001', 'ELT013', 'DIS008', 3.6, 5, NULL, NULL);
