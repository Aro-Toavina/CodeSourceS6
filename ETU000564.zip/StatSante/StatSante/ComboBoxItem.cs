﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatSante
{
    public class ComboBoxItem
    {
        private string hiddenValue;
        private string displayedValue;

        public ComboBoxItem() { }
        public ComboBoxItem(string hiddenValue, string displayedValue)
        {
            this.HiddenValue = hiddenValue;
            this.DisplayedValue = displayedValue;
        }

        public string HiddenValue
        {
            get
            {
                return hiddenValue;
            }

            set
            {
                hiddenValue = value;
            }
        }

        public string DisplayedValue
        {
            get
            {
                return displayedValue;
            }

            set
            {
                displayedValue = value;
            }
        }

        public override string ToString()
        {
            return displayedValue;
        }
    }
}
