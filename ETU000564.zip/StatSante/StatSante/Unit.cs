﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Unit
    {
        private int id;
        private string idUnit;
        private string nameUnit;

        public Unit() { }
        public Unit(string idUnit, string nameUnit)
        {
            this.IdUnit = idUnit;
            this.NameUnit = nameUnit;
        }

        public int Id
        {
            set
            {
                id = value;
            }
        }

        public string IdUnit
        {
            get
            {
                return idUnit;
            }

            set
            {
                idUnit = value;
            }
        }

        public string NameUnit
        {
            get
            {
                return nameUnit;
            }

            set
            {
                nameUnit = value;
            }
        }

        public static List<Unit> listObjectToUnit(List<Unit> objs)
        {
            List<Unit> result = new List<Unit>();

            foreach (Object obj in objs)
            {
                result.Add((Unit)(obj));
            }

            return result;
        }
    }
}
