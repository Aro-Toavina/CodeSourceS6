﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Disease
    {
        private int id;
        private string idDisease;
        private string nameDisease;

        public Disease(){}
        public Disease(string idDisease, string nameDisease)
        {
            this.IdDisease = idDisease;
            this.NameDisease = nameDisease;
        }

        public int Id
        {
            set
            {
                id = value;
            }
        }

        public string IdDisease
        {
            get
            {
                return idDisease;
            }

            set
            {
                idDisease = value;
            }
        }

        public string NameDisease
        {
            get
            {
                return nameDisease;
            }

            set
            {
                nameDisease = value;
            }
        }

        public static List<Disease> listObjectToDisease(List<Object> objs)
        {
            List<Disease> result = new List<Disease>();

            foreach (Object obj in objs)
            {
                result.Add((Disease)(obj));
            }

            return result;
        }
    }
}
