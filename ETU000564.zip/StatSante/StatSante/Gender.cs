﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Gender
    {
        private int id;
        private string idGender;
        private string signGender;

        public Gender() { }
        public Gender(string idGender, string signGender)
        {
            this.IdGender = idGender;
            this.SignGender = signGender;
        }

        public int Id
        {
            set
            {
                id = value;
            }
        }

        public string IdGender
        {
            get
            {
                return idGender;
            }

            set
            {
                idGender = value;
            }
        }

        public string SignGender
        {
            get
            {
                return signGender;
            }

            set
            {
                signGender = value;
            }
        }

        public static List<Gender> listObjectToGender(List<Object> objs)
        {
            List<Gender> result = new List<Gender>();

            foreach (Object obj in objs)
            {
                result.Add((Gender)(obj));
            }

            return result;
        }
    }
}
