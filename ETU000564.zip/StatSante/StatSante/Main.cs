﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StatSante
{
    public partial class Main : Form
    {
        SqlConnection connection;
        private AxeUtil axeUtil;
        private Label[] elementsNames;
        Point origin;
        int selectedPointIndex;
        public Main()
        {
            InitializeComponent();
            initResultData();
            this.connection = ConnectionInfo.getConnection();

            initGenderComboBox();
            this.origin = new Point(this.graphPanel.Width / 2, this.graphPanel.Height / 2);
            this.selectedPointIndex = 0;

            this.axeUtil = new AxeUtil();
            this.axeUtil.Tips = GraphUtil.initPoints(graphPanel, this.axeUtil.Tips, this.origin, 14);
            this.axeUtil.initEquations(axeUtil.Tips.Length);
            GraphUtil.setEquations(this.axeUtil, this.origin);
            this.axeUtil.initElements(axeUtil.Tips.Length);
            this.axeUtil.setElements(this.connection);
            initCoordinates();
        }

        private void initGenderComboBox()
        {
            List<Gender> genders = Gender.listObjectToGender(DAO.findObject(this.connection, "Gender", "SignGender != 'M'"));
            foreach(Gender gender in genders)
            {
                genderCombo.Items.Add(new ComboBoxItem(gender.IdGender, gender.SignGender));
            }
            genderCombo.SelectedIndex = 0;
            genderCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void initResultData()
        {
            resultData.Columns.Add("DiseaseName", "Maladie");
            resultData.Columns.Add("Probability", "Probabilité (%)");
        }

        private void graphPanel_Paint(object sender, PaintEventArgs e)
        {
            base.OnPaint(e);
            GraphUtil.drawAxes(e, graphPanel, this.axeUtil.Tips);
            setLabelLocationsAndNames();
        }

        private void graphPanel_MouseDown(object sender, MouseEventArgs e)
        {
            Console.WriteLine("Down");
            Point onPoint = GraphUtil.MouseOnPoint(this.axeUtil.Tips, e);
            Console.WriteLine("onPoint.X: " + onPoint.X);
            Console.WriteLine("onPoint.Y: " + onPoint.Y);
            if (!onPoint.IsEmpty)
            {
                this.graphPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.graphPanel_MouseMove);
                for(int i=0; i< this.axeUtil.Tips.Length; i++)
                {
                    if(onPoint.X == this.axeUtil.Tips[i].X && onPoint.Y == this.axeUtil.Tips[i].Y)
                    {
                        this.selectedPointIndex = i;
                        break;
                    }
                }
            }
        }

        private void graphPanel_MouseMove(object sender, MouseEventArgs e)
        {
            //Console.WriteLine("Move");
            this.axeUtil.Tips[this.selectedPointIndex] = GraphUtil.movePoint(new Point(e.X, e.Y), this.axeUtil, this.selectedPointIndex, this.origin);
            Console.WriteLine("selectedPoint: {" + this.axeUtil.Tips[this.selectedPointIndex].X + "," + this.axeUtil.Tips[this.selectedPointIndex].Y + "}");
            /*Console.WriteLine("POINTS AVANT REFRESH:");
            foreach (Point point in this.axeUtil.Tips)
            {
                Console.WriteLine("{" + point.X + ";" + point.Y + "}");
            }*/
            this.graphPanel.Refresh();
        }

        private void graphPanel_MouseUp(object sender, MouseEventArgs e)
        {
            Console.WriteLine("Up");
            this.graphPanel.MouseMove -= new System.Windows.Forms.MouseEventHandler(this.graphPanel_MouseMove);
            Console.WriteLine("DISTANCE: " + GraphUtil.getDistance(this.origin, this.axeUtil.Tips[this.selectedPointIndex]));
        }

        private void estimationButton_Click(object sender, EventArgs e)
        {
            List<ResultUtil> resultUtil;
            try
            {
                resultUtil = GraphUtil.getProbas(this.connection, this.axeUtil, this.origin, (ComboBoxItem)this.genderCombo.SelectedItem, this.ageText.Text);

                Console.WriteLine("DISEASES:");
                foreach (ResultUtil result in resultUtil)
                {
                    Console.WriteLine("disease: " + result.Disease.IdDisease + " - " + result.Disease.NameDisease + " - " + result.Probability);
                }
                changeResults(resultUtil);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void changeResults(List<ResultUtil> resultUtil)
        {
            resultTitleLabel.Text = resultUtil.Count == 0 ? "Le patient est en bonne santé" : "Résultats de l'analyse:";
            resultData.Rows.Clear();
            foreach(ResultUtil result in resultUtil)
            {
                resultData.Rows.Add(result.Disease.NameDisease, result.Probability);
            }
        }

        private void changeResults(List<Disease> diseases)
        {
            this.resultPanel.Controls.Clear();
            Label label;
            Point location = new Point(100, 0);
            foreach(Disease disease in diseases)
            {
                label = new Label();
                label.Text = disease.NameDisease;

                this.resultPanel.Controls.Add(label);
                location = new Point(location.X, location.Y + 30);
                label.Location = location;
            }
        }

        private void initCoordinates()
        {
            this.elementsNames = new Label[14];
            for (int i = 0; i < this.elementsNames.Length; i++)
            {                
                this.elementsNames[i] = new Label();
                this.elementsNames[i].AutoSize = true;
                this.graphPanel.Controls.Add(this.elementsNames[i]);
            }
        }

        private void setLabelLocationsAndNames()
        {
            Point tipTemp;
            for (int i=0; i < this.axeUtil.Tips.Length; i++)
            {
                tipTemp = this.axeUtil.Tips[i];
                this.elementsNames[i].Text = axeUtil.Elements[i].NameElement + ":" + GraphUtil.getDistance(this.origin, tipTemp);
                this.elementsNames[i].Location = new Point(tipTemp.X + 5, tipTemp.Y);
            }
        }
    }
}
