﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Element
    {
        private int id;
        private string idElement;
        private string nameElement;
        private float normMin;
        private float normMax;
        private float quantityMin;
        private float quantityMax;

        public Element() { }
        public Element(string idElement, string nameElement, float normMin, float normMax, float quantityMin, float quantityMax)
        {
            this.IdElement = idElement;
            this.NameElement = nameElement;
            this.NormMin = normMin;
            this.NormMax = normMax;
            this.QuantityMin = quantityMin;
            this.QuantityMax = quantityMax;
        }

        public int Id
        {
            set
            {
                id = value;
            }
        }

        public string IdElement
        {
            get
            {
                return idElement;
            }

            set
            {
                idElement = value;
            }
        }

        public string NameElement
        {
            get
            {
                return nameElement;
            }

            set
            {
                nameElement = value;
            }
        }

        public float NormMin
        {
            get
            {
                return normMin;
            }

            set
            {
                normMin = value;
            }
        }

        public float NormMax
        {
            get
            {
                return normMax;
            }

            set
            {
                normMax = value;
            }
        }

        public float QuantityMin
        {
            get
            {
                return quantityMin;
            }

            set
            {
                quantityMin = value;
            }
        }

        public float QuantityMax
        {
            get
            {
                return quantityMax;
            }

            set
            {
                quantityMax = value;
            }
        }

        public static List<Element> listObjectToElement(List<Object> objs)
        {
            List<Element> result = new List<Element>();

            foreach (Object obj in objs)
            {
                result.Add((Element)(obj));
            }

            return result;
        }
    }
}
