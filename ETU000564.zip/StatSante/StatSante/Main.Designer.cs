﻿namespace StatSante
{
    partial class Main
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.graphPanel = new System.Windows.Forms.Panel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.ageLabel = new System.Windows.Forms.Label();
            this.genderLabel = new System.Windows.Forms.Label();
            this.ageText = new System.Windows.Forms.TextBox();
            this.genderCombo = new System.Windows.Forms.ComboBox();
            this.estimationButton = new System.Windows.Forms.Button();
            this.resultatGlobalPanel = new System.Windows.Forms.Panel();
            this.resultPanel = new System.Windows.Forms.Panel();
            this.enregistrerButton = new System.Windows.Forms.Button();
            this.resultatsLabel = new System.Windows.Forms.Label();
            this.resultData = new System.Windows.Forms.DataGridView();
            this.resultTitleLabel = new System.Windows.Forms.Label();
            this.rightPanel.SuspendLayout();
            this.resultatGlobalPanel.SuspendLayout();
            this.resultPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultData)).BeginInit();
            this.SuspendLayout();
            // 
            // graphPanel
            // 
            this.graphPanel.BackColor = System.Drawing.Color.AliceBlue;
            this.graphPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.graphPanel.Location = new System.Drawing.Point(12, 12);
            this.graphPanel.Name = "graphPanel";
            this.graphPanel.Size = new System.Drawing.Size(574, 574);
            this.graphPanel.TabIndex = 0;
            this.graphPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.graphPanel_Paint);
            this.graphPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.graphPanel_MouseDown);
            this.graphPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.graphPanel_MouseUp);
            // 
            // rightPanel
            // 
            this.rightPanel.Controls.Add(this.ageLabel);
            this.rightPanel.Controls.Add(this.genderLabel);
            this.rightPanel.Controls.Add(this.ageText);
            this.rightPanel.Controls.Add(this.genderCombo);
            this.rightPanel.Controls.Add(this.estimationButton);
            this.rightPanel.Controls.Add(this.resultatGlobalPanel);
            this.rightPanel.Location = new System.Drawing.Point(592, 12);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(296, 512);
            this.rightPanel.TabIndex = 2;
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(218, 15);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(26, 13);
            this.ageLabel.TabIndex = 5;
            this.ageLabel.Text = "Age";
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Location = new System.Drawing.Point(58, 15);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(31, 13);
            this.genderLabel.TabIndex = 4;
            this.genderLabel.Text = "Sexe";
            // 
            // ageText
            // 
            this.ageText.Location = new System.Drawing.Point(178, 35);
            this.ageText.Name = "ageText";
            this.ageText.Size = new System.Drawing.Size(112, 20);
            this.ageText.TabIndex = 3;
            // 
            // genderCombo
            // 
            this.genderCombo.FormattingEnabled = true;
            this.genderCombo.Location = new System.Drawing.Point(17, 34);
            this.genderCombo.Name = "genderCombo";
            this.genderCombo.Size = new System.Drawing.Size(121, 21);
            this.genderCombo.TabIndex = 2;
            // 
            // estimationButton
            // 
            this.estimationButton.Location = new System.Drawing.Point(89, 61);
            this.estimationButton.Name = "estimationButton";
            this.estimationButton.Size = new System.Drawing.Size(129, 23);
            this.estimationButton.TabIndex = 1;
            this.estimationButton.Text = "Estimation";
            this.estimationButton.UseVisualStyleBackColor = true;
            this.estimationButton.Click += new System.EventHandler(this.estimationButton_Click);
            // 
            // resultatGlobalPanel
            // 
            this.resultatGlobalPanel.Controls.Add(this.resultPanel);
            this.resultatGlobalPanel.Controls.Add(this.enregistrerButton);
            this.resultatGlobalPanel.Controls.Add(this.resultatsLabel);
            this.resultatGlobalPanel.Location = new System.Drawing.Point(3, 90);
            this.resultatGlobalPanel.Name = "resultatGlobalPanel";
            this.resultatGlobalPanel.Size = new System.Drawing.Size(290, 419);
            this.resultatGlobalPanel.TabIndex = 0;
            // 
            // resultPanel
            // 
            this.resultPanel.Controls.Add(this.resultTitleLabel);
            this.resultPanel.Controls.Add(this.resultData);
            this.resultPanel.Location = new System.Drawing.Point(3, 40);
            this.resultPanel.Name = "resultPanel";
            this.resultPanel.Size = new System.Drawing.Size(284, 334);
            this.resultPanel.TabIndex = 2;
            // 
            // enregistrerButton
            // 
            this.enregistrerButton.Location = new System.Drawing.Point(108, 380);
            this.enregistrerButton.Name = "enregistrerButton";
            this.enregistrerButton.Size = new System.Drawing.Size(75, 23);
            this.enregistrerButton.TabIndex = 1;
            this.enregistrerButton.Text = "Enregistrer";
            this.enregistrerButton.UseVisualStyleBackColor = true;
            // 
            // resultatsLabel
            // 
            this.resultatsLabel.AutoSize = true;
            this.resultatsLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultatsLabel.Location = new System.Drawing.Point(94, 11);
            this.resultatsLabel.Name = "resultatsLabel";
            this.resultatsLabel.Size = new System.Drawing.Size(99, 26);
            this.resultatsLabel.TabIndex = 0;
            this.resultatsLabel.Text = "Résultats";
            // 
            // resultData
            // 
            this.resultData.AllowUserToAddRows = false;
            this.resultData.AllowUserToDeleteRows = false;
            this.resultData.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.resultData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultData.Location = new System.Drawing.Point(3, 64);
            this.resultData.Name = "resultData";
            this.resultData.Size = new System.Drawing.Size(278, 150);
            this.resultData.TabIndex = 0;
            // 
            // resultTitleLabel
            // 
            this.resultTitleLabel.AutoSize = true;
            this.resultTitleLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultTitleLabel.Location = new System.Drawing.Point(7, 29);
            this.resultTitleLabel.Name = "resultTitleLabel";
            this.resultTitleLabel.Size = new System.Drawing.Size(0, 19);
            this.resultTitleLabel.TabIndex = 1;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 596);
            this.Controls.Add(this.rightPanel);
            this.Controls.Add(this.graphPanel);
            this.Name = "Main";
            this.Text = "Estimation de Santé";
            this.rightPanel.ResumeLayout(false);
            this.rightPanel.PerformLayout();
            this.resultatGlobalPanel.ResumeLayout(false);
            this.resultatGlobalPanel.PerformLayout();
            this.resultPanel.ResumeLayout(false);
            this.resultPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel graphPanel;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Button estimationButton;
        private System.Windows.Forms.Panel resultatGlobalPanel;
        private System.Windows.Forms.Button enregistrerButton;
        private System.Windows.Forms.Label resultatsLabel;
        private System.Windows.Forms.Panel resultPanel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.TextBox ageText;
        private System.Windows.Forms.ComboBox genderCombo;
        private System.Windows.Forms.DataGridView resultData;
        private System.Windows.Forms.Label resultTitleLabel;
    }
}

