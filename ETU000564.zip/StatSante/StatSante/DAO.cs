﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace StatSante
{
    class DAO
    {
        public static List<Object> findObject(SqlConnection connection, string nomTable, string critere)
        {
            List<Object> result = new List<Object>();

            string fullname = "Model." + nomTable;
            /*try
            {*/
            Type type = Type.GetType(fullname);

            string query = "SELECT * FROM " + nomTable;
            if (critere != null)
                query += " WHERE " + critere;

            Console.WriteLine("Query : " + query);

            connection.Open();

            SqlDataReader myReader = null;
            SqlCommand myCommand = new SqlCommand(query, connection);

            myReader = myCommand.ExecuteReader();

            int indiceResult = 0;
            while (myReader.Read())
            {
                result.Add(Activator.CreateInstance(type));

                for (int i = 0; i < myReader.FieldCount; i++)
                {
                    PropertyInfo prop = null;
                    foreach (PropertyInfo property in type.GetProperties())
                    {
                        if(property.Name.ToLower() == myReader.GetName(i).ToLower())
                        {
                            prop = property;
                            break;
                        }
                    }
                    /*Console.WriteLine("DataType:" + myReader.GetDataTypeName(i));
                    Console.WriteLine("Prop:" + prop.Name);*/

                    string dataTypeName = myReader.GetDataTypeName(i);
                    if (dataTypeName.Equals("int"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetInt32(i));
                    else if (dataTypeName.Equals("smallint"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetInt16(i));
                    else if (dataTypeName.Equals("tinyint"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetByte(i));
                    else if (dataTypeName.Equals("decimal"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : (float)myReader.GetDecimal(i));
                    else if (dataTypeName.Equals("date") || myReader.GetDataTypeName(i).Equals("datetime"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? DateTime.Now : myReader.GetDateTime(i));
                    else
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? "" : myReader.GetString(i));
                }
                indiceResult++;
            }

            myReader.Close();
            connection.Close();
            /*}
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }*/

            return result;
        }

        public static void insertObject(SqlConnection connection, string nomTable, string[] parameters)
        {
            string query = "INSERT INTO " + nomTable + " VALUES(";
            int temp;
            for (int i = 0; i < parameters.Length; i++)
            {
                query += int.TryParse(parameters[i], out temp) || parameters[i].Equals("null") || parameters[i].Contains("CONVERT") ? parameters[i] : "'" + parameters[i] + "'";
                query += i == parameters.Length - 1 ? ")" : ",";
            }
            Console.WriteLine("Insert Query : " + query);

            try
            {
                connection.Open();
                SqlCommand myCommand = new SqlCommand(query, connection);

                myCommand.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void updateObject(SqlConnection connection, string nomTable, int id, string colonne, string newValue)
        {
            int temp;
            if (!int.TryParse(newValue, out temp))
                newValue = "'" + newValue + "'";

            string query = "UPDATE " + nomTable + " SET " + colonne + " = " + newValue + " WHERE id=" + id;
            try
            {
                connection.Open();
                SqlCommand myCommand = new SqlCommand(query, connection);

                myCommand.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}
