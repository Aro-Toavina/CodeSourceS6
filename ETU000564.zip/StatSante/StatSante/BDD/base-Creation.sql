/*==============================================================*/
/* Nom de SGBD :  Microsoft SQL Server 2008                     */
/* Date de cr�ation :  30/04/2018 10:08:38                      */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('DISEASE')
            and   type = 'U')
   drop table DISEASE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_SEXE_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_SEXE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_UNITE_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_UNITE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASEDETAIL_ELEMENT_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASEDETAIL_ELEMENT_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DISEASEDETAIL')
            and   name  = 'DISEASE_DISEASEDETAIL_FK'
            and   indid > 0
            and   indid < 255)
   drop index DISEASEDETAIL.DISEASE_DISEASEDETAIL_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('DISEASEDETAIL')
            and   type = 'U')
   drop table DISEASEDETAIL
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ELEMENT')
            and   type = 'U')
   drop table ELEMENT
go

if exists (select 1
            from  sysobjects
           where  id = object_id('GENDER')
            and   type = 'U')
   drop table GENDER
go

if exists (select 1
            from  sysobjects
           where  id = object_id('UNIT')
            and   type = 'U')
   drop table UNIT
go

/*==============================================================*/
/* Table : DISEASE                                              */
/*==============================================================*/
create table DISEASE (
   ID      				int IDENTITY(1,1)    not null,
   IDDISEASE      AS 'DIS' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEDISEASE          varchar(25)          not null,
   constraint PK_DISEASE primary key nonclustered (IDDISEASE)
)
go

/*==============================================================*/
/* Table : DISEASEDETAIL                                        */
/*==============================================================*/
create table DISEASEDETAIL (
   ID      				int IDENTITY(1,1)    not null,
   IDDISEASEDETAIL      AS 'DSD' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   IDUNIT               char(6)              not null,
   IDGENDER             char(6)              not null,
   IDELEMENT            char(6)              not null,
   IDDISEASE            char(6)              not null,
   QUANTITYMIN          decimal(5,3)         not null,
   QUANTITYMAX          decimal(5,3)         not null,
   AGEMIN               smallint             null,
   AGEMAX               smallint             null,
   constraint PK_DISEASEDETAIL primary key nonclustered (IDDISEASEDETAIL)
)
go

/*==============================================================*/
/* Index : DISEASE_DISEASEDETAIL_FK                             */
/*==============================================================*/
create index DISEASE_DISEASEDETAIL_FK on DISEASEDETAIL (
IDDISEASE ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_ELEMENT_FK                             */
/*==============================================================*/
create index DISEASEDETAIL_ELEMENT_FK on DISEASEDETAIL (
IDELEMENT ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_UNITE_FK                               */
/*==============================================================*/
create index DISEASEDETAIL_UNITE_FK on DISEASEDETAIL (
IDUNIT ASC
)
go

/*==============================================================*/
/* Index : DISEASEDETAIL_SEXE_FK                                */
/*==============================================================*/
create index DISEASEDETAIL_SEXE_FK on DISEASEDETAIL (
IDGENDER ASC
)
go

/*==============================================================*/
/* Table : ELEMENT                                              */
/*==============================================================*/
create table ELEMENT (
   ID      				int IDENTITY(1,1)    not null,
   IDELEMENT      AS 'ELT' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEELEMENT          varchar(25)          not null,
   constraint PK_ELEMENT primary key nonclustered (IDELEMENT)
)
go

/*==============================================================*/
/* Table : GENDER                                               */
/*==============================================================*/
create table GENDER (
   ID      				int IDENTITY(1,1)    not null,
   IDGENDER      AS 'GEN' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   SIGNGENDER           char(1)              not null,
   constraint PK_GENDER primary key nonclustered (IDGENDER)
)
go

/*==============================================================*/
/* Table : UNIT                                                 */
/*==============================================================*/
create table UNIT (
   ID      				int IDENTITY(1,1)    not null,
   IDUNIT      AS 'UNT' + RIGHT('000' + CAST(ID AS varchar(3)), 3) PERSISTED,
   NAMEUNIT             varchar(10)          not null,
   constraint PK_UNIT primary key nonclustered (IDUNIT)
)
go

