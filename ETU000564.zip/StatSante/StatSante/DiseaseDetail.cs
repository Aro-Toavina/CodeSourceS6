﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class DiseaseDetail
    {
        private int id;
        private string idDiseaseDetail;
        private string idUnit;
        private string idGender;
        private string idElement;
        private string idDisease;
        private float quantityMin;
        private float quantityMax;
        private int ageMin;
        private int ageMax;

        public DiseaseDetail() { }
        public DiseaseDetail(string idDiseaseDetail, string idUnit, string idGender, string idElement, string idDisease, float quantityMin, float quantityMax, int ageMin, int ageMax)
        {
            this.IdDiseaseDetail = idDiseaseDetail;
            this.IdUnit = idUnit;
            this.IdGender = idGender;
            this.IdElement = idElement;
            this.IdDisease = idDisease;
            this.QuantityMin = quantityMin;
            this.QuantityMax = quantityMax;
            this.AgeMin = ageMin;
            this.AgeMax = ageMax;
        }

        public int Id
        {
            set
            {
                id = value;
            }
        }

        public string IdDiseaseDetail
        {
            get
            {
                return idDiseaseDetail;
            }

            set
            {
                idDiseaseDetail = value;
            }
        }

        public string IdUnit
        {
            get
            {
                return idUnit;
            }

            set
            {
                idUnit = value;
            }
        }

        public string IdElement
        {
            get
            {
                return idElement;
            }

            set
            {
                idElement = value;
            }
        }

        public string IdDisease
        {
            get
            {
                return idDisease;
            }

            set
            {
                idDisease = value;
            }
        }

        public float QuantityMin
        {
            get
            {
                return quantityMin;
            }

            set
            {
                quantityMin = value;
            }
        }

        public float QuantityMax
        {
            get
            {
                return quantityMax;
            }

            set
            {
                quantityMax = value;
            }
        }

        public string IdGender
        {
            get
            {
                return idGender;
            }

            set
            {
                idGender = value;
            }
        }

        public int AgeMin
        {
            get
            {
                return ageMin;
            }

            set
            {
                ageMin = value;
            }
        }

        public int AgeMax
        {
            get
            {
                return ageMax;
            }

            set
            {
                ageMax = value;
            }
        }

        public static List<DiseaseDetail> listObjectToDiseaseDetail(List<Object> objs)
        {
            List<DiseaseDetail> result = new List<DiseaseDetail>();

            foreach (Object obj in objs)
            {
                result.Add((DiseaseDetail)(obj));
            }

            return result;
        }
    }
}
