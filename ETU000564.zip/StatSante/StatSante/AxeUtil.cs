﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatSante
{
    public class AxeUtil
    {
        Point[] tips;
        Point[] vectors;
        float[][] equations;
        Element[] elements;

        public AxeUtil()
        {
        }
        public AxeUtil(Point[] tips, Point[] vectors, float[][] equations, Element[] elements)
        {
            this.Tips = tips;
            this.Vectors = vectors;
            this.Equations = equations;
            this.Elements = elements;
        }

        public Point[] Tips
        {
            get
            {
                return tips;
            }

            set
            {
                tips = value;
            }
        }

        public Point[] Vectors
        {
            get
            {
                return vectors;
            }

            set
            {
                vectors = value;
            }
        }

        public float[][] Equations
        {
            get
            {
                return equations;
            }

            set
            {
                equations = value;
            }
        }

        public Element[] Elements
        {
            get
            {
                return elements;
            }

            set
            {
                elements = value;
            }
        }

        public void initEquations(int axesNb)
        {
            this.equations = new float[axesNb][];
            for(int i=0; i<this.equations.Length; i++)
            {
                equations[i] = new float[2];
            }
        }

        public void initElements(int elementsNb)
        {
            this.elements = new Element[elementsNb];
        }

        public void setElements(SqlConnection connection)
        {
            if (this.Tips.Length != 14)
                throw new Exception("Cette méthode est faite pour 14 axes");

            Element elementTemp;
            List<Element> databaseElts = Element.listObjectToElement(DAO.findObject(connection, "Element", null));
            Console.WriteLine("DatabaseElts Number: " + databaseElts.Count);

            try
            {
                elementTemp = databaseElts.Where(elt => elt.NameElement == "Gamma GT").Single();
                this.elements[0] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Phosphatases alcalines").Single();
                this.elements[1] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Transamines ASAT").Single();
                this.elements[2] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Transamines ALAT").Single();
                this.elements[3] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Bilirubine conjuguée").Single();
                this.elements[4] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Bilirubine libre").Single();
                this.elements[5] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Créatinémie").Single();
                this.elements[6] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Glycémie").Single();
                this.elements[7] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Lipasémie").Single();
                this.elements[8] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Uricémie").Single();
                this.elements[9] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Cholestérolémie totale").Single();
                this.elements[10] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Hémoglobine").Single();
                this.elements[11] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Potassium").Single();
                this.elements[12] = elementTemp;

                elementTemp = databaseElts.Where(elt => elt.NameElement == "Amylasémie").Single();
                this.elements[13] = elementTemp;
            } catch(InvalidOperationException e)
            {
                throw new InvalidOperationException("Il n'y a aucun élément inséré dans la base de données");
            }

            Console.WriteLine("elt[0]: " + this.elements[0].IdElement);
            Console.WriteLine("elt[1]: " + this.elements[1].IdElement);

        }
    }
}
