﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatSante
{
    public class ResultUtil
    {
        private Disease disease;
        private float probability;

        public ResultUtil() { }
        public ResultUtil(Disease disease, float probability)
        {
            this.Disease = disease;
            this.Probability = probability;
        }

        public Disease Disease
        {
            get
            {
                return disease;
            }

            set
            {
                disease = value;
            }
        }

        public float Probability
        {
            get
            {
                return probability;
            }

            set
            {
                probability = value;
            }
        }
    }
}
