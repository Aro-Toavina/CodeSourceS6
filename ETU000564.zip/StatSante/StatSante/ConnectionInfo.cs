﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatSante
{
    class ConnectionInfo
    {
        public static SqlConnection getConnection()
        {
            return new SqlConnection("Data Source=Kev\\SQLEXPRESS;Initial Catalog=StatSante;User ID=sa;Password=tsotra");
        }
    }
}
