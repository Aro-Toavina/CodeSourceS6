﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StatSante
{
    public class GraphUtil
    {
        public static Point[] initPoints(Panel pan, Point[] points, Point origin, int axes)
        {
            points = new Point[axes];
            float ecart = (float)((2 * Math.PI) / axes);
            //Console.WriteLine("Ecart: " + ecart);

            Console.WriteLine("X0: " + origin.X);
            Console.WriteLine("Y0: " + origin.Y);

            Point tip = new Point(pan.Width - 15, pan.Height / 2);

            int hypotenuse = tip.X - origin.X;
            //Console.WriteLine("Hypotenuse: " + hypotenuse);

            float alpha = 0;
            int iteration = 0;
            while (iteration < axes)
            {
                /*Console.WriteLine("X1: " + tip.X);
                Console.WriteLine("Y1: " + tip.Y);
                Console.WriteLine("Alpha: " + alpha);*/

                points[iteration] = new Point(tip.X, tip.Y);
                alpha += ecart;

                //Console.WriteLine("newAlpha: " + alpha);

                tip = getNextPoint(origin, alpha, hypotenuse);
                iteration++;
            }

            /*Console.WriteLine("POINTS:");
            foreach (Point point in points)
            {
                Console.WriteLine("{" + point.X + "," + point.Y + "}");
            }*/

            return points;
        }
        public static void drawAxes(PaintEventArgs e, Panel pan, Point[] points)
        {
            Pen blackPen = new Pen(Color.LightSeaGreen, 2);
            SolidBrush brush = new SolidBrush(Color.Black);
            SolidBrush innerColor = new SolidBrush(Color.LightCoral);

            Point origin = new Point(pan.Width / 2, pan.Height / 2);

            e.Graphics.FillPolygon(innerColor, points);
            foreach (Point point in points)
            {
                e.Graphics.DrawLine(blackPen, origin, point);
                e.Graphics.FillEllipse(brush, point.X - 3, point.Y - 3, 6, 6);
            }
            e.Graphics.DrawPolygon(blackPen, points);
        }

        private static Point getNextPoint(Point origin, float angle, int hypotenuse)
        {
            int x = (int)((Math.Cos(System.Convert.ToDouble(angle))) * hypotenuse + origin.X);
            int y = (int)(-(Math.Sin(System.Convert.ToDouble(angle))) * hypotenuse + origin.Y);

            return new Point(x, y);
        }

        public static Point MouseOnPoint(Point[] points ,MouseEventArgs e)
        {
            Point result = Point.Empty;
            int ecart = 4;
            foreach(Point point in points)
            {
                if(e.X <= point.X + ecart && e.X >= point.X - ecart && e.Y >= point.Y - ecart && e.Y <= point.Y + ecart)
                {
                    result = new Point(point.X, point.Y);
                    break;
                }
            }
            return result;
        }

        public static Point getOriginDifference(Point point, Point origin)
        {
            return new Point(point.X - origin.X, point.Y - origin.Y);
        }

        public static float[] getEquation(Point point, Point origin)
        {
            float[] result = new float[2];

            Console.WriteLine("origin: {" + origin.X + ";" + origin.Y + "}");
            Console.WriteLine("point: {" + point.X + ";" + point.Y + "}");

            result[0] = (float)((float)(origin.Y - point.Y) / (float)(origin.X - point.X));
            Console.WriteLine("result[0]:" + result[0]);
            result[1] = (float)(origin.Y - (result[0] * origin.X));

            Console.WriteLine("{" + result[0] + ";" + result[1] + "}");

            return result;
        }

        public static void setEquations(AxeUtil axeUtil, Point origin)
        {
            Point[] points = axeUtil.Tips;
            float[][] equations = axeUtil.Equations;
            float[] equationTemp;

            Console.WriteLine("EQUATIONS:");
            for (int i=0; i<equations.Length; i++)
            {
                equationTemp = getEquation(points[i], origin);
                equations[i][0] = equationTemp[0];
                equations[i][1] = equationTemp[1];
            }
        }

        public static Point movePoint(Point clickPoint, AxeUtil axeUtil, int indicePoint, Point origin)
        {
            Point originDiff = getOriginDifference(axeUtil.Tips[indicePoint], origin);
            int[] vectorEquation = new int[3];
            vectorEquation[0] = -originDiff.X;
            vectorEquation[1] = -originDiff.Y;
            vectorEquation[2] = (clickPoint.X * originDiff.X) + (clickPoint.Y * originDiff.Y);

            float[] lineEquation = axeUtil.Equations[indicePoint];
            float x = -(vectorEquation[2] + (lineEquation[1] * vectorEquation[1])) / (vectorEquation[0] + (lineEquation[0] * vectorEquation[1]));
            float y = (lineEquation[0] * x) + lineEquation[1];

            return new Point((int)x, (int)y);
        }

        public static float getDistance(Point point1, Point point2)
        {
            return (float) (Math.Sqrt((double)((point2.X - point1.X) * (point2.X - point1.X)) + (double)((point2.Y - point1.Y)) * ((point2.Y - point1.Y))) /5);
        }

        public static List<Disease> getEstimation(SqlConnection connection, AxeUtil axeUtil, Point origin, ComboBoxItem genderCombo, string age)
        {
            int checkAge;
            if (!int.TryParse(age, out checkAge) || int.Parse(age) < 0)
                throw new Exception("Le champ \"âge\" doit contenir un nombre positif");

            List<Disease> result = new List<Disease>();
            List<Disease> diseases = Disease.listObjectToDisease(DAO.findObject(connection, "Disease", null));

            string idMixtGender = Gender.listObjectToGender(DAO.findObject(connection, "Gender", "SignGender = 'M'"))[0].IdGender;

            List<DiseaseDetail> diseaseDet;
            string ageCriterion = "(AgeMin IS NULL OR AgeMin <= " + age + ") AND (AgeMax IS NULL OR AgeMax >= " + age + ")";
            Element elementTemp;
            float distanceTemp = 0f;
            int i;
            foreach(Disease disease in diseases)
            {
                diseaseDet = DiseaseDetail.listObjectToDiseaseDetail(DAO.findObject(connection, "DiseaseDetail", "IdDisease = '" + disease.IdDisease + "' AND (IdGender = '" + genderCombo.HiddenValue + "' OR IdGender = '" + idMixtGender + "') AND " + ageCriterion));
                i = 0;
                while (i < diseaseDet.Count)
                {
                    for(int j = 0; j < axeUtil.Tips.Length; j++)
                    {
                        elementTemp = axeUtil.Elements[j];
                        distanceTemp = getDistance(origin, axeUtil.Tips[j]);
                        if (elementTemp.IdElement == diseaseDet[i].IdElement)
                        {
                            if (!(distanceTemp >= diseaseDet[i].QuantityMin && distanceTemp <= diseaseDet[i].QuantityMax))
                                i = diseaseDet.Count + 1;
                            break;
                        }

                        if (j == axeUtil.Tips.Length - 1)
                            i = diseaseDet.Count + 1;
                    }

                    i++;
                }
                if (diseaseDet.Count != 0 && i == diseaseDet.Count())
                    result.Add(disease);
            }

            return result;
        }

        public static List<ResultUtil> getProbas(SqlConnection connection, AxeUtil axeUtil, Point origin, ComboBoxItem genderCombo, string age)
        {
            int checkAge;
            if (!int.TryParse(age, out checkAge) || int.Parse(age) < 0)
                throw new Exception("Le champ \"âge\" doit contenir un nombre positif");

            List<ResultUtil> result = new List<ResultUtil>();
            List<Disease> diseases = Disease.listObjectToDisease(DAO.findObject(connection, "Disease", null));

            string idMixtGender = Gender.listObjectToGender(DAO.findObject(connection, "Gender", "SignGender = 'M'"))[0].IdGender;

            List<DiseaseDetail> diseaseDet;
            string ageCriterion = "(AgeMin IS NULL OR AgeMin <= " + age + ") AND (AgeMax IS NULL OR AgeMax >= " + age + ")";
            Element elementTemp;
            ResultUtil resultUtil;
            float distanceTemp = 0f;
            int numberDiseaseDet;
            foreach (Disease disease in diseases)
            {
                diseaseDet = DiseaseDetail.listObjectToDiseaseDetail(DAO.findObject(connection, "DiseaseDetail", "IdDisease = '" + disease.IdDisease + "' AND (IdGender = '" + genderCombo.HiddenValue + "' OR IdGender = '" + idMixtGender + "') AND " + ageCriterion));
                resultUtil = new ResultUtil(disease, 0);

                numberDiseaseDet = 0;
                foreach (DiseaseDetail det in diseaseDet)
                {
                    for (int j = 0; j < axeUtil.Tips.Length; j++)
                    {
                        elementTemp = axeUtil.Elements[j];
                        distanceTemp = getDistance(origin, axeUtil.Tips[j]);
                        if (elementTemp.IdElement == det.IdElement)
                        {
                            if (distanceTemp >= det.QuantityMin && distanceTemp <= det.QuantityMax)
                            {
                                numberDiseaseDet++;
                                break;
                            }
                        }
                    }
                }

                if(diseaseDet.Count != 0)
                {
                    resultUtil.Probability = numberDiseaseDet * 100 / diseaseDet.Count;
                    result.Add(resultUtil);
                }
            }

            result.OrderBy(res => res.Probability);
            
            for(int i = 0; i < result.Count; i++)
            {
                if (result[i].Probability == 0)
                    result.Remove(result[i]);
            }
            if(result.Count > 3)
                result = result.GetRange(0, 3);

            return result;
        }
    }
}