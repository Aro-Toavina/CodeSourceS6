﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AnalyseMedical.util
{
    class ErrorException : Exception
    {
        public ErrorException() : base("Message par défaut de l'exception. ") { }
        public ErrorException(string message) : base(message) { }
        public void DisplayError()
        {
            MessageBox.Show(base.Message, "Erreur : ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    
}
