﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace AnalyseMedical.util
{
    class Connection
    {
        public SqlConnection connect { get; set; }
        private string connectionString = null;

        public Connection()
        {
            connectionString = "Data Source=(local);Initial Catalog=analysemedical;User ID=sa;Password=itu";
            connect = new SqlConnection(connectionString);
            try
            {
                connect.Open();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
