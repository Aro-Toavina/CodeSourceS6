﻿ --Create database analysemedical

 CREATE TABLE Element(
	id INT IDENTITY(1,1) NOT NULL,
	nom VARCHAR(50),
	unite VARCHAR(10),
	normInf DECIMAL(12,2),
	normSup DECIMAL(12,2),
	sexe INT,
	PRIMARY KEY(id)
);

CREATE TABLE Maladie(
	id INT IDENTITY(1,1) NOT NULL,
	nom VARCHAR(50),
	PRIMARY KEY(id)
);

CREATE TABLE Diagnostic(
	id INT IDENTITY(1,1) NOT NULL,
	idElement INT,
	idMaladie INT,
	siSupInf INT,
	pasProbabilite DECIMAL(12,2),
	PRIMARY KEY(id),
	FOREIGN KEY(idElement) REFERENCES Element(id),
	FOREIGN KEY(idMaladie) REFERENCES Maladie(id),
);

INSERT INTO Element(nom, unite, normInf, normSup, sexe) VALUES
	('Hématie', '/mm³', 4200000, 6200000, 2),
	('Hémoglobine', 'g/100 ml', 13, 18, 2),
	('Phosphates alcalines', 'Ui/L', 53, 128, 2),
	('Transaminases ASAT', 'U/L', 0, 35, 2),
	('Transaminases ALAT', 'U/L', 0, 45, 2),
	('Créatininémie', 'µmol/L', 0, 100, 0),
	('Créatininémie', 'µmol/L', 0, 120, 1),
	('Glycémie', 'mmol/L', 4, 6, 2),
	('Uricémie', 'µmol/L', 0, 410, 2),
	('Cholestérolémie totale', 'mmol/L', 3, 6.2, 2),
	('Lipasémie', 'U/L', 0, 60, 2),
	('Sodium', 'mmol/L', 137, 145, 2),
	('Potassium', 'mmol/L', 3.6, 5, 2),
	('Chlore', 'mmol/L', 98, 107, 2),
	('Anti-streptolysine O', 'U/mL', 0, 200, 2);

INSERT INTO Maladie(nom) VALUES
	('Anémie'),
	('Polyglobulie'),
	('Hépatite'),
	('Insuffisance rénale'),
	('Hypoglycémie'),
	('Diabète'),
	('Goutte'),
	('Insuffisance hépatique'),
	('Syndrome de surcharge'),
	('Pancréatite'),
	('Hyponatrémie'),
	('Hypokaliémie'),
	('Hypochlorhémie'),
	('Hypernatrémie'),
	('Hyperkaliémie'),
	('Hyperchlorhémie'),
	('Rhumatisme Articulaire Aigu');

INSERT INTO Diagnostic(idElement, idMaladie, siSupInf, pasProbabilite) VALUES
	(1, 1, 0, 20000),	(1, 2, 1, 20000),
	(2, 1, 0, 0.15),	(2, 2, 1, 0.15),
						(3, 3, 1, 0.75),
						(4, 3, 1, 0.1),
						(5, 3, 1, 0.1),
						(6, 4, 1, 1),
						(7, 4, 1, 1),
	(8, 5, 0, 0.02),	(8, 6, 1, 0.02),
						(9, 7, 1, 5),
	(10, 8, 0, 0.03),	(10, 9, 1, 0.03),
						(11, 10, 1, 0.5),
	(12, 11, 0, 0.8),	(12, 14, 1, 0.8),
	(13, 12, 0, 0.1),	(13, 15, 1, 0.1),
	(14, 13, 0, 0.08),	(14, 16, 1, 0.08),
						(15, 17, 1, 2);

CREATE VIEW DiagnosticVue AS
SELECT d.*, e.nom as nomElement, e.unite, e.normInf, e.normSup, e.sexe, m.nom as nomMaladie FROM Diagnostic d
JOIN Element e ON d.idElement = e.id
JOIN Maladie m ON d.idMaladie = m.id;