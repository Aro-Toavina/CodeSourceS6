﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AnalyseMedical.util;
using AnalyseMedical.medecine;

namespace AnalyseMedical.personne
{
    class AnalysePatient
    {
        private double _valeur;
        private Element _elementReference;

        public AnalysePatient(double valeur, Element elementReference)
        {
            this.valeur = valeur;
            this.elementReference = elementReference;
        }

        public double valeur
        {
            get { return _valeur; }
            set { _valeur = value; }
        }

        public Element elementReference
        {
            get { return _elementReference; }
            set { _elementReference = value; }
        }


    }
}
