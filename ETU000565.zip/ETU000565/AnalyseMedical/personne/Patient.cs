﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AnalyseMedical.util;

namespace AnalyseMedical.personne
{
    class Patient
    {
        private string _nom;
        private string _prenom;
        private int _age;
        private int _sexe;
        private AnalysePatient[] _analyse;

        public Patient(string nom, string prenom, int age, int sexe, AnalysePatient[] analyse)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.age = age;
            this.sexe = sexe;
            this.analyse = analyse;
        }
        public Patient(string nom, string prenom, int age, int sexe)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.age = age;
            this.sexe = sexe;
        }

        public string nom
        {
            get { return _nom; }
            set { _nom = value; }
        }
        public string prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }
        public int age
        {
            get { return _age; }
            set { _age = value; }
        }
        public int sexe
        {
            get { return _sexe; }
            set
            {
                if (value < 0 || value > 2)
                    throw new ErrorException("Veuillez entrer 0 pour Femme, 1 pour Homme, 2 pour les deux");
                else
                    _sexe = value;
            }
        }
        public AnalysePatient[] analyse
        {
            get { return _analyse; }
            set { _analyse = value; }
        }

    }
}
