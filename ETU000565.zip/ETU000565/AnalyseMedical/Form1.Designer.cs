﻿namespace AnalyseMedical
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label0 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.quantityArea0 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.quantityArea1 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea2 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea3 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea4 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea5 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea6 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea7 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea8 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea9 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea10 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea11 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea12 = new System.Windows.Forms.NumericUpDown();
            this.quantityArea13 = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.radioFemme = new System.Windows.Forms.RadioButton();
            this.radioHomme = new System.Windows.Forms.RadioButton();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listResultatBox = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.buttonAnalyser = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea13)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(100, 38);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Radar;
            series1.Legend = "Legend1";
            series1.MarkerBorderColor = System.Drawing.Color.Black;
            series1.MarkerColor = System.Drawing.Color.White;
            series1.MarkerSize = 9;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(534, 450);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            this.chart1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseDown);
            this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseMove);
            this.chart1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(473, 376);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Créatininémie";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(506, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Transaminases ALAT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(506, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Transaminases ASAT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(462, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Phosphates alcalines";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(383, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Hémoglobine";
            // 
            // label0
            // 
            this.label0.AutoSize = true;
            this.label0.Location = new System.Drawing.Point(291, 30);
            this.label0.Name = "label0";
            this.label0.Size = new System.Drawing.Size(51, 13);
            this.label0.TabIndex = 2;
            this.label0.Text = "Hématies";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(133, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Anti-streptolysine O";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(108, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Chlore";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(77, 293);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Sodium";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 209);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Potassium";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(106, 376);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Lipasémie";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(386, 444);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Glycémie";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(166, 446);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Cholestérolémie totale";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(275, 465);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Uricémie";
            // 
            // quantityArea0
            // 
            this.quantityArea0.DecimalPlaces = 2;
            this.quantityArea0.Location = new System.Drawing.Point(260, 46);
            this.quantityArea0.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.quantityArea0.Name = "quantityArea0";
            this.quantityArea0.Size = new System.Drawing.Size(103, 20);
            this.quantityArea0.TabIndex = 16;
            this.quantityArea0.ThousandsSeparator = true;
            this.quantityArea0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(363, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "/mm³";
            // 
            // quantityArea1
            // 
            this.quantityArea1.Location = new System.Drawing.Point(418, 80);
            this.quantityArea1.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea1.Name = "quantityArea1";
            this.quantityArea1.Size = new System.Drawing.Size(53, 20);
            this.quantityArea1.TabIndex = 18;
            this.quantityArea1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea1_ValueChanged);
            // 
            // quantityArea2
            // 
            this.quantityArea2.Location = new System.Drawing.Point(476, 136);
            this.quantityArea2.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea2.Name = "quantityArea2";
            this.quantityArea2.Size = new System.Drawing.Size(53, 20);
            this.quantityArea2.TabIndex = 19;
            this.quantityArea2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea2_ValueChanged);
            // 
            // quantityArea3
            // 
            this.quantityArea3.Location = new System.Drawing.Point(509, 225);
            this.quantityArea3.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea3.Name = "quantityArea3";
            this.quantityArea3.Size = new System.Drawing.Size(53, 20);
            this.quantityArea3.TabIndex = 20;
            this.quantityArea3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea3_ValueChanged);
            // 
            // quantityArea4
            // 
            this.quantityArea4.Location = new System.Drawing.Point(506, 309);
            this.quantityArea4.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea4.Name = "quantityArea4";
            this.quantityArea4.Size = new System.Drawing.Size(53, 20);
            this.quantityArea4.TabIndex = 21;
            this.quantityArea4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea4_ValueChanged);
            // 
            // quantityArea5
            // 
            this.quantityArea5.Location = new System.Drawing.Point(465, 391);
            this.quantityArea5.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea5.Name = "quantityArea5";
            this.quantityArea5.Size = new System.Drawing.Size(53, 20);
            this.quantityArea5.TabIndex = 22;
            this.quantityArea5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea5_ValueChanged);
            // 
            // quantityArea6
            // 
            this.quantityArea6.Location = new System.Drawing.Point(386, 461);
            this.quantityArea6.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea6.Name = "quantityArea6";
            this.quantityArea6.Size = new System.Drawing.Size(53, 20);
            this.quantityArea6.TabIndex = 23;
            this.quantityArea6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea6_ValueChanged);
            // 
            // quantityArea7
            // 
            this.quantityArea7.Location = new System.Drawing.Point(278, 481);
            this.quantityArea7.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea7.Name = "quantityArea7";
            this.quantityArea7.Size = new System.Drawing.Size(53, 20);
            this.quantityArea7.TabIndex = 24;
            this.quantityArea7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea7_ValueChanged);
            // 
            // quantityArea8
            // 
            this.quantityArea8.Location = new System.Drawing.Point(169, 463);
            this.quantityArea8.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea8.Name = "quantityArea8";
            this.quantityArea8.Size = new System.Drawing.Size(53, 20);
            this.quantityArea8.TabIndex = 25;
            this.quantityArea8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea8_ValueChanged);
            // 
            // quantityArea9
            // 
            this.quantityArea9.Location = new System.Drawing.Point(95, 392);
            this.quantityArea9.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea9.Name = "quantityArea9";
            this.quantityArea9.Size = new System.Drawing.Size(53, 20);
            this.quantityArea9.TabIndex = 26;
            this.quantityArea9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea9_ValueChanged);
            // 
            // quantityArea10
            // 
            this.quantityArea10.Location = new System.Drawing.Point(37, 309);
            this.quantityArea10.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea10.Name = "quantityArea10";
            this.quantityArea10.Size = new System.Drawing.Size(53, 20);
            this.quantityArea10.TabIndex = 27;
            this.quantityArea10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea10_ValueChanged);
            // 
            // quantityArea11
            // 
            this.quantityArea11.Location = new System.Drawing.Point(33, 225);
            this.quantityArea11.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea11.Name = "quantityArea11";
            this.quantityArea11.Size = new System.Drawing.Size(53, 20);
            this.quantityArea11.TabIndex = 28;
            this.quantityArea11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea11_ValueChanged);
            // 
            // quantityArea12
            // 
            this.quantityArea12.Location = new System.Drawing.Point(68, 136);
            this.quantityArea12.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea12.Name = "quantityArea12";
            this.quantityArea12.Size = new System.Drawing.Size(53, 20);
            this.quantityArea12.TabIndex = 29;
            this.quantityArea12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea12_ValueChanged);
            // 
            // quantityArea13
            // 
            this.quantityArea13.Location = new System.Drawing.Point(140, 77);
            this.quantityArea13.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.quantityArea13.Name = "quantityArea13";
            this.quantityArea13.Size = new System.Drawing.Size(53, 20);
            this.quantityArea13.TabIndex = 30;
            this.quantityArea13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantityArea13_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.radioFemme);
            this.panel1.Controls.Add(this.radioHomme);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label16);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(672, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(413, 144);
            this.panel1.TabIndex = 31;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(126, 118);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 13);
            this.label20.TabIndex = 42;
            this.label20.Text = "Sexe :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(126, 89);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 13);
            this.label19.TabIndex = 41;
            this.label19.Text = "Age :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(126, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 40;
            this.label18.Text = "Prénom :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(126, 37);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 39;
            this.label17.Text = "Nom :";
            // 
            // radioFemme
            // 
            this.radioFemme.AutoSize = true;
            this.radioFemme.Location = new System.Drawing.Point(287, 115);
            this.radioFemme.Name = "radioFemme";
            this.radioFemme.Size = new System.Drawing.Size(74, 17);
            this.radioFemme.TabIndex = 38;
            this.radioFemme.TabStop = true;
            this.radioFemme.Text = "Femme ♀";
            this.radioFemme.UseVisualStyleBackColor = true;
            this.radioFemme.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioHomme
            // 
            this.radioHomme.AutoSize = true;
            this.radioHomme.Location = new System.Drawing.Point(194, 115);
            this.radioHomme.Name = "radioHomme";
            this.radioHomme.Size = new System.Drawing.Size(76, 17);
            this.radioHomme.TabIndex = 37;
            this.radioHomme.TabStop = true;
            this.radioHomme.Text = "Homme ♂";
            this.radioHomme.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(194, 87);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(87, 20);
            this.numericUpDown1.TabIndex = 36;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(194, 60);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(207, 20);
            this.textBox2.TabIndex = 35;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(194, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(207, 20);
            this.textBox1.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label16.Location = new System.Drawing.Point(3, 2);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(142, 25);
            this.label16.TabIndex = 33;
            this.label16.Text = "Infos patient";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label15.Location = new System.Drawing.Point(672, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(422, 31);
            this.label15.TabIndex = 32;
            this.label15.Text = "Analyses médicales prédictives";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel2.Controls.Add(this.listResultatBox);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Location = new System.Drawing.Point(672, 279);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(412, 209);
            this.panel2.TabIndex = 33;
            // 
            // listResultatBox
            // 
            this.listResultatBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listResultatBox.FormattingEnabled = true;
            this.listResultatBox.ItemHeight = 20;
            this.listResultatBox.Location = new System.Drawing.Point(44, 38);
            this.listResultatBox.Name = "listResultatBox";
            this.listResultatBox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listResultatBox.Size = new System.Drawing.Size(325, 144);
            this.listResultatBox.TabIndex = 35;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label21.Location = new System.Drawing.Point(3, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 25);
            this.label21.TabIndex = 34;
            this.label21.Text = "Résultats";
            // 
            // buttonAnalyser
            // 
            this.buttonAnalyser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnalyser.Location = new System.Drawing.Point(809, 234);
            this.buttonAnalyser.Name = "buttonAnalyser";
            this.buttonAnalyser.Size = new System.Drawing.Size(160, 35);
            this.buttonAnalyser.TabIndex = 34;
            this.buttonAnalyser.Text = "ANALYSER";
            this.buttonAnalyser.UseVisualStyleBackColor = true;
            this.buttonAnalyser.Click += new System.EventHandler(this.buttonAnalyser_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(472, 82);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 13);
            this.label22.TabIndex = 35;
            this.label22.Text = "g/100mL";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(528, 138);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 13);
            this.label23.TabIndex = 36;
            this.label23.Text = "Ui/L";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(561, 227);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 13);
            this.label24.TabIndex = 37;
            this.label24.Text = "U/L";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(560, 311);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 13);
            this.label25.TabIndex = 38;
            this.label25.Text = "U/L";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(517, 394);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 13);
            this.label26.TabIndex = 39;
            this.label26.Text = "µmol/L";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(439, 464);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(42, 13);
            this.label27.TabIndex = 40;
            this.label27.Text = "mmol/L";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(330, 483);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 13);
            this.label28.TabIndex = 41;
            this.label28.Text = "µmol/L";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(221, 465);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(42, 13);
            this.label29.TabIndex = 42;
            this.label29.Text = "mmol/L";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(148, 394);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 13);
            this.label30.TabIndex = 43;
            this.label30.Text = "U/L";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(90, 311);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(42, 13);
            this.label31.TabIndex = 44;
            this.label31.Text = "mmol/L";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(84, 227);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(42, 13);
            this.label32.TabIndex = 45;
            this.label32.Text = "mmol/L";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(120, 138);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(42, 13);
            this.label33.TabIndex = 46;
            this.label33.Text = "mmol/L";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(193, 80);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(34, 13);
            this.label34.TabIndex = 47;
            this.label34.Text = "U/mL";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 516);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.buttonAnalyser);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.quantityArea13);
            this.Controls.Add(this.quantityArea12);
            this.Controls.Add(this.quantityArea11);
            this.Controls.Add(this.quantityArea10);
            this.Controls.Add(this.quantityArea9);
            this.Controls.Add(this.quantityArea8);
            this.Controls.Add(this.quantityArea7);
            this.Controls.Add(this.quantityArea6);
            this.Controls.Add(this.quantityArea5);
            this.Controls.Add(this.quantityArea4);
            this.Controls.Add(this.quantityArea3);
            this.Controls.Add(this.quantityArea2);
            this.Controls.Add(this.quantityArea1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.quantityArea0);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label0);
            this.Controls.Add(this.chart1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityArea13)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label0;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown quantityArea0;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown quantityArea1;
        private System.Windows.Forms.NumericUpDown quantityArea2;
        private System.Windows.Forms.NumericUpDown quantityArea3;
        private System.Windows.Forms.NumericUpDown quantityArea4;
        private System.Windows.Forms.NumericUpDown quantityArea5;
        private System.Windows.Forms.NumericUpDown quantityArea6;
        private System.Windows.Forms.NumericUpDown quantityArea7;
        private System.Windows.Forms.NumericUpDown quantityArea8;
        private System.Windows.Forms.NumericUpDown quantityArea9;
        private System.Windows.Forms.NumericUpDown quantityArea10;
        private System.Windows.Forms.NumericUpDown quantityArea11;
        private System.Windows.Forms.NumericUpDown quantityArea12;
        private System.Windows.Forms.NumericUpDown quantityArea13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton radioFemme;
        private System.Windows.Forms.RadioButton radioHomme;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox listResultatBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button buttonAnalyser;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;

    }
}

