﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using AnalyseMedical.medecine;
using AnalyseMedical.util;

namespace AnalyseMedical.dao
{
    class DiagnosticDAO
    {
        private static String whr = " where ";
        private static String select = "select * from ";
        public static Diagnostic[] find(String afterWhere, String nTable, Connection conn)
        {
            if (nTable == null)
                nTable = "Diagnostic";
            SqlCommand command0 = null;
            SqlDataReader dataReader0 = null;
            SqlCommand command = null; ;
            SqlDataReader dataReader = null;
            String req = select;
            int i = 0;
            int l = 0;
            Diagnostic[] retMag = null;

            try
            {
                req = req + nTable;
                if (afterWhere != null)
                {
                    req = req + whr;
                    req = req + afterWhere;
                }
                Console.Write(req);
                //MessageBox.Show(req);

                command0 = new SqlCommand(req, conn.connect);
                dataReader0 = command0.ExecuteReader();
                while (dataReader0.Read())
                    l = l + 1;
                retMag = new Diagnostic[l];
                dataReader0.Close();
                command = new SqlCommand(req, conn.connect);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    if(nTable.Equals("Diagnostic"))
                        retMag[i] = new Diagnostic(dataReader.GetInt32(0), dataReader.GetInt32(1), dataReader.GetInt32(2), dataReader.GetInt32(3), dataReader.GetFloat(4));
                    else
                        //retMag[i] = new Diagnostic(dataReader.GetInt32(0), dataReader.GetInt32(1), dataReader.GetInt32(2), dataReader.GetInt32(3), float.Parse(dataReader.GetDecimal(4).ToString()));
                        retMag[i] = new Diagnostic(dataReader.GetInt32(0), dataReader.GetInt32(1), dataReader.GetInt32(2), dataReader.GetInt32(3), float.Parse(dataReader.GetDecimal(4).ToString()), dataReader.GetString(5), dataReader.GetString(6), float.Parse(dataReader.GetDecimal(7).ToString()), float.Parse(dataReader.GetDecimal(8).ToString()), dataReader.GetInt32(9), dataReader.GetString(10));
                    i++;
                }
            }
            catch (ErrorException ex)
            {
                throw ex;
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (command != null)
                    command.Dispose();
                if (dataReader0 != null)
                    dataReader0.Close();
                if (command0 != null)
                    command0.Dispose();
                if (conn != null)
                    conn.connect.Close();
            }
            return retMag;
        }
        public static Diagnostic[] find(String afterWhere, String nTable)
        {
            Connection conn = null;
            try
            {
                conn = new Connection();
                return find(afterWhere, nTable, conn);
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("**************" + e);
                throw e;
                
            }
            finally
            {
                if (conn != null)
                    conn.connect.Close();
            }
        }
    }
}
