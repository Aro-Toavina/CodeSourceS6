﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using AnalyseMedical.medecine;
using AnalyseMedical.util;


namespace AnalyseMedical.dao
{
    class MaladieDAO
    {
        private static String whr = " where ";
        private static String select = "select * from ";
        public static Maladie[] find(String afterWhere, String nTable, Connection conn)
        {
            if (nTable == null)
                nTable = "Maladie";
            SqlCommand command0 = null;
            SqlDataReader dataReader0 = null;
            SqlCommand command = null; ;
            SqlDataReader dataReader = null;
            String req = select;
            int i = 0;
            int l = 0;
            Maladie[] retMag = null;

            try
            {
                req = req + nTable;
                if (afterWhere != null)
                {
                    req = req + whr;
                    req = req + afterWhere;
                }
                Console.Write(req);
                //MessageBox.Show(req);

                command0 = new SqlCommand(req, conn.connect);
                dataReader0 = command0.ExecuteReader();
                while (dataReader0.Read())
                    l = l + 1;
                retMag = new Maladie[l];
                dataReader0.Close();
                command = new SqlCommand(req, conn.connect);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    retMag[i] = new Maladie(dataReader.GetInt32(0), dataReader.GetString(1));
                    i++;
                }
            }
            catch (ErrorException ex)
            {
                throw ex;
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (command != null)
                    command.Dispose();
                if (dataReader0 != null)
                    dataReader0.Close();
                if (command0 != null)
                    command0.Dispose();
                if (conn != null)
                    conn.connect.Close();
            }
            return retMag;
        }
        public static Maladie[] find(String afterWhere, String nTable)
        {
            Connection conn = null;
            try
            {
                conn = new Connection();
                return find(afterWhere, nTable, conn);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (conn != null)
                    conn.connect.Close();
            }
        }
    }
}
