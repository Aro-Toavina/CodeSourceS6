﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AnalyseMedical.util;

namespace AnalyseMedical.medecine
{
    class Element
    {
        private int _id;
        private string _nom;
        private string _unite;
        private float _normInf;
        private float _normSup;
        private int _sexe;

        public Element(string nom, string unite, float normInf, float normSup, int sexe) : this(0, nom, unite, normInf, normSup, sexe) { }
        public Element(int id, string nom, string unite, float normInf, float normSup, int sexe) 
        {
            this.id = id;
            this.nom = nom;
            this.unite = unite;
            this.normInf = normInf;
            this.normSup = normSup;
            this.sexe = sexe;
        }

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string nom
        {
            get { return _nom; }
            set { _nom = value; }
        }
        public string unite
        {
            get { return _unite; }
            set { _unite = value; }
        }
        public float normInf
        {
            get { return _normInf; }
            set
            {
                if (value < 0)
                    throw new ErrorException("Veuillez entrer une valeur positive");
                else
                    _normInf = value;
            }
        }
        public float normSup
        {
            get { return _normSup; }
            set 
            {
                if (value < 0)
                    throw new ErrorException("Veuillez entrer une valeur positive");
                else
                    _normSup = value; 
            }
        }
        public int sexe
        {
            get { return _sexe; }
            set
            {
                if (value < 0 || value > 2)
                    throw new ErrorException("Veuillez entrer 0 pour Femme, 1 pour Homme, 2 pour les deux");
                else
                    _sexe = value;
            }
        }

    }
}
