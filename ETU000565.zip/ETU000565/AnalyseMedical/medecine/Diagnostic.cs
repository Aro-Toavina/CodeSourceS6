﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AnalyseMedical.util;

namespace AnalyseMedical.medecine
{
    class Diagnostic
    {
        private int _id;
        private int _idElement;
        private int _idMaladie;
        private int _siSupInf;
        private float _pasProbabilite;
        //View only :
        private string _nomElement;
        private string _unite;
        private float _normInf;
        private float _normSup;
        private int _sexe;
        private string _nomMaladie;

        public Diagnostic(int idElement, int idMaladie, int siSupInf, float pasProbabilite) : this(0, idElement, idMaladie, siSupInf, pasProbabilite) { }
        public Diagnostic(int id, int idElement, int idMaladie, int siSupInf, float pasProbabilite)
        {
            this.id = id;
            this.idElement = idElement;
            this.idMaladie = idMaladie;
            this.siSupInf = siSupInf;
            this.pasProbabilite = pasProbabilite;
        }
        public Diagnostic(int id, int idElement, int idMaladie, int siSupInf, float pasProbabilite, string nomElement, string unite, float normInf, float normSup, int sexe, string nomMaladie)
        {
            this.id = id;
            this.idElement = idElement;
            this.idMaladie = idMaladie;
            this.siSupInf = siSupInf;
            this.pasProbabilite = pasProbabilite;
            this.nomElement = nomElement;
            this.unite = unite;
            this.normInf = normInf;
            this.normSup = normSup;
            this.sexe = sexe;
            this.nomMaladie = nomMaladie;
        }
        public string nomMaladie
        {
            get { return _nomMaladie; }
            set { _nomMaladie = value; }
        }
        public string unite
        {
            get { return _unite; }
            set { _unite = value; }
        }
        public float normInf
        {
            get { return _normInf; }
            set
            {
                if (value < 0)
                    throw new ErrorException("Veuillez entrer une valeur positive");
                else
                    _normInf = value;
            }
        }
        public float normSup
        {
            get { return _normSup; }
            set
            {
                if (value < 0)
                    throw new ErrorException("Veuillez entrer une valeur positive");
                else
                    _normSup = value;
            }
        }
        public int sexe
        {
            get { return _sexe; }
            set
            {
                if (value < 0 || value > 2)
                    throw new ErrorException("Veuillez entrer 0 pour Femme, 1 pour Homme, 2 pour les deux");
                else
                    _sexe = value;
            }
        }
        public string nomElement
        {
            get { return _nomElement; }
            set { _nomElement = value; }
        }
        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        public int idElement
        {
            get { return _idElement; }
            set { _idElement = value; }
        }
        public int idMaladie
        {
            get { return _idMaladie; }
            set { _idMaladie = value; }
        }
        public int siSupInf
        {
            get { return _siSupInf; }
            set { _siSupInf = value; }
        }
        public float pasProbabilite
        {
            get { return _pasProbabilite; }
            set
            {
                if (value < 0)
                    throw new ErrorException("Veuillez entrer une valeur positive");
                else
                    _pasProbabilite = value;
            }
        }
    }
}
