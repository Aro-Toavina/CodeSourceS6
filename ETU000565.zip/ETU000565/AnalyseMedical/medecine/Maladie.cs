﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnalyseMedical.medecine
{
    class Maladie
    {
        private int _id;
        private string _nom;

        public Maladie(string nom) : this(0, nom) { }
        public Maladie(int id, string nom) 
        {
            this.id = id;
            this.nom = nom;
        }

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string nom
        {
            get { return _nom; }
            set { _nom = value; }
        }
    }
}
