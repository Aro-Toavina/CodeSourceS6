﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AnalyseMedical.personne;
using AnalyseMedical.medecine;
using AnalyseMedical.dao;

namespace AnalyseMedical
{
    public partial class Form1 : Form
    {
        private int nbVar = 14;
        private int MaxY = 120;
        private int countCursor = 0;
        private bool moussePress = false;
        private double[][] valInit = null;
        private double[] trueMaxValues = null;
        private string[] listResultat = null;
        private Diagnostic[] listDiagnostic = null;
        public Form1()
        {
            InitializeComponent();
            this.listDiagnostic = DiagnosticDAO.find(null, "DiagnosticVue");
            listResultatBox.DataSource = listResultat;
            chart1.ChartAreas[0].AxisY.Maximum = MaxY;
            chart1.ChartAreas[0].AxisY.LabelStyle.Enabled = false;
            trueMaxValues = new double[14];
            trueMaxValues[0] = 10000000;
            trueMaxValues[1] = 24;
            trueMaxValues[2] = 200;
            trueMaxValues[3] = 100;
            trueMaxValues[4] = 100;
            trueMaxValues[5] = 200;
            trueMaxValues[6] = 10;
            trueMaxValues[7] = 1000;
            trueMaxValues[8] = 10;
            trueMaxValues[9] = 100;
            trueMaxValues[10] = 200;
            trueMaxValues[11] = 10;
            trueMaxValues[12] = 150;
            trueMaxValues[13] = 400;

            quantityArea0.Maximum = decimal.Parse(trueMaxValues[0].ToString());
            quantityArea1.Maximum = decimal.Parse(trueMaxValues[1].ToString());
            quantityArea2.Maximum = decimal.Parse(trueMaxValues[2].ToString());
            quantityArea3.Maximum = decimal.Parse(trueMaxValues[3].ToString());
            quantityArea4.Maximum = decimal.Parse(trueMaxValues[4].ToString());
            quantityArea5.Maximum = decimal.Parse(trueMaxValues[5].ToString());
            quantityArea6.Maximum = decimal.Parse(trueMaxValues[6].ToString());
            quantityArea7.Maximum = decimal.Parse(trueMaxValues[7].ToString());
            quantityArea8.Maximum = decimal.Parse(trueMaxValues[8].ToString());
            quantityArea9.Maximum = decimal.Parse(trueMaxValues[9].ToString());
            quantityArea10.Maximum = decimal.Parse(trueMaxValues[10].ToString());
            quantityArea11.Maximum = decimal.Parse(trueMaxValues[11].ToString());
            quantityArea12.Maximum = decimal.Parse(trueMaxValues[12].ToString());
            quantityArea13.Maximum = decimal.Parse(trueMaxValues[13].ToString());

            for (int i = 0; i < nbVar; i++)
            {
                chart1.Series["Series1"].Points.AddY(50);
            }

            //change it when all 14 ar ready:
            //quantityArea0.Value = 50;
            //********************

                       // chart1.Series["Series1"].Points.ElementAt(0).AxisLabel = "Globules Rouges";
         
           // chart1.Series["Series1"].Points.ElementAt(1).IsValueShownAsLabel = true;
            
            saveValues();
           // MessageBox.Show(chart1.Series["Series1"].Points.ElementAt(0).YValues.Length.ToString());
        }
        private void initValues()
        {
            for (int i = 0; i < nbVar; i++)
            {
                chart1.Series["Series1"].Points.ElementAt(i).YValues = valInit[i];

            }

        }
        private void saveValues()
        {
            valInit = new double[nbVar][];
            for (int i = 0; i < nbVar; i++)
            {
                valInit[i] = new double[1];
                valInit[i] = chart1.Series["Series1"].Points.ElementAt(i).YValues;
            }
        }
        private void chart1_Click(object sender, EventArgs e)
        {
            
            // centre du point
            double x = this.chart1.Size.Width - this.chart1.Location.X;
            double y = this.chart1.Size.Height - this.chart1.Location.Y;
            x = 214; y = 220;
            double[] yvalues = new double[1];
            
            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);
            
            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
            
            //MessageBox.Show(msgA + "\n" + msgB + "\n" + msgC + "\n" + msgD);
            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea1.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[1], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea8.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[8], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea2.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[2], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea9.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[9], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea3.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[3], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea10.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[10], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea4.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[4], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea11.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[11], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea5.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[5], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea12.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[12], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea6.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[6], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea13.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[13], float.Parse(yvalues[0].ToString())).ToString());
                }



                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea0.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[0], float.Parse(yvalues[0].ToString())).ToString());
                }
                else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                {
                    yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                    chart1.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                    if (yvalues[0] <= MaxY)
                        quantityArea7.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[7], float.Parse(yvalues[0].ToString())).ToString());
                }
           
                //MessageBox.Show("yvalues=" + yvalues[0]);
            }


            saveValues();
                
              //  chart1.Series["test1"].ChartType = SeriesChartType.FastLine;
           // chart1.Series["Series1"].Points.ElementAt(0).Color = Color.Red;

               // chart1.Series["test2"].ChartType =SeriesChartType.FastLine;
              
            
        }

        private static double calculHypotenuse(double x, double y)
        {
            // 10 sur l'echelle equivaut a 15 px
            return Math.Sqrt(x * x + y * y) * 10.0 / 16;
        }

        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            
            
            //Console.WriteLine("Cursor Changed************" + (countCursor++));
            // centre du point
            
            double x = this.chart1.Size.Width - this.chart1.Location.X;
            double y = this.chart1.Size.Height - this.chart1.Location.Y;
            x = 214; y = 220;
            double[] yvalues = new double[1];
            Random rdn = new Random();
            MouseEventArgs mEvent = (MouseEventArgs)e;
            double tan = (mEvent.Y - y) / (mEvent.X - x);

            string msgA = ("(mEvent.Y - y)=" + (mEvent.Y - y));
            string msgB = ("(mEvent.X - x)=" + (mEvent.X - x));
            string msgC = ("tan=" + tan);
            string msgD = ("Math.Atan(tan)=" + Math.Atan(tan));
           
            //MessageBox.Show(msgA + "\n" + msgB + "\n" + msgC + "\n" + msgD);
            initValues();

            if (Math.Abs(mEvent.X - x) * 10.0 / 16 < MaxY && (Math.Abs(mEvent.Y - y) * 10.0 / 16 < MaxY))
            {
                if (moussePress)
                {
                    if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(1).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea1.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[1], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (-1.2) && Math.Atan(tan) < (-1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(8).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea8.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[8], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(2).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea2.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[2], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (-0.75) && Math.Atan(tan) < (-0.5) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(9).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea9.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[9], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x > 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(3).YValues = yvalues;
                        if(yvalues[0] <= MaxY)
                            quantityArea3.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[3], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (-0.3) && Math.Atan(tan) < (-0.1) && mEvent.X - x < 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(10).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea10.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[10], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(4).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea4.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[4], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (0.1) && Math.Atan(tan) < (0.3) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(11).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea11.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[11], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(5).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea5.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[5], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (0.5) && Math.Atan(tan) < (0.75) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(12).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea12.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[12], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x > 0 && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(6).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea6.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[6], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (Math.Atan(tan) > (1.0) && Math.Atan(tan) < (1.2) && mEvent.X - x < 0 && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(13).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea13.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[13], float.Parse(yvalues[0].ToString())).ToString());
                    }



                    else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y < 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(0).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea0.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[0], float.Parse(yvalues[0].ToString())).ToString());
                    }
                    else if (((Math.Atan(tan) > (-1.58) && Math.Atan(tan) < (-1.45)) || (Math.Atan(tan) > (1.45) && Math.Atan(tan) < (1.58))) && mEvent.Y - y > 0)
                    {
                        yvalues[0] = Form1.calculHypotenuse(Math.Abs(mEvent.X - x), Math.Abs(mEvent.Y - y));
                        chart1.Series["Series1"].Points.ElementAt(7).YValues = yvalues;
                        if (yvalues[0] <= MaxY)
                            quantityArea7.Value = decimal.Parse(this.getTrueElementValue(trueMaxValues[7], float.Parse(yvalues[0].ToString())).ToString());
                    }
                }
            }
            else 
            {
                //Console.WriteLine("Reinitialized = " + valInit[0][0]);
                initValues();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
        private void changeValueAxe(int indexAxe, double newValue)
        {
            double[] yvalues = new double[1];
            yvalues[0] = newValue;
            chart1.Series["Series1"].Points.ElementAt(indexAxe).YValues = yvalues;
        }
        
        private void quantityArea_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[0], double.Parse(quantityArea0.Value.ToString()));
                this.changeValueAxe(0, fakeValue);
                saveValues();
            }
        }
        private void quantityArea1_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[1], double.Parse(quantityArea1.Value.ToString()));
                this.changeValueAxe(1, fakeValue);
                saveValues();
            }
        }
        private void quantityArea2_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[2], double.Parse(quantityArea2.Value.ToString()));
                this.changeValueAxe(2, fakeValue);
                saveValues();
            }
        }
        private void quantityArea3_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[3], double.Parse(quantityArea3.Value.ToString()));
                this.changeValueAxe(3, fakeValue);
                saveValues();
            }
        }
        private void quantityArea4_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[4], double.Parse(quantityArea4.Value.ToString()));
                this.changeValueAxe(4, fakeValue);
                saveValues();
            }
        }
        private void quantityArea5_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[5], double.Parse(quantityArea5.Value.ToString()));
                this.changeValueAxe(5, fakeValue);
                saveValues();
            }
        }
        private void quantityArea6_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[6], double.Parse(quantityArea6.Value.ToString()));
                this.changeValueAxe(6, fakeValue);
                saveValues();
            }
        }
        private void quantityArea7_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[7], double.Parse(quantityArea7.Value.ToString()));
                this.changeValueAxe(7, fakeValue);
                saveValues();
            }
        }
        private void quantityArea8_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[8], double.Parse(quantityArea8.Value.ToString()));
                this.changeValueAxe(8, fakeValue);
                saveValues();
            }
        }
        private void quantityArea9_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[9], double.Parse(quantityArea9.Value.ToString()));
                this.changeValueAxe(9, fakeValue);
                saveValues();
            }
        }
        private void quantityArea10_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[10], double.Parse(quantityArea10.Value.ToString()));
                this.changeValueAxe(10, fakeValue);
                saveValues();
            }
        }
        private void quantityArea11_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[11], double.Parse(quantityArea11.Value.ToString()));
                this.changeValueAxe(11, fakeValue);
                saveValues();
            }
        }
        private void quantityArea12_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[12], double.Parse(quantityArea12.Value.ToString()));
                this.changeValueAxe(12, fakeValue);
                saveValues();
            }
        }
        private void quantityArea13_ValueChanged(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                double fakeValue = this.getFakeElementValue(trueMaxValues[13], double.Parse(quantityArea13.Value.ToString()));
                this.changeValueAxe(13, fakeValue);
                saveValues();
            }
        }

        private double getTrueElementValue(double trueMax, double actualValue) //for Quantity area
        {
            return (actualValue * trueMax) / MaxY;
        }
        private double getFakeElementValue(double trueMax, double actualValue) //for Char element YValue
        {
            return (actualValue * MaxY) / trueMax;
        }

        private void chart1_MouseUp(object sender, MouseEventArgs e)
        {
            moussePress = false;
        }

        private void chart1_MouseDown(object sender, MouseEventArgs e)
        {
            moussePress = true;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void buttonAnalyser_Click(object sender, EventArgs e)
        {
            /*listResultat = new string[2];
            listResultat[0] = "99% : VIH SIDA";
            listResultat[1] = "15% : Rhume des foins";
            listResultatBox.DataSource = listResultat;*/


            AnalysePatient[] listAnalyse = saveAnalysePatient();
            AnalysePatient[] listAnalyseAnormal = getAnalyseAnormal(listAnalyse);
            List<string> listRes = new List<string>();
            Diagnostic[] listDiagnosticAnormal = getAllDiagnosticAnormal(listAnalyseAnormal);

            Diagnostic[] listDiagAnormParMaladie = null;
            AnalysePatient[] listAnalPatientParMaladie = null;

            listResultat = new string[listDiagnosticAnormal.Length];
            for (int i = 0; i < listAnalyseAnormal.Length; i++)
            {
                listResultat[i] = listDiagnosticAnormal[i].nomMaladie;
            }
           // string[] listResultatDistinct = getMaladieProbaSimple(listDiagnosticAnormal);

            Maladie[] listMaladie = MaladieDAO.find(null, null);
            foreach (Maladie m in listMaladie)
            {
                
                listDiagAnormParMaladie = getDiagnosticByMaladie(listDiagnosticAnormal, m.id);
                listAnalPatientParMaladie = getAnalyseCorrespondToDiagnostic(listAnalyseAnormal, listDiagAnormParMaladie);
                listRes = concatListString(listRes, getMaladieParProba(listDiagAnormParMaladie, listAnalPatientParMaladie).ToList());
               
                //MessageBox.Show(getMaladieParProba(listDiagAnormParMaladie, listAnalPatientParMaladie)[0]);
            }
            List<string> b = new List<string>();
            b.AddRange(listRes.Distinct());
            b.Sort();
            b.Reverse();

            listResultatBox.DataSource = b.Take(3).ToArray();              
        }
        private List<string> concatListString(List<string> lA, List<string> lB)
        {
            List<string> ret = lA;
            foreach (string sB in lB)
            {
                ret.Add(sB);
            }

            return ret;
        }
        private Diagnostic[] getDiagnosticByMaladie(Diagnostic[] listDiagnostic, int idMaladie)
        {
            List<Diagnostic> listDiag = new List<Diagnostic>();
            foreach (Diagnostic d in listDiagnostic)
            {
                if (d.idMaladie == idMaladie)
                    listDiag.Add(d);
            }
            return listDiag.ToArray();
        }
        private AnalysePatient[] getAnalyseCorrespondToDiagnostic(AnalysePatient[] listAnalyse, Diagnostic[] listDiagnostic)
        {
            List<AnalysePatient> listAp = new List<AnalysePatient>();
            foreach (AnalysePatient ap in listAnalyse)
            {
                foreach(Diagnostic diag in listDiagnostic)
                {
                    if (ap.elementReference.id == diag.idElement)
                    listAp.Add(ap);
                }
                
            }
            return listAp.ToArray();
        }
        private Diagnostic getDiagnosticAnormal(AnalysePatient analyseAnormal)
        {
            Diagnostic ret = null;
            foreach (Diagnostic d in this.listDiagnostic)
            {
                if (analyseAnormal.elementReference.id == d.idElement && ((analyseAnormal.valeur < d.normInf && d.siSupInf == 0) || analyseAnormal.valeur > d.normSup && d.siSupInf == 1)) 
                {
                    ret = d;
                    //MessageBox.Show("getDiagnosticAnormal : " + d.nomMaladie + " avec val = " + analyseAnormal.valeur + ", normInf=" + d.normInf + " et normSup="+d.normSup);
                    break;
                }
            }
            return ret;
        }
        private Diagnostic[] getAllDiagnosticAnormal(AnalysePatient[] analyseAnormal)   //avec doublons encore
        { 
            Diagnostic[] ret = new Diagnostic[analyseAnormal.Length];
            for (int i = 0; i < analyseAnormal.Length; i++)
            {
                ret[i] = getDiagnosticAnormal(analyseAnormal[i]);
                
            }
            
            return ret;
        }
        private string[] getMaladieParProba(Diagnostic[] listDiagnosticAnormal, AnalysePatient[] listApAnormal)
        {
            List<string> ret = new List<string>();
            List<Diagnostic> diagTemp = new List<Diagnostic>();
            List<AnalysePatient> apTemp = new List<AnalysePatient>();
            int j= 0;
            for (int i = 0; i < listDiagnosticAnormal.Length; i++ )
            {
                diagTemp.Clear();
                apTemp.Clear();
                diagTemp.Add(listDiagnosticAnormal[i]);
                apTemp.Add(listApAnormal[i]);
                j=0;
                foreach (Diagnostic dAnormOther in listDiagnosticAnormal)
                {
                    if (listDiagnosticAnormal[i].idElement != dAnormOther.idElement)
                    {
                        diagTemp.Add(dAnormOther);
                        apTemp.Add(listApAnormal[j]);
                    }
                    j++;
                }
                int probaTemp = probaMaladie(diagTemp.ToArray(), apTemp.ToArray());
                string maladieTemp = probaTemp + "% : " + listDiagnosticAnormal[i].nomMaladie;
                //MessageBox.Show(maladieTemp);
                ret.Add(maladieTemp);
            }

            ret.Sort();
            return ret.ToArray();
        }
        private string[] getMaladieProbaSimple(Diagnostic[] listDiagnosticAnormal)    //temp
        {
            string[] ret = null;
            string[] maladieTemp = new string[listDiagnosticAnormal.Length];
            string tempM = "";
            int tempP = 0;
            
            int[] probaTemp = new int[listDiagnosticAnormal.Length];
            List<string> retTemp = new List<string>();
            
            for (int i = 0; i < listDiagnosticAnormal.Length; i++)
            {
                probaTemp[i] = 25;
                maladieTemp[i] = listDiagnosticAnormal[i].nomMaladie;
                retTemp.Add(maladieTemp[i]);
                retTemp = retTemp.Distinct().ToList();
            }
           /*for (int i = 0; i < maladieTemp.Length; i++)
            { 
                tempM = maladieTemp[i];
                tempP = probaTemp[i];
                for (int j = 0; j < maladieTemp.Length; j++)
                {
                    if (tempM.Equals(maladieTemp[j]) && j!=i)
                    {
                        
                        tempP = tempP + probaTemp[j];
                        
                        MessageBox.Show("la maladie " + tempM + " est en double avec p="+tempP);
                    }
                    
                }
                
            }*/
            return retTemp.ToArray();
        }

        private int probaMaladieParDiagnostic(Diagnostic d, AnalysePatient ap)
        {
            int ret = 0;
            double valPatient = ap.valeur;
            double valNorm = 0;
            double diff = 0;
            string log = "";
            if (ap.valeur > double.Parse(d.normSup.ToString()))
            { 
                valNorm = double.Parse(d.normSup.ToString());
                diff = valPatient - valNorm;
                log = "sup";
            }
            else if (ap.valeur < double.Parse(d.normInf.ToString()))
            {
                valNorm = double.Parse(d.normInf.ToString());
                diff = valNorm - valPatient;
                log = "inf " + ap.valeur + " < " + d.normInf;
            }
            ret = (int)(diff / double.Parse(d.pasProbabilite.ToString()));
            //MessageBox.Show(ret + " % de chance en "+log);
            if (ret > 100)
                ret = 99;
            return ret;
        }

        private int probaMaladie(Diagnostic[] listDiag, AnalysePatient[] ap)//seules diag positives de meme maladie ; max proba des diag de même maladie; 
        {
            int temp = probaMaladieParDiagnostic(listDiag[0], ap[0]);
            for (int i = 1; i < listDiag.Length; i++ )
            {
                
                if (temp < probaMaladieParDiagnostic(listDiag[i], ap[i]))
                {
                    temp = probaMaladieParDiagnostic(listDiag[i], ap[i]);
                }
                //MessageBox.Show(" ProbaMaladie : " + listDiag[i].nomMaladie + " - " + temp);
            }

            return temp;
        }



        private AnalysePatient[] getAnalyseAnormal(AnalysePatient[] analyseComplet)
        {
            AnalysePatient[] ret = null;
            List<AnalysePatient> retTemp = new List<AnalysePatient>();
            foreach (AnalysePatient ap in analyseComplet)
            {
                if (ap.valeur > ap.elementReference.normSup || ap.valeur < ap.elementReference.normInf)
                {
                    retTemp.Add(ap);
                }
            }
            int row = retTemp.Count;
            ret = new AnalysePatient[row];
            for (int i = 0; i < row; i++)
            {
                ret[i] = new AnalysePatient(retTemp.ElementAt(i).valeur, retTemp.ElementAt(i).elementReference);
            }
                return ret;
        }

        private AnalysePatient[] saveAnalysePatient()
        { 
            AnalysePatient[] ret = new AnalysePatient[14];
            Element[] elementRef = ElementDAO.find(null, null);
            for (int i = 0; i < 5; i++)
            {
                ret[i] = new AnalysePatient(this.getTrueElementValue(trueMaxValues[i], float.Parse(chart1.Series["Series1"].Points.ElementAt(i).YValues[0].ToString())), elementRef[i]);
            }
            if(radioFemme.Checked)
                ret[5] = new AnalysePatient(this.getTrueElementValue(trueMaxValues[5], float.Parse(chart1.Series["Series1"].Points.ElementAt(5).YValues[0].ToString())), elementRef[5]);
            else
                ret[5] = new AnalysePatient(this.getTrueElementValue(trueMaxValues[5], float.Parse(chart1.Series["Series1"].Points.ElementAt(5).YValues[0].ToString())), elementRef[6]);
            for (int i = 6; i < 14; i++)
            {
                ret[i] = new AnalysePatient(this.getTrueElementValue(trueMaxValues[i], float.Parse(chart1.Series["Series1"].Points.ElementAt(i).YValues[0].ToString())), elementRef[i+1]);
            }

            /*float f = 1.2F;
            MessageBox.Show(elementRef[9].nom + " : "+ elementRef[9].normInf + " - " + elementRef[9].normSup+ " et " +f);
            */    
            return ret;
        }
       

         
    }
}
