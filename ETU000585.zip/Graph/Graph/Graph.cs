﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Graph
{
    class Graph : Panel
    {
        List<Maladie> listeAxe;
        private Point origine;
        Angle[] pointRehetra;
        Point[] ListePoint;
        int axe;
        Angle clicker;
        bool modification = false;
        public Graph(){
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Location = new System.Drawing.Point(83, 4);
            this.Name = "panel2";
            this.Size = new System.Drawing.Size(600, 600);
            this.TabIndex = 7;
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint_1);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(clickMouse);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(maintenir);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(mivotsitraSouris);

            int p2Width = this.Width;
            int p2Height = this.Height;
            int longueur = p2Height / 2;
            int largeur = p2Width / 2;
            origine = new Point(longueur, largeur);
            MaladieDAO dao = new MaladieDAO();
            listeAxe = dao.findMaladie();
            axe = listeAxe.Count;
            pointRehetra = new Angle[axe];
            initialize();
        }

        public void maintenir(object sender, MouseEventArgs e)
        {
            if (modification)
            {
                double distanceAuCentre = distance(e.X, e.Y);
                double x = makaX(clicker.getAngle(), distanceAuCentre);
                double y = makaY(clicker.getAngle(), distanceAuCentre);
                if (distanceAuCentre <= 250)
                {
                    for (int compt = 0; compt < pointRehetra.Length; compt++)
                    {
                        if (pointRehetra[compt].getPoint().X == clicker.getPoint().X && pointRehetra[compt].getPoint().Y == clicker.getPoint().Y)
                        {
                            pointRehetra[compt].setPoint(new Point((int)x, (int)y));
                            pointRehetra[compt].setDistance(distanceAuCentre);
                            ListePoint[compt] = pointRehetra[compt].getPoint();
                            break;
                        }
                    }
                    this.Refresh();

                    verifClick((int)x, (int)y);
                }
            }
        }
        public void mivotsitraSouris(object sender, MouseEventArgs e)
        {
            modification = false;
        }

        public double distance(int x,int y)
        {
            double d = Math.Sqrt(((origine.X - x) * (origine.X - x)) + ((origine.Y - y) * (origine.Y - y)));
            return d;
        } 

        public void clickMouse(object sender, MouseEventArgs e) {    
            verifClick(e.X,e.Y);
            modification = true;
        }
        public void verifClick(int x,int y)
        {
            for (int i=0; i < pointRehetra.Length; i++)
            {
                if(pointRehetra[i].getPoint().X-15 < x  && x < pointRehetra[i].getPoint().X + 15 && pointRehetra[i].getPoint().Y - 15 < y && y < pointRehetra[i].getPoint().Y + 15)
                {
                    clicker = pointRehetra[i];
                    break;
                }
            }
        }

        public double makaX(double angle, double rayon)
        {
            double rad = angle * Math.PI / 180;
            double valiny = Math.Sin(rad) * rayon;
            valiny = origine.X + valiny;
            return valiny;

        }

        public double makaY(double angle, double rayon)
        {
            double rad = angle * Math.PI / 180;
            double valiny = Math.Cos(rad) * rayon;
            valiny = origine.Y - valiny;
            return valiny;

        }
        public void initialize()
        {
            int rayon = 250;
            double alpha = 360 / axe;
            ListePoint = new Point[axe];
            
            for (int i = 0; i < axe; i++)
            {
                pointRehetra[i] = new Angle();
                pointRehetra[i].setPoint(new Point((int)makaX(alpha * i, rayon), (int)makaY(alpha * i, rayon)));
                pointRehetra[i].setAngle(alpha * i);
                pointRehetra[i].setL(listeAxe[i]);
                pointRehetra[i].setDistance(distance((int)makaX(alpha * i, rayon), (int)makaY(alpha * i, rayon)));
                ListePoint[i] = pointRehetra[i].getPoint();

            }
            double distanceAxe = alpha * rayon;
            int a = (int)distanceAxe;

        }
        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {
            Pen bluePen = new Pen(Color.GreenYellow, 8);
            Pen greenPen = new Pen(Color.Green, 8);
            Pen pinkPen = new Pen(Color.Salmon, 8);
            

            e.Graphics.DrawPolygon(pinkPen, ListePoint);
            for (int x = 0; x < axe; x++)
            {
                e.Graphics.DrawLine(bluePen, pointRehetra[x].getPoint(), origine);
                Rectangle rond = new Rectangle(pointRehetra[x].getPoint().X, pointRehetra[x].getPoint().Y, 10, 10);
                e.Graphics.DrawEllipse(greenPen, rond);
                e.Graphics.DrawString(pointRehetra[x].getNom(), this.Font, Brushes.Black, pointRehetra[x].getPoint().X, pointRehetra[x].getPoint().Y);

            }
        }
    }
}

