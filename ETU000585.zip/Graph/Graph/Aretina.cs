﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Aretina
    {
        int id;
        string nom;
        int axe;
        double inf;
        double sup;

        public Aretina() { }

        public Aretina(int id, string nom, int axe, double inf, double sup)
        {
            setId(id);
            setNom(nom);
            setAxe(axe);
            setInf(inf);
            setSup(sup);

        }
        public Aretina(string nom, int axe, double inf, double sup)
        {
            setNom(nom);
            setAxe(axe);
            setInf(inf);
            setSup(sup);
        }

        public void setId(int id)
        {
            this.id = id;
        }
        public void setId(string id)
        {
            setId(int.Parse(id));
        }
        public int getId()
        {
            return id;
        }
        public void setNom(string nom)
        {
            this.nom = nom;
        }
        public string getNom()
        {
            return nom;
        }
        public void setAxe(int axe)
        {
            this.axe = axe;
        }
        public int getAxe()
        {
            return axe;
        }
        public void setInf(double inf)
        {
            this.inf = inf;
        }
        public double getInf()
        {
            return inf;
        }
        public void setSup(double sup)
        {
            this.sup = sup;
        }
        public double getSup()
        {
            return sup;
        }
    }
}
