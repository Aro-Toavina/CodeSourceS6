﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class MaladieDAO
    {

            public List<Maladie> findMaladie()
            {

                SqlConnection conn = null;
                SqlCommand command = null;
                Connect c = null;
                SqlDataReader read = null;


                try
                {
                    c = new Connect();
                    conn = c.connecter();


                    command = new SqlCommand("SELECT * FROM axe", conn);
                    read = command.ExecuteReader();

                    List<Maladie> soc = new List<Maladie>();

                    while (read.Read())
                    {
                        int id = Convert.ToInt32((read["id"].ToString()));
                        String nom = (read["nom"].ToString());
                        float normal = float.Parse(read["normal"].ToString());
                        float min = float.Parse((read["min"].ToString()));
                        float max = float.Parse(read["max"].ToString());
                        String unite = (read["unité"].ToString());


                    soc.Add(new Maladie(id, nom, normal, min, max, unite));
                    }
                    return soc;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (read != null) read.Close();
                    if (command != null) command.Dispose();
                    if (conn != null) conn.Close();
                }
            }

            public void insertMaladie(Maladie pe)
            {
                Connect c = null;
                SqlConnection conn = null;
                SqlCommand command = null;
                SqlDataReader read = null;

                try
                {
                    c = new Connect();
                    conn = c.connecter();

                    command = new SqlCommand("INSERT INTO axe VALUES('" + pe.getNom() + "'," + pe.getNormal() + ","+ pe.getMin() + "," + pe.getMax() + ",'" + pe.getUnite() + "')", conn);
                    read = command.ExecuteReader();
                }
                catch (Exception ex)
                {
                    throw new NotImplementedException("Echec de l'insertion : " + ex.Message);
                    //Console.Error.WriteLine(ex.Message);
                }
                finally
                {
                    if (read != null) read.Close();
                    if (command != null) command.Dispose();
                    if (conn != null) conn.Close();
                }
            }
    }
}

