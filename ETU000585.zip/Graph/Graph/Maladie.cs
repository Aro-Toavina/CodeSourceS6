﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Maladie
    {
        int id;
        string nom;
        float normal;
        float min;
        float max;
        string unite;

        public Maladie() { }

        public Maladie(int id, string nom, float normal, float min, float max, string unite)
        {
            setId(id);
            setNom(nom);
            setNormal(normal);
            setMin(min);
            setMax(max);
            setUnite(unite);

        }
        public Maladie(string nom, float normal, float min, float max, string unite)
        {
            setNom(nom);
            setNormal(normal);
            setMin(min);
            setMax(max);
            setUnite(unite);
        }

        public void setId(int id)
        {
            this.id = id;
        }
        public void setId(string id)
        {
            setId(int.Parse(id));
        }
        public int getId()
        {
            return id;
        }
        public void setNom(string nom)
        {
            this.nom = nom;
        }
        public string getNom()
        {
            return nom;
        }
        public void setNormal(float normal)
        {
            this.normal = normal;
        }
        public float getNormal()
        {
            return normal;
        }
        public void setMin(float min)
        {
            this.min = min;
        }
        public float getMin()
        {
            return min;
        }
        public void setMax(float max)
        {
            this.max = max;
        }
        public float getMax()
        {
            return max;
        }
        public void setUnite(string unite)
        {
            this.unite = unite;
        }
        public string getUnite()
        {
            return unite;
        }
    }
}
