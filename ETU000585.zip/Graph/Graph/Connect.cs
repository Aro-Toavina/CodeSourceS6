﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Graph
{
    public class Connect
    {
        private SqlConnection _connex;

        public Connect() { }
        public SqlConnection connex
        {

            get { return _connex; }
            set { _connex = value; }
        }//connection  


        public static void afficher(String msg) { Console.Out.WriteLine(msg); }

        internal SqlConnection getConnect()
        {
            throw new NotImplementedException();
        }

        public static void affichererreur(String msg) { Console.Error.WriteLine(msg); }


        public SqlConnection connecter()
        {

            string connetionString = null;
            connetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=graph;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            try
            {
                _connex = new SqlConnection(connetionString);
                _connex.Open();
                // MessageBox.Show("Can  open connection to the server ! ");
                afficher("connexion etablie!");
                return _connex;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Can not open connection to the server ! ");
                affichererreur("Can't connect " + ex.Message);
            }


            return _connex;

        }
    }
}