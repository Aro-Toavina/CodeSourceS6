﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Angle
    {
        double angle;
        double distance;
        Point point;
        Maladie l;
        public Angle(double angle,double distance,Point point,Maladie l)
        {
            setAngle(angle);
            setDistance(distance);
            setPoint(point);
            setL(l);
        }
        public Angle() { }
        public void setAngle(double angle)
        {
            this.angle = angle;
        }
        public double getAngle()
        {
            return angle;
        }

        public void setDistance(double distance)
        {
            this.distance = distance;
        }
        public double getDistance()
        {
            return distance;
        }

        public void setPoint(Point point)
        {
            this.point = point;
        }
        public Point getPoint()
        {
            return point;
        }
        public string getNom()
        {
            return l.getNom();
        }
        public void setL(Maladie l)
        {
            this.l = l ;
        }
        public Maladie getL()
        {
            return l;
        }
    }
}
