SET IDENTITY_INSERT [dbo].[Categorie] ON
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (1, N'Nouveau né')
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (2, N'1 à 2ans')
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (3, N'3 à 6 ans')
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (4, N'7 à 10 ans')
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (5, N'Homme')
INSERT INTO [dbo].[Categorie] ([Id], [Nom]) VALUES (6, N'Femme')
SET IDENTITY_INSERT [dbo].[Categorie] OFF
