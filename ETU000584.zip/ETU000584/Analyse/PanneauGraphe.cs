﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    public class PanneauGraphe : Panel
    {
        private int nombreAxe;
        Point[] pointTrace;
        Point[] limite;
        private Point centre;
        private String[] nomAxe;
        private double rayon = 250;
        private Accueil fenetre;

        Point modif;
        bool modified = false;
        public PanneauGraphe() { }
        public PanneauGraphe(Accueil fen)
        {
            fenetre = fen;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Location = new System.Drawing.Point(24, 185);
            this.Name = "panneauGraphe";
            this.Size = new System.Drawing.Size(800, 600);
            this.TabIndex = 0;
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_down);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_mousemove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_up);
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.wheel);
            

            nombreAxe = fenetre.getNombreAxe();
            pointTrace = new Point[nombreAxe];
            fenetre.points = new PointAxe[nombreAxe];
            limite = new Point[nombreAxe];
            //points = new PointAxe[nombreAxe];
            centre = new Point(400, 300);
            /*nomAxe = new String[nombreAxe];
            nomAxe[0] = "Globule rouge";
            nomAxe[1] = "Globule rouge";
            nomAxe[2] = "Globule rouge";
            nomAxe[3] = "Globule rouge";
            nomAxe[4] = "Globule rouge";
            nomAxe[5] = "Globule rouge";
            nomAxe[6] = "Globule rouge";
            nomAxe[7] = "Globule rouge";
            nomAxe[8] = "Globule rouge";
            nomAxe[9] = "Globule rouge";
            nomAxe[10] = "Globule rouge";
            nomAxe[11] = "Globule rouge";
            nomAxe[12] = "Globule rouge";
            nomAxe[13] = "Globule rouge";*/
            initialisePoint();

        }
        private void initialisePoint()
        {
            int xLabel = 15;
            int yLabel = 30;
            int xTextbox = 180;
            int yTextbox = 30;
            int xLabel2 = 280;
            int yLabel2 = 30;
            double degre = 360 / nombreAxe;
            double deg = degre;
            for (int i = 0; i < nombreAxe; i++) {
                deg = degre * (double)i;
                int x = (int)valueX(deg, rayon);
                int y = (int)valueY(deg, rayon);

                PointAxe p = new PointAxe(fenetre.axes[i],xLabel,yLabel,xTextbox,yTextbox,xLabel2,yLabel2);
                //MessageBox.Show(fenetre.axes[i].getNom());
                p.setPoint(new Point(x,y));
                p.setAngle(deg);
                p.setDistance(distanceFromCenter(x, y));
                fenetre.changePoint(i, p);
                pointTrace[i] = p.getPoint();
                limite[i] = p.getPoint();
                yLabel = yLabel + 30;
                yTextbox = yTextbox + 30;
                yLabel2 = yLabel2 + 30;
            }
        }
        public double valueX(double degre, double rayon)
        {
            double rep = 0;
            double radiant = degre * Math.PI / 180;
            rep = Math.Sin(radiant) * rayon;
            rep = centre.X + rep; 
            return rep;
        }
        public double valueY(double degre, double rayon)
        {
            double rep = 0;
            double radiant = degre * Math.PI / 180;
            rep = Math.Cos(radiant) * rayon;
            rep = centre.Y - rep;
            return rep;
        }
        public void drawPoints(PaintEventArgs e)
        {

            Pen redPen = new Pen(Color.Red, 10);
            Pen blackPen = new Pen(Color.DarkCyan, 10);
            Pen pinkPen = new Pen(Color.Pink, 10);

            //e.Graphics.DrawLine(blackPen, new Point(0,250), centre);
            //e.Graphics.DrawLine(blackPen, new Point(250,0), centre);

            for (int i = 0; i < nombreAxe; i++)
            {

                //MessageBox.Show("Degrée:   " + deg + "\n" + "Radiant:  " + radiant + "\n" + "Point:  x -> " + fenetre.get(i).getX() + " y -> " + fenetre.get(i).getY());
                //e.Graphics.DrawLine(blackPen, fenetre.get(i).getPoint(), centre);
                Rectangle temp = new Rectangle(fenetre.get(i).getX() - 5, fenetre.get(i).getY() - 5, 10, 10);
                if (modif != null && modif.X == fenetre.get(i).getX() && modif.Y == fenetre.get(i).getY())
                {
                    e.Graphics.DrawEllipse(redPen, temp);
                    //MessageBox.Show("Misy le modif  " + "\n" + "X : " + modif.X + "\n" + "Y : " + modif.Y);
                }
                else
                {
                    e.Graphics.DrawEllipse(blackPen, temp);
                }
                
                e.Graphics.DrawString(fenetre.get(i).getNom(), this.Font, Brushes.Black, fenetre.get(i).getX(), fenetre.get(i).getY());
                //rayon = rayon - 1;
            }
            blackPen.Dispose();
            redPen.Dispose();
            pinkPen.Dispose();
        }
        public void identifiePoint(int x, int y)
        {
            int i;
            for (i = 0; i < nombreAxe; i++)
            {
                if ((x - 10 < fenetre.get(i).getX() && fenetre.get(i).getX() < x + 10) && (y - 10 < fenetre.get(i).getY() && fenetre.get(i).getY() < y + 10))
                {
                    //System.Diagnostics.Debug.Write("Nandalo down zany ehhh");
                    fenetre.setFocusOn(i);
                    break;
                }
            }
            if (i== nombreAxe) {
                modif.X = 0;
                modif.Y = 0;
                this.Refresh();
            }
        }
        public void setFocusOn(int i)
        {
            modif = fenetre.get(i).getPoint();
            this.Refresh();
        }
        public void updatePoint(int x, int y)
        {
            for (int i = 0; i < nombreAxe; i++)
            {
                if (fenetre.get(i).getX() == modif.X && fenetre.get(i).getY() == modif.Y)
                {
                    //System.Diagnostics.Debug.Write("Nandalo up zany ehhh");
                    int distance = distanceFromCenter(x, y);
                    if (distance <= rayon)
                    {
                        Point p = new Point((int)valueX(fenetre.get(i).getAngle(), distance), (int)valueY(fenetre.get(i).getAngle(), distance));
                        fenetre.changePoint(i, p, distance);
                        pointTrace[i] = fenetre.get(i).getPoint();
                        this.Refresh();
                        identifiePoint(p.X, p.Y);
                        break;
                    }
                } 
            }
        }
        public void updatePoint(int distance)
        {
            for (int i = 0; i < nombreAxe; i++)
            {
                if (fenetre.get(i).getX() == modif.X && fenetre.get(i).getY() == modif.Y)
                {
                    //System.Diagnostics.Debug.Write("Nandalo up zany ehhh");
                    if (distance <= rayon)
                    {
                        Point p = new Point((int)valueX(fenetre.get(i).getAngle(), distance), (int)valueY(fenetre.get(i).getAngle(), distance));
                        fenetre.changePoint(i, p, distance);
                        pointTrace[i] = fenetre.get(i).getPoint();
                        fenetre.Refresh();
                        identifiePoint(p.X, p.Y);
                        break;
                    }
                }
            }
        }
        public int distanceFromCenter(int x, int y)
        {
            double rep = 0;
            rep = rep + (centre.X - x) * (centre.X - x);
            rep = rep + (centre.Y - y) * (centre.Y - y);
            rep = Math.Sqrt(rep);
            return (int)rep;
        }


        private void panel1_Click(object sender, MouseEventArgs e)
        {
            //MessageBox.Show(e.X.ToString()+","+ e.Y.ToString());
            //MessageBox.Show(e.Y.ToString());
        }

        private void wheel(object sender, MouseEventArgs e)
        {
            fenetre.wheel(sender, e);
        }

        private void panel1_paint(object sender, PaintEventArgs e)
        {
            Pen whitePen = new Pen(Color.WhiteSmoke, 8);
            Pen pinkPen = new Pen(Color.Pink, 4);

            Rectangle ctr = new Rectangle(centre.X, centre.Y, 8, 8);
            e.Graphics.DrawEllipse(whitePen, ctr);
            e.Graphics.DrawPolygon(pinkPen, limite);
            e.Graphics.FillPolygon(Brushes.LightYellow, pointTrace);
            this.drawPoints(e);
            whitePen.Dispose();
            pinkPen.Dispose();
        }

        private void panel1_down(object sender, MouseEventArgs e)
        {
            modified = true;
            identifiePoint(e.X, e.Y);
        }

        private void panel1_up(object sender, MouseEventArgs e)
        {
            modified = false;
            //updatePoint(e.X, e.Y);
            //MessageBox.Show("Distance : " + distanceFromCenter(e.X, e.Y));
        }

        private void panel1_mousemove(object sender, MouseEventArgs e)
        {
            if (modified)
            {
                updatePoint(e.X, e.Y);
            }

        }
            /*private double traduitXouY(double degre)
            {
                double rep = 0;
                double radiant = degre * ((double)Math.PI) / 180;
                rep = (double)(Math.Sin(radiant) * rayon);
                return rep;
            }*/
        }
}
