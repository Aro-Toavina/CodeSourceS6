﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class UniteDAO
    {
        public Unite[] findUnite(SqlConnection connection, string where)
        {
            Unite[] unites = null;
            List<Unite> listeUnites = new List<Unite>();
            SqlCommand cmd = null;
            string sql = "Select * from Unite " + where;
            SqlDataReader reader = null;
            try
            {
                cmd = new SqlCommand(sql, connection);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Unite temp = new Unite(reader["Id"].ToString(), reader["Nom"].ToString(), reader["ValeurPixel"].ToString());
                    listeUnites.Add(temp);
                }

                int nb = listeUnites.Count;
                unites = new Unite[nb];
                listeUnites.CopyTo(unites);
                return unites;
            }
            catch (Exception e) { throw e; }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
            }
        }
        public Unite[] findAllUnite()
        {
            Unite[] unites = null;
            SqlConnection connection = null;
            try
            {
                Connexion conn = new Connexion();
                connection = conn.connect();
                unites = findUnite(connection, "");
                return unites;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }
        public Unite findOneUnite(SqlConnection connection,int idUnite)
        {
            Unite unite = null;
            try
            {
                Unite[] unites = findUnite(connection, "where id = "+idUnite);
                if (unites.Length > 0)
                {
                    unite = unites[0];
                }
                return unite;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public Unite findOneUnite(int idUnite)
        {
            Unite unite = null;
            SqlConnection connection = null;
            try
            {
                Connexion conn = new Connexion();
                connection = conn.connect();
                unite = findOneUnite(connection, idUnite);
                return unite;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }
    }
}
