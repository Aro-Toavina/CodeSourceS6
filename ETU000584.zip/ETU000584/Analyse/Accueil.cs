﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    public partial class Accueil : Form
    {
        public PointAxe[] points;
        public int nombreAxe;
        public Axe[] axes = null;
        
        public void setNombreAxe(int n)
        {
            nombreAxe = n;
        }
        public int getNombreAxe() { return nombreAxe; }
        public void changePoint(int index,PointAxe point)
        {
            points[index] = point;
        }
        public void changePoint(int index, Point point, int distance)
        {
            points[index].setDistance(distance);
            points[index].setPoint(point);
            panneauValeur.update(index,points[index].getDistance().ToString());
        }
        public PointAxe get(int index)
        {
            return points[index];
        }
        public void updateByTextBox(int index, int value)
        {
            panneauGraphe.identifiePoint(points[index].getX(), points[index].getY());
            panneauGraphe.updatePoint(value);
        }
        public void setFocusOn(int index)
        {
            panneauValeur.setFocusOn(index);
            panneauGraphe.setFocusOn(index);
        }

        public Accueil()
        {
            AxeDAO axeDao = new AxeDAO();
            axes = axeDao.findAllAxe();
            setNombreAxe(axes.Length);
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panneauGraphe = new PanneauGraphe(this);
            panneauValeur = new PanneauValeur(this);
            this.Controls.Add(this.panneauGraphe);
            this.Controls.Add(this.panneauValeur);
        }
        public void wheel(object sender, MouseEventArgs e)
        {
            panneauValeur.wheel(sender, e);
        }
    }
}
