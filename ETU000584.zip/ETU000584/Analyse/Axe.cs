﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    public class Axe
    {
        private int id;
        private String nom;
        private int idUnite;
        private Unite unite;

        public Axe(String id, String nom, String idUnite)
        {
            setId(id);
            setNom(nom);
            setIdUnite(idUnite);
        }

        public void setId(int i)
        {
            if (i <= 0)
            {
                throw new Exception("IdAxe invalide");
            }
            id = i;
        }
        public void setId(String i)
        {
            try
            {
                setId(Int32.Parse(i));
            }
            catch(Exception e) { throw e; }
        }
        public void setNom(String n)
        {
            nom = n;
        }
        public void setIdUnite(int u)
        {
            if (u <= 0)
            {
                throw new Exception("idUnite dans Axe invalide");
            }
            idUnite = u;
        }
        public void setIdUnite(String i)
        {
            try
            {
                setIdUnite(Int32.Parse(i));
            }
            catch (Exception e) { throw e; }
        }
        public void setUnite(Unite un)
        {
            unite = un;
        }
        public Unite getUnite() { return unite; }
        public String getNomUnite() { return unite.getNom(); }
        public int getId() { return id; }
        public String getNom() { return nom; }
        public int getIdUnite() { return idUnite; }
    }
}
