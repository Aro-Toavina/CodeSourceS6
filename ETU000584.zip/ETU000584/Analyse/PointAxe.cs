﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    public class PointAxe
    {
        private Point point;
        private int distance;
        private double angle;
        private Label label;
        private Label label2;
        private TextBox textbox;
        private Axe axe;

        public void setAxe(Axe a)
        {
            axe = a;
        }
        public Axe getAxe() { return axe; }
        public Label getLabel() {
            //initLabel(label.Location.X,label.Location.Y);
            return label;
        }
        public Label getLabel2()
        {
            //initLabel(label.Location.X,label.Location.Y);
            return label2;
        }
        public TextBox getTextBox() {
            initTextbox(textbox.Location.X, textbox.Location.Y);
            return textbox;
        }
        public String getNom() { return axe.getNom(); }
        public void setAngle(double an)
        {
            angle = an;
        }
        public double getAngle() { return angle; }
        public void setX(int x)
        {
            point.X = x;
        }
        public void setY(int y)
        {
            point.Y = y;
        }
        public int getX() { return point.X; }
        public int getY() { return point.Y; }
        public void setPoint(Point p)
        {
            point = p;
        }
        public Point getPoint()
        {
            return point;
        }

        public PointAxe(Axe p, int xLabel, int yLabel, int xTextbox, int yTextbox, int xLabel2, int yLabel2)
        {
            setAxe(p);
            initLabel(xLabel,yLabel);
            initTextbox(xTextbox, yTextbox);
            initLabel2(xLabel2, yLabel2);
        }
        public void setDistance(int d)
        {
            distance = d;
        }
        public int getDistance()
        {
            return distance;
        }
        public int getDistance(Point centre)
        {
            int rep = 0;
            if (getDistance() != 0)
            {
                rep = getDistance();
            }
            else
            {
                rep = distanceFromCenter(centre);
                setDistance(rep);
            }
            return rep;
        }
        
        private void initLabel(int x, int y)
        {
            label = new Label();
            label.AutoSize = true;
            label.Location = new System.Drawing.Point(x, y);
            label.MinimumSize = new System.Drawing.Size(50, 15);
            label.Name = "label2";
            label.Size = new System.Drawing.Size(50, 15);
            label.TabIndex = 2;
            label.Text = axe.getNom() + " :";
        }
        private void initLabel2(int x, int y)
        {
            label2 = new Label();
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(x, y);
            label2.MinimumSize = new System.Drawing.Size(50, 15);
            label2.Name = "label3";
            label2.Size = new System.Drawing.Size(50, 15);
            label2.TabIndex = 2;
            label2.Text = axe.getNomUnite();
        }
        private void initTextbox(int x, int y)
        {
            textbox = new TextBox();
            textbox.Location = new System.Drawing.Point(x, y);
            textbox.Name = "textBox1";
            textbox.Size = new System.Drawing.Size(100, 20);
            textbox.TabIndex = 3;
            textbox.Text = distance.ToString();
        }

        public int distanceFromCenter(Point centre)
        {
            double rep = 0;
            rep = rep + (centre.X - getX()) * (centre.X - getX());
            rep = rep + (centre.Y - getY()) * (centre.Y - getY());
            rep = Math.Sqrt(rep);
            return (int)rep;
        }
    }
}
