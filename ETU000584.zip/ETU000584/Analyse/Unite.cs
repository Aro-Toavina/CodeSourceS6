﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    public class Unite
    {
        private int id;
        private String nom;
        private double valeur;

        public void setValeur(double v)
        {
            valeur = v;
        }
        public void setValeur(string v)
        {
            try
            {
                setValeur(Double.Parse(v));
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public double getValeur() { return valeur; }
        public void setId(int i)
        {
            id = i;
        }
        public void setId(String i)
        {
            try
            {
                setId(Int32.Parse(i));
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void setNom(String n)
        {
            nom = n;
        }
        public int getId() { return id; }
        public String getNom() { return nom; }
        public Unite(int id, String nom)
        {
            setId(id);
            setNom(nom);
        }
        public Unite(String id, String nom)
        {
            setId(id);
            setNom(nom);
        }
        public Unite(String id, String nom, String valeur)
        {
            setId(id);
            setNom(nom);
            setValeur(valeur);
        }
        public Unite(String nom)
        {
            setNom(nom);
        }
        public Unite() { }
    }
}
