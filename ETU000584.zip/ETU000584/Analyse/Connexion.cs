﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    public class Connexion
    {
        private SqlConnection con;


        public SqlConnection conex
        {
            get { return con; }
            set { con = value; }
        }
        public static void afficher(String msg) { Console.Out.WriteLine(msg); }
        public static void affichererreur(String msg) { Console.Error.WriteLine(msg); }

        public SqlConnection connect()
        {
            string connetionString = null;
            connetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Analyse;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            try
            {
                con = new SqlConnection(connetionString);
                con.Open();
                afficher("connexion etablie!");
                return con;
            }
            catch (Exception ex)
            {
                affichererreur("Can't connect " + ex.Message);
            }
            return con;
        }
    }
}
