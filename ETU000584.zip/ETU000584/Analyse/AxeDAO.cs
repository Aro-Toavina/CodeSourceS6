﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse
{
    class AxeDAO
    {
        public Axe[] findAxe(SqlConnection connection, string where)
        {
            Axe[] axes = null;
            List<Axe> listeAxes = new List<Axe>();
            SqlCommand cmd = null;
            string sql = "Select * from Axe " + where;
            SqlDataReader reader = null;
            try
            {
                Connexion c = new Connexion();
                SqlConnection conn = c.connect();
                cmd = new SqlCommand(sql, connection);
                reader = cmd.ExecuteReader();
                UniteDAO uniteDao = new UniteDAO();
                while (reader.Read())
                {
                    Axe temp = new Axe(reader["Id"].ToString(), reader["Nom"].ToString(), reader["IdUnite"].ToString());
                    temp.setUnite(uniteDao.findOneUnite(conn, temp.getIdUnite()));
                    listeAxes.Add(temp);
                }
                conn.Close();

                int nb = listeAxes.Count;
                axes = new Axe[nb];
                listeAxes.CopyTo(axes);
                return axes;
            }
            catch (Exception e) { throw e; }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (cmd!=null){
                    cmd.Dispose();   
                }
            }
        }
        public Axe[] findAllAxe()
        {
            Axe[] axes = null;
            SqlConnection connection = null;
            try
            {
                Connexion conn = new Connexion();
                connection = conn.connect();
                axes = findAxe(connection, "");
                return axes;
            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }
    }
}
