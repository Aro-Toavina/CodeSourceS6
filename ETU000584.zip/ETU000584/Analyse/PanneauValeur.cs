﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyse
{
    class PanneauValeur : Panel
    {
        Accueil fenetre;
        private int nombreAxe;
        private Label[] label;
        private Label[] label2;
        private TextBox[] textbox;

        public PanneauValeur() { }
        public PanneauValeur(Accueil fen)
        {
            fenetre = fen;
            nombreAxe = fenetre.getNombreAxe();

            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Location = new System.Drawing.Point(870, 185);
            this.Name = "panneauValeur";
            this.Size = new System.Drawing.Size(341, 600);
            this.TabIndex = 1;
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_paint);

            label = new Label[nombreAxe];
            label2 = new Label[nombreAxe];
            textbox = new TextBox[nombreAxe];

            for (int i = 0; i < nombreAxe; i++)
            {
                label[i] = fenetre.get(i).getLabel();
                label2[i] = fenetre.get(i).getLabel2();
                textbox[i] = fenetre.get(i).getTextBox();
                textbox[i].KeyUp += new KeyEventHandler(updateViaTextBox);
                textbox[i].KeyDown += new KeyEventHandler(down);
                textbox[i].GotFocus += new EventHandler(gotFocus);
                textbox[i].MouseWheel += new System.Windows.Forms.MouseEventHandler(this.wheel);
                this.Controls.Add(label[i]);
                this.Controls.Add(label2[i]);
                this.Controls.Add(textbox[i]);

                //this.Controls.Add(fenetre.get(i).getTextBox());
            }
            //MessageBox.Show("Dans Construct Fin");
        }
        public void update(int index, String toadd)
        {
            textbox[index].Text = toadd;
        }
        private void panel1_paint(object sender, PaintEventArgs e)
        {
            //MessageBox.Show("Dans paint");
            
        }
        public void updateViaTextBox(object sender, KeyEventArgs e){
            //MessageBox.Show("Dans up eh");
            for (int compteur = 0; compteur < nombreAxe; compteur++)
            {
                if (textbox[compteur].Focused)
                {
                    if (textbox[compteur].Text == "")
                    {
                        textbox[compteur].Text = "0";
                    }
                    try
                    {
                        fenetre.updateByTextBox(compteur, Int32.Parse(textbox[compteur].Text));
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
        public void down(object sender, KeyEventArgs e)
        {
            for (int compteur = 0; compteur < nombreAxe; compteur++)
            {
                if (textbox[compteur].Focused)
                {
                    if (textbox[compteur].Text == "")
                    {
                        textbox[compteur].Text = "0";
                    }
                    try
                    {
                        
                        if (e.KeyCode.ToString().CompareTo("Down") == 0)
                        {
                            int val = Int32.Parse(textbox[compteur].Text) - 1;
                            if (val >= 0)
                            {
                                textbox[compteur].Text = (val).ToString();
                            }
                        }
                        else if (e.KeyCode.ToString().CompareTo("Up") == 0)
                        {
                            int val = Int32.Parse(textbox[compteur].Text) + 1;
                            if (val <= 250)
                            {
                                textbox[compteur].Text = (val).ToString();
                            }
                        }
                        fenetre.updateByTextBox(compteur, Int32.Parse(textbox[compteur].Text));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
        public void setFocusOn(int index)
        {
            textbox[index].Focus();
            textbox[index].BackColor = System.Drawing.Color.LightYellow;
            textbox[index].ForeColor = System.Drawing.Color.Red;
        }
        private void gotFocus(object sender, EventArgs e)
        {
            for(int compteur = 0; compteur < nombreAxe; compteur++)
            {
                textbox[compteur].BackColor = System.Drawing.Color.White;
                textbox[compteur].ForeColor = System.Drawing.Color.Black;
                if (textbox[compteur].Focused)
                {
                    //MessageBox.Show("Sady nandalo click no nahita");
                    fenetre.setFocusOn(compteur);
                }
            }
        }
        public void wheel(object sender, MouseEventArgs e)
        {
            for (int compteur = 0; compteur < nombreAxe; compteur++)
            {
                if (textbox[compteur].Focused)
                {
                    if (textbox[compteur].Text == "")
                    {
                        textbox[compteur].Text = "0";
                    }
                    try
                    {

                        if (e.Delta < 0)
                        {
                            int val = Int32.Parse(textbox[compteur].Text) - 1;
                            if (val >= 0)
                            {
                                textbox[compteur].Text = (val).ToString();
                            }
                        }
                        else if (e.Delta > 0)
                        {
                            int val = Int32.Parse(textbox[compteur].Text) + 1;
                            if (val <= 250)
                            {
                                textbox[compteur].Text = (val).ToString();
                            }
                        }
                        fenetre.updateByTextBox(compteur, Int32.Parse(textbox[compteur].Text));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
    }
}
