create table axe (
	id int,
	nom varchar,
	unité varchar,
	echelle double
)
create table categorie(
	id int,
	nom varchar,
	
)
create table categorie(
)
create table limiteaxe(
	idAxe int,
	min int,
	max int,
	idcategorie int
)

insert into categorie values('Nouveau né');
insert into categorie values('1 à 2ans');
insert into categorie values('3 à 6 ans');
insert into categorie values('7 à 10 ans');
insert into categorie values('Homme');
insert into categorie values('Femme');

insert into unite values(1,'10^9/L','2,5');
insert into unite(Nom,ValeurPixel) values('g/dl','2,5');
insert into unite(Nom,ValeurPixel) values('%','2,5');
insert into unite(Nom,ValeurPixel) values('µ^3','2,5');
insert into unite(Nom,ValeurPixel) values('mm','2,5');
insert into unite(Nom,ValeurPixel) values('Ul/l','2,5');
insert into unite(Nom,ValeurPixel) values('mmol/l','2,5');
insert into unite(Nom,ValeurPixel) values('µmol/l','2,5');

insert into axe values(1,'Globules Blancs',1);
insert into axe(Nom,IdUnite) values('Polynucléaires Neutrophiles',1);
insert into axe(Nom,IdUnite) values('Polynucléaires Posinophiles',1);
insert into axe(Nom,IdUnite) values('Polynucléaires Basinophiles',1);
insert into axe(Nom,IdUnite) values('Lymphocites',1);
insert into axe(Nom,IdUnite) values('Monocites',1);
insert into axe(Nom,IdUnite) values('Globules Rouges',1);
insert into axe(Nom,IdUnite) values('Hémoglobine',2);
insert into axe(Nom,IdUnite) values('Hématocrite',3);
insert into axe(Nom,IdUnite) values('VGM',4);
insert into axe(Nom,IdUnite) values('CCMH',3);
insert into axe(Nom,IdUnite) values('Plaquettes',1);
insert into axe(Nom,IdUnite) values('ASAT',6);
insert into axe(Nom,IdUnite) values('ALAT',6);
insert into axe(Nom,IdUnite) values('Glycémie',7);
insert into axe(Nom,IdUnite) values('Uricémie',8);
insert into axe(Nom,IdUnite) values('Créatininémie',8);
insert into axe(Nom,IdUnite) values('Urée',7);
insert into axe(Nom,IdUnite) values('Cholestérol Total',7);
insert into axe(Nom,IdUnite) values('HDL Cholestérol',7);
insert into axe(Nom,IdUnite) values('LDL Cholestérol',7);
insert into axe(Nom,IdUnite) values('Triglycéride',7);

insert into normalaxe values(1,'9','30',1);
insert into normalaxe values(1,'6','15',2);
insert into normalaxe values(1,'5','13',3);
insert into normalaxe values(1,'4,5','11',4);
insert into normalaxe values(1,'4','10',5);
insert into normalaxe values(1,'4','10',6);

insert into normalaxe values(2,'2','7,5',1);
insert into normalaxe values(2,'2','7,5',2);
insert into normalaxe values(2,'2','7,5',3);
insert into normalaxe values(2,'2','7,5',4);
insert into normalaxe values(2,'2','7,5',5);
insert into normalaxe values(2,'2','7,5',6);

insert into normalaxe values(3,'0,1','0,4',1);
insert into normalaxe values(3,'0,1','0,4',2);
insert into normalaxe values(3,'0,1','0,4',3);
insert into normalaxe values(3,'0,1','0,4',4);
insert into normalaxe values(3,'0,1','0,4',5);
insert into normalaxe values(3,'0,1','0,4',6);

insert into normalaxe values(4,'0','0,15',1);
insert into normalaxe values(4,'0','0,15',2);
insert into normalaxe values(4,'0','0,15',3);
insert into normalaxe values(4,'0','0,15',4);
insert into normalaxe values(4,'0','0,15',5);
insert into normalaxe values(4,'0','0,15',6);

insert into normalaxe values(5,'1,5','4',1);
insert into normalaxe values(5,'1,5','4',2);
insert into normalaxe values(5,'1,5','4',3);
insert into normalaxe values(5,'1,5','4',4);
insert into normalaxe values(5,'1,5','4',5);
insert into normalaxe values(5,'1,5','4',6);

insert into normalaxe values(6,'0,2','0,8',1);
insert into normalaxe values(6,'0,2','0,8',2);
insert into normalaxe values(6,'0,2','0,8',3);
insert into normalaxe values(6,'0,2','0,8',4);
insert into normalaxe values(6,'0,2','0,8',5);
insert into normalaxe values(6,'0,2','0,8',6);

insert into normalaxe values(7,'4,3','6',1);
insert into normalaxe values(7,'3,6','4,8',2);
insert into normalaxe values(7,'4','5,2',3);
insert into normalaxe values(7,'4','5,4',4);
insert into normalaxe values(7,'4','5,4',5);
insert into normalaxe values(7,'4','5,3',6);

insert into normalaxe values(8,'16,5','21',1);
insert into normalaxe values(8,'11','13',2);
insert into normalaxe values(8,'12','14',3);
insert into normalaxe values(8,'12','14,5',4);
insert into normalaxe values(8,'13','18',5);
insert into normalaxe values(8,'12','16',6);

insert into normalaxe values(9,'44','64',1);
insert into normalaxe values(9,'31','39',2);
insert into normalaxe values(9,'36','44',3);
insert into normalaxe values(9,'37','45',4);
insert into normalaxe values(9,'40','52',5);
insert into normalaxe values(9,'37','46',6);

insert into normalaxe values(10,'100','128',1);
insert into normalaxe values(10,'70','86',2);
insert into normalaxe values(10,'74','88',3);
insert into normalaxe values(10,'77','91',4);
insert into normalaxe values(10,'80','95',5);
insert into normalaxe values(10,'80','95',6);

insert into normalaxe values(11,'30','34',1);
insert into normalaxe values(11,'28','33',2);
insert into normalaxe values(11,'28','33',3);
insert into normalaxe values(11,'28','33',4);
insert into normalaxe values(11,'32','36',5);
insert into normalaxe values(11,'32','36',6);

insert into normalaxe values(12,'160','450',1);
insert into normalaxe values(12,'160','450',2);
insert into normalaxe values(12,'160','450',3);
insert into normalaxe values(12,'160','450',4);
insert into normalaxe values(12,'160','350',5);
insert into normalaxe values(12,'160','350',6);