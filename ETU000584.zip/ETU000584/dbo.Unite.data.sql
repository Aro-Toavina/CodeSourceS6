SET IDENTITY_INSERT [dbo].[Unite] ON
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (1, N'10^9/L', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (2, N'g/dl', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (3, N'%', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (4, N'µ^3', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (5, N'mm', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (6, N'Ul/l', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (7, N'mmol/l', N'2,5')
INSERT INTO [dbo].[Unite] ([Id], [Nom], [ValeurPixel]) VALUES (8, N'µmol/l', N'2,5')
SET IDENTITY_INSERT [dbo].[Unite] OFF
