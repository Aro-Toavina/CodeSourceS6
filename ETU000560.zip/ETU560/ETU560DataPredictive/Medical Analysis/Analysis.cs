﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Medical_Analysis.Model;
using Medical_Analysis.DAO;
using Medical_Analysis.Connexion;

namespace Medical_Analysis
{
    public partial class Analysis : Form
    {
        private int rayon = 300;
        private Point selectedPoint = new Point();
        private Axe selectedAxis = new Axe();
        private int selectedIndex = 0;
        private Boolean dragging = false;
        private Boolean init = true;
        public Analysis()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Load(object sender, EventArgs e)
        {
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (init)
            {
                drawAxe(g, axes.Count);

                drawPolygonLimit(g);

                drawPolygon(g);
                
                drawAxe(g, axes.Count);
                
                drawPoints(g);
               
                init = false;
            }
            else
            {
                drawPolygonLimit(g);
                drawPolygon(g);
                drawAxe(g, axes.Count);
                drawPoints(g);
            }
        }
        private void drawAxe(Graphics g, int nb)
        {
            Pen pen = new Pen(Color.FromArgb(100, 100, 100));
            double angle = 0;
            for(int i=0; i<nb; i++)
            {
                
                if (init)
                {
                    angle = (2 * Math.PI / nb) * i;
                    int x = (int)(rayon * (1 + Math.Sin(angle)));
                    int y = (int)(rayon * (1 - Math.Cos(angle)));
                    Point p = new Point(x, y);
                    
                    axes.ElementAt(i).complete(p, center);
                    
                    g.DrawLine(pen, center.getX(), center.getY(), p.getX(), p.getY());
                    
                    DrawString(g, axes.ElementAt(i).getCriteria().getName(), x, y);
                    
                }
                else
                {
                    g.DrawLine(pen, center.getX(), center.getY(), axes.ElementAt(i).getMax().getX(), axes.ElementAt(i).getMax().getY());
                    DrawString(g, axes.ElementAt(i).getCriteria().getName(), axes.ElementAt(i).getMax().getX(), axes.ElementAt(i).getMax().getY());
                }
                
            }
            
        }
        public void drawPoints(Graphics g)
        {
            for (int i = 0; i < axes.Count; i++)
            {
                drawPoint(g, axes.ElementAt(i).getValue());
            }
        }
        public void drawPolygon(Graphics g)
        {
            PointF[] p = new PointF[axes.Count];
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(Color.FromArgb(194, 109, 92));
            for (int i = 0; i < axes.Count; i++)
            {
                p[i] = new PointF(axes.ElementAt(i).getValue().getX(), axes.ElementAt(i).getValue().getY());
            }
            g.FillPolygon(myBrush, p);
        }
        public void drawPolygonLimit(Graphics g)
        {
            PointF[] p = new PointF[axes.Count];
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(Color.FromArgb(17, 230, 97));
            for (int i = 0; i < axes.Count; i++)
            {
                p[i] = new PointF(axes.ElementAt(i).getMax().getX(), axes.ElementAt(i).getMax().getY());
            }
            g.FillPolygon(myBrush, p);
        }
        public void DrawString(Graphics g, String str, float x, float y)
        {
            System.Drawing.Graphics formGraphics = g;
            string drawString = str;
            System.Drawing.Font drawFont = new System.Drawing.Font("Arial", 14);
            System.Drawing.SolidBrush drawBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
            System.Drawing.StringFormat drawFormat = new System.Drawing.StringFormat();
            formGraphics.DrawString(drawString, drawFont, drawBrush, x, y, drawFormat);
            drawFont.Dispose();
            drawBrush.Dispose();
        }
        public void drawPoint(Graphics g, Point p)
        {
            int size = Point.size;
            int shift = size / 2;
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(Color.FromArgb(11, 55, 26));
            Rectangle rect = new Rectangle(p.getX()-shift, p.getY()-shift, size, size);
            g.FillEllipse(myBrush, rect);
        }
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            for (int i=0; i<axes.Count; i++)
            {
                //List<Point> liste = axes.ElementAt(i).getIntervals(center);
                
                    if(selectedPoint.isSelected(axes.ElementAt(i).getValue(), e.Location.X, e.Location.Y)){
                        selectedPoint = axes.ElementAt(i).getValue();
                        selectedAxis = axes.ElementAt(i);
                        selectedIndex = i;
                        dragging = true;
                        break;
                    }
            }
        }
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                selectedPoint = selectedAxis.getProjectionOnAxis(new Point(e.Location.X, e.Location.Y), center);
                axes.ElementAt(selectedIndex).setValue(selectedPoint, center);
                panel_chart.Refresh();
                refreshPanelValues();
            }
        }
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
            selectedPoint = new Point();
            selectedAxis = new Axe();
            Refresh();
        }
        private void Analysis_Load(object sender, EventArgs e)
        {
           
        }

        private void panel_background_Paint(object sender, PaintEventArgs e)
        {

        }
        private void panel_values_Paint(object sender, PaintEventArgs e)
        {

        }
        private int getSexe()
        {
            if (radio_homme.Checked)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }
        private void button_analyse_Click(object sender, EventArgs e)
        {
            try
            {
                DiseaseDAO d = new DiseaseDAO();

                List<Criteria> criterias = new List<Criteria>();
                for (int i = 0; i < axes.Count(); i++)
                {
                    criterias.Add(axes.ElementAt(i).getCriteria());
                }
                Health_Status health = new Health_Status(Int32.Parse(textBox_age.Text), getSexe(), criterias, d.findAll());
                for(int i = 0; i< health.getDiseases().Count; i++)
                {
                    Console.WriteLine("Nb " + i);
                    health.getDiseases().ElementAt(i).setPercentage(health.getDiseases().ElementAt(i).getPercentage(health));
                    Console.WriteLine("Percentage Calculation successfull");
                    Console.WriteLine("-------------------------------");
                }
                health.setDiseases(health.orderDiseases(health.getDiseases()));
                drawLabelResults(comboBoxNumber.SelectedIndex + 1, health);
            }
            catch(System.FormatException ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Invalid age format, please enter numbers");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            
        }
    }
}
