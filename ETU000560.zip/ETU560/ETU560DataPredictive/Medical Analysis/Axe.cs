﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Medical_Analysis.Model;

namespace Medical_Analysis
{
    class Axe
    {
        private Criteria criteria;
        private Point value;
        private Point max;
        private List<Point> listPoints;
        private bool isVertical = false;
        //Constructors
        public Axe()
        {

        }
        public Axe(Criteria newCriteria, Point center)
        {
            this.setCriteria(newCriteria);
        }
        public Axe (Criteria newCriteria, Point newMax, Point center)
        {
            this.setCriteria(newCriteria);
            this.setValue(getLocation(newCriteria.getDefaultValue(), center), center);
            this.setMax(newMax, center);
        }

        //Setters
       public void setCriteria(Criteria newCriteria)
        {
            this.criteria = newCriteria;
        }
        public void setValue(Point newValue, Point center)
        {
            this.getCriteria().setValue(getPointValue(newValue, center));
            this.value = getLocation(criteria.getValue(), center);
        }
        public void setMax(Point newMax, Point center)
        {
            this.max = newMax;
            if (max.getX() == center.getX())
                isVertical = true;
        }
        public void setListPoints(List<Point> liste)
        {
            this.listPoints = liste;
        }

        //Getters
        public Criteria getCriteria()
        {
            return this.criteria;
        }
        public Point getValue()
        {
            return this.value;
        }
        public Point getMax()
        {
            return this.max;
        }
        public List<Point> getListPoints()
        {
            return this.listPoints;
        }

        //Functions
        public void complete(Point newMax, Point center)
        {
            this.setMax(newMax, center);
            this.setValue(getLocation(criteria.getValue(), center), center);
            
        }
        public Point getLocation(double doubleValue, Point center)
        {
            double percentage = getPercentage(criteria.getMinValue(), criteria.getMaxValue(), doubleValue);
            
            Point ans = null;
            if (!isVertical)
            {
                int x = getXValueAtPercentage(center.getX(), max.getX(), percentage);
                
                ans= getPointValue(x, center);
            }
            else
            {
                int y = getXValueAtPercentage(center.getY(), max.getY(), percentage);
                
                ans= getPointValue(y, center);
            }
            return ans;
                

        }
        public double getPercentage(double start, double finish, double value)
        {
            double ans = 0;
           
            double val = finish - start;
            
            value = value - start;
            
            ans = (value * 100) / val;
            return ans;
        }
        public int getXValueAtPercentage(int start, int finish, double percentage)
        {
            int ans = 0;
            
            int val = finish - start;
            
            ans = (int)((val * percentage) / 100) + start;
            
            return ans;
        }
        public Point getPointValue(int x, Point center)
        {
            Point ans = null;
            if (!isVertical)
            {
                ans = getPointInLine(center, x);
            }
            else
            {
                ans = new Point(center.getX(), x);
            }
            return ans;
        }
        public double getPointValue(Point p, Point center)
        {
            double percentage = 0;
            if (!isVertical)
            {
                percentage = getPercentage(center.getX(), max.getX(), p.getX());
            }
            else
            {
                percentage = getPercentage(center.getY(), max.getY(), p.getY());
            }
            
            double ans = 0;
            double val = criteria.getMaxValue() - criteria.getMinValue();
            
            ans = (val * percentage) / 100;
                        return ans;
        }
        public Point getNearestInterval(Point p)
        {
            Point ans = null;
            int xDifference = 1000000;
            int yDifference = 1000000;
            for(int i=0; i<listPoints.Count; i++)
            {
                Point p1 = listPoints.ElementAt(i);
                if (Math.Abs(p.getX() - p1.getX()) <= xDifference)
                {
                    xDifference = Math.Abs(p.getX() - p1.getX());
                    if(Math.Abs(p.getY() - p1.getY()) <= yDifference)
                    {
                        yDifference = Math.Abs(p.getY() - p1.getY());
                        ans = p1;
                    }
                }
            }
            return ans;
        }
        public Point getProjectionOnAxis(Point p, Point center)
        {
            Point ans = null;
            if (!isVertical)
            {
                ans = getPointInLine(center, p.getX());
            }
            else
            {
                if (center.isEqual(p))
                {
                    ans = center;
                }
                else
                    ans = new Point(center.getX(), p.getY());
            }
            return ans;
        }
        public Point getPointInLine(Point center, int x)
        {
            Point ans = new Point();
            
            float deltaY=max.getY() - center.getY();
            
            float deltaX=max.getX() - center.getX();
            
            float a = deltaY/deltaX;
            float b = max.getY() - (a * max.getX());
            
            int y = (int)((a * x) + b);
            
            ans = new Point(x, y);
            return ans;
        }
    }
}
