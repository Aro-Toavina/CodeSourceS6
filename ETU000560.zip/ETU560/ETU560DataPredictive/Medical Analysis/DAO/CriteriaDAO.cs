﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Medical_Analysis.Model;
using Medical_Analysis.Connexion;
using System.Data.SqlClient;
using System.Data;

namespace Medical_Analysis.DAO
{
    class CriteriaDAO
    {
        public List<Criteria> findAll()
        {
            List<Criteria> ans = new List<Criteria>();
            SqlConnection myConnection = null;
            SqlDataReader readdata = null;
            SqlCommand cmd = null;
            try
            {
                myConnection = new Connection().Connecter();
                myConnection.Open();
                cmd = new SqlCommand(null, myConnection);
                cmd.CommandText = "select * from [dbo].[Criterias] ";
                cmd.Prepare();
                readdata = cmd.ExecuteReader();
                while (readdata.Read())
                {
                    Console.WriteLine(readdata["id"].ToString());
                    Console.WriteLine(readdata["name"].ToString());
                    Criteria p = new Criteria(readdata["id"].ToString(), readdata["name"].ToString(), Double.Parse(readdata["minValue"].ToString()), Double.Parse(readdata["maxValue"].ToString()), Double.Parse(readdata["defaultValue"].ToString()), Double.Parse(readdata["normalValueMin"].ToString()), Double.Parse(readdata["normalValueMax"].ToString()), readdata["unit"].ToString());
                    ans.Add(p);
                }
                Console.WriteLine("Ok");
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (readdata != null)
                    readdata.Close();
                if (cmd != null)
                    cmd.Dispose();
                if (myConnection != null)
                    myConnection.Close();
            }
            return ans;
        }
        public Criteria findCriteriaById(string id, SqlConnection myConnection)
        {
            Criteria ans = new Criteria();
            SqlDataReader readdata = null;
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand(null, myConnection);
                cmd.CommandText = "select * from [dbo].[Criterias] where id = @id";
                SqlParameter idParam = new SqlParameter("@id", SqlDbType.VarChar, 50);
                idParam.Value = id;
                cmd.Parameters.Add(idParam);
                cmd.Prepare();
                readdata = cmd.ExecuteReader();
                while (readdata.Read())
                {
                    ans = new Criteria(readdata["id"].ToString(), readdata["name"].ToString(), Double.Parse(readdata["minValue"].ToString()), Double.Parse(readdata["maxValue"].ToString()), Double.Parse(readdata["defaultValue"].ToString()), Double.Parse(readdata["normalValueMin"].ToString()), Double.Parse(readdata["normalValueMax"].ToString()));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (readdata != null)
                    readdata.Close();
                if (cmd != null)
                    cmd.Dispose();
            }
            return ans;
        }
    }
}
