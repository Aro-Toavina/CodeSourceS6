﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Medical_Analysis.Model;
using Medical_Analysis.Connexion;
using System.Data.SqlClient;
using System.Data;

namespace Medical_Analysis.DAO
{
    class DiseaseDAO
    {
        public List<Disease> findAll()
        {
            List<Disease> ans = new List<Disease>();
            SqlConnection myConnection = null;
            SqlDataReader readdata = null;
            SqlCommand cmd = null;
            try
            {
                myConnection = new Connection().Connecter();
                myConnection.Open();
                cmd = new SqlCommand(null, myConnection);
                cmd.CommandText = "select * from [dbo].[Diseases] ";
                cmd.Prepare();
                readdata = cmd.ExecuteReader();
                while (readdata.Read())
                {
                    Disease d = new Disease(readdata["id"].ToString(), readdata["name"].ToString(), Int32.Parse(readdata["ageMin"].ToString()), Int32.Parse(readdata["ageMax"].ToString()), Double.Parse(readdata["ageImpact"].ToString()), Double.Parse(readdata["femaleImpact"].ToString()), Double.Parse(readdata["maleImpact"].ToString()));
                    ans.Add(d);
                }
                readdata.Close();
                cmd.Dispose();
                for (int i = 0; i<ans.Count; i++)
                {
                    CompleteDisease(ans.ElementAt(i), myConnection);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (readdata != null)
                    readdata.Close();
                if (cmd != null)
                    cmd.Dispose();
                if (myConnection != null)
                    myConnection.Close();
            }
            return ans;
        }
        public void CompleteDisease(Disease disease, SqlConnection myConnection)
        {
            List<Criteria> list = new List<Criteria>();
            List<string> idCriteria = new List <string>();
            List<Double> valMin = new List<Double>();
            List<Double> valMax = new List<Double>();
            List<int> type = new List<int>();
            SqlDataReader readdata = null;
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand(null, myConnection);
                cmd.CommandText = "select * from [dbo].[DiseasesDetails] where idDisease = @id";
                SqlParameter idParam = new SqlParameter("@id", SqlDbType.VarChar, 50);
                idParam.Value = disease.getId();
                cmd.Parameters.Add(idParam);
                cmd.Prepare();
                readdata = cmd.ExecuteReader();
                while (readdata.Read())
                {
                    idCriteria.Add(readdata["idCriteria"].ToString());
                    valMin.Add(Double.Parse(readdata["minValue"].ToString()));
                    valMax.Add(Double.Parse(readdata["maxValue"].ToString()));
                    type.Add(Int32.Parse(readdata["type"].ToString()));
                }
                readdata.Close();
                cmd.Dispose();
                CriteriaDAO criteriaDAO = new CriteriaDAO();
                for(int i = 0; i<idCriteria.Count; i++)
                {
                    list.Add(criteriaDAO.findCriteriaById(idCriteria.ElementAt(i), myConnection));
                    list.ElementAt(i).setMinValue(valMin.ElementAt(i));
                    list.ElementAt(i).setMaxValue(valMax.ElementAt(i));
                    list.ElementAt(i).setType(type.ElementAt(i));
                }
                disease.setConditions(list);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (readdata != null)
                    readdata.Close();
                if (cmd != null)
                    cmd.Dispose();
            }
        }
    }
}
