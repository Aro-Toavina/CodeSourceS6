drop table [dbo].[DiseasesDetails];
drop table [dbo].[Diseases];
drop table [dbo].[Criterias];

drop sequence [dbo].[seqIdCriterias];
drop sequence [dbo].[seqIdDiseases];
drop sequence [dbo].[seqIdDiseasesDetails];
