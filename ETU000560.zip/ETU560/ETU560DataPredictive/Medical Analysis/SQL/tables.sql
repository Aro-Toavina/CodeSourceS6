CREATE TABLE [dbo].[Criterias]
(
	[id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [name] VARCHAR(50) NOT NULL, 
    [minValue] FLOAT NOT NULL,
	[maxValue] FLOAT NOT NULL,
	[defaultValue] FLOAT NOT NULL,
	[normalValueMin] FLOAT NOT NULL,
	[normalValueMax] FLOAT NOT NULL,
	[unit] VARCHAR(50)
);

CREATE TABLE [dbo].[Diseases]
(
	[id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [name] VARCHAR(50) NOT NULL, 
	[ageMin] INT NOT NULL,
	[ageMax] INT NOT NULL,
	[ageImpact] FLOAT NOT NULL,
	[femaleImpact] FLOAT NOT NULL,
	[maleImpact] FLOAT NOT NULL
);
CREATE TABLE [dbo].[DiseasesDetails](
    [id] VARCHAR(50) NOT NULL PRIMARY KEY,
    [idDisease] VARCHAR(50) NOT NULL,
    [idCriteria] VARCHAR(50) NOT NULL,
    [minValue] FLOAT NOT NULL,
    [maxValue] FLOAT NOT NULL,
    [type] INT NOT NULL,
    foreign key (idDisease) references Diseases(id),
    foreign key (idCriteria) references Criterias(id)
);

