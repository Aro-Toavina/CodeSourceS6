
/* Criterias */
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Hématies', 0, 10, 5, 4.5, 6, 'Tera/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Hémoglobine', 0, 250, 150, 130, 175, 'g/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Hématocrite', 0, 1, 0.47, 0.4, 0.55, 'Tera/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Volume globulaire', 0, 200, 90, 80, 100, 'µcubes');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'TGMH', 0, 50, 30, 27, 50, 'pg');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'CCMH', 0, 600, 340, 320, 360, 'g/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Indice de distribution globulaire', 0, 25, 13, 11, 15, '');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Leucocytes', 0, 10, 6, 4, 10, 'Giga/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Plaquettes', 0, 500, 300, 160, 400, 'Giga/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Vitesse de Sédimentation', 0, 40, 14, 0, 20, 'mm/h');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Glycémie', 0, 10, 5, 4.1, 5.9, 'mmol/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Créatinine', 0, 150, 75, 59, 104, 'µmol/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Triglycéride', 0, 4, 1.6, 1, 2.25, 'mmol/l');
insert into [dbo].[Criterias] values (Concat('CRIT000',next value for seqIdCriterias), 'Cholesterol', 0, 10, 3.5, 2.9, 5.2, 'mmol/l');

/* Diseases */
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Polyglobulie', 25, 45, 0.15, 1, 1.02);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Anémie', 0, 145, 0.15, 1.1, 1.07);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Microcytose', 15, 70, 0.15, 1, 1);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Macrocytose', 15, 70, 0.15, 1, 1);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Leucémie', 5, 80, 1.2, 0.15, 1.04);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Infection virale', 0, 145, 0.15, 1, 1);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Obesite', 10, 145, 0.25, 1.1, 1);
insert into [dbo].[Diseases] values (Concat('DIS00',next value for seqIdDiseases), 'Anorexie', 10, 145, 0.1, 1, 1.15);


/* Diseases Details */
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS001', 'CRIT0002', 175, 250, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS002', 'CRIT0002', 0, 130, 1);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS003', 'CRIT0004', 0, 80, 1);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS004', 'CRIT0004', 100, 200, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS005', 'CRIT0008', 8, 10, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS006', 'CRIT0008', 0, 4, 1);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS006', 'CRIT0007', 5, 10, 2);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS006', 'CRIT0004', 110, 150, 2);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS007', 'CRIT00014', 5.2, 10, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS007', 'CRIT00011', 5.9, 10, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS007', 'CRIT00013', 2.3, 4, 3);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS008', 'CRIT00014', 0, 2.9, 1);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS008', 'CRIT00013', 0.1, 0.9, 2);
insert into [dbo].[DiseasesDetails] values (Concat('DISDTL00',next value for seqIdDiseasesDetails), 'DIS008', 'CRIT00011', 1, 4, 2);
