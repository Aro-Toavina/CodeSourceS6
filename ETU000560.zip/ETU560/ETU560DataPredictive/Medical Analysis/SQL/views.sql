create view JoueurEquipeNom as
select j.ID, j.Nom, e.Nom as Equipe, j.Numero, j.Poste, j.Type
from Joueur j
join Equipe e
on e.ID = j.Equipe;

create view ParticipationNom as
select p.Match, j.Nom as Joueur, p.Equipe
from Participation p
join Joueur j
on j.ID = p.Joueur;

create view MatchEquipeNom as
select m.ID, m.Daty, e1.name as EquipeA, m.CouleurA, e2.name as EquipeB, m.CouleurB, m.Duree, m.Remplacement, m.Type, m.Etat
from Match m
join Teams e1
on e1.ID = m.EquipeA
join Teams e2
on e2.ID = m.EquipeB;

create view TotalArgentEngage as
select a.Utilisateur, 'Tous' as Pari, sum(Somme) as Somme, 1 as Type
from ArgentEngage a
where Pari in (select ID from Pari where Operationnel = 1)
group by a.Utilisateur;

create view EtatPorteMonnaie as
select p.ID, p.Utilisateur, p.Somme - isnull(t.Somme, 0) as Somme
from PorteMonnaie p
left outer join TotalArgentEngage t
on t.Utilisateur = p.Utilisateur;

create view TotalSommePari as
select p.Pari, sum(p.MontantA) as MontantA, sum(p.MontantB) as MontantB
from PariSuivi p
group by p.Pari;

create view EtatPari as
select p.ID, p.Daty, p.Utilisateur, p.Match, p.TypeMatch, p.Categorie, p.Type, p.JoueurA, p.JoueurB, p.CompensationA, p.CompensationB, p.MontantA - (isnull(t.MontantA, 0)) as MontantA, p.MontantB - (isnull(t.MontantB, 0)) as MontantB ,
p.ForfaitA, p.ForfaitB, p.EgaliteA, p.EgaliteB, p.Choix, p.Operationnel 
from Pari p left outer join TotalSommePari t on t.Pari = p.ID;

create view PariNom as
select p.ID, p.Daty, u.Nom as Utilisateur, p.Match, t.Nom as TypeMatch, c.Libelle as Categorie,
p.Type, ea.name as JoueurA, eb.name as JoueurB, p.CompensationA, p.CompensationB, p.MontantA, p.MontantB, p.ForfaitA, p.ForfaitB,
p.EgaliteA, p.EgaliteB, p.Choix, p.Operationnel
from Pari p
join Utilisateur u 
on u.ID = p.Utilisateur
join TypeMatch t
on t.ID = p.TypeMatch
join CategoriePari c
on c.ID = p.Categorie
join Teams ea
on ea.ID = p.JoueurA
join Teams eb
on eb.ID = p.JoueurB;

create view PariSuiviNom as
select p.ID, p.Daty, u.Nom as Utilisateur, p.Match, t.Nom as TypeMatch, c.Libelle as Categorie,
p.Type, ea.name as JoueurA, eb.name as JoueurB, p.CompensationA, p.CompensationB, p.MontantA, p.MontantB, p.ForfaitA, p.ForfaitB,
p.EgaliteA, p.EgaliteB, p.Choix, p.Operationnel, p.Pari, u2.Nom as Parieur
from PariSuivi p
join Utilisateur u 
on u.ID = p.Utilisateur
join TypeMatch t
on t.ID = p.TypeMatch
join CategoriePari c
on c.ID = p.Categorie
join Teams ea
on ea.ID = p.JoueurA
join Teams eb
on eb.ID = p.JoueurB
join Utilisateur u2
on u2.ID = p.Parieur;

create view EtatPariNom as
select p.ID, p.Daty, u.Nom as Utilisateur, p.Match, t.Nom as TypeMatch, c.Libelle as Categorie,
p.Type, ea.name as JoueurA, eb.name as JoueurB, p.CompensationA, p.CompensationB, p.MontantA, p.MontantB, p.ForfaitA, p.ForfaitB,
p.EgaliteA, p.EgaliteB, p.Choix, p.Operationnel
from EtatPari p
join Utilisateur u 
on u.ID = p.Utilisateur
join TypeMatch t
on t.ID = p.TypeMatch
join CategoriePari c
on c.ID = p.Categorie
join Teams ea
on ea.ID = p.JoueurA
join Teams eb
on eb.ID = p.JoueurB;