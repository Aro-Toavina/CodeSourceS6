create sequence [dbo].[seqIdCriterias] as integer start with 1 increment by 1 MAXVALUE 99999;
create sequence [dbo].[seqIdDiseases] as integer start with 1 increment by 1 MAXVALUE 99999;
create sequence [dbo].[seqIdDiseasesDetails] as integer start with 1 increment by 1 MAXVALUE 99999;
