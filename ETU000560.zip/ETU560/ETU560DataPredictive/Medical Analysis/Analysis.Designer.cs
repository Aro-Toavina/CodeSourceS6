﻿using System;
using System.Collections.Generic;
using Medical_Analysis.Model;
using Medical_Analysis.DAO;
using Medical_Analysis.Connexion;
using System.Windows.Forms;

namespace Medical_Analysis
{
    partial class Analysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Point center = new Point();
        private List<Axe> axes = new List<Axe>();
        private List<System.Windows.Forms.Label> results= new List<System.Windows.Forms.Label>();


        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            initListAxes();
            this.panel_background = new System.Windows.Forms.Panel();
            this.panel_results = new System.Windows.Forms.Panel();
            this.label_results = new System.Windows.Forms.Label();
            this.panel_chart = new System.Windows.Forms.Panel();
            this.panel_dataInsert = new System.Windows.Forms.Panel();
            this.label_age = new System.Windows.Forms.Label();
            this.textBox_age = new System.Windows.Forms.TextBox();
            this.radio_femme = new System.Windows.Forms.RadioButton();
            this.radio_homme = new System.Windows.Forms.RadioButton();
            this.button_analyse = new System.Windows.Forms.Button();
            this.panel_right = new System.Windows.Forms.Panel();
            this.panel_values = new System.Windows.Forms.Panel();
            initPanel();
            this.label_values = new System.Windows.Forms.Label();
            this.comboBoxNumber = new System.Windows.Forms.ComboBox();
            this.panel_background.SuspendLayout();
            this.panel_results.SuspendLayout();
            this.panel_dataInsert.SuspendLayout();
            this.panel_right.SuspendLayout();
            this.panel_values.SuspendLayout();
            suspendLayout(listPanelValues);
            this.SuspendLayout();
            // 
            // panel_background
            // 
            this.panel_background.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel_background.Controls.Add(this.panel_results);
            this.panel_background.Controls.Add(this.panel_chart);
            this.panel_background.Location = new System.Drawing.Point(0, 1);
            this.panel_background.Name = "panel_background";
            this.panel_background.Size = new System.Drawing.Size(1370, 700);
            this.panel_background.TabIndex = 0;
            this.panel_background.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_background_Paint);
            // 
            // panel_results
            // 
            this.panel_results.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel_results.Controls.Add(this.label_results);
            this.panel_results.Location = new System.Drawing.Point(1052, 0);
            this.panel_results.Name = "panel_results";
            this.panel_results.Size = new System.Drawing.Size(298, 700);
            this.panel_results.TabIndex = 3;
            // 
            // label1
            // 
            
            // 
            // label_results
            // 
            this.label_results.AccessibleName = "labelResults";
            this.label_results.AutoSize = true;
            this.label_results.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_results.Location = new System.Drawing.Point(99, 8);
            this.label_results.Name = "label_results";
            this.label_results.Size = new System.Drawing.Size(122, 37);
            this.label_results.TabIndex = 4;
            this.label_results.Text = "Results";
            // 
            // panel_chart
            // 
            this.panel_chart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_chart.Location = new System.Drawing.Point(12, 0);
            this.panel_chart.Name = "panel_chart";
            this.panel_chart.Size = new System.Drawing.Size(717, 700);
            this.panel_chart.TabIndex = 0;
            this.panel_chart.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel_chart.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel_chart.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel_chart.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // panel_dataInsert
            // 
            this.panel_dataInsert.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_dataInsert.Controls.Add(this.label_age);
            this.panel_dataInsert.Controls.Add(this.textBox_age);
            this.panel_dataInsert.Controls.Add(this.radio_femme);
            this.panel_dataInsert.Controls.Add(this.radio_homme);
            this.panel_dataInsert.Location = new System.Drawing.Point(0, 0);
            this.panel_dataInsert.Name = "panel_dataInsert";
            this.panel_dataInsert.Size = new System.Drawing.Size(300, 153);
            this.panel_dataInsert.TabIndex = 0;
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(60, 50);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(77, 31);
            this.label_age.TabIndex = 3;
            this.label_age.Text = "Age :";
            // 
            // textBox_age
            // 
            this.textBox_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_age.Location = new System.Drawing.Point(179, 50);
            this.textBox_age.Name = "textBox_age";
            this.textBox_age.Size = new System.Drawing.Size(70, 31);
            this.textBox_age.TabIndex = 2;
            // 
            // radio_femme
            // 
            this.radio_femme.AutoSize = true;
            this.radio_femme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_femme.Location = new System.Drawing.Point(178, 117);
            this.radio_femme.Name = "radio_femme";
            this.radio_femme.Size = new System.Drawing.Size(81, 24);
            this.radio_femme.TabIndex = 1;
            this.radio_femme.TabStop = true;
            this.radio_femme.Text = "Femme";
            this.radio_femme.UseVisualStyleBackColor = true;
            // 
            // radio_homme
            // 
            this.radio_homme.AutoSize = true;
            this.radio_homme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_homme.Location = new System.Drawing.Point(49, 117);
            this.radio_homme.Name = "radio_homme";
            this.radio_homme.Size = new System.Drawing.Size(83, 24);
            this.radio_homme.TabIndex = 0;
            this.radio_homme.TabStop = true;
            this.radio_homme.Text = "Homme";
            this.radio_homme.UseVisualStyleBackColor = true;
            // 
            // button_analyse
            // 
            this.button_analyse.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_analyse.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_analyse.Location = new System.Drawing.Point(89, 531);
            this.button_analyse.Name = "button_analyse";
            this.button_analyse.Size = new System.Drawing.Size(187, 58);
            this.button_analyse.TabIndex = 1;
            this.button_analyse.Text = "Start analysis";
            this.button_analyse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_analyse.UseVisualStyleBackColor = false;
            this.button_analyse.Click += new System.EventHandler(this.button_analyse_Click);
            // 
            // panel_right
            // 
            this.panel_right.Controls.Add(this.comboBoxNumber);
            this.panel_right.Controls.Add(this.panel_values);
            this.panel_right.Controls.Add(this.panel_dataInsert);
            this.panel_right.Controls.Add(this.button_analyse);
            this.panel_right.Location = new System.Drawing.Point(741, 1);
            this.panel_right.Name = "panel_right";
            this.panel_right.Size = new System.Drawing.Size(300, 700);
            this.panel_right.TabIndex = 2;
            // 
            // panel_values
            // 
            this.panel_values.AutoScroll = true;
            this.panel_values.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel_values.Controls.Add(this.label_values);
            this.panel_values.Location = new System.Drawing.Point(1, 150);
            this.panel_values.Name = "panel_values";
            this.panel_values.Size = new System.Drawing.Size(298, 363);
            this.panel_values.TabIndex = 2;
            this.panel_values.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_values_Paint);
            initPanelValues();
            // 
            // label_values
            // 
            this.label_values.AutoSize = true;
            this.label_values.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_values.Location = new System.Drawing.Point(107, 18);
            this.label_values.Name = "label_values";
            this.label_values.Size = new System.Drawing.Size(97, 31);
            this.label_values.TabIndex = 4;
            this.label_values.Text = "Values";
            // 
            // comboBoxNumber
            // 
            this.comboBoxNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxNumber.FormattingEnabled = true;
            this.comboBoxNumber.Location = new System.Drawing.Point(24, 545);
            this.comboBoxNumber.Name = "comboBoxNumber";
            this.comboBoxNumber.Size = new System.Drawing.Size(39, 33);
            this.comboBoxNumber.TabIndex = 3;
            initComboBox();
            // 
            // Analysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 602);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_background);
            this.Name = "Analysis";
            this.Text = "Analysis";
            this.Load += new System.EventHandler(this.Analysis_Load);
            this.panel_background.ResumeLayout(false);
            this.panel_results.ResumeLayout(false);
            this.panel_results.PerformLayout();
            this.panel_dataInsert.ResumeLayout(false);
            this.panel_dataInsert.PerformLayout();
            this.panel_right.ResumeLayout(false);
            this.panel_values.ResumeLayout(false);
            resumeLayout(listPanelValues);
            this.panel_values.PerformLayout();
            performLayout(listPanelValues);
            this.ResumeLayout(false);

        }
        public void initListAxes()
        {
            try
            {
                center = new Point(this.Width, this.Height);
                CriteriaDAO dao = new CriteriaDAO();
                List<Criteria> list = dao.findAll();
                for (int i = 0; i < list.Count; i++)
                {
                    axes.Add(new Axe(list[i], center));
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
        }
        public void resumeLayout(List<System.Windows.Forms.Panel> panel)
        {
            for (int i = 0; i < panel.Count; i++)
            {
                panel[i].ResumeLayout(false);
            }
        }
        public void suspendLayout(List<System.Windows.Forms.Panel> panel)
        {
            for (int i = 0; i < panel.Count; i++)
            {
                panel[i].SuspendLayout();
            }
        }
        public void performLayout(List<System.Windows.Forms.Panel> panel)
        {
            for (int i = 0; i < panel.Count; i++)
            {
                panel[i].PerformLayout();
            }
        }
        public void initPanel()
        {
            listPanelValues = new List<System.Windows.Forms.Panel>();
            listLabelCriterias = new List<System.Windows.Forms.Label>();
            listLabelValues = new List<System.Windows.Forms.Label>();
            for (int i = 0; i < axes.Count; i++)
            {
                System.Windows.Forms.Panel panel_value = new System.Windows.Forms.Panel(); ;
                System.Windows.Forms.Label label1 = new System.Windows.Forms.Label();
                System.Windows.Forms.Label label_value1 = new System.Windows.Forms.Label();
                listPanelValues.Add(panel_value);
                listLabelCriterias.Add(label1);
                listLabelValues.Add(label_value1);
                panel_values.Controls.Add(listPanelValues[i]);
            }

        }
        void drawLabelResults(int nb, Health_Status health)
        {
            List<Disease> diseases = health.getDiseases();
            try
            {
                for (int i = 0; i < results.Count; i++)
                {
                    this.panel_results.Controls.Remove(results[i]);
                }
                results.Clear();
                if (nb > diseases.Count)
                    nb = diseases.Count;
                for (int i = 0; i < nb; i++)
                {
                    System.Windows.Forms.Label label1 = new System.Windows.Forms.Label();
                    label1.AutoSize = true;
                    label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    label1.Location = new System.Drawing.Point(37, 68 + (50 * i));
                    label1.Name = "label" + i;
                    label1.Size = new System.Drawing.Size(119, 25);
                    label1.TabIndex = 5;
                    label1.Text = ""+ diseases[i].getName()+" - "+ Math.Round(diseases[i].getPercentage(),3)+"%";
                    results.Add(label1);
                    this.panel_results.Controls.Add(label1);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
        }
        void initPanelValues()
        {
            int space = 50;
            for (int i = 0; i < axes.Count; i++)
            {

                // panel_value
                // 
                listPanelValues[i].BackColor = System.Drawing.SystemColors.InactiveCaption;
                listPanelValues[i].Controls.Add(listLabelValues[i]);
                listPanelValues[i].Controls.Add(listLabelCriterias[i]);
                listPanelValues[i].Location = new System.Drawing.Point(2, 62 + (space * i));
                listPanelValues[i].Name = "panel_value" + i;
                listPanelValues[i].Size = new System.Drawing.Size(293, 46);
                listPanelValues[i].TabIndex = 5;

                // 
                // label1

                // 
                listLabelCriterias[i].AutoSize = false;
                listLabelCriterias[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                listLabelCriterias[i].Location = new System.Drawing.Point(18, 13);
                listLabelCriterias[i].Name = "label_criteria" + i;
                listLabelCriterias[i].Size = new System.Drawing.Size(80, 30);
                listLabelCriterias[i].TabIndex = 5;
                listLabelCriterias[i].Text = axes[i].getCriteria().getName();

                // 
                // label_value1
                // 
                listLabelValues[i].AutoSize = true;
                listLabelValues[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                listLabelValues[i].Location = new System.Drawing.Point(166, 13);
                listLabelValues[i].Name = "label_value" + i;
                listLabelValues[i].Size = new System.Drawing.Size(27, 20);
                listLabelValues[i].TabIndex = 6;
                listLabelValues[i].Text = (Math.Round(axes[i].getCriteria().getValue(),4)).ToString() + " " + axes[i].getCriteria().getUnit();
                // 
            }

        }
        void initComboBox()
        {
            for (int  i=1; i<8; i++)
            {
                comboBoxNumber.Items.Add(i);
            }
            comboBoxNumber.SelectedIndex = 3;
        }
        void refreshPanelValues()
        {
            for (int i = 0; i < axes.Count; i++)
            {
                listLabelValues[i].Text = (Math.Round(axes[i].getCriteria().getValue(), 4)).ToString() + " " + axes[i].getCriteria().getUnit();
            }
        }


        #endregion

        private System.Windows.Forms.Panel panel_background;
        private System.Windows.Forms.Panel panel_dataInsert;
        private System.Windows.Forms.Button button_analyse;
        private System.Windows.Forms.Panel panel_right;
        private System.Windows.Forms.Panel panel_values;
        private System.Windows.Forms.Label label_age;
        private System.Windows.Forms.TextBox textBox_age;
        private System.Windows.Forms.RadioButton radio_femme;
        private System.Windows.Forms.RadioButton radio_homme;
        private System.Windows.Forms.Panel panel_chart;
        private System.Windows.Forms.Panel panel_results;
        private System.Windows.Forms.Label label_results;
        private System.Windows.Forms.Label label_values;
        private List<System.Windows.Forms.Panel> listPanelValues;
        private List<System.Windows.Forms.Label> listLabelCriterias;
        private List<System.Windows.Forms.Label> listLabelValues;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxNumber;
    }
}

