﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medical_Analysis.Model
{
    class Health_Status:BaseModel
    {
        private int age;
        private int sex;
        private List<Criteria> criterias;
        private List<Disease> diseases;

        //Constructors
        public Health_Status(int newAge, int newSex, List<Criteria> newCriterias, List<Disease> newDiseases)
        {
            setAge(newAge);
            setSex(newSex);
            setCriterias(newCriterias);
            setDiseases(newDiseases);
        }

        //Setters
        public void setAge(int newAge)
        {
            if (newAge < 0)
                throw new Exception("Invalid Age");
            else
                age = newAge;
        }
        public void setSex(int newSexe)
        {
            if (newSexe == 1 || newSexe == 2)
                this.sex = newSexe;
            else
                throw new Exception("Invalid Sex");
        }
        public void setCriterias(List<Criteria> newCriterias)
        {
            if (newCriterias != null)
                this.criterias = newCriterias;
            else
                throw new Exception("Invalid Criterias");
        }
        public void setDiseases(List<Disease> newDiseases)
        {
            if (newDiseases != null)
                this.diseases = newDiseases;
            else
                throw new Exception("Empty Diseases List");
        }
        //Getters
        public int getAge()
        {
            return this.age;
        }
        public int getSex()
        {
            return this.sex;
        }
        public List<Criteria> getCriterias()
        {
            return this.criterias;
        }
        public List<Disease> getDiseases()
        {
            return this.diseases;
        }

        //Functions
        public List<Disease> orderDiseases(List<Disease> diseases)
        {
            List<Disease> ans = new List<Disease>();
            int nb = diseases.Count;
            for(int i=0; i<nb; i++)
            {
                Disease max = getMax(diseases);
                ans.Add(max);
                diseases.Remove(max);
            }
            return ans;
        }
        public Disease getMax(List<Disease> diseases)
        {
            
            Disease ans = diseases[0];
            
            for (int i = 0; i < diseases.Count; i++)
            {
                
                if (ans.getPercentage() < diseases[i].getPercentage())
                {
                    ans = diseases[i];
                }
            }
            return ans;
        }
    }
}
