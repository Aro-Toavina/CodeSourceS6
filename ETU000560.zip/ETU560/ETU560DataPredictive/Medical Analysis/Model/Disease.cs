﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medical_Analysis.Model
{
    class Disease : BaseModel
    {
        private string name;
        private int ageMin;
        private int ageMax;
        private double ageImpact;
        private double femaleImpact;
        private double maleImpact;
        private List<Criteria> conditions;
        private double percentage;

        //Constructors
        public Disease(string newId, string newName, List<Criteria> newConditions)
        {
            setId(newId);
            setName(newName);
            setConditions(newConditions);
        }
        public Disease(string newId, string newName, int newAgeMin, int newAgeMax, double newAgeImpact, double newFemaleImpact, double newMaleImpact)
        {
            setId(newId);
            setName(newName);
            setAgeMin(newAgeMin);
            setAgeMax(newAgeMax);
            setAgeImpact(newAgeImpact);
            setFemaleImpact(newFemaleImpact);
            setMaleImpact(newMaleImpact);
        }


        //Setters
        public void setPercentage(double newPercentage)
        {
            if (newPercentage < 0)
                throw new Exception("Invalid Percentage");

            else
            {
                if (newPercentage > 100)
                    newPercentage = 100;
                this.percentage = newPercentage;
            }
                
        }
        public void setName(string newName)
        {
            this.name = base.setString(newName);
        }
        public void setAgeMin(int newAgeMin)
        {
            this.ageMin = newAgeMin;
        }
        public void setAgeMax(int newAgeMax)
        {
            this.ageMax = newAgeMax;
        }
        public void setAgeImpact(double newAgeImpact)
        {
            this.ageImpact = newAgeImpact;
        }
        public void setFemaleImpact(double newFemaleImpact)
        {
            this.femaleImpact = newFemaleImpact;
        }
        public void setMaleImpact(double newMaleImpact)
        {
            this.maleImpact = newMaleImpact;
        }
        public void setConditions(List<Criteria> c)
        {
            this.conditions = c;
        }

        //Getters
        public double getPercentage()
        {
            return this.percentage;
        }
        public string getName()
        {
            return this.name;
        }
        public int getAgeMin()
        {
            return this.ageMin;
        }
        public int getAgeMax()
        {
            return this.ageMax;
        }
        public double getAgeImpact()
        {
            return this.ageImpact;
        }
        public double getFemaleImpact()
        {
            return this.femaleImpact;
        }
        public double getMaleImpact()
        {
            return this.maleImpact;
        }
        public List<Criteria> getConditions(List<Criteria> c)
        {
            return this.conditions;
        }

        //Functions
        public double getPercentage(Health_Status health)
        {
            double ans = 0;
            Console.WriteLine("Disease : " + name);
            Console.WriteLine("Nb of criterias : " + conditions.Count);
            for (int i =0;i<conditions.Count; i++)
            {
                Console.WriteLine(conditions.ElementAt(i).getName());
                ans = ans + getPercentage(conditions.ElementAt(i), health);
            }
            ans = ans / conditions.Count;
            Console.WriteLine("Percentage = " + ans);
            return ans;
        }
        public double getPercentage(Criteria conditionCrit, Health_Status health)
        {
            double ans = 0;
            Criteria valueCrit = conditionCrit.getSameCrit(health.getCriterias());
            if (conditionCrit.getType() == 1)
            {
                ans = getPercentage1(valueCrit, conditionCrit, health);
            }
            if (conditionCrit.getType() == 2)
            {
                ans = getPercentage2(valueCrit, conditionCrit, health);
            }
            if (conditionCrit.getType() == 3)
            {
                ans = getPercentage3(valueCrit, conditionCrit, health);
            }
            return ans;
        }
        public double getPercentage1(Criteria valueCrit, Criteria conditionCrit, Health_Status health)
        {
            Console.WriteLine("Percentage 1 ");
            double ans = 0;
            double delta = conditionCrit.getMaxValue() - conditionCrit.getMinValue();
            double difference = conditionCrit.getMaxValue() - valueCrit.getValue();
            Console.WriteLine("age de la personne : " + health.getAge());
            Console.WriteLine("age min : " + ageMax);
            Console.WriteLine("age max : " + ageMin);
            Console.WriteLine("valeur : " + valueCrit.getValue());
            Console.WriteLine("valeur max : " + conditionCrit.getMaxValue());
            Console.WriteLine("valeur min : " + conditionCrit.getMinValue());
            Console.WriteLine(health.getAge() <= ageMax && health.getAge() >= ageMin);
            Console.WriteLine(valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue());
            Console.WriteLine("Delta = " + delta);
            Console.WriteLine("Difference = " + difference);
            Console.WriteLine(ans);
            if (health.getAge() <= ageMax && health.getAge() >= ageMin)
            {
                if (valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue())
                {
                    Console.WriteLine(difference * 100 / delta);
                    ans = difference * 100 / delta;
                }
            }
            ans = ans * health.getAge() * ageImpact/3;
            Console.WriteLine(ans);
            if (health.getSex() == 1)
                ans = ans * maleImpact;
            else
                ans = ans * femaleImpact;
            Console.WriteLine(ans);
            return ans;
        }
        public double getPercentage2(Criteria valueCrit, Criteria conditionCrit, Health_Status health)
        {
            Console.WriteLine("Percentage 2 ");
            double ans = 0;
            double middle = (conditionCrit.getMaxValue() - conditionCrit.getMinValue())/2;
            double delta = Math.Abs(conditionCrit.getMaxValue() - middle);
            double difference = Math.Abs(valueCrit.getValue() - middle);
            Console.WriteLine("age de la personne : " + health.getAge());
            Console.WriteLine("age min : " + ageMax);
            Console.WriteLine("age max : " + ageMin);
            Console.WriteLine("valeur : " + valueCrit.getValue());
            Console.WriteLine("valeur max : " + conditionCrit.getMaxValue());
            Console.WriteLine("valeur min : " + conditionCrit.getMinValue());
            Console.WriteLine(health.getAge() <= ageMax && health.getAge() >= ageMin);
            Console.WriteLine(valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue());
            Console.WriteLine("Delta = " + delta);
            Console.WriteLine("Difference = " + difference);
            Console.WriteLine(ans);
            if (health.getAge() <= ageMax && health.getAge() >= ageMin)
            {
                if (valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue())
                {
                    ans = (difference * 100) / delta;
                }
            }
            ans = ans * health.getAge() * ageImpact /3;
            if (health.getSex() == 1)
                ans = ans * maleImpact;
            else
                ans = ans * femaleImpact;
            return ans;
        }
        public double getPercentage3(Criteria valueCrit, Criteria conditionCrit, Health_Status health)
        {
            Console.WriteLine("Percentage 3 ");
            double ans = 0;
            double delta = conditionCrit.getMaxValue() - conditionCrit.getMinValue();
            double difference = valueCrit.getValue() - conditionCrit.getMinValue();
            Console.WriteLine("age de la personne : " + health.getAge());
            Console.WriteLine("age min : " + ageMax);
            Console.WriteLine("age max : " + ageMin);
            Console.WriteLine("valeur : " + valueCrit.getValue());
            Console.WriteLine("valeur max : " + conditionCrit.getMaxValue());
            Console.WriteLine("valeur min : " + conditionCrit.getMinValue());
            Console.WriteLine(health.getAge() <= ageMax && health.getAge() >= ageMin);
            Console.WriteLine(valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue());
            Console.WriteLine("Delta = " + delta);
            Console.WriteLine("Difference = " + difference);
            Console.WriteLine(ans);
            if (health.getAge() <= ageMax && health.getAge() >= ageMin)
            {
                if (valueCrit.getValue() <= conditionCrit.getMaxValue() && valueCrit.getValue() >= conditionCrit.getMinValue())
                {
                    ans = (difference * 100) / delta;
                }
            }
            ans = ans * health.getAge() * ageImpact / 3;
            if (health.getSex() == 1)
                ans = ans * maleImpact;
            else
                ans = ans * femaleImpact;
            return ans;
        }

    }
}
