﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medical_Analysis.Model
{
    class Criteria : BaseModel
    {
        private string name;
        private double minValue;
        private double maxValue;
        private double defaultValue;
        private double normalValueMin;
        private double normalValueMax;
        private int type;
        private double value;
        private string unit;

        //Constructors
        public Criteria()
        {

        }
        public Criteria(string newName, double newMinValue, double newMaxValue, double newDefaultValue)
        {
            base.setId("CRIT", "seqIdCriteria");
            this.setName(newName);
            this.setMinValue(newMinValue);
            this.setMaxValue(newMaxValue);
            this.setDefaultValue(newDefaultValue);
            this.setValue(newDefaultValue);
        }
        public Criteria(string newId, string newName, double newMinValue, double newMaxValue, double newDefaultValue)
        {
            base.setId(newId);
            this.setName(newName);
            this.setMinValue(newMinValue);
            this.setMaxValue(newMaxValue);
            this.setDefaultValue(newDefaultValue);
            this.setValue(newDefaultValue);
        }
        public Criteria(string newId, string newName, double newMinValue, double newMaxValue, double newDefaultValue, double newNormalValueMin, double newNormalValueMax)
        {
            base.setId(newId);
            this.setName(newName);
            this.setMinValue(newMinValue);
            this.setMaxValue(newMaxValue);
            this.setDefaultValue(newDefaultValue);
            this.setNormalValueMin(newNormalValueMin);
            this.setNormalValueMax(newNormalValueMax);
            this.setValue(newDefaultValue);
        }
        public Criteria(string newId, string newName, double newMinValue, double newMaxValue, double newDefaultValue, double newNormalValueMin, double newNormalValueMax, string newUnit)
        {
            base.setId(newId);
            this.setName(newName);
            this.setMinValue(newMinValue);
            this.setMaxValue(newMaxValue);
            this.setDefaultValue(newDefaultValue);
            this.setNormalValueMin(newNormalValueMin);
            this.setNormalValueMax(newNormalValueMax);
            this.setValue(newDefaultValue);
            this.setUnit(newUnit);
        }

        //Setters
        public void setUnit(string newUnit)
        {
            this.unit = newUnit;
        }
        public void setValue(double newValue)
        {
            if (newValue > maxValue)
            {
                newValue = maxValue;
            }
            try
            {
                this.value = base.setDouble(newValue);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                this.value = minValue;
            }
            
        }
        public void setType(int newType)
        {
            this.type = newType;
        }
        public void setName(string newName)
        {
            Console.WriteLine("newName = "+ newName);
            this.name=base.setString(newName);
        }
        public void setMinValue(double newMinValue)
        {
            this.minValue=base.setDouble(newMinValue);
        }
        public void setMaxValue(double newMaxValue)
        {
            this.maxValue=base.setDouble(newMaxValue);
        }
        public void setDefaultValue(double newDefaultValue)
        {
            this.defaultValue=base.setDouble(newDefaultValue);
        }
        public void setNormalValueMin(double newNomalValueMin)
        {
            this.normalValueMin = base.setDouble(newNomalValueMin);
        }
        public void setNormalValueMax(double newNormalValueMax)
        {
            this.normalValueMax = base.setDouble(newNormalValueMax);
        }

        //Getters
        public double getValue()
        {
            return this.value;
        }
        public string getName()
        {
            return this.name;
        }
        public double getMinValue()
        {
            return this.minValue;
        }
        public double getMaxValue()
        {
            return this.maxValue;
        }
        public double getDefaultValue()
        {
            return this.defaultValue;
        }
        public double getNormalValueMin()
        {
            return this.normalValueMin;
        }
        public double getNormalValueMa()
        {
            return this.normalValueMax;
        }
        public int getType()
        {
            return this.type;
        }
        public string getUnit()
        {
            return this.unit;
        }
        public Criteria getSameCrit(List<Criteria> list)
        {
            Criteria ans = null;
            for(int i =0; i<list.Count; i++)
            {
                if (list[i].getId().Equals(this.getId()))
                {
                    ans = list[i];
                    break;
                }
            }
            return ans;
        }
        public void show()
        {
            Console.WriteLine(getId());
            Console.WriteLine(getName());
            Console.WriteLine(getMinValue());
            Console.WriteLine(getMaxValue());
            Console.WriteLine(getDefaultValue());

        }
    }
}
