﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Medical_Analysis.Connexion;

namespace Medical_Analysis.Model
{
    class BaseModel
    {
        private string id;

        //Constructors
        public BaseModel()
        {

        }

        //Setters
        public void setId(string idNew)
        {
            if (idNew == "")
                throw new Exception("Id invalide");
            else
                id = idNew;
        }


        //Getters
        public string getId()
        {
            return this.id;
        }

        //Functions
        public int setInt(int nb)
        {
            if (nb < 0)
                throw new Exception("Invalid Number");
            else
                return nb;
        }
        public double setDouble(double nb)
        {
            if (nb < 0)
                throw new Exception("Invalid Number");
            else
                return nb;
        }
        public string setString(string s)
        {
            if (s.Equals(""))
                throw new Exception("Invalid String");
            else
                return s;
        }
        public void setId(string predicat, string sequence)
        {
            id = getId(predicat, getId(sequence));
        }
        private string getId(string sequence)
        {
            string id = null;
            SqlConnection myConnection = null;
            SqlDataReader readdata = null;
            SqlCommand cmd = null;
            try
            {
                myConnection = new Connection().Connecter();
                myConnection.Open();
                String querry = "select next value for " + sequence;
                cmd = new SqlCommand(querry, myConnection);
                id = cmd.ExecuteScalar().ToString();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (readdata != null)
                    readdata.Close();
                if (cmd != null)
                    cmd.Dispose();
                if (myConnection != null)
                    myConnection.Close();
            }
            return id;
        }
        private string getId(string predicat, string id)
        {
            string idAns = null;
            switch (id.Length)
            {
                case 1:
                    idAns = predicat + "000" + id;
                    break;
                case 2:
                    idAns = predicat + "00" + id;
                    break;
                case 3:
                    idAns = predicat + "0" + id;
                    break;
                case 4:
                    idAns = predicat + id;
                    break;
            }
            if (id.Length > 4)
            {
                throw new Exception("id invalide");
            }
            return idAns;
        }
    }
}
