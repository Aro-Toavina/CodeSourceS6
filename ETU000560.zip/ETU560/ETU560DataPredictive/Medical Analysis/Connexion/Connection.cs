﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Medical_Analysis.Connexion
{
    class Connection
    {
        private SqlConnection _connex;


        public SqlConnection connex
        {

            get { return _connex; }
            set { _connex = value; }
        }

        public static void afficher(String msg) { Console.Out.WriteLine(msg); }
        public static void affichererreur(String msg) { Console.Error.WriteLine(msg); }


        public SqlConnection Connecter()
        {

            string connetionString = null;
            connetionString = "Data Source=(localdb)\\ProjectsV13;Initial Catalog=Analysis;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";


            try
            {
                _connex = new SqlConnection(connetionString);
                afficher("connexion etablie!");
                return _connex;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Can not open connection to the server ! ");
                affichererreur("Can't connect " + ex.Message);
            }


            return _connex;
        }
    }
}
