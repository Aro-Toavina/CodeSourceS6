﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medical_Analysis
{
    public class Point
    {
        int x;
        int y;
        public static int size = 10;

        //Constructors
        public Point()
        {

        }
        public Point(int newX, int newY)
        {
            setX(newX);
            setY(newY);
        }

        //Setters
        public void setX(int newX)
        {
            this.x = setNum(newX);
        }
        public void setY(int newY)
        {
            this.y = setNum(newY);
        }
        //Getters
        public int getX()
        {
            return this.x;
        }
        public int getY()
        {
            return this.y;
        }
        //Functions
        public int setNum(int num)
        {
            if (num < 0)
                return num;//throw new Exception("Invalid number");
            else
                return num;
        }
        public void show()
        {
            Console.WriteLine("X : " + x + "  Y : " + y);
        }
        public Boolean isSelected(Point p, int x, int y)
        {
            bool ans = false;
            if(x<=p.getX()+(size/2) && x >= p.getX() - (size / 2))
            {
                if(y<=p.getY()+(size/2) && y >= p.getY() - (size / 2))
                {
                    ans = true;
                }
            }
            return ans;
        }
        public Point getPointSelected(List<Point> listPoints, int x, int y)
        {
            Point ans = null;
            for (int i=0; i<listPoints.Count; i++)
            {
                Point p = listPoints.ElementAt(i);
                if (isSelected(p, x, y))
                    ans = p;
            }
            return ans;
        }
        public bool isEqual(Point p)
        {
            bool ans = false;
            if (Math.Abs(this.getX()-p.getX())<(size/2) && Math.Abs(this.getY()-p.getY())<(size/2))
                ans = true;
            return ans;
        }
    }
}
