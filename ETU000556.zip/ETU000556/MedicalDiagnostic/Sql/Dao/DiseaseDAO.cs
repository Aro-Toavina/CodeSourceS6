﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; // Use ADO.NET namespace
using System.Data.SqlClient; // Use SQL Server data provider namespace

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql;

namespace MedicalDiagnostic.Sql.Dao
{
    public class DiseaseDAO : BaseDAO<Disease>
    {
        public DiseaseDAO()
        {
            base.tableName = "disease";
        }

        public override List<Disease> List(string condition)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Disease> val = new List<Disease>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "SELECT * FROM " + base.tableName;
                if (condition != null)
                    query = query + " WHERE " + condition;
                SqlDataReader rdr = mscon.ExecuteReader(query);
                while (rdr.Read())
                {
                    List<AgeStats> ageStats = new AgeStatsDAO().ListByDisease((string)rdr["id"]);
                    val.Add(new Disease((string)rdr["id"], (string)rdr["name"], ageStats));
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                mscon.CloseReader();
            }
            return val;
        }

        public override void Insert(Disease obj)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Disease> val = new List<Disease>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                AgeStatsDAO aStatsDAO = new AgeStatsDAO();
                obj.Id = DBUtil.NextId("disease_seq", "DIS", 10);
                foreach (var item in obj.AgeStats)
                {
                    aStatsDAO.Insert(item);
                }
                string query = "INSERT INTO " + tableName + " (id, name) VALUES ('" + obj.Id + "', '" + obj.Name + "')";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }

        public new void Delete(string id)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "DELETE FROM composant WHERE age_stats_id IN (SELECT id FROM age_stats WHERE disease_id='" + id + "')";
                mscon.ExecuteNonQuery(query);
                query = "DELETE FROM age_stats WHERE disease_id='" + id + "'";
                mscon.ExecuteNonQuery(query);
                query = "DELETE FROM " + tableName + " WHERE id='" + id + "'";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }
    }

    public class DimensionDAO : BaseDAO<Dimension>
    {
        public DimensionDAO()
        {
            base.tableName = "dimension";
        }

        public override List<Dimension> List(string condition)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "SELECT * FROM " + base.tableName;
                if (condition != null)
                    query = query + " WHERE " + condition;
                SqlDataReader rdr = mscon.ExecuteReader(query);
                while (rdr.Read())
                {
                    val.Add(new Dimension((string)rdr["id"], (string)rdr["name"], (double)rdr["low"], (double)rdr["high"], (string)rdr["unit"]));
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                mscon.CloseReader();
            }
            return val;
        }

        public override void Insert(Dimension obj)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "INSERT INTO "+ tableName +" (id, name, low, high, unit) VALUES ('" + obj.Id + "', '" + obj.Name + "', " + obj.Low + ", "+ obj.High +", '"+ obj.Unit +"')";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }

        public new void Delete(string id)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "DELETE FROM composant WHERE dimension_id='" + id + "'";
                mscon.ExecuteNonQuery(query);
                query = "DELETE FROM " + tableName + " WHERE id='" + id + "'";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }
    }

    public class AgeStatsDAO : BaseDAO<AgeStats>
    {
        public AgeStatsDAO()
        {
            base.tableName = "age_stats";
        }

        public override List<AgeStats> List(string condition)
        {
            MedicalDiagnosticConnection mscon = null;
            List<AgeStats> val = new List<AgeStats>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "SELECT * FROM " + base.tableName;
                if (condition != null)
                    query = query + " WHERE " + condition;
                SqlDataReader rdr = mscon.ExecuteReader(query);
                while (rdr.Read())
                {
                    val.Add(new AgeStats((string)rdr["id"], (string)rdr["disease_id"], (int?)rdr["low_age"], (int?)rdr["high_age"], new GenderUtil().ToGender((int)rdr["gender"]), new ComposantDAO().ListByAgeStats((string)rdr["id"])));
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                mscon.CloseReader();
            }
            return val;
        }

        public List<AgeStats> ListByDisease(String id)
        {
            return List("disease_id='"+id+"'");
        }

        public bool IsFreeAge(AgeStats obj)
        {
            MedicalDiagnosticConnection mscon = null;
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "SELECT * FROM " + base.tableName + " WHERE disease_id='"+obj.Disease+"' and gender="+(int)obj.Gender+" and (("+obj.LowAge+ " between low_age and high_age) or (" + obj.HighAge + " between low_age and high_age) or (low_age between " + obj.LowAge + " and " + obj.HighAge + "))";
                SqlDataReader rdr = mscon.ExecuteReader(query);
                if (rdr.Read())
                    return false;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
            return true;
        }

        public override void Insert(AgeStats obj)
        {
            MedicalDiagnosticConnection mscon = null;
            try
            {
                if (!IsFreeAge(obj))
                    throw new ArgumentException("OUPS!!!! Cette tranche d'age coincide avec une tranche existente");
                mscon = new MedicalDiagnosticConnection();
                obj.Id = DBUtil.NextId("age_stats_seq", "AGE", 10);
                string query = "INSERT INTO " + tableName + " (id, disease_id, low_age, high_age, gender) VALUES ('"+obj.Id+"', '"+obj.Disease+"', "+obj.LowAge+", "+obj.HighAge+", "+(int)obj.Gender+")";
                mscon.ExecuteNonQuery(query);
                ComposantDAO composantDAO = new ComposantDAO();
                List<Dimension> dimensions = new DimensionDAO().ListAll();
                foreach (var dimension in dimensions)
                {
                    composantDAO.Insert(new Composant(null, obj.Id, dimension.Id, dimension.Low, 0, 0, 0));
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }

        public new void Delete(string id)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "DELETE FROM composant WHERE age_stats_id='" + id + "'";
                mscon.ExecuteNonQuery(query);
                query = "DELETE FROM " + tableName + " WHERE id='" + id + "'";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }
    }

    public class ComposantDAO : BaseDAO<Composant>
    {
        public ComposantDAO()
        {
            base.tableName = "composant";
        }

        public override List<Composant> List(string condition)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Composant> val = new List<Composant>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "SELECT * FROM " + base.tableName;
                if (condition != null)
                    query = query + " WHERE " + condition;
                SqlDataReader rdr = mscon.ExecuteReader(query);
                while (rdr.Read())
                {
                    val.Add(new Composant((string)rdr["id"], (string)rdr["age_stats_id"], (string)rdr["dimension_id"], (double)rdr["val"], (double)rdr["dimension_coeff"], (double)rdr["asc_exponential_coeff"], (double)rdr["desc_exponential_coeff"]));
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                mscon.CloseReader();
            }
            return val;
        }

        public List<Composant> ListByAgeStats(String id)
        {
            return List("age_stats_id='" + id + "'");
        }

        public override void Insert(Composant obj)
        {
            MedicalDiagnosticConnection mscon = null;
            try
            {
                mscon = new MedicalDiagnosticConnection();
                obj.Id = DBUtil.NextId("composant_seq", "CMP", 10);
                string query = "INSERT INTO " + tableName + " (id, age_stats_id, dimension_id, val, dimension_coeff, asc_exponential_coeff, desc_exponential_coeff) VALUES ('" + obj.Id + "', '" + obj.AgeStats + "', '" + obj.Dimension + "', "+obj.Val+", " + obj.DimensionCoeff + ", " + obj.AscExponentialCoeff + ", " + obj.DescExponentialCoeff + ")";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }

        public void Update(Composant obj)
        {
            MedicalDiagnosticConnection mscon = null;
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "UPDATE " + tableName + " SET val="+obj.Val+", dimension_coeff="+obj.DimensionCoeff+", asc_exponential_coeff="+obj.AscExponentialCoeff+", desc_exponential_coeff="+obj.DescExponentialCoeff+"  WHERE id='"+obj.Id+"'";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }
    }

    public abstract class BaseDAO<T> : IDAO<T>
    {
        protected string tableName = "";

        public abstract List<T> List(string condition);

        public List<T> ListAll()
        {
            return List(null);
        }

        public T Get(string id)
        {
            List<T> liste = List("id='" + id + "'");
            if (liste == null)
                return default(T);
            if (liste.Count == 1)
                return liste.ElementAt(0);
            return default(T);
        }

        public abstract void Insert(T obj);

        public void Delete(string id)
        {
            MedicalDiagnosticConnection mscon = null;
            List<Dimension> val = new List<Dimension>();
            try
            {
                mscon = new MedicalDiagnosticConnection();
                string query = "DELETE FROM " + tableName + " WHERE id='" + id + "'";
                mscon.ExecuteNonQuery(query);
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                ;
            }
        }
    }
}
