﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; // Use ADO.NET namespace
using System.Data.SqlClient; // Use SQL Server data provider namespace

namespace MedicalDiagnostic.Sql
{
    class MSSQLConnection
    {
        public string server { get; set; }
        public string uid { get; set; }
        public string pwd { get; set; }
        public string db { get; set; }

        public SqlConnection Connection { get; set; }
        public SqlDataReader rdr { get; set; }

        public MSSQLConnection(string s, string u, string p, string d)
        {
            server = s; uid = u; pwd = p; db = d;
            this.Connection = new SqlConnection(ConnectionString());
        }

        // The user of the function has to close the reader and connection manually (by calling CloseReader())
        public SqlDataReader ExecuteReader(string query)
        {
            OpenConnection();
            SqlCommand thisCommand = Connection.CreateCommand();
            thisCommand.CommandText = query;
            rdr = thisCommand.ExecuteReader();
            return rdr;
        }

        public void CloseReader()
        {
            rdr.Close();
            CloseConnection();
        }

        public int ExecuteScalar(string query)
        {
            int result = -1;
            try
            {
                OpenConnection();
                SqlCommand thisCommand = this.Connection.CreateCommand();
                thisCommand.CommandText = query;
                result = (int)thisCommand.ExecuteScalar();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
            }

            return result;
        }

        public int ExecuteNonQuery(string query)
        {
            int rowsAffected = -1;
            try
            {
                OpenConnection();
                SqlCommand thisCommand = this.Connection.CreateCommand();
                thisCommand.CommandText = query;
                rowsAffected = thisCommand.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                CloseConnection();
            }
            return rowsAffected;
        }

        public string ConnectionString()
        {
            return @"Data Source=" + server + ";Initial Catalog=" + db + ";User ID=" + uid + ";Password=" + pwd;
        }

        private void OpenConnection()
        {
            // should test that the connection is closed
            this.Connection.Open();
        }
        private void CloseConnection()
        {
            // should test that the connection is opened
            this.Connection.Close();
        }
    }

    public class DBUtil
    {
        public static string NextId(string sequence, string prefix, int length)
        {
            if (length < prefix.Length)
                throw new ArgumentException("Id length is too small");
            MSSQLConnection mscon = new MedicalDiagnosticConnection();
            string next = mscon.ExecuteScalar("select next value for " + sequence) + "";
            int idLen = length - prefix.Length;
            for (int curlen = next.Length; curlen < idLen; curlen++)
                next = "0" + next;
            return prefix + next;
        }
    }

    class MedicalDiagnosticConnection : MSSQLConnection
    {
        public MedicalDiagnosticConnection() :
            base("127.0.0.1", "sa", "root", "medical_diagnostic")
        {
        }
    }
}
