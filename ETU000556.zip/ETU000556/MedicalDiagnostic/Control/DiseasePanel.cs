﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class DiseasePanel : UserControl
    {
        private List<Dimension> dimensions;
        private List<Disease> diseases;

        public UserControl NewDiagnosticControl { get; set; }
        public UserControl AllDiagnosticControl { get; set; }

        public DiseasePanel(List<Dimension> dimensions, List<Disease> diseases)
        {
            this.dimensions = dimensions;
            this.diseases = diseases;
            InitControls();
            InitializeComponent();
        }

        private void InitControls()
        {
            NewDiagnosticControl = new NewDiagnosticControl(this.dimensions, this.diseases);
            AllDiagnosticControl = null;
        }

        private void newMenuLbl_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(newMenuLbl);
        }

        private void newMenuLbl_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(newMenuLbl);
        }

        private void newMenuLbl_Click(object sender, EventArgs e)
        {
            ShowTab(DiseaseTabType.All, null);
        }

        private void LabelMenuMouseHover(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlText;
        }
        private void LabelMenuMouseLeave(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
        }

        private void ShowTab(DiseaseTabType type, object param)
        {
            UserControl control = null;
            switch (type)
            {
                case DiseaseTabType.All:
                    control = new DiseaseListControl(this.diseases, this, (string)param);
                    label3.Visible = true;
                    break;
                case DiseaseTabType.Details:
                    if (param != null)
                    {
                        control = new DiseaseDetailControl(this, this.diseases.ElementAt((int)param), (int)param);
                        label3.Visible = false;
                    }
                    break;
                case DiseaseTabType.Composant:
                    int[] parameters = (int[])param;
                    control = new DiseaseComposantControl(this.dimensions, this.diseases.ElementAt(parameters[0]).AgeStats.ElementAt(parameters[1]));
                    label3.Visible = false;
                    break;
                default:
                    break;
            }
            panel1.Controls.Clear();
            panel1.Controls.Add(control);
        }

        public void ShowDetails(int index)
        {
            ShowTab(DiseaseTabType.Details, index);
        }

        public void ShowComposants(int indexDisease, int indexAgeStats)
        {
            ShowTab(DiseaseTabType.Composant, new int[] { indexDisease, indexAgeStats});
        }

        public void ReloadDisease(int? index)
        {
            new ListUtil<Disease>().CopyInto(new DiseaseDAO().ListAll(), diseases);
            if (index != null)
                ShowDetails((int)index);
            else
                ShowTab(DiseaseTabType.All, null);
        }

        private void allMenuLbl_MouseDown(object sender, MouseEventArgs e)
        {
            ShowDialog(e, "Liste des diagnostics enregistres");
        }

        private void allMenuLbl_MouseUp(object sender, MouseEventArgs e)
        {
            HideDialog();
        }

        private void ShowDialog(MouseEventArgs e, string message)
        {
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            label1.Name = "label";
            label1.Size = new System.Drawing.Size(100, 23);
            label1.Text = message;
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.Visible = true;
        }
        private void HideDialog()
        {
            label1.Visible = false;
        }

        private void allMenuLbl_MouseMove(object sender, MouseEventArgs e)
        {
            //label1.Location = new Point(e.X + label1.Location.X, e.Y + label1.Location.Y - 20);
        }
    }

    public enum DiseaseTabType
    {
        All = 0,
        Details = 1,
        Composant = 2
    }
}
