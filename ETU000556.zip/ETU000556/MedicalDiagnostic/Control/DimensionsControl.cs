﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Use SQL Server data provider namespace

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class DimensionsControl : UserControl
    {
        public List<Dimension> Dimensions { get; set; }

        public DimensionsControl(List<Dimension> dimensions)
        {
            this.Dimensions = dimensions;
            InitializeComponent();
            ShowPanelList();
        }

        private void ShowPanelList()
        {
            this.SuspendLayout();
            int u = 0;
            foreach (var item in Dimensions)
            {
                Panel panel = new Panel();
                if (u % 2 == 0)
                    panel.BackColor = System.Drawing.SystemColors.ButtonFace;
                else
                    panel.BackColor = Color.White;
                int i = u;
                panel.Size = new System.Drawing.Size(919, 55);
                panel.Location = new System.Drawing.Point(26, 19 + panel.Size.Height * i);
                panel.Name = "panel";
                panel.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                panel.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));

                Label lbl1 = new Label();
                lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                lbl1.Location = new System.Drawing.Point(30, 0);
                lbl1.Name = "lbl1";
                lbl1.Size = new System.Drawing.Size(252, 55);
                lbl1.TabIndex = 0;
                lbl1.Text = item.Name;
                lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                lbl1.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                lbl1.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                panel.Controls.Add(lbl1);

                Label lbl2 = new Label();
                lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                lbl2.Location = new System.Drawing.Point(288, 0);
                lbl2.Name = "label4";
                lbl2.Size = new System.Drawing.Size(91, 55);
                lbl2.TabIndex = 1;
                lbl2.Text = item.Id;
                lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                lbl2.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                lbl2.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                panel.Controls.Add(lbl2);

                Label lbl3 = new Label();
                lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                lbl3.Location = new System.Drawing.Point(408, 0);
                lbl3.Name = "label5";
                lbl3.Size = new System.Drawing.Size(219, 55);
                lbl3.TabIndex = 2;
                lbl3.Text = item.Low + " - " + item.High + " " + item.Unit;
                lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                lbl3.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                lbl3.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                panel.Controls.Add(lbl3);

                LinkLabel linkLbl = new LinkLabel();
                linkLbl.AutoSize = true;
                linkLbl.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                linkLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                linkLbl.Location = new System.Drawing.Point(741, 20);
                linkLbl.Name = "linkLabel1";
                linkLbl.Size = new System.Drawing.Size(73, 17);
                linkLbl.TabIndex = 3;
                linkLbl.TabStop = true;
                linkLbl.Text = "Supprimer";
                linkLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                linkLbl.UseWaitCursor = true;
                linkLbl.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                linkLbl.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                linkLbl.MouseClick += new System.Windows.Forms.MouseEventHandler((object sender, MouseEventArgs e) => DeleteDimension(i));
                panel.Controls.Add(linkLbl);

                this.panel1.Controls.Add(panel);
                u++;
            }
            this.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void PanelMenuMouseHover(Panel panel)
        {
            panel.BackColor = System.Drawing.SystemColors.ControlLight;
        }
        private void PanelMenuMouseLeave(Panel panel, int i)
        {
            if (i % 2 == 0)
                panel.BackColor = System.Drawing.SystemColors.ButtonFace;
            else
                panel.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string id = textBox2.Text;
            double low = (double)numericUpDown1.Value;
            double high = (double)numericUpDown2.Value;
            string unit = textBox3.Text;
            try
            {
                Dimension dimension = new Dimension(id, name, low, high, unit);
                DimensionDAO dimensionDAO = new DimensionDAO();
                dimensionDAO.Insert(dimension);
                ReloadDimension();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ReloadDimension()
        {
            new ListUtil<Dimension>().CopyInto(new DimensionDAO().ListAll(), Dimensions);
            this.panel1.Controls.Clear();
            ShowPanelList();
        }

        private void DeleteDimension(int index)
        {
            if (index < 0 || index >= Dimensions.Count)
                return;
            DimensionDAO dao = new DimensionDAO();
            dao.Delete(Dimensions.ElementAt(index).Id);
            ReloadDimension();
        }
    }
}
