﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class NewDiagnosticControl : UserControl
    {
        private List<Dimension> dimensions;
        private List<Disease> diseases;

        private RadarControl radarControl1;

        public NewDiagnosticControl(List<Dimension> dimensions, List<Disease> diseases)
        {
            this.dimensions = dimensions;
            this.diseases = diseases;
            radarControl1 = new RadarControl(this, dimensions);
            InitializeComponent();
            AddRadar();
        }

        public void AddRadar()
        {
            this.SuspendLayout();
            this.radarControl1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.radarControl1.Location = new System.Drawing.Point(3, 3);
            this.radarControl1.Name = "radarControl1";
            this.radarControl1.Size = new System.Drawing.Size(570, 570);
            this.radarControl1.TabIndex = 5;
            this.panel3.Controls.Add(this.radarControl1);
            this.ResumeLayout(false);
        }

        private void maleCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (maleCheckBox.Checked == true)
                femaleCheckBox.Checked = false;
            else
                femaleCheckBox.Checked = true;
        }

        private void femaleCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (femaleCheckBox.Checked == true)
                maleCheckBox.Checked = false;
            else
                maleCheckBox.Checked = true;
        }

        private void SetPodiumLabels(DiseasePercentage dPer)
        {
            panel4.Controls.Clear();
            for (int i = 0; i < dPer.Disease.Count && i < 3; i++)
            {
                Disease disease = dPer.Disease.ElementAt(i);
                double value = dPer.Percentage.ElementAt(i);

                Label disease3Lbl = new Label();
                disease3Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                disease3Lbl.Location = new System.Drawing.Point(149, 10 + 50 * i);
                disease3Lbl.Name = "disease3Lbl";
                disease3Lbl.Size = new System.Drawing.Size(215, 23);
                disease3Lbl.TabIndex = 5;
                disease3Lbl.Text = "" + disease.Name;
                panel4.Controls.Add(disease3Lbl);

                Label label5 = new Label();
                label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                label5.Location = new System.Drawing.Point(18, 10 + 50 * i);
                label5.Name = "label5";
                label5.Size = new System.Drawing.Size(100, 23);
                label5.TabIndex = 2;
                label5.Text = (int)value+" %";
                panel4.Controls.Add(label5);
            }
        }

        private void SetLabels(DiseasePercentage dPer)
        {
            panel5.Controls.Clear();
            for (int i=3; i<dPer.Disease.Count;i++)
            {
                Disease disease = dPer.Disease.ElementAt(i);
                double value = dPer.Percentage.ElementAt(i);

                Panel panel6 = new Panel();
                panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
                panel6.Location = new System.Drawing.Point(4, 4 + 32 * i);
                panel6.Name = "panel6";
                panel6.Size = new System.Drawing.Size(380, 32);
                panel6.TabIndex = 0;

                Label label6 = new Label();
                label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                label6.Location = new System.Drawing.Point(18, 4);
                label6.Name = "label6";
                label6.Size = new System.Drawing.Size(100, 23);
                label6.TabIndex = 0;
                label6.Text = (int)value+" %";
                label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                panel6.Controls.Add(label6);

                Label label7 = new Label();
                label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                label7.Location = new System.Drawing.Point(149, 4);
                label7.Name = "label6";
                label7.Size = new System.Drawing.Size(100, 23);
                label7.TabIndex = 0;
                label7.Text = "" + disease.Name;
                label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                panel6.Controls.Add(label7);

                panel5.Controls.Add(panel6);
            }
        }

        public void GetValues()
        {
            List<double> values = this.radarControl1.DimensionValues();
            Gender gender = Gender.Male;
            if (femaleCheckBox.Checked == true)
                gender = Gender.Female;
            int age = (int)numericUpDown1.Value;
            List<double> percentage = new Disease(null, null, null).Percentage(gender, age, values, dimensions, diseases);
            /*foreach (var item in percentage)
            {
                MessageBox.Show("pourcentage = " + item);
            }*/
            DiseasePercentage dPer = new DiseasePercentage(diseases, percentage);
            new CompareDisease().ReorderListDesc(dPer);

            //disease1Lbl.Text = dPer.Disease.ElementAt(0).Name;
            //label3.Text = dPer.Percentage.ElementAt(0) + "";
            SetPodiumLabels(dPer);
            SetLabels(dPer);
        }
    }

    public class CompareDisease
    {
        public void ReorderListDesc(DiseasePercentage dPer)
        {
            for (int i = 0; i < dPer.Disease.Count; i++)
            {
                double max = dPer.Percentage.ElementAt(i);
                for (int u = i; u < dPer.Disease.Count; u++)
                {
                    if (dPer.Percentage.ElementAt(u) > max)
                    {
                        max = dPer.Percentage.ElementAt(u);
                        double old = dPer.Percentage.ElementAt(i);
                        double tmpPer = dPer.Percentage.ElementAt(u);
                        dPer.Percentage.RemoveAt(u);
                        dPer.Percentage.Insert(u, old);
                        dPer.Percentage.RemoveAt(i);
                        dPer.Percentage.Insert(i, tmpPer);
                        Disease oldD = dPer.Disease.ElementAt(i);
                        Disease tmpD = dPer.Disease.ElementAt(u);
                        dPer.Disease.RemoveAt(u);
                        dPer.Disease.Insert(u, oldD);
                        dPer.Disease.RemoveAt(i);
                        dPer.Disease.Insert(i, tmpD);
                    }
                }
            }
        }
    }

    public class DiseasePercentage
    {
        public List<Disease> Disease { get; set; }
        public List<double> Percentage { get; set; }

        public DiseasePercentage(List<Disease> disease, List<double> percentage)
        {
            this.Disease = disease;
            this.Percentage = percentage;
        }
    }
}
