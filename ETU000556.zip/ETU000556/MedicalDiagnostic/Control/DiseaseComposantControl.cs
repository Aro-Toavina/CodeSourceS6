﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.SqlClient; // Use SQL Server data provider namespace
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class DiseaseComposantControl : UserControl
    {
        private List<Dimension> dimensions;
        private AgeStats ageStats;


        private ComposantRadarControl radarControl1;
        private int? Index = null;

        public DiseaseComposantControl(List<Dimension> dimensions, AgeStats ageStats)
        {
            this.dimensions = dimensions;
            this.ageStats = ageStats;
            radarControl1 = new ComposantRadarControl(this, dimensions, ageStats);
            InitializeComponent();
            AddRadar();
        }

        public void AddRadar()
        {
            this.SuspendLayout();
            this.radarControl1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.radarControl1.Location = new System.Drawing.Point(3, 3);
            this.radarControl1.Name = "radarControl1";
            this.radarControl1.Size = new System.Drawing.Size(570, 570);
            this.radarControl1.TabIndex = 5;
            this.panel3.Controls.Add(this.radarControl1);
            this.ResumeLayout(false);
        }

        public void SetLabels(int index)
        {
            if (index < 0 || index >= dimensions.Count)
                return;
            Dimension dimension = dimensions.ElementAt(index);
            label1.Text = dimension.Name + " ("+radarControl1.DimensionValue(index)+")";
            this.Index = index;

            numericUpDown1.Value = (decimal)this.ageStats.Composant.ElementAt((int)Index).DimensionCoeff;
            numericUpDown2.Value = (decimal)this.ageStats.Composant.ElementAt((int)Index).AscExponentialCoeff;
            numericUpDown3.Value = (decimal)this.ageStats.Composant.ElementAt((int)Index).DescExponentialCoeff;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Index == null)
                return;
            Composant composant = this.ageStats.Composant.ElementAt((int)Index);
            composant.Val = radarControl1.DimensionValue((int)Index);
            composant.DimensionCoeff = (double)numericUpDown1.Value;
            composant.AscExponentialCoeff = (double)numericUpDown2.Value;
            composant.DescExponentialCoeff = (double)numericUpDown3.Value;
            try
            {
                new ComposantDAO().Update(composant);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
