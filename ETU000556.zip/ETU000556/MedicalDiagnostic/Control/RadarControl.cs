﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;

namespace MedicalDiagnostic.Control
{
    public partial class RadarControl : UserControl
    {
        private List<Line> Lines = new List<Line>();
        private List<Point> Points = new List<Point>();
        private List<Label> Labels = new List<Label>();
        private List<Dimension> Dimensions;
        private NewDiagnosticControl NewDiagnostic;

        private const int PointRay = 5;
        private const int RadarRay = 250;
        private const int MinPointPos = 50;

        public int? clickedIndex = null;

        public RadarControl(NewDiagnosticControl newDiagnostic, List<Dimension> dimensions)
        {
            this.NewDiagnostic = newDiagnostic;
            this.Dimensions = dimensions;
            InitLabels();
            InitializeComponent();
        }

        private int NbAxes()
        {
            return Dimensions.Count;
        }

        
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            /* BUG: when using these functions, all the labels disappeear after minimizing
             */
            //HideLabels();
            //ShowLabels();
            if (Lines.Count != Dimensions.Count || Points.Count != Dimensions.Count)
            {
                Lines.Clear(); Points.Clear();
                DrawAllLines(true, true);
                SetLabels(true);
            }
            else
            {
                SetLabels(false);
                DrawAllLines(false, false);
            }
        }

        private void RadarControl_Paint(object sender, PaintEventArgs e)
        {
            //this.CreateGraphics().DrawLine(new Pen(Color.Black), new Point(this.Size.Width/2, this.Size.Height/2), new Point(200, 200));
            //DrawAllLines(false, false);
        }

        public List<double> DimensionValues()
        {
            List<double> values = new List<double>();
            for (int i = 0; i < Dimensions.Count; i++)
            {
                values.Add(DimensionValue(i));
            }
            return values;
        }

        public double DimensionValue(int index)
        {
            if (index < 0 || index >= Dimensions.Count)
                throw new ArgumentException("Index out of range");
            Dimension dimension = Dimensions.ElementAt(index);
            Point point = Points.ElementAt(index);
            GeometryUtil geom = new GeometryUtil();
            double norm = geom.Norm(new Point(this.Size.Width/2, this.Size.Height/2), point) - MinPointPos;
            double res = norm * (dimension.High - dimension.Low) / (RadarRay - MinPointPos);
            // double operation so exact value should not be expected
            if (res < dimension.Low)
                res = dimension.Low;
            else if ((res > dimension.High) || (dimension.High - res < .05))
                res = dimension.High;
            return res;
        }

        private void RadarControl_MouseClick(object sender, MouseEventArgs e)
        {
            //double mouseAngle = new GeometryUtil().AngleBetweenPoints(new Point(0, 0),
            //        new Point(0, 100), new Point(e.X- this.Size.Width / 2, e.Y- this.Size.Height / 2));
            //MessageBox.Show("norme is  " + mouseAngle);
            //RedrawLine(0, new Line(this.Size.Width / 2, this.Size.Height / 2, e.X, e.Y), DashedPen());
            /*RedrawLine(0, new Line(this.Size.Width / 2, this.Size.Height / 2, (float)0.0, 200));
            RedrawLine(0, new Line(this.Size.Width / 2, this.Size.Height / 2, (float)90.0, 200));
            RedrawLine(0, new Line(this.Size.Width / 2, this.Size.Height / 2, (float)180.0, 200));
            */
            //DrawAllLines(false, false);
        }

        private void FindClickedIndex(MouseEventArgs e)
        {
            clickedIndex = null;
            int i = 0;
            foreach (var item in Points)
            {
                if (Math.Abs(item.X - e.X) < PointRay && Math.Abs(item.Y - e.Y) < PointRay)
                {
                    clickedIndex = i; return;
                }
                i++;
            }
        }

        private void ShowLabels()
        {
            this.SuspendLayout();
            foreach (var item in this.Labels)
            {
                item.Visible = true;
            }
        }

        private void HideLabels()
        {
            foreach (var item in this.Labels)
            {
                item.Visible = false;
            }
        }

        private void InitLabels()
        {
            foreach (var item in Dimensions)
            {
                Label tmp = new Label();
                this.Labels.Add(tmp);
            }
        }

        private void SetLabels(bool add)
        {
            for (int i = 0; i < Labels.Count; i++)
            {
                Label tmp = Labels.ElementAt(i);
                Dimension dimension = Dimensions.ElementAt(i);
                //tmp.AutoSize = true;
                tmp.AutoSize = false;
                //tmp.TextAlign = ContentAlignment.MiddleCenter;
                tmp.Size = new Size(200, 10);
                Line line = Lines.ElementAt(i);
                Point point = new Point(line.BottomX, line.BottomY);
                SetLabelText(i);
                tmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                int nbChar = tmp.Text.Length / 2;
                int x = point.X - nbChar * 4;
                int y = point.Y;
                if (point.Y > this.Size.Height / 2)
                    y += 15;
                else
                    y -= 20;
                tmp.Location = new Point(x, y);
                if (add)
                    this.Controls.Add(tmp);
            }
        }

        private void SetLabelText(int index)
        {
            if (index < 0 || index >= Dimensions.Count)
                throw new ArgumentException("Index out of range");
            Label tmp = Labels.ElementAt(index);
            Dimension dimension = Dimensions.ElementAt(index);
            tmp.Text = dimension.Name + " (" + dimension.Id + ") " + DimensionValue(index);
        }

        private void DrawAllLines(bool insertInLinesList, bool insertInPointsList)
        {
            int nbAxes = Dimensions.Count;
            for (int i = 0; i < nbAxes; i++)
            {
                double angle = (double)(Math.PI / nbAxes * 2 * i);
                //var task = new Task(() => {
                    DrawLine(angle, 250, DashedPen(), Color.Black, insertInLinesList);
                    DrawEllipse(angle, 250, 5, Color.Red, insertInPointsList);
                //});
                //task.Start();
            }
        }

        private void RedrawEllipse(int index, Point point)
        {
            //MessageBox.Show(Points.a);
            if (IsValidIndex(index))
                return;
            RemoveEllipse(index);
            DrawEllipse(point, PointRay, Color.Red, false);
            Points.RemoveAt(index);
            Points.Insert(index, point);
        }

        private void RedrawLine(int index, Line line, Pen pen)
        {
            if (IsValidIndex(index))
                return;
            RemoveLine(index, pen);
            DrawLine(line, pen, Color.Black, false);
            Lines.RemoveAt(index);
            Lines.Insert(index, line);
        }

        private void RemoveLine(int index, Pen pen)
        {
            if (IsValidIndex(index))
                return;
            DrawLine(Lines.ElementAt(index), pen, this.BackColor, false);
        }

        private void RemoveEllipse(int index)
        {
            if (IsValidIndex(index))
                return;

            // BUG: when this code is removed the initial position of
            // the ellipse is not removed
            for (int i = 0; i<Lines.Count;i++)
            {
                var l = Lines.ElementAt(i);
                var pt = Points.ElementAt(i);
                Point p2 = new Point(l.BottomX, l.BottomY);
                if (p2.X != pt.X || p2.Y != pt.Y)
                    DrawEllipse(p2, PointRay, this.BackColor, false);
            }


            Point p = Points.ElementAt(index);
            DrawEllipse(p, PointRay, this.BackColor, false);
            RedrawLine(index, Lines.ElementAt(index), DashedPen());
        }

        private void DrawLine(Line line, Pen pen, Color color, bool insertInLinesList)
        {
            if (insertInLinesList)
                Lines.Add(line);
            pen.Color = color;
            this.CreateGraphics().DrawLine(pen, new Point(line.TopX, line.TopY), new Point(line.BottomX, line.BottomY));
        }

        private void DrawLine(double angle, int length, Pen pen, Color color, bool insertInLinesList)
        {
            Line line = new Line(this.Size.Width / 2, this.Size.Height / 2, angle, length);
            DrawLine(line, pen, color, insertInLinesList);
        }

        private void DrawEllipse(Point center, int ray, Color color, bool insertInPointsList)
        {
            /*for (int i = 0; i < Lines.Count; i++)
            {
                var l = Lines.ElementAt(i);
                Point p2 = new Point(l.BottomX, l.BottomY);
                if ((p2.X == center.X && p2.Y == center.Y) && !insertInPointsList && color != this.BackColor)
                {
                    //MessageBox.Show("Not Painting at "+center);
                    return;
                }
            }*/
            if (insertInPointsList)
                Points.Add(center);
            SolidBrush brush = new SolidBrush(color);
            this.CreateGraphics().FillEllipse(brush, new Rectangle(center.X-ray, center.Y-ray, ray*2, ray*2));
        }

        private void DrawEllipse(double angle, int length, int ray, Color color, bool insertInPointsList)
        {
            SolidBrush brush = new SolidBrush(Color.Red);
            int x = this.Size.Width / 2 + (int)(Math.Sin(angle) * length);
            int y = this.Size.Height / 2 + (int)(Math.Cos(angle) * length);
            DrawEllipse(new Point(x, y), ray, color, insertInPointsList);
        }

        private Pen LinePen()
        {
            return new Pen(Color.Black);
        }

        private Pen DashedPen()
        {
            Pen pen = new Pen(Color.Black);
            float[] dashValues = { 10, 10 };
            pen.DashPattern = dashValues;
            return pen;
        }
        private bool IsValidIndex(int index)
        {
            return (index < 0 || index >= Lines.Count);
        }

        private class Line
        {
            public int TopX { get; set; }
            public int TopY { get; set; }
            public int BottomX { get; set; }
            public int BottomY { get; set; }

            public Line(int topX, int topY, int bottomX, int bottomY)
            {
                this.TopX = topX; this.TopY = topY;
                this.BottomX = bottomX; this.BottomY = bottomY;
            }

            public Line(int centerX, int centerY, double radianAngle, int length)
            {
                this.TopX = centerX; this.TopY = centerY;
                this.BottomX = centerX + (int)(Math.Sin(radianAngle) * length);
                this.BottomY = centerY + (int)(Math.Cos(radianAngle) * length);
            }
        }

        private void RadarControl_MouseDown(object sender, MouseEventArgs e)
        {
            FindClickedIndex(e);
            if (clickedIndex == null)
                return;
            //this.Cursor = Cursors.Hand;
            

            SetNewCoordinates((int)clickedIndex, e);
        }

        private void SetNewCoordinates(int index, MouseEventArgs e)
        {
            Point oldP = Points.ElementAt(index);
            double angle = Math.PI / NbAxes() * 2 * index;
            int x = e.X - this.Size.Width / 2;
            int y = e.Y - this.Size.Height / 2;
            int length = (int)(Math.Sqrt(x*x + y*y));
            //Points.RemoveAt(index);
            double mouseAngle = new GeometryUtil().AngleBetweenPoints(new Point(0, 0),
                    new Point(oldP.X - this.Size.Width / 2, oldP.Y - this.Size.Height / 2), new Point(x, y));
            double newLength = Math.Cos(mouseAngle) * length;
            if (newLength < MinPointPos)
                newLength = MinPointPos;
            if (newLength > RadarRay)
                newLength = RadarRay;
            Line line = new Line(this.Size.Width / 2, this.Size.Height / 2, angle, (int)newLength);
            Point newP = new Point(line.BottomX, line.BottomY);
            
            RedrawEllipse(index, newP);
        }

        private double AngleFromCenter(Point point)
        {
            return new GeometryUtil().AngleBetweenPoints(new Point(0, 0),
                    new Point(0, 100), new Point(point.X, point.Y));
        }

        private void RadarControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (clickedIndex == null)
                return;
            int index = (int)clickedIndex;
            SetNewCoordinates((int)clickedIndex, e);
            Label tmp = Labels.ElementAt(index);
            Dimension dimension = Dimensions.ElementAt(index);
            SetLabelText(index);
        }

        private void RadarControl_MouseUp(object sender, MouseEventArgs e)
        {
            if (clickedIndex == null)
                return;
            double value = DimensionValue((int)clickedIndex);
            //this.Cursor = Cursors.Default;
            //MessageBox.Show("Value = " + value);
            clickedIndex = null;
            this.NewDiagnostic.GetValues();
        }
    }

    public class GeometryUtil
    {
        public double Norm(Point p1, Point p2)
        {
            double x = p1.X - p2.X;
            double y = p1.Y - p2.Y;
            return Math.Sqrt(x*x + y*y);
        }

        public double AngleBetweenPoints(Point p1, Point p2, Point p3)
        {
            double p12 = Norm(p1, p2);
            double p13 = Norm(p1, p3);
            double p23 = Norm(p2, p3);
            return Math.Acos((p12*p12 + p13*p13 - p23*p23) / (2*p12*p13));
        }
    }
}
