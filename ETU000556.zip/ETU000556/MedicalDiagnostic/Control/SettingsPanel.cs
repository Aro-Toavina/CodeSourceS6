﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;

namespace MedicalDiagnostic.Control
{
    public partial class SettingsPanel : UserControl
    {
        private UserControl DimensionControl;

        public SettingsPanel(List<Dimension> dimensions)
        {
            this.DimensionControl = new DimensionsControl(dimensions);
            InitializeComponent();
        }

        private void ShowTab(SettingsTabType type)
        {
            UserControl control = null;
            switch (type)
            {
                case SettingsTabType.Dimension:
                    label3.Visible = true;
                    control = DimensionControl;
                    break;
                default:
                    return;
            }
            panel1.Controls.Clear();
            panel1.Controls.Add(control);
        }

        private void newMenuLbl_Click(object sender, EventArgs e)
        {
            ShowTab(SettingsTabType.Dimension);
        }

        private void newMenuLbl_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(newMenuLbl);
        }

        private void newMenuLbl_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(newMenuLbl);
        }

        private void LabelMenuMouseHover(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlText;
        }
        private void LabelMenuMouseLeave(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
        }
    }

    public enum SettingsTabType
    {
        Dimension = 0
    }
}
