﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Use SQL Server data provider namespace

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class DiseaseListControl : UserControl
    {
        public List<Disease> Diseases { get; set; }
        private DiseasePanel DiseasePanel;

        public DiseaseListControl(List<Disease> diseases, DiseasePanel diseasePanel, string pattern)
        {
            this.Diseases = diseases;
            this.DiseasePanel = diseasePanel;
            InitializeComponent();
            ShowPanelList();
        }

        private void ShowPanelList()
        {
            this.SuspendLayout();
            int u = 0;
            foreach (var item in Diseases)
            {
                Panel panel = new Panel();
                if (u % 2 == 0)
                    panel.BackColor = System.Drawing.SystemColors.ButtonFace;
                else
                    panel.BackColor = Color.White;
                int i = u;
                panel.Size = new System.Drawing.Size(919, 55);
                panel.Location = new System.Drawing.Point(26, 19 + panel.Size.Height * i);
                panel.Name = "panel";
                panel.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                panel.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));

                Label lbl1 = new Label();
                lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                lbl1.Location = new System.Drawing.Point(30, 0);
                lbl1.Name = "lbl1";
                lbl1.Size = new System.Drawing.Size(252, 55);
                lbl1.TabIndex = 0;
                lbl1.Text = item.Name;
                lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                lbl1.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                lbl1.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                panel.Controls.Add(lbl1);

                LinkLabel linkLbl1 = new LinkLabel();
                linkLbl1.AutoSize = true;
                linkLbl1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                linkLbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                linkLbl1.Location = new System.Drawing.Point(420, 20);
                linkLbl1.Name = "linkLabel1";
                linkLbl1.Size = new System.Drawing.Size(73, 17);
                linkLbl1.TabIndex = 3;
                linkLbl1.TabStop = true;
                linkLbl1.Text = "Details";
                linkLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                linkLbl1.UseWaitCursor = true;
                linkLbl1.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                linkLbl1.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                linkLbl1.MouseClick += new System.Windows.Forms.MouseEventHandler((object sender, MouseEventArgs e) => ShowDetails(i));
                panel.Controls.Add(linkLbl1);

                LinkLabel linkLbl2 = new LinkLabel();
                linkLbl2.AutoSize = true;
                linkLbl2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                linkLbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                linkLbl2.Location = new System.Drawing.Point(741, 20);
                linkLbl2.Name = "linkLabel1";
                linkLbl2.Size = new System.Drawing.Size(73, 17);
                linkLbl2.TabIndex = 3;
                linkLbl2.TabStop = true;
                linkLbl2.Text = "Supprimer";
                linkLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                linkLbl2.UseWaitCursor = true;
                linkLbl2.MouseHover += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseHover(panel));
                linkLbl2.MouseLeave += new System.EventHandler((object sender, EventArgs e) => PanelMenuMouseLeave(panel, i));
                linkLbl2.MouseClick += new System.Windows.Forms.MouseEventHandler((object sender, MouseEventArgs e) => DeleteDisease(i));
                panel.Controls.Add(linkLbl2);

                this.panel1.Controls.Add(panel);
                u++;
            }
            this.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void PanelMenuMouseHover(Panel panel)
        {
            panel.BackColor = System.Drawing.SystemColors.ControlLight;
        }
        private void PanelMenuMouseLeave(Panel panel, int i)
        {
            if (i % 2 == 0)
                panel.BackColor = System.Drawing.SystemColors.ButtonFace;
            else
                panel.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            try
            {
                Disease disease = new Disease(null, name, null);
                DiseaseDAO diseaseDAO = new DiseaseDAO();
                diseaseDAO.Insert(disease);
                ReloadDisease();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        public void ReloadDisease()
        {
            new ListUtil<Disease>().CopyInto(new DiseaseDAO().ListAll(), Diseases);
            this.panel1.Controls.Clear();
            ShowPanelList();
        }

        private void DeleteDisease(int index)
        {
            if (index < 0 || index >= Diseases.Count)
                return;
            DiseaseDAO dao = new DiseaseDAO();
            dao.Delete(Diseases.ElementAt(index).Id);
            ReloadDisease();
        }

        private void ShowDetails(int index)
        {
            if (index < 0 || index >= Diseases.Count)
                return;
            DiseasePanel.ShowDetails(index);
        }
    }
}
