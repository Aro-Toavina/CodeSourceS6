﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic.Control
{
    public partial class DiagnosticPanel : UserControl
    {
        private List<Dimension> dimensions;
        private List<Disease> diseases;

        public UserControl NewDiagnosticControl { get; set; }
        public UserControl AllDiagnosticControl { get; set; }

        public DiagnosticPanel(List<Dimension> dimensions, List<Disease> diseases)
        {
            this.dimensions = dimensions;
            this.diseases = diseases;
            InitControls();
            InitializeComponent();
        }

        private void InitControls()
        {
            NewDiagnosticControl = new NewDiagnosticControl(this.dimensions, this.diseases);
            AllDiagnosticControl = null;
        }

        private void newMenuLbl_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(newMenuLbl);
        }

        private void newMenuLbl_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(newMenuLbl);
        }

        private void newMenuLbl_Click(object sender, EventArgs e)
        {
            ShowTab(DiagnosticTabType.New);
        }

        private void LabelMenuMouseHover(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlText;
        }
        private void LabelMenuMouseLeave(Label label)
        {
            label.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
        }

        private void allMenuLbl_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(allMenuLbl);
        }

        private void allMenuLbl_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(allMenuLbl);
        }

        private void ShowTab(DiagnosticTabType type)
        {
            UserControl control = null;
            switch (type)
            {
                case DiagnosticTabType.New:
                    control = new NewDiagnosticControl(this.dimensions, this.diseases);
                    label3.Visible = true;
                    label4.Visible = false;
                    break;
                case DiagnosticTabType.All:
                    control = AllDiagnosticControl;
                    label3.Visible = false;
                    label4.Visible = true;
                    break;
                default:
                    break;
            }
            panel1.Controls.Clear();
            panel1.Controls.Add(control);
        }

        private void allMenuLbl_MouseDown(object sender, MouseEventArgs e)
        {
            ShowDialog(e, "Liste des diagnostics enregistres");
        }

        private void allMenuLbl_MouseUp(object sender, MouseEventArgs e)
        {
            HideDialog();
        }

        private void ShowDialog(MouseEventArgs e, string message)
        {
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            label1.Location = new System.Drawing.Point(e.X + allMenuLbl.Location.X, e.Y + allMenuLbl.Location.Y - 30);
            label1.Name = "label";
            label1.Size = new System.Drawing.Size(100, 23);
            label1.Text = message;
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.Visible = true;
        }
        private void HideDialog()
        {
            label1.Visible = false;
        }

        private void allMenuLbl_MouseMove(object sender, MouseEventArgs e)
        {
            //label1.Location = new Point(e.X + label1.Location.X, e.Y + label1.Location.Y - 20);
        }
    }

    public enum DiagnosticTabType
    {
        New = 0,
        All = 1
    }
}
