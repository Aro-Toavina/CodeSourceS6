﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalDiagnostic.Model
{
    public class Dimension
    {
        private string _id;
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 3, 3, true))
                    throw new ArgumentException("Id should have 3 characters");
                _id = value;
            }
        }

        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 50, 0, true))
                    throw new ArgumentException("Name should be less than 50 and greater than 0 characters");
                _name = value;
            }
        }

        private double _low;
        public double Low
        {
            get
            {
                return _low;
            }
            set
            {
                if (value < 0) value = 0;
                _low = value;
            }
        }

        private double _high;
        public double High
        {
            get
            {
                return _high;
            }
            set
            {
                if (value < Low)
                    throw new ArgumentException("Max doit etre superieur a Min");
                _high = value;
            }
        }

        private string _unit;
        public string Unit
        {
            get
            {
                return _unit;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 0, true))
                    throw new ArgumentException("Unite should be less than 10 and greater than 0 characters");
                _unit = value;
            }
        }

        public Dimension(string id, string name, double low, double high, string unit)
        {
            this.Id = id;
            this.Name = name;
            this.Low = low;
            this.High = high;
            this.Unit = unit;
        }
    }

    public class Disease
    {
        private string _id;
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 10, true))
                    throw new ArgumentException("Id should have 10 characters:'"+value+"'");
                _id = value;
            }
        }

        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 50, 1, true))
                    throw new ArgumentException("Name should be less than 50 and greater than 0 characters");
                _name = value;
            }
        }

        private List<AgeStats> _ageStats;
        public List<AgeStats> AgeStats
        {
            get
            {
                return _ageStats;
            }
            set
            {
                if (value == null)
                    value = new List<Model.AgeStats>();
                _ageStats = value;
            }
        }

        public Disease(string id, string name, List<AgeStats> ageStats)
        {
            this.Id = id;
            this.Name = name;
            this.AgeStats = ageStats;
        }

        public AgeStats AgeStatsByAge(int age)
        {
            for (int i = 0; i < AgeStats.Count; i++)
            {
                AgeStats current = AgeStats.ElementAt(i);
                if (IsBetween(current.LowAge, current.HighAge, age))
                    return current;
            }
            return null;
        }

        private bool IsBetween(int? lowAge, int? highAge, int age)
        {
            if (lowAge != null && age < lowAge)
                return false;
            else if (highAge != null && age > highAge)
                return false;
            return true;
        }

        public double Percentage(Gender gender, int age, List<double> values, List<Dimension> dimensions)
        {
            double res = 0;
            foreach (var ageStats in AgeStats)
            {
                if (!IsBetween(ageStats.LowAge, ageStats.HighAge, age))
                    continue;
                double per = 0; double nb = 0;
                int u = 0;
                foreach (var composant in ageStats.Composant)
                {
                    if (composant.DimensionCoeff == 0)
                    {
                        u++;
                        continue;
                    }
                    nb += composant.DimensionCoeff;
                    double delta = GetDimension(dimensions, composant.Dimension).High - GetDimension(dimensions, composant.Dimension).Low;
                    double perDelta = delta / 100;
                    /*double plusPer = (values.ElementAt(u) - composant.Val) * perDelta;
                    if (composant.AscExponentialCoeff > 0)
                        per += 50 + plusPer;
                    else
                        per += 50 - plusPer;*/
                    double val = values.ElementAt(u);
                    double tmpPer = 50;
                    for (double i = val, p = 1; i > composant.Val; i -= perDelta, p++)
                    {
                        tmpPer += 1 * composant.AscExponentialCoeff / p;
                    }
                    for (double i = val, p = 1; i < composant.Val; i += perDelta, p++)
                    {
                        tmpPer -= 1 * composant.DescExponentialCoeff / p;
                    }
                    //System.Windows.Forms.MessageBox.Show("tmpPer["+u+"]="+tmpPer);
                    u++;
                    per += tmpPer;
                }
                
                per = per / nb;
                if (per > res)
                    res = per;
            }
            return res;
        }

        public List<double> Percentage(Gender gender, int age, List<double> values, List<Dimension> dimensions, List<Disease> disease)
        {
            List<double> res = new List<double>();
            foreach (var item in disease)
            {
                res.Add(item.Percentage(gender, age, values, dimensions));
            }
            return res;
        }

        public Dimension GetDimension(List<Dimension> dimensions, string id)
        {
            foreach (var dimension in dimensions)
            {
                if (id.Equals(dimension.Id))
                    return dimension;
            }
            return null;
        }
    }

    public class AgeStats
    {
        private string _id;
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 10, true))
                    throw new ArgumentException("Id should have 10 characters:'"+value+"'");
                _id = value;
            }
        }

        private string _disease;
        public string Disease
        {
            get
            {
                return _disease;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 10, true))
                    throw new ArgumentException("DiseaseId should have 10 characters");
                _disease = value;
            }
        }

        private int? _lowAge;
        public int? LowAge
        {
            get { return _lowAge; }
            set
            {
                if (value == null) _lowAge = null;
                if (value <= 0)
                    throw new ArgumentException("Low age must be greater than 0");
                _lowAge = value;
            }
        }

        private int? _highAge;
        public int? HighAge
        {
            get { return _highAge; }
            set
            {
                if (value == null) _highAge = null;
                if (value < 0)
                    throw new ArgumentException("Low age must be greater than 0");
                if (_lowAge!=null && value < _lowAge)
                    throw new ArgumentException("HighAge must be greater than LowAge");
                _highAge = value;
            }
        }

        public Gender Gender { get; set; }

        private List<Composant> _composant;
        public List<Composant> Composant
        {
            get
            {
                return _composant;
            }
            set
            {
                if (value == null)
                    value = new List<Model.Composant>();
                _composant = value;
            }
        }

        public AgeStats(string id, string disease, int? lowAge, int? highAge,
                         Gender gender, List<Composant> composant)
        {
            this.Id = id; this.Disease = disease;
            this.LowAge = lowAge; this.HighAge = highAge;
            this.Gender = gender;
            this.Composant = composant;
        }

        public override string ToString()
        {
            string age = LowAge + " - " + HighAge;
            if (LowAge == HighAge)
                age = "" + LowAge;
            return age + " ans (" + new GenderUtil().ToString(Gender) + ")";
        }
    }

    public class Composant
    {
        public Composant(string id, string ageStats, string dimension, double val, double dimensionCoeff,
                        double ascExponentialCoeff, double descExponentialCoeff)
        {
            this.Id = id;
            this.AgeStats = ageStats;
            this.Dimension = dimension;
            this.Val = val;
            this.DimensionCoeff = dimensionCoeff;
            this.AscExponentialCoeff = ascExponentialCoeff;
            this.DescExponentialCoeff = descExponentialCoeff;
        }

        private string _id;
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 10, true))
                    throw new ArgumentException("Id should have 10 characters:'" + value + "'");
                _id = value;
            }
        }

        private string _ageStats;
        public string AgeStats
        {
            get
            {
                return _ageStats;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 10, 10, true))
                    throw new ArgumentException("AgeStatsId should have 10 characters");
                _ageStats = value;
            }
        }

        private string _dimension;
        public string Dimension
        {
            get
            {
                return _dimension;
            }
            set
            {
                if (!new CheckValueUtil().IsValidString(value, 3, 3, true))
                    throw new ArgumentException("DimensionId should have 3 characters:'" + value + "'");
                _dimension = value;
            }
        }

        public double Val { get; set; }

        private double _dimensionCoeff;
        public double DimensionCoeff
        {
            get { return _dimensionCoeff; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("DimensionCoeff should be greater than or equal to 0");
                _dimensionCoeff = value;
            }
        }
        
        public double AscExponentialCoeff { get; set; }
        
        public double DescExponentialCoeff { get; set; }
    }
    
    public class CheckValueUtil
    {
        public bool IsValidString(string str, int? maxLen, int? minLen, bool canBeNull)
        {
            if (canBeNull && str == null)
                return true;
            else if (!canBeNull && str == null)
                return false;

            if (maxLen != null)
            {
                if (str.Length > maxLen)
                    return false;
            }
            if (minLen != null)
            {
                if (str.Length < minLen)
                    return false;
            }
            return true;
        }
    }

    public enum Gender
    {
        Male = 1,
        Female = 2
    }

    public class GenderUtil
    {
        public Gender ToGender(int i)
        {
            if (i == (int)Gender.Male)
                return Gender.Male;
            return Gender.Female;
        }

        public string ToString(Gender gender)
        {
            string res = null;
            switch (gender)
            {
                case Gender.Male:
                    res = "Homme";
                    break;
                case Gender.Female:
                    res = "Femme";
                    break;
                default:
                    res = null;
                    break;
            }
            return res;
        }
    }

    public class ListUtil<T>
    {
        public void CopyInto(List<T> from, List<T> into)
        {
            into.Clear();
            into.AddRange(from);
        }
    }
}
