﻿CREATE DATABASE medical_diagnostic;

USE medical_diagnostic;

IF EXISTS (SELECT 1 FROM sys.tables WHERE [Name] = 'dimension')
BEGIN
	IF EXISTS (SELECT 1 FROM sys.tables WHERE [Name] = 'disease')
	BEGIN
		IF EXISTS (SELECT 1 FROM sys.tables WHERE [Name] = 'age_stats')
		BEGIN
			IF EXISTS (SELECT 1 FROM sys.tables WHERE [Name] = 'composant')
			BEGIN
				DROP TABLE dbo.composant;
			END;
			DROP TABLE dbo.age_stats;
		END;
		DROP TABLE dbo.disease;
	END;
	DROP TABLE dbo.dimension;
END;

CREATE TABLE dimension (
	id		CHAR(3) PRIMARY KEY,
	name	VARCHAR(50) NOT NULL,
	low		FLOAT NOT NULL,
	high	FLOAT NOT NULL,
	unit	VARCHAR(10) NOT NULL,
	CONSTRAINT CK_low_high CHECK (low <= high)
);

CREATE TABLE disease (
	id		CHAR(10) PRIMARY KEY,
	name	VARCHAR(50) UNIQUE NOT NULL
);

IF EXISTS (SELECT 1 FROM sys.sequences WHERE [Name] = 'disease_seq')
BEGIN
	DROP SEQUENCE dbo.disease_seq;
END;
CREATE SEQUENCE disease_seq AS INT START WITH 1 INCREMENT BY 1;

CREATE TABLE age_stats (
	id		CHAR(10) PRIMARY KEY,
	disease_id CHAR(10) NOT NULL REFERENCES disease(id),
	low_age		INT,
	high_age	INT,
	/* 1: male
	 * else: female
	 */
	gender		INT NOT NULL,
	CONSTRAINT CK_low_age CHECK (low_age >= 0),
	CONSTRAINT CK_high_age CHECK (high_age >= low_age)
);

IF EXISTS (SELECT 1 FROM sys.sequences WHERE [Name] = 'age_stats_seq')
BEGIN
	DROP SEQUENCE dbo.age_stats_seq;
END;
CREATE SEQUENCE age_stats_seq AS INT START WITH 1 INCREMENT BY 1;


CREATE TABLE composant (
	id		CHAR(10) PRIMARY KEY,
	age_stats_id	CHAR(10) NOT NULL REFERENCES age_stats(id),
	dimension_id	CHAR(3) NOT NULL REFERENCES dimension(id),
	val				FLOAT NOT NULL,
	dimension_coeff FLOAT DEFAULT 1,
	asc_exponential_coeff FLOAT NOT NULL,
	desc_exponential_coeff FLOAT NOT NULL
);

IF EXISTS (SELECT 1 FROM sys.sequences WHERE [Name] = 'composant_seq')
BEGIN
	DROP SEQUENCE dbo.composant_seq;
END;
CREATE SEQUENCE composant_seq AS INT START WITH 1 INCREMENT BY 1;