﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MedicalDiagnostic.Control;
using MedicalDiagnostic.Model;
using MedicalDiagnostic.Sql;
using MedicalDiagnostic.Sql.Dao;

namespace MedicalDiagnostic
{
    public partial class MainForm : Form
    {
        private List<Dimension> dimensions = new DimensionDAO().ListAll();
        private List<Disease> diseases = new DiseaseDAO().ListAll();

        public UserControl Diagnostic { get; set; }
        public UserControl Disease { get; set; }
        public UserControl Settings { get; set; }

        public MainForm()
        {
            MedicalDiagnosticConnection con = new MedicalDiagnosticConnection();
            //int val = con.ExecuteScalar("select count(*) from age_stats");
            List<Dimension> dimensions = new DimensionDAO().ListAll();
            //MessageBox.Show("dimension[0].Id = " + dimensions.ElementAt(0).Id);
            List<Disease> diseases = new DiseaseDAO().ListAll();
            //MessageBox.Show("diseases.Count = " + diseases.Count);
            List<AgeStats> ageStats = new AgeStatsDAO().ListAll();
            //MessageBox.Show("ageStats.Count = " + ageStats.Count);
            
            InitializeComponent();
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(label1);
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(label1);
        }

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {
            LabelMenuMouseClick(label1);
            ShowPanel(WindowType.Diagnostic);
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(label2);
        }
        private void label2_Click(object sender, EventArgs e)
        {
            LabelMenuMouseClick(label2);
            ShowPanel(WindowType.Disease);
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(label2);
        }

        private void label3_MouseHover(object sender, EventArgs e)
        {
            LabelMenuMouseHover(label3);
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            LabelMenuMouseLeave(label3);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            LabelMenuMouseClick(label3);
            ShowPanel(WindowType.Settings);
        }

        private void LabelMenuMouseHover(Label button)
        {
            button.BackColor = System.Drawing.SystemColors.ControlLight;
        }
        private void LabelMenuMouseLeave(Label button)
        {
            button.BackColor = System.Drawing.SystemColors.ButtonFace;
        }
        private void LabelMenuMouseClick(Label button)
        {
            button.BackColor = System.Drawing.SystemColors.ControlDark;
        }

        private void ShowPanel(WindowType type)
        {
            UserControl control = null;
            switch (type)
            {
                case WindowType.Diagnostic:
                    control = new DiagnosticPanel(dimensions, diseases);
                    break;
                case WindowType.Disease:
                    control = new DiseasePanel(dimensions, diseases);
                    break;
                case WindowType.Settings:
                    control = new SettingsPanel(dimensions);
                    break;
                default:
                    return;
            }
            panel2.Controls.Clear();
            panel2.Controls.Add(control);
        }
    }

    public enum WindowType
    {
        Diagnostic = 0,
        Disease = 1,
        Settings = 2
    }
}
