﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMedical
{
    public partial class Form1 : Form
    {

        int xMiddle;
        int yMiddle;        
        int rayon;
        double angle;
        List<Rond> point;
        List<Rond> currval;
        List<int> x;
        List<int> y;
        Diagnostique diag = new Diagnostique();
        Element elmt = new Element();
       // List<Diagnostique> list = new List<Diagnostique>();
        List<Element> listElmt = new List<Element>();
        List<double> ldouble = new List<double>();
        Disease dis;
        List<Disease> listdis;
        Quantity qtt;
        List<Quantity> listqtt;



        public Form1()
        {
            InitializeComponent();
            listElmt = elmt.findElement("");
            x = new List<int>();
            y = new List<int>();
            Addpoint();
            point = new List<Rond>();
            currval = new List<Rond>();
            dis = new Disease();
            qtt = new Quantity();
            listdis=dis.findMatch("");
            comboBox1.Items.Add("H");
            comboBox1.Items.Add("F");
            comboBox1.Items.Add("E");

            initListRond();

           //

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            xMiddle = panel1.Width / 2;
            yMiddle = panel1.Height / 2;
            rayon = panel1.Width / 2;
            Graphics g = e.Graphics;
            Point pointLast = new Point(xMiddle, 0);
            for (int i = 0; i < listElmt.Count; i++)
            {
                angle = (Math.PI / 7) * i;
                Point p = angle1(g, angle);
                g.DrawString(listElmt[i].getdesc().ToString(), new Font("Arial", 10), new SolidBrush(Color.Black), p.X-10, p.Y-15);
            }
           
            showNiveau(g);

        }

        private void Addpoint()
        {
            xMiddle = panel1.Width / 2;
            yMiddle = panel1.Height / 2;
            rayon = panel1.Width / 2 ;
            for (int i = 0; i <= 14; i++)
            {
                angle = (Math.PI / 7) * i;
                Point p = getangle(angle);
                x.Add(p.X);
                y.Add(p.Y);
            }
        }

        public Point getangle(double angle)
        {
         
            int x = (int)((rayon) * (1 + Math.Sin(angle)));
            int y = (int)((rayon) * (1 - Math.Cos(angle)));
            Point point2 = new Point(x, y);
            return point2;
        }
        public Point angle1(Graphics g, double angle)
        {
            Pen p = new Pen(Color.Black, 2);
            int x = (int)((rayon) * (1 + Math.Sin(angle)));
            int y = (int)((rayon) * (1 - Math.Cos(angle)));
            Point point = new Point(xMiddle, yMiddle);
            Point point2 = new Point(x, y);
            g.DrawLine(p, point, point2);
            return point2;
        }

        public void drawJoinpoint(Graphics g, Point point1,Point point2)
        {
            Pen p = new Pen(Color.Red, 2);
            g.DrawLine(p, point1, point2);
        }

        
        public void initListRond()
        {
          
         
             for(int  j=0; j<listElmt.Count; j++)
             {
                 point.Add(new Rond(x[j], y[j], new Point(panel1.Width / 2, panel1.Height / 2),this.listElmt[j]));
               // Console.WriteLine("current " + diag.getcurrval());

            }
           
            for (int i = 0; i < point.Count; i++)
             {

                 panel1.Controls.Add(point[i]);
             } 
        }

        public void showNiveau(Graphics g)
        {
            Point a = new Point();
            Point point2 = new Point();
           
            for (int i = 0; i < point.Count; i++)
            {
                point2 = new Point(point[i].Location.X, point[i].Location.Y);
                //panel1.Controls.Add(new Pourcent(point[i].Location.X, point[i].Location.Y));
                if (i != 0)
                {              
                    drawJoinpoint(g, a, point2);                   
                }
                a = point2;                
            }

            //Console.WriteLine(point.ElementAt(1));
            Point first = new Point(point.ElementAt(0).Location.X, point.ElementAt(0).Location.Y);
            Pen p = new Pen(Color.Black, 2);
            drawJoinpoint(g, a, first);
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            List<double> result = new List<double>();
          
            DiseaseComposition dc = new DiseaseComposition();
            List<DiseaseComposition> listdc = new List<DiseaseComposition>();
            Console.WriteLine("list disease :" + listdis.Count);

            for (int i=0; i<listdis.Count; i++)
            {
                double TauxPourcentage = 0;
                //Console.WriteLine("miditra boucle i:" + i);
                listdc = dc.findElementDisease(" where  idDisease="+listdis[i].getid());

                Console.WriteLine("Maladie :" + listdis[i].getvalue());

                for (int k = 0; k < listdc.Count; k++)
                {
                    //Console.WriteLine("miditra boucle k:" + k);

                    for (int j=0; j<point.Count; j++)
                         {
                    //Console.WriteLine("miditra boucle j:" + j);
                    Console.WriteLine("list disease comp :" + listdc[k].getidElement());
                   
                        

                        if (listdc[k].getidElement() == point[j].elmt.getid())
                        {
                            Console.WriteLine("miditra if 1");
                            listqtt = qtt.findquantity(" where idElement="+ listdc[k].getidElement()+" and Sex='"+comboBox1.Text+"'");
                            Console.WriteLine("quantite :"+listqtt.Count);
                            if ((point[j].elmt.getcurrval()) <=(double)(listqtt[0].getnormmax()) && point[j].elmt.getcurrval() >= (double)(listqtt[0].getnormmin()) )
                            {
                                Console.WriteLine("miditra if normal");
                                TauxPourcentage = TauxPourcentage+0;
                            }
                            else
                            {
                                Console.WriteLine("miditra if tsy normal(else)");
                                if (point[j].elmt.getcurrval() <= listdc[k].getdmax() && point[j].elmt.getcurrval() >= listdc[k].getdmin())
                                {
                                    Console.WriteLine("miditra if an if tsy normal(else)");
                                    Console.WriteLine("type :"+ listdc[k].gettype());
                                    double tauxmax;

                                    if(listdc[k].gettype() ==1)
                                    {
                                        Console.WriteLine("miditra if baisse");
                                        tauxmax= (listdc[k].getdmin() - listdc[k].getdmax());

                                        Console.WriteLine("taux baisse"  +tauxmax);
                                        double res = ((point[j].elmt.getcurrval() - listdc[k].getdmax()) * 100) / tauxmax;
                                        Console.WriteLine("resultat " + res);
                                        TauxPourcentage =  TauxPourcentage+ res;
                                    }
                                    else if (listdc[k].gettype() == 2)
                                    {
                                        Console.WriteLine("miditra if hausse");
                                        tauxmax = (listdc[k].getdmax() - listdc[k].getdmin());
                                        Console.WriteLine("taux hausse" + tauxmax);
                                        double res = ((point[j].elmt.getcurrval() - listdc[k].getdmin()) * 100) / tauxmax;
                                        //Console.WriteLine("taux hausse miditra" );
                                        Console.WriteLine("resultat " + res);
                                        TauxPourcentage = TauxPourcentage + res;
                                    }
                                }

                                else
                                {
                                    Console.WriteLine("miditra else an if tsy normal(else)");
                                    TauxPourcentage = TauxPourcentage +  0;
                                }


                            }
                        }
                    }
                    
                }

                Console.WriteLine("nombre d'element a diviser " +listdc.Count);
                TauxPourcentage = TauxPourcentage / listdc.Count;
                Console.WriteLine("resultat final calcul" + TauxPourcentage+"  /"+ listdc.Count);
                Console.WriteLine("resultat final " + TauxPourcentage);
                result.Add(TauxPourcentage);
            }
            for(int l=0; l<listdis.Count; l++) { 
            Console.WriteLine("result de la maladie "+ listdis[l].getvalue()+" est" + result[l]);

            }
            Form2 form2 = new Form2(listdis,result,this.textBox1.Text,Int32.Parse(this.textBox2.Text),Char.Parse(this.comboBox1.Text),point);
            form2.ShowDialog();
        }
    }
}
