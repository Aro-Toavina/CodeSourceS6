﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMedical
{
    public partial class Form2 : Form
    {
        List<Disease> listeDesease = new List<Disease>();
        List<Double> listeValue = new List<double>();
        List<Rond> listePoint = new List<Rond>();
        String nom;
        int age;
        char sexe;

        

        public Form2(List<Disease> ld, List<Double> lv, String n, int age, char s,List<Rond> lr)
        {
            InitializeComponent();
            this.listeDesease = ld;
            this.listeValue = lv;
            this.nom = n;
            this.age = age;
            this.sexe = s;
            this.listePoint = lr;
            initResult();
        }

        public void initResult()
        {
            for(int i = 0; i < listeDesease.Count; i++)
            {
                this.dataGridView1.Rows.Add(listeDesease[i].getvalue(), listeValue[i]+"%");
            }

            this.label4.Text = this.nom;
            this.label5.Text = this.age.ToString();
            this.label6.Text = this.sexe.ToString();

            List<Quantity> qtt = new List<Quantity>(); 
            for(int i = 0; i < listePoint.Count; i++)
            {
                qtt = new Quantity().findquantity("where idElement=" + listePoint[i].elmt.getid() + " and Sex='" + this.sexe + "'");
                this.dataGridView2.Rows.Add(listePoint[i].elmt.getdesc(), qtt[0].getnormmax() + " - " + qtt[0].getnormmin(),listePoint[i].elmt.getcurrval());
            }
        }

        
    }
}
