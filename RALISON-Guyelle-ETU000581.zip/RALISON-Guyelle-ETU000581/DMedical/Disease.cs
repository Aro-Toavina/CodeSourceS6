﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Disease
    {
        int id;
        String value;

        public Disease()
        {

        }
        public Disease(int id, String value)
        {
            this.setid(id);
            this.setvalue(value);

        }
        public Disease(String value)
        {
          
            this.setvalue(value);

        }
        public int getid()
        {
            return id;
        }

        public string getvalue()
        {
            return value;
        }
        public void setid(int id)
        {
            this.id = id;
        }
        public void setvalue(String value)
        {
            this.value=value;
        }

        public List<Disease> findMatch(String critere)
        {
            List<Disease> liste = new List<Disease>();
            List<int> id = new List<int>();
            List<String> value = new List<String>();

            Disease ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

           /* try
            {*/
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Disease]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Disease] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                    
                        Console.WriteLine("id");
                        id.Add((read.GetByte(0)));
                        Console.WriteLine("value");
                       value.Add(read.GetString(1));

                    }


                    for (int k = 0; k < id.Count; k++)
                    {
                        ma = new Disease(id.ElementAt(k), value.ElementAt(k));
                        liste.Add(ma);

                    }


                }
            /* }
           catch (Exception ex)
            {
                throw ex;
                
            }

            finally
            {
                connexion.Close();
            }*/

            return liste;
        }

    }
}
