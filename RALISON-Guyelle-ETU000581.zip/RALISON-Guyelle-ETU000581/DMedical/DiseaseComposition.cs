﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    class DiseaseComposition
    {
        int id;
        int idDisease;
        int idElement;
        Double dmax;
        Double dmin;
        int type;
        String sexe;


        public DiseaseComposition()
        {

        }
        public DiseaseComposition(int id, int idDisease, int idElement, Double dmax, Double dmin, int type)
        {
            this.setid(id);
            this.setidDisease(idDisease);
            this.setidElement(idElement);
            this.setdmin(dmin);
            this.setdmax(dmax);
            this.settype(type);

        }
        public DiseaseComposition( int idDisease, int idElement, Double dmax, Double dmin,int type, String sexe)
        {
            this.setid(id);
            this.setidDisease(idDisease);
            this.setidElement(idElement);
            this.setdmin(dmin);
            this.setdmax(dmax);
            this.settype(type);
            this.setsex(sexe);
          

        }
        public int getid()
        {
            return id;
        }
        public int getidDisease()
        {
            return idDisease;
        }
        public int getidElement()
        {
            return idElement;
        }
        public Double getdmin()
        {
            return dmin;
        }
        public Double getdmax()
        {
            return dmax;
        }
        public int gettype()
        {
            return type;
        }
        public String getsex()
        {
            return sexe;
        }

        public void setid(int id)
        {
            this.id = id;
        }
        public void setidDisease(int id)
        {
            this.idDisease = id;
        }
        public void setidElement(int id)
        {
            this.idElement = id;
        }
        public void setdmin(Double id)
        {
            this.dmin = id;
        }
        public void setdmax(Double id)
        {
            this.dmax = id;
        }
        public void settype(int id)
        {
            this.type = id;
        }
        public void setsex(String sex)
        {
            this.sexe = sex;
        }

        public List<DiseaseComposition> findElementDisease(String critere)
        {
            List<DiseaseComposition> liste = new List<DiseaseComposition>();
            List<int> id = new List<int>();
            List<int> idDisease = new List<int>();
            List<int> idElement = new List<int>();
            List<Double> dmax = new List<Double>();
            List<Double> dmin = new List<Double>();
            List<int> type = new List<int>();
            List<string> sex = new List<string>();

            DiseaseComposition ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

          /*  try
            {*/
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[DiseaseComposition]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[DiseaseComposition] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                        // Console.WriteLine("miditra boucle1");
                        id.Add(read.GetByte(0));
                        idDisease.Add(read.GetByte(1));
                        idElement.Add(read.GetByte(2));
                        dmax.Add(read.GetDouble(3));
                        dmin.Add(read.GetDouble(4));
                        type.Add(read.GetByte(5));
                      //  sex.Add(read.GetString(6));

                    }


                    for (int k = 0; k < id.Count; k++)
                    {
                        ma = new DiseaseComposition(id.ElementAt(k), idDisease.ElementAt(k), idElement.ElementAt(k), dmax.ElementAt(k), dmin.ElementAt(k), type.ElementAt(k));
                        liste.Add(ma);

                    }


                }
           /* }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connexion.Close();
            }*/

            return liste;
        }
    }
}
