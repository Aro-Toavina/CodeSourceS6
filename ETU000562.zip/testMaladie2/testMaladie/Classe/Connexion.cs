﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace testMaladie.Classe
{
    public class Connexion
    {
        /// Paramètres de connexion
        string ConnectionString =
            "Server=localhost;" +
            "Database=Maladie;" +
            "User ID=sa;" +
            "Password=itu;";
        SqlConnection con;

        /// Etablir la connexion avec la base
        public void getCon()
        {
            try
            {
                con = new SqlConnection(ConnectionString);
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connexion échouée : "+ex.Message.ToString());
            }
        }

        /// Fermer la connexion avec la base
        public void close()
        {
            con.Close();
        }

        /// Excecuter n'importe quelle commande sql(CRUD)
        public void ExecuteQueries(string Query_)
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        /// Présenter les résultats dans un champ de texte
        public SqlDataReader DataReader(string Query_)
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query_, con);
            SqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        /// Présenter les résultats sous forme de tableau 
        public object ShowDataInGridView(string Query_)
        {
            SqlDataAdapter dr = new SqlDataAdapter(Query_, ConnectionString);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            object dataum = ds.Tables[0];
            return dataum;
        }
    }
}
