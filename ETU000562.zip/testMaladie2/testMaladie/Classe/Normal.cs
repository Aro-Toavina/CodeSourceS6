﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace testMaladie.Classe
{
    public class Normal
    {
        private int id;
        private int idaxe;
        private double valeurMin;
        private double valeurMax;
        private int sexe;
        private int ageMin;
        private int ageMax;
        private string calcul;
        private string valeur;
        private string calculinverse;

        public Normal(int idaxe, string valeurMin, string valeurMax, int sexe, int ageMin, int ageMax, string calcul, string valeur, string calculinverse) { this.idaxe = idaxe; this.valeurMin = double.Parse(valeurMin); this.valeurMax = double.Parse(valeurMax); this.sexe = sexe; this.ageMin = ageMin; this.ageMax = ageMax; this.calcul = calcul; this.valeur = valeur; this.calculinverse = calculinverse; }

        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        public void setIdaxe(int idaxe) { this.idaxe = idaxe; }
        public int getIdaxe() { return this.idaxe; }
        public void setValeurMin(double valeurMin) { this.valeurMin = valeurMin; }
        public double getValeurMin() { return this.valeurMin ; }
        public void setValeurMax(double valeurMax) { this.valeurMax = valeurMax; }
        public double getValeurMax() { return this.valeurMax ; }
        public void setSexe(int sexe) { this.sexe = sexe; }
        public int getSexe() { return this.sexe ; }
        public void setAgeMin(int ageMin) { this.ageMin = ageMin; }
        public int getAgeMin() { return this.ageMin ; }
        public void setAgeMax(int ageMax) { this.ageMax = ageMax; }
        public int setAgeMax() { return this.ageMax ; }
        public void setCalcul(string calcul) { this.calcul = calcul; }
        public string getCalcul() { return this.calcul; }
        public void setValeur(string valeur) { this.valeur = valeur; }
        public string getValeur() { return this.valeur; }
        public void setCalculinverse(string calculinverse) { this.calculinverse = calculinverse; }
        public string getCalculinverse() { return this.calculinverse; }
    }
}
