﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace testMaladie.Classe
{
    public class Patient
    {
        private int id;
        private string nom;
        private string sexe;
        private int age;
        private string daty;
        private double axe0;
        private double axe1;
        private double axe2;
        private double axe3;
        private double axe4;
        private double axe5;
        private double axe6;
        private double axe7;
        private double axe8;
        private double axe9;
        private double axe10;
        private double axe11;
        private double axe12;
        private double axe13;

        public Patient(string nom, string sexe, int age, string daty, double axe0, double axe1, double axe2, double axe3, double axe4, double axe5, double axe6, double axe7, double axe8, double axe9, double axe10, double axe11, double axe12, double axe13) { this.nom = nom; this.sexe = sexe; this.age = age; this.daty = daty; this.axe0 = axe0; this.axe1 = axe1; this.axe2 = axe2; this.axe3 = axe3; this.axe4 = axe4; this.axe5 = axe5; this.axe6 = axe6; this.axe7 = axe7; this.axe8 = axe8; this.axe9 = axe9; this.axe10 = axe10; this.axe11 = axe11; this.axe12 = axe12; this.axe13 = axe13; }

        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        public void setNom(string nom) { this.nom = nom; }
        public string getNom() { return this.nom; }
        public void setSexe(string sexe) { this.sexe = sexe; }
        public string getSexe() { return this.sexe; }
        public void setAge(int age) { this.age = age; }
        public int getAge() { return this.age; }
        public void setDaty(string daty) { this.daty = daty; }
        public string getDaty() { return this.daty; }
        public void setAxe0(double axe0) { this.axe0 = axe0; }
        public double getAxe0() { return this.axe0; }
        public void setAxe1(double axe1) { this.axe1 = axe1; }
        public double getAxe1() { return this.axe1; }
        public void setAxe2(double axe2) { this.axe2 = axe2; }
        public double getAxe2() { return this.axe2; }
        public void setAxe3(double axe3) { this.axe3 = axe3; }
        public double getAxe3() { return this.axe3; }
        public void setAxe4(double axe4) { this.axe4 = axe4; }
        public double getAxe4() { return this.axe4; }
        public void setAxe5(double axe5) { this.axe5 = axe5; }
        public double getAxe5() { return this.axe5; }
        public void setAxe6(double axe6) { this.axe6 = axe6; }
        public double getAxe6() { return this.axe6; }
        public void setAxe7(double axe7) { this.axe7 = axe7; }
        public double getAxe7() { return this.axe7; }
        public void setAxe8(double axe8) { this.axe8 = axe8; }
        public double getAxe8() { return this.axe8; }
        public void setAxe9(double axe9) { this.axe9 = axe9; }
        public double getAxe9() { return this.axe9; }
        public void setAxe10(double axe10) { this.axe10 = axe10; }
        public double getAxe10() { return this.axe10; }
        public void setAxe11(double axe11) { this.axe11 = axe11; }
        public double getAxe11() { return this.axe11; }
        public void setAxe12(double axe12) { this.axe12 = axe12; }
        public double getAxe12() { return this.axe12; }
        public void setAxe13(double axe13) { this.axe13 = axe13; }
        public double getAxe13() { return this.axe13; }
    }
}
