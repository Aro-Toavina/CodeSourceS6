﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace testMaladie.Classe
{
    public class Axe
    {
        private int id;
        private string nom;
        private string mesure;

        public Axe(int id, string nom, string mesure) { this.id = id; this.nom = nom; this.mesure = mesure; }
        public Axe(string nom, string mesure) { this.nom = nom; this.mesure = mesure; }

        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        public void setNom(string nom) { this.nom = nom; }
        public string getNom() { return this.nom; }
        public void setMesure(string mesure) { this.nom = mesure; }
        public string getMesure() { return this.mesure; }
    }
}
