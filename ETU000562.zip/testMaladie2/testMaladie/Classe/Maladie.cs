﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace testMaladie.Classe
{
    public class Maladie
    {
        private int id;
        private string maladie;
        private int idaxe;
        private int moinsOUplus;

        public Maladie(int id, string maladie, int idaxe, int moinsOUplus) { this.id = id; this.maladie = maladie; this.idaxe = idaxe; this.moinsOUplus = moinsOUplus; }
        public Maladie(string maladie, int idaxe, int moinsOUplus) { this.maladie = maladie; this.idaxe = idaxe; this.moinsOUplus = moinsOUplus; }
        public Maladie() {}

        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        public void setMaladie(string maladie) { this.maladie = maladie; }
        public string getMaladie() { return this.maladie; }
        public void setIdaxe(int idaxe) { this.idaxe = idaxe; }
        public int getIdaxe() { return this.idaxe; }
        public void setMoinsOUplus(int moinsOUplus) { this.moinsOUplus = moinsOUplus; }
        public int getMoinsOUplus() { return this.moinsOUplus; }
    }
}
