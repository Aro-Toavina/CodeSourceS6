CREATE TABLE Axe(
	id int not null IDENTITY(0,1),
	nom char(25),
	mesure varchar(15),
	PRIMARY KEY(id)	
);

INSERT INTO Axe VALUES('Hématies','millions/mm3');
INSERT INTO Axe VALUES('Hémoglobine','g/100 mL');
INSERT INTO Axe VALUES('Hémactocrite','%');
INSERT INTO Axe VALUES('Leucocytes','/mm3');
INSERT INTO Axe VALUES('Thrombocytes','/mm3');
INSERT INTO Axe VALUES('Cholestérole totale','mmol/L');
INSERT INTO Axe VALUES('Amylasémie','UI/L');
INSERT INTO Axe VALUES('Triglycérides','g/L');
INSERT INTO Axe VALUES('Glycémie','g/L');
INSERT INTO Axe VALUES('Sodium','mmol');
INSERT INTO Axe VALUES('Potassium','mmol');
INSERT INTO Axe VALUES('Chlore','mmol');
INSERT INTO Axe VALUES('Créatinine','mmol');
INSERT INTO Axe VALUES('ASLO','U/mL');

CREATE TABLE Base(
	id int not null IDENTITY(0,1),
	idaxe int not null,
	calcul char(1),
	base int,
	calculinverse char(1),
	PRIMARY KEY(id),
	FOREIGN KEY(idaxe) REFERENCES Axe(id)
);

INSERT INTO Base VALUES(0,'*',10,'/');
INSERT INTO Base VALUES(3,'/',1000,'*');
INSERT INTO Base VALUES(4,'/',1000,'*');
INSERT INTO Base VALUES(5,'*',10,'/');
INSERT INTO Base VALUES(7,'*',10,'/');
INSERT INTO Base VALUES(8,'*',10,'/');
INSERT INTO Base VALUES(9,'/',10,'*');
INSERT INTO Base VALUES(10,'/',10,'*');
INSERT INTO Base VALUES(11,'/',10,'*');
INSERT INTO Base VALUES(13,'/',10,'*');

CREATE TABLE Normal(
	id int not null IDENTITY(0,1),
	idaxe int not null,
	valeurmin decimal,
	valeurmax decimal,
	sexe int not null,
	agemin int not null,
	agemax int not null,
	calcul char(1),
	base varchar(5),
	calculinverse char(1),
	PRIMARY KEY(id),
	FOREIGN KEY(idaxe) REFERENCES Axe(id)
);

INSERT INTO Normal VALUES(0,4.0,5.33,0,0,100,'*',10,'/');
INSERT INTO Normal VALUES(0,4.22,5.77,1,0,100,'*',10,'/');

INSERT INTO Normal VALUES(1,12.55,15.55,0,0,100,'0','0','0');
INSERT INTO Normal VALUES(1,14.0,17.0,1,0,100,'0','0','0');

INSERT INTO Normal VALUES(2,37,46,0,0,100,'0','0','0');
INSERT INTO Normal VALUES(2,40,52,0,0,100,'0','0','0');

INSERT INTO Normal VALUES(3,4000,10000,2,0,100,'/',1000,'*');

INSERT INTO Normal VALUES(4,150000,400000,2,0,100,'/',1000,'*');

INSERT INTO Normal VALUES(5,3,6.22,2,0,1005,'*',10,'/');

INSERT INTO Normal VALUES(6,0,45,2,0,18,'0','0','0');
INSERT INTO Normal VALUES(6,0,55,2,19,100,'0','0','0');

INSERT INTO Normal VALUES(7,1.55,2,2,0,100,'*',10,'/');

INSERT INTO Normal VALUES(8,0.77,1.006,2,0,100,'*',10,'/');

INSERT INTO Normal VALUES(9,100,300,2,0,100,'/',10,'*');

INSERT INTO Normal VALUES(10,50,100,2,0,100,'/',10,'*');

INSERT INTO Normal VALUES(11,80,270,2,0,100,'/',10,'*');

INSERT INTO Normal VALUES(12,9,12,0,0,100,'0','0','0');
INSERT INTO Normal VALUES(12,10,22,1,0,100,'0','0','0');

INSERT INTO Normal VALUES(13,0,200,2,0,100,'/',10,'*');

CREATE TABLE Maladie(
	id int not null IDENTITY(0,1),
	maladie char(60),
	idaxe int not null,
	moinsOUplus int not null,
	PRIMARY KEY(id),
	FOREIGN KEY(idaxe) REFERENCES Axe(id)
);

INSERT INTO Maladie VALUES('Anémie',0,0);
INSERT INTO Maladie VALUES('Polyglobulie',0,1);

INSERT INTO Maladie VALUES('Anémie',1,0);
INSERT INTO Maladie VALUES('Polyglobulie',1,1);

INSERT INTO Maladie VALUES('Anémie',2,0);
INSERT INTO Maladie VALUES('Polyglobulie',2,1);

INSERT INTO Maladie VALUES('Déficience immunitaire',3,0);
INSERT INTO Maladie VALUES('Infection virale,bactérienne ou parasitaire',3,1);

INSERT INTO Maladie VALUES('Risque : hémoragie',4,0);
INSERT INTO Maladie VALUES('Thrombose',4,1);

INSERT INTO Maladie VALUES('Insuffisance hépatique',5,0);
INSERT INTO Maladie VALUES('Insuffisance hépatique',5,1);

INSERT INTO Maladie VALUES('Pancréatite',6,1);

INSERT INTO Maladie VALUES('Maladies cardiovasculaires et troubles métaboliques',7,1);

INSERT INTO Maladie VALUES('Hypoglycémie',8,0);
INSERT INTO Maladie VALUES('Hyperglycémie',8,1);
INSERT INTO Maladie VALUES('Diabète',8,1);

INSERT INTO Maladie VALUES('Hypochlorhémie',9,0);
INSERT INTO Maladie VALUES('Hyperchlorhémie',9,1);

INSERT INTO Maladie VALUES('Hypochlorhémie',10,0);
INSERT INTO Maladie VALUES('Hyperchlorhémie',10,1);

INSERT INTO Maladie VALUES('Hypochlorhémie',11,0);
INSERT INTO Maladie VALUES('Hyperchlorhémie',11,1);

INSERT INTO Maladie VALUES('Insuffisance rénale',12,1);

INSERT INTO Maladie VALUES('Rhumatisme Articulaire Aigü',13,1);

CREATE TABLE Patient(
	id int not null IDENTITY(0,1),
	nom char(50),
	sexe char(10),
	age int not null,
	daty datetime,
	axe0 decimal,
	axe1 decimal,
	axe2 decimal,
	axe3 decimal,
	axe4 decimal,
	axe5 decimal,
	axe6 decimal,
	axe7 decimal,
	axe8 decimal,
	axe9 decimal,
	axe10 decimal,
	axe11 decimal,
	axe12 decimal,
	axe13 decimal
);

CREATE VIEW Facteur AS SELECT maladie, COUNT(maladie) AS facteur FROM dbo.Maladie GROUP BY maladie;

CREATE TABLE MaladieDetail(
	id int not null IDENTITY(0,1),
	idmaladie int not null,
	idaxe int not null,
	PRIMARY KEY(id),
	FOREIGN KEY(idmaladie) REFERENCES Maladie(id),
	FOREIGN KEY(idaxe) REFERENCES Axe(id)
);