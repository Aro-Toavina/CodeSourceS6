﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using testMaladie.DAO;
using testMaladie.Classe;
using System.Windows.Forms;

namespace testMaladie.Functions
{
    public class Fonctions
    {
        public string dateToday1()
        {
            DateTime d = DateTime.Today;
            string day = (d.Day).ToString();
            string month = (d.Month).ToString();
            string year = (d.Year).ToString();
            string daty = month + "-" + day + "-" + year;
            return daty;
        }
        public string doubleer(string nb)
        {
            string[] split = nb.Split(',',' ','.');
            string sqlfloqt = nb;
            if (nb.Contains(',') == true)
            {
                sqlfloqt = split[0] + "." + split[1] + "F";
            }
            else 
            {
                sqlfloqt = sqlfloqt + "F";
            }
            return sqlfloqt;
        }
        public double calculHypotenuse(double x, double y)
        {
            // 100 = -226 Asus 20 / 46
            // 100 = -230 Prolink 20 / 49 
            return Math.Sqrt(x * x + y * y) * 20.0 / 46;
        }
        public int getAxe(double mathtan, double x, double y) 
        {
            int i = -1;
            if (Math.Abs(calculHypotenuse(x, y)) <= 100)
            {
                if ((mathtan >= 1.338 && mathtan <= 1.566 && x <= 0 && y < 0) || (mathtan >= -1.566 && mathtan <= -1.346 && x >= 0 && y < 0))
                {
                    i = 0;
                }
                if (mathtan >= -1.345 && mathtan <= -0.898 && x > 0 && y < 0)
                {
                    i = 1;
                }
                if (mathtan >= -0.897 && mathtan <= 0.451 && x > 0 && y < 0)
                {
                    i = 2;
                }
                if (mathtan >= -0.450 && mathtan <= 0 && x > 0 && y <= 0)
                {
                    i = 3;
                }
                if (mathtan >= 0.001 && mathtan <= 0.450 && x > 0 && y > 0)
                {
                    i = 4;
                }
                if (mathtan >= 0.451 && mathtan <= 0.887 && x > 0 && y > 0)
                {
                    i = 5;
                }
                if (mathtan >= 0.888 && mathtan <= 1.337 && x > 0 && y > 0)
                {
                    i = 6;
                }
                if ((mathtan >= 1.338 && mathtan <= 1.566 && x >= 0 && y > 0) || (mathtan >= -1.566 && mathtan <= -1.346 && x <= 0 && y > 0))
                {
                    i = 7;
                }
                if (mathtan >= -1.318 && mathtan <= -0.865 && x < 0 && y > 0)
                {
                    i = 8;
                }
                if (mathtan >= -0.864 && mathtan <= -0.420 && x < 0 && y > 0)
                {
                    i = 9;
                }
                if (mathtan >= -0.419 && mathtan <= 0 && x < 0 && y >= 0)
                {
                    i = 10;
                }
                if (mathtan >= 0.001 && mathtan <= 0.461 && x < 0 && y < 0)
                {
                    i = 11;
                }
                if (mathtan >= 0.462 && mathtan <= 0.898 && x < 0 && y < 0)
                {
                    i = 12;
                }
                if (mathtan >= 0.899 && mathtan <= 1.337 && x < 0 && y < 0)
                {
                    i = 13;
                }
            }
            return i;
        }
        public string[] getMaladie(double[] points,Connexion c,int sexe,int age) 
        {
            Liste l = new Liste();
            Maladie m = new Maladie();

            Normal[] normal = new Normal[l.getNormal(c)];
            Maladie[] liste = new Maladie[l.getMaladie(c)];

            normal = l.listeNormal(c);
            liste = l.listeMaladie(c);

            string[] maladie = new string[l.getAxe(c)];

            for (int i = 0; i < points.Length; i++)
            {
                for (int j = 0; j < normal.Length; j++) 
                {
                    if (i == normal[j].getIdaxe()) 
                    {
                        if (normal[j].getCalculinverse() == "*") 
                        {
                            if (points[i] * Int32.Parse(normal[j].getValeur()) > normal[j].getValeurMax()) 
                            {
                                double distance = normal[j].getValeurMax() * Int32.Parse(normal[j].getValeur())  - points[i] * Int32.Parse(normal[j].getValeur());
                                double pas = distance / 100 ;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 1) + (distance2 / pas) + "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                            if (points[i] * Int32.Parse(normal[j].getValeur()) < normal[j].getValeurMin())
                            {
                                double distance = normal[j].getValeurMin() * Int32.Parse(normal[j].getValeur()) - points[i] * Int32.Parse(normal[j].getValeur());
                                double pas = distance / 100;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 0) + (distance2 / pas).ToString() + "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                        }
                        if (normal[j].getCalculinverse() == "/") 
                        {
                            if (points[i] / Int32.Parse(normal[j].getValeur()) > normal[j].getValeurMax())
                            {
                                double distance = normal[j].getValeurMax() / Int32.Parse(normal[j].getValeur()) - points[i] / Int32.Parse(normal[j].getValeur());
                                double pas = distance / 100;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 1) + (distance2 / pas) +  "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                            if (points[i] / Int32.Parse(normal[j].getValeur()) < normal[j].getValeurMin())
                            {
                                double distance = normal[j].getValeurMin() / Int32.Parse(normal[j].getValeur()) - points[i] / Int32.Parse(normal[j].getValeur());
                                double pas = distance / 100;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 0) + (distance2 / pas).ToString() + "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                        }
                        if (normal[j].getCalculinverse() == "0") 
                        {
                            if (points[i] > normal[j].getValeurMax())
                            {
                                double distance = normal[j].getValeurMax() - points[i];
                                double pas = distance / 100;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 1) + (distance2 / pas).ToString() + "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                            if (points[i] < normal[j].getValeurMin())
                            {
                                double distance = normal[j].getValeurMin() - points[i];
                                double pas = distance / 100;
                                double distance2 = distance - points[i];
                                maladie[i] = l.FindMaladie(c, normal[j].getIdaxe(), 0) + (distance2 / pas).ToString() + "%";
                                //MessageBox.Show(maladie[i] + "valeur =" + points[i]);
                            }
                        }
                    }
                }
            }

            return maladie;
        }
    }
}
