﻿using System;
using System.Windows.Forms;
using testMaladie.Classe;
using testMaladie.DAO;
using testMaladie.Functions;

namespace testMaladie
{
    public partial class Form1 : Form
    {
        Liste l = new Liste();
        Connexion c = new Connexion();
        Fonctions f = new Fonctions();

        public double[] points = new double[14]; // Axe et y

        public bool selection = false;
        public int axeSelected;

        public int maxY = 100;

        //Asus y = 350
        //Prolink y = 346
        public int xchart = 368;
        public int ychart = 350; 

        public double tan = 0;
        public double hyp = 0;
        public double mathtan = 0;
        
        public Form1()
        {
            InitializeComponent();
            //IsSelection.Text = selection.ToString();
            c.getCon();

            this.Etat.ChartAreas[0].AxisY.Maximum = maxY;

            for (int i = 0; i < points.Length; i++) 
            {
                this.Etat.Series["Etat"].Points.AddY(i);
                this.Etat.Series["Etat"].Points[i].AxisLabel = l.listeAxe(c)[i].getNom();
                dataGridView1.Rows.Add(l.listeAxe(c)[i].getNom(),i,l.listeAxe(c)[i].getMesure());
            }

            c.close();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
  
        }

        private void Etat_Click(object sender, EventArgs e)
        {
            selection = false;
            //IsSelection.Text = selection.ToString();
            //Fonction pour voir la maladie
        }

        private void Etat_MouseMove(object sender, MouseEventArgs e)
        {
            if (selection == true) 
            {
                MouseEventArgs mousevent = (MouseEventArgs)e; // 

                double[] yvalues = new double[1]; //Stockage de la valeur de y

                double x = mousevent.X - xchart;
                double y = mousevent.Y - ychart;
                //xvalue.Text = "x= " + x.ToString();
                //yvalue.Text = "y= " + y.ToString();

                if (x != 0) { 
                    tan = y / x; hyp = f.calculHypotenuse(x, y);
                    mathtan = Math.Atan(tan);
                }

                //tangente.Text = "tan= " + tan.ToString();
                //hypotenuse.Text = "hyp= " + hyp.ToString();
                //Atan.Text = "Atan = " + mathtan.ToString();

                yvalues[0] = double.Parse(x.ToString());

                if (hyp > 100) { 
                    yvalues[0] = 100;
                    points[axeSelected] = yvalues[0];
                    this.dataGridView1.Rows[axeSelected].Cells[1].Value = yvalues[0];
                    Etat.Series["Etat"].Points[axeSelected].YValues = yvalues; 
                }
                if (hyp <= 0)
                {
                    yvalues[0] = 0;
                    points[axeSelected] = yvalues[0];
                    this.dataGridView1.Rows[axeSelected].Cells[1].Value = yvalues[0];
                    Etat.Series["Etat"].Points[axeSelected].YValues = yvalues;
                }
                if(hyp >= 0 && hyp <= 100) {
                    yvalues[0] = hyp;
                    points[axeSelected] = yvalues[0];
                    this.dataGridView1.Rows[axeSelected].Cells[1].Value = yvalues[0];
                    Etat.Series["Etat"].Points[axeSelected].YValues = yvalues; 
                }
            }
        }

        private void Etat_DoubleClick(object sender, EventArgs e)
        {
            MouseEventArgs mousevent = (MouseEventArgs)e;
            double x = mousevent.X - xchart;
            double y = mousevent.Y - ychart;
            if (x != 0)
            {
                tan = y / x; hyp = f.calculHypotenuse(x, y);
                mathtan = Math.Atan(tan);
            }
            axeSelected = f.getAxe(mathtan, x, y);
            if (axeSelected >= 0 && axeSelected <= 13)
            {
                selection = true;
            }
            //MessageBox.Show(label);
            //this.Etat.Series["Etat"].Points.Clear();
            //points[0] = mousevent.X - 201;
            //MessageBox.Show("x=" + this.Etat.ChartAreas[0].AxisX.PixelPositionToValue(mousevent.X).ToString() + "\n" + "y=" + this.Etat.ChartAreas[0].AxisY.PixelPositionToValue(mousevent.Y).ToString());
        }

        private void Enregistrer_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            string[] maladie = f.getMaladie(points, c, 0, 0);
            for (int i = 0; i < maladie.Length; i++) 
            {
                if (maladie[i] != "--%")
                {
                    dataGridView2.Rows.Add(maladie[i]);
                }
            }
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Enregistrer_Click_1(object sender, EventArgs e)
        {
            Patient p = new Patient(Nom.Text.ToString(),comboBox1.Text.ToString(), int.Parse(Age.Value.ToString()),null,
                double.Parse((dataGridView1.Rows[0].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[1].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[2].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[3].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[4].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[5].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[6].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[7].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[8].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[9].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[10].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[11].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[12].Cells[1].Value).ToString()),
                double.Parse((dataGridView1.Rows[13].Cells[1].Value).ToString())
                );
            l.insertPatient(c, p);
			MessageBox.Show("Patient " + Nom.Text.ToString() + "enregistré");
        }
    }
}
