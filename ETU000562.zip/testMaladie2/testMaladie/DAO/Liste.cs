﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using testMaladie.Classe;
using System.Data.SqlClient;
using System.Windows.Forms;
using testMaladie.Functions;

namespace testMaladie.DAO
{
    public class Liste
    {
        public int getAxe(Connexion c) 
        {
            int nb = 0;
            try
            {
                string select = "select count(id) from Axe ";
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    nb = sd.GetInt32(0);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return nb;
        }
        public int getNormal(Connexion c) 
        {
            int nb = 0;
            try
            {
                string select = "select count(id) from Normal ";
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    nb = sd.GetInt32(0);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return nb;
        }
        public int getMaladie(Connexion c) 
        {
            int nb = 0;
            try
            {
                string select = "select count(id) from Maladie ";
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    nb = sd.GetInt32(0);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return nb;
        }

        public Axe[] listeAxe(Connexion c)
        {
            Axe[] liste = new Axe[getAxe(c)];
            try
            {
                string select = "select * from Axe ";
                SqlDataReader sd = c.DataReader(select);
                int i = 0;
                while (sd.Read())
                {
                    liste[i] = new Axe(sd.GetInt32(0), sd.GetString(1), sd.GetString(2));
                    i++;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }
        public Normal[] listeNormal(Connexion c)
        {
            Fonctions f = new Fonctions();
            Normal[] liste = new Normal[getNormal(c)];
            try
            {
                string select = "select * from Normal ";
                SqlDataReader sd = c.DataReader(select);
                int i = 0;
                while (sd.Read()) {
                    //MessageBox.Show(sd.GetInt32(1) + "," + (f.doubleer(sd.GetValue(2).ToString())).ToString() + "," + (f.doubleer(sd.GetValue(3).ToString())).ToString());
                    liste[i] = new Normal(sd.GetInt32(1),sd.GetDecimal(2).ToString(),sd.GetDecimal(3).ToString(),sd.GetInt32(4),sd.GetInt32(5),sd.GetInt32(6),sd.GetString(7),sd.GetString(8),sd.GetString(9));
                    i++;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }
        public Maladie[] listeMaladie(Connexion c) 
        {
            Maladie[] liste = new Maladie[getMaladie(c)];
            try
            {
                string select = "select * from Maladie ";
                SqlDataReader sd = c.DataReader(select);
                int i = 0;
                while (sd.Read())
                {
                    liste[i] = new Maladie(sd.GetInt32(0), sd.GetString(1),sd.GetInt32(2), sd.GetInt32(3));
                    i++;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }

        public string FindMaladie(Connexion c, int id) 
        {
            string maladie = "--";
            try
            {
                string select = "select * from Maladie where id = " +id ;
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    maladie = sd.GetString(0);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return maladie;
        }
        public string FindMaladie(Connexion c, int idaxe, int moinsOUplus) 
        {
            string maladie = "--";
            try
            {
                string select = "select * from Maladie where idaxe = " + idaxe + "AND moinsOUplus = " + moinsOUplus ;
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    maladie = sd.GetString(1);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return maladie;
        }
        public int FindFacteur(Connexion c, string nom) 
        {
            int facteur = 0 ;
            try
            {
                string select = "select * from Facteur where maladie = " + nom;
                SqlDataReader sd = c.DataReader(select);
                while (sd.Read())
                {
                    facteur = sd.GetInt32(1);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return facteur;
        }

        public void insertPatient(Connexion c, Patient p) 
        {
            Fonctions f = new Fonctions();
            try
            {
                string insert = "insert into Patient( nom,  sexe,  age,  daty,  axe0,  axe1,  axe2,  axe3,  axe4,  axe5,  axe6,  axe7,  axe8,  axe9,  axe10,  axe11,  axe12,  axe13) VALUES('"
                                + p.getNom() + "','"
                                + p.getSexe() + "',"
                                + p.getAge() + ",'"
                                + f.dateToday1() + "',"
                                + p.getAxe0() + ","
                                + p.getAxe1() + ","
                                + p.getAxe2() + ","
                                + p.getAxe3() + ","
                                + p.getAxe4() + ","
                                + p.getAxe5() + ","
                                + p.getAxe6() + ","
                                + p.getAxe7() + ","
                                + p.getAxe8() + ","
                                + p.getAxe9() + ","
                                + p.getAxe10() + ","
                                + p.getAxe11() + ","
                                + p.getAxe12() + ","
                                + p.getAxe13() + ")";
                c.ExecuteQueries(insert);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
