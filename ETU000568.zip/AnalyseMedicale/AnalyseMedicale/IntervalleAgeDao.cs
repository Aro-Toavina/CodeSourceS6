﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class IntervalleAgeDao
    {
        private string table = "IntervalleAge";

        public IntervalleAge findById(int id)
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table + " WHERE IdIntervalleAge = " + id;
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    int ageMin = int.Parse(reader["AgeMin"].ToString()),
                        ageMax = int.Parse(reader["AgeMax"].ToString());
                    return new IntervalleAge(id, ageMin, ageMax);
                }
                return null;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
