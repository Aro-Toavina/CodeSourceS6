﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class IntervalleAge
    {
        private int idIntervalleAge;
        private int ageMin;
        private int ageMax;

        public IntervalleAge(int idIntervalleAge, int ageMin, int ageMax)
        {
            IdIntervalleAge = idIntervalleAge;
            AgeMin = ageMin;
            AgeMax = ageMax;
        }

        public int IdIntervalleAge
        {
            get
            {
                return idIntervalleAge;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id négatif : " + value);
                idIntervalleAge = value;
            }
        }

        public int AgeMin
        {
            get
            {
                return ageMin;
            }

            set
            {
                if (value < 0 || value > 120)
                    throw new Exception("Age incroyable : " + value);
                ageMin = value;
            }
        }

        public int AgeMax
        {
            get
            {
                return ageMax;
            }

            set
            {
                if (value < 0 || value > 120)
                    throw new Exception("Age incroyable : " + value);
                ageMax = value;
            }
        }
    }
}
