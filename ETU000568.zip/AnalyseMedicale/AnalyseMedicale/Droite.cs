﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class Droite
    {
        private Point ptA;
        private Point ptB;

        public double getY0(double cd)
        {
            return ptA.Y - (cd * ptA.X);
        }

        public double getCoefDir()
        {
            if (ptA.X == ptB.X)
                return -1000;
            else
            {
                double n = (ptB.Y - ptA.Y),
                    d = (ptB.X - ptA.X);
                return n / d;
            }
        }

        public Droite(Point ptA, Point ptB)
        {
            PtA = ptA;
            PtB = ptB;
        }

        public Point PtA
        {
            get
            {
                return ptA;
            }

            set
            {
                ptA = value;
            }
        }

        public Point PtB
        {
            get
            {
                return ptB;
            }

            set
            {
                ptB = value;
            }
        }
    }
}
