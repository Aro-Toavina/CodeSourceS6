﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class DonneesDao
    {
        private string table = "Donnees";

        public Donnees[] findByIdMaladie(int idMaladie)
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table + " WHERE IdMaladie = " + idMaladie;
                reader = command.ExecuteReader();
                List<Donnees> donnees = new List<Donnees>();
                while (reader.Read())
                {
                    int id = int.Parse(reader["IdDonnees"].ToString()),
                        idAxe = int.Parse(reader["IdAxe"].ToString());
                    float valeur = float.Parse(reader["Valeur"].ToString());
                    donnees.Add(new Donnees(id, idAxe, idMaladie, valeur));
                }
                return donnees.ToArray();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
