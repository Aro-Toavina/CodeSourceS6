﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class GrapheMath
    {
        private Point[] pts;

        public int comparer(GrapheMath graphe)
        {
            return 0;
        }

        public GrapheMath(Point[] pts)
        {
            Pts = pts;
        }

        public GrapheMath() {}

        public Point[] Pts
        {
            get
            {
                return pts;
            }

            set
            {
                pts = value;
            }
        }
    }
}
