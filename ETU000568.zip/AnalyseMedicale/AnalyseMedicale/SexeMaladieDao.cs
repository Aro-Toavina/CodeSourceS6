﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class SexeMaladieDao
    {
        private string table = "SexeMaladie";

        public SexeMaladie findById(int id)
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table + " WHERE IdSexeMaladie = " + id;
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string nom = reader["NomSexeMaladie"].ToString();
                    return new SexeMaladie(id, nom);
                }
                return null;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }

        public SexeMaladie[] findAll()
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table;
                reader = command.ExecuteReader();
                List<SexeMaladie> sexes = new List<SexeMaladie>();
                while (reader.Read())
                {
                    int id = int.Parse(reader["IdSexeMaladie"].ToString());
                    string nom = reader["NomSexeMaladie"].ToString();
                    sexes.Add(new SexeMaladie(id, nom));
                }
                return sexes.ToArray();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
