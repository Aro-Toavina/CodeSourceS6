﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class Axe
    {
        private int idAxe;
        private string label;
        private string unite;
        private float vnMin;
        private float vnMax;

        public Axe(int idAxe, string label, string unite, float vnMin, float vnMax)
        {
            IdAxe = idAxe;
            Label = label;
            Unite = unite;
            VnMin = vnMin;
            VnMax = vnMax;
        }

        public int IdAxe
        {
            get
            {
                return idAxe;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id négatif : " + value);
                idAxe = value;
            }
        }

        public string Label
        {
            get
            {
                return label;
            }

            set
            {
                if (value.Equals(""))
                    throw new Exception("Label d'axe vide");
                label = value;
            }
        }

        public string Unite
        {
            get
            {
                return unite;
            }

            set
            {
                if (value.Equals(""))
                    throw new Exception("Unité vide");
                unite = value;
            }
        }

        public float VnMin
        {
            get
            {
                return vnMin;
            }

            set
            {
                if (value < 0)
                    throw new Exception("Valeur normale min négative : " + value);
                vnMin = value;
            }
        }

        public float VnMax
        {
            get
            {
                return vnMax;
            }

            set
            {
                if (value < 0)
                    throw new Exception("Valeur normale max négative : " + value);
                vnMax = value;
            }
        }
    }
}
