﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class Util
    {
        public static double getDistance(Point pt1, Point pt2)
        {
            double x1 = pt1.X,
                x2 = pt2.X,
                y1 = pt1.Y,
                y2 = pt2.Y,
                x = (x2 - x1) * (x2 - x1),
                y = (y2 - y1) * (y2 - y1);
            return Math.Sqrt(x + y);
        }

        public static Point getIntersectionPerpend(Droite d, Point pt, Point centre)
        {
            double a1 = d.getCoefDir();
            if (a1 == -1000)
                return new Point(centre.X, pt.Y);
            else if (a1 == 0)
                return new Point(pt.X, centre.Y);
            else
            {
                double a2 = -1.0 / a1,
                    b1 = d.getY0(a1),
                    b2 = pt.Y - (a2 * pt.X),
                    num = (b2 - b1),
                    den = (a1 - a2),
                    x = num / den,
                    y = (a2 * x) + b2;
                return new Point(int.Parse(Math.Round(x).ToString()), int.Parse(Math.Round(y).ToString()));
            }
        }

        public static bool comprisEntre(int nb, int min, int max)
        {
            return (nb >= min && nb <= max);
        }
    }
}
