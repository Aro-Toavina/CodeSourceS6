﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class SexeMaladie
    {
        private int idSexeMaladie;
        private string nomSexeMaladie;

        public SexeMaladie(int idSexeMaladie, string nomSexeMaladie)
        {
            IdSexeMaladie = idSexeMaladie;
            NomSexeMaladie = nomSexeMaladie;
        }

        public int IdSexeMaladie
        {
            get
            {
                return idSexeMaladie;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id négatif : " + value);
                idSexeMaladie = value;
            }
        }

        public string NomSexeMaladie
        {
            get
            {
                return nomSexeMaladie;
            }

            set
            {
                if (!value.Equals("M") && !value.Equals("F") && !value.Equals("M/F"))
                    throw new Exception("Sexe pour maladie invalide : " + value);
                nomSexeMaladie = value;
            }
        }
    }
}
