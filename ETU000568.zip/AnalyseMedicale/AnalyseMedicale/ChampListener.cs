﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale
{
    public class ChampListener
    {
        private Fenetre fenetre;

        public void champAgeLostFocus(object sender, EventArgs e)
        {
            Label labelMaladie = fenetre.getLabelMaladie();
            TextBox champAge = fenetre.getChampAge();
            labelMaladie.Text = champAge.Text;
        }

        public ChampListener(Fenetre fenetre)
        {
            Fenetre = fenetre;
        }

        public ChampListener() {}

        public Fenetre Fenetre
        {
            get
            {
                return fenetre;
            }

            set
            {
                fenetre = value;
            }
        }
    }
}
