﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale
{
    public partial class Fenetre : Form
    {
        private Maladie[] maladies;
        private Graphe graphe;

        public Fenetre()
        {
            InitializeComponent();
            graphe = new Graphe(panelGraphe);
            maladies = (new MaladieDao()).findAll();
            initListener();
        }

        private void initListener()
        {
            GrapheListener listener = new GrapheListener(this);
            panelGraphe.MouseDown += new MouseEventHandler(listener.grapheMouseDown);
            panelGraphe.MouseUp += new MouseEventHandler(listener.grapheMouseUp);
            panelGraphe.MouseMove += new MouseEventHandler(listener.grapheMouseMove);
            ChampListener cListener = new ChampListener(this);
            champAge.LostFocus += new EventHandler(cListener.champAgeLostFocus);
        }

        public ComboBox getChampSexe()
        {
            return champSexe;
        }

        public TextBox getChampAge()
        {
            return champAge;
        }

        public Label getLabelMaladie()
        {
            return labelMaladie;
        }

        public Graphe getGraphe()
        {
            return graphe;
        }

        public void repaint()
        {
            panelGraphe.Refresh();
            graphe.dessiner();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            graphe.dessiner();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
