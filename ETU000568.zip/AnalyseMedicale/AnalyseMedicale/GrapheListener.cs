﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale
{
    public class GrapheListener
    {
        private bool mousePressed = false;
        private Point ptEnCours;
        private Fenetre fenetre;
        private int indexPtEncours = -1;
        private Droite axe;

        public void grapheMouseMove(object sender, MouseEventArgs m)
        {
            if (mousePressed)
            {
                Point temp = new Point(m.X, m.Y);
                double distance = Util.getDistance(fenetre.getGraphe().Centre, temp);
                if (distance >= 0 && distance <= 210)
                {
                    setPtsPolygon(getPtProcheDroite(temp));
                    fenetre.repaint();
                }
            }
        }

        private Point getPtProcheDroite(Point pt)
        {
            return Util.getIntersectionPerpend(axe, pt, fenetre.getGraphe().Centre);
        }

        private void setPtsPolygon(Point pt)
        {
            fenetre.getGraphe().PtsPolygon[indexPtEncours] = pt;
        }

        public void grapheMouseDown(object sender, MouseEventArgs m)
        {
            if (setPtEncours(m.X, m.Y))
            {
                setAxe();
                mousePressed = true;
            }
        }

        private void setAxe()
        {
            axe = new Droite(fenetre.getGraphe().Centre, ptEnCours);
        }

        private bool setPtEncours(int x, int y)
        {
            Graphe graphe = Fenetre.getGraphe();
            Point[] ptsPolygon = graphe.PtsPolygon;
            for (int i = 0; i < 14; i++)
            {
                if (Util.comprisEntre(ptsPolygon[i].X, x - 5, x + 5) && Util.comprisEntre(ptsPolygon[i].Y, y - 5, y + 5))
                {
                    ptEnCours = ptsPolygon[i];
                    indexPtEncours = i;
                    return true;
                }
            }
            return false;
        }

        public void grapheMouseUp(object sender, MouseEventArgs m)
        {
            mousePressed = false;
            ptEnCours = new Point();
            axe = null;
        }

        public GrapheListener(Fenetre fenetre)
        {
            Fenetre = fenetre;
        }

        public Fenetre Fenetre
        {
            get
            {
                return fenetre;
            }

            set
            {
                fenetre = value;
            }
        }
    }
}
