﻿namespace AnalyseMedicale
{
    partial class Fenetre
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuBar = new System.Windows.Forms.MenuStrip();
            this.menusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelGraphe = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelMaladie = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.champSexe = new System.Windows.Forms.ComboBox();
            this.champAge = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuBar.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuBar
            // 
            this.menuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menusToolStripMenuItem});
            this.menuBar.Location = new System.Drawing.Point(0, 0);
            this.menuBar.Name = "menuBar";
            this.menuBar.Size = new System.Drawing.Size(772, 24);
            this.menuBar.TabIndex = 0;
            this.menuBar.Text = "menuBar";
            // 
            // menusToolStripMenuItem
            // 
            this.menusToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitterToolStripMenuItem});
            this.menusToolStripMenuItem.Name = "menusToolStripMenuItem";
            this.menusToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.menusToolStripMenuItem.Text = "Menus";
            // 
            // quitterToolStripMenuItem
            // 
            this.quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            this.quitterToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.quitterToolStripMenuItem.Text = "Quitter";
            this.quitterToolStripMenuItem.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // panelGraphe
            // 
            this.panelGraphe.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panelGraphe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGraphe.Location = new System.Drawing.Point(13, 28);
            this.panelGraphe.Name = "panelGraphe";
            this.panelGraphe.Size = new System.Drawing.Size(450, 450);
            this.panelGraphe.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(469, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(291, 279);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.labelMaladie);
            this.panel2.Location = new System.Drawing.Point(24, 161);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(239, 100);
            this.panel2.TabIndex = 5;
            // 
            // labelMaladie
            // 
            this.labelMaladie.AutoSize = true;
            this.labelMaladie.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMaladie.Location = new System.Drawing.Point(18, 34);
            this.labelMaladie.Name = "labelMaladie";
            this.labelMaladie.Size = new System.Drawing.Size(99, 29);
            this.labelMaladie.TabIndex = 0;
            this.labelMaladie.Text = "Maladie";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.champSexe);
            this.panel3.Controls.Add(this.champAge);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(24, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(239, 121);
            this.panel3.TabIndex = 4;
            // 
            // champSexe
            // 
            this.champSexe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.champSexe.FormattingEnabled = true;
            this.champSexe.Items.AddRange(new object[] {
            "Masculin",
            "Féminin"});
            this.champSexe.Location = new System.Drawing.Point(78, 60);
            this.champSexe.Name = "champSexe";
            this.champSexe.Size = new System.Drawing.Size(127, 33);
            this.champSexe.TabIndex = 3;
            // 
            // champAge
            // 
            this.champAge.CausesValidation = false;
            this.champAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.champAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.champAge.Location = new System.Drawing.Point(78, 17);
            this.champAge.Name = "champAge";
            this.champAge.Size = new System.Drawing.Size(127, 32);
            this.champAge.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sexe";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Age";
            // 
            // Fenetre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 488);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelGraphe);
            this.Controls.Add(this.menuBar);
            this.MainMenuStrip = this.menuBar;
            this.MaximizeBox = false;
            this.Name = "Fenetre";
            this.Text = "Fenetre d\'analyse";
            this.menuBar.ResumeLayout(false);
            this.menuBar.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuBar;
        private System.Windows.Forms.ToolStripMenuItem menusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitterToolStripMenuItem;
        private System.Windows.Forms.Panel panelGraphe;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelMaladie;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox champSexe;
        private System.Windows.Forms.TextBox champAge;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

