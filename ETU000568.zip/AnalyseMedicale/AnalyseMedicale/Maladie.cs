﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class Maladie
    {
        private int idMaladie;
        private string nom;
        private string description;
        private int idIntervalleAge;
        private int idSexeMaladie;

        private IntervalleAge intervalleAge;
        private SexeMaladie sexeMaladie;
        private Donnees[] donnees;

        public IntervalleAge getIntervalleAge()
        {
            return intervalleAge;
        }

        public SexeMaladie getSexeMaladie()
        {
            return sexeMaladie;
        }

        public Donnees[] getDonnees()
        {
            return donnees;
        }

        public Maladie(int idMaladie, string nom, string description, int idIntervalleAge, int idSexeMaladie)
        {
            IdMaladie = idMaladie;
            Nom = nom;
            Description = description;
            IdIntervalleAge = idIntervalleAge;
            IdSexeMaladie = idSexeMaladie;
            intervalleAge = (new IntervalleAgeDao()).findById(IdIntervalleAge);
            sexeMaladie = (new SexeMaladieDao()).findById(IdSexeMaladie);
            donnees = (new DonneesDao()).findByIdMaladie(IdMaladie);
        }

        public int IdMaladie
        {
            get
            {
                return idMaladie;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id négatif : " + value);
                idMaladie = value;
            }
        }

        public string Nom
        {
            get
            {
                return nom;
            }

            set
            {
                if (value.Equals(""))
                    throw new Exception("Nom de maladie vide");
                nom = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public int IdIntervalleAge
        {
            get
            {
                return idIntervalleAge;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id intervalle d'âge négatif : " + value);
                idIntervalleAge = value;
            }
        }

        public int IdSexeMaladie
        {
            get
            {
                return idSexeMaladie;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id sexe maladie négatif : " + value);
                idSexeMaladie = value;
            }
        }
    }
}
