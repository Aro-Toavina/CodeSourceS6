﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class AxeDao
    {
        private string table = "Axe";

        public Axe findById(int id)
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table + " WHERE IdAxe = " + id;
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    string label = reader["Label"].ToString(),
                        unite = reader["Unite"].ToString();
                    float vnMin = float.Parse(reader["VnMin"].ToString()),
                        vnMax = float.Parse(reader["VnMax"].ToString());
                    return new Axe(id, label, unite, vnMin, vnMax);
                }
                return null;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
