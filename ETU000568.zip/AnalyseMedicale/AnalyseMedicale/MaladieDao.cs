﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class MaladieDao
    {
        private string table = "Maladie";

        public Maladie[] findAll()
        {
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader reader = null;
            try
            {
                connection = (new DBConnection()).get();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM " + table;
                reader = command.ExecuteReader();
                List<Maladie> maladies = new List<Maladie>();
                while (reader.Read())
                {
                    int id = int.Parse(reader["IdMaladie"].ToString()),
                        idIA = int.Parse(reader["IdIntervalleAge"].ToString()),
                        idSM = int.Parse(reader["IdSexeMaladie"].ToString());
                    string nom = reader["Nom"].ToString(),
                        description = reader["Description"].ToString();
                    maladies.Add(new Maladie(id, nom, description, idIA, idSM));
                }
                return maladies.ToArray();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
