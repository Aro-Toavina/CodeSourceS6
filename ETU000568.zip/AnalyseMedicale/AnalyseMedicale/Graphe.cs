﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalyseMedicale
{
    public class Graphe
    {
        private Panel panelGraphe;
        private Point centre;
        private Point[] extremitesAxes;
        private Point[] ptsPolygon;

        public GrapheMath getGraphe()
        {
            return new GrapheMath(PtsPolygon);
        }

        public void dessiner()
        {
            Graphics g = PanelGraphe.CreateGraphics();
            Pen pen = new Pen(Color.Gray);
            SolidBrush brush1 = new SolidBrush(Color.Red),
                brush2 = new SolidBrush(Color.Green),
                brush3 = new SolidBrush(Color.LightBlue);
            g.DrawEllipse(pen, 15, 15, 420, 420);
            g.FillPolygon(brush3, PtsPolygon);
            for (int i = 0; i < 14; i++)
            {
                g.FillEllipse(brush1, ExtremitesAxes[i].X - 3, ExtremitesAxes[i].Y - 3, 6, 6);
                g.FillEllipse(brush2, PtsPolygon[i].X - 5, PtsPolygon[i].Y - 5, 10, 10);
                g.DrawLine(pen, Centre, ExtremitesAxes[i]);
            }
            g.FillEllipse(brush1, Centre.X - 3, Centre.Y - 3, 6, 6);
            g.Dispose();
        }

        private void setPtsPolygon()
        {
            PtsPolygon = new Point[14];
            double k = 6.0 / 7.0;
            for (int i = 0; i < 14; i++)
            {
                int x = getXImageHom(ExtremitesAxes[i].X, k),
                    y = getYImageHom(ExtremitesAxes[i].Y, k);
                PtsPolygon[i] = new Point(x, y);
            }
        }

        private int getYImageHom(int y, double k)
        {
            double yImage = (k * (y - Centre.Y)) + Centre.Y;
            return int.Parse(Math.Round(yImage).ToString());
        }

        private int getXImageHom(int x, double k)
        {
            double xImage = (k * (x - Centre.X)) + Centre.X;
            return int.Parse(Math.Round(xImage).ToString());
        }

        public Graphe(Panel panelGraphe)
        {
            PanelGraphe = panelGraphe;
            setCentre();
            setExtremitesAxes();
            setPtsPolygon();
        }

        private void setExtremitesAxes()
        {
            ExtremitesAxes = new Point[14];
            ExtremitesAxes[0] = new Point(435, 225);
            double angle = Math.PI / 7,
                temp = angle;
            for (int i = 1; i < 14; i++)
            {
                int x = getXImageRot(435, 225, angle),
                    y = getYImageRot(435, 225, angle);
                ExtremitesAxes[i] = new Point(x, y);
                angle += temp;
            }
        }

        private int getYImageRot(int x, int y, double angle)
        {
            double yImage = (x - Centre.X) * Math.Sin(angle);
            yImage += (y - Centre.Y) * Math.Cos(angle);
            yImage += Centre.Y;
            return int.Parse(Math.Round(yImage).ToString());
        }

        private int getXImageRot(int x, int y, double angle)
        {
            double xImage = (x - Centre.X) * Math.Cos(angle);
            xImage += (Centre.Y - y) * Math.Sin(angle);
            xImage += Centre.X;
            return int.Parse(Math.Round(xImage).ToString());
        }

        private void setCentre()
        {
            Centre = new Point(PanelGraphe.Width / 2, PanelGraphe.Width / 2);
        }

        public Graphe() {}

        public Panel PanelGraphe
        {
            get
            {
                return panelGraphe;
            }

            set
            {
                panelGraphe = value;
            }
        }

        public Point Centre
        {
            get
            {
                return centre;
            }

            set
            {
                centre = value;
            }
        }

        public Point[] ExtremitesAxes
        {
            get
            {
                return extremitesAxes;
            }

            set
            {
                extremitesAxes = value;
            }
        }

        public Point[] PtsPolygon
        {
            get
            {
                return ptsPolygon;
            }

            set
            {
                ptsPolygon = value;
            }
        }
    }
}
