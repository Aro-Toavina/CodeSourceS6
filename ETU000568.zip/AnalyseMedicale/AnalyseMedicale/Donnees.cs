﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnalyseMedicale
{
    public class Donnees
    {
        private int idDonnees;
        private int idAxe;
        private int idMaladie;
        private float valeur;

        private Axe axe;

        public Axe getAxe()
        {
            return axe;
        }

        public Donnees(int idDonnees, int idAxe, int idMaladie, float valeur)
        {
            IdDonnees = idDonnees;
            IdAxe = idAxe;
            IdMaladie = idMaladie;
            Valeur = valeur;
            axe = (new AxeDao()).findById(IdAxe);
        }

        public int IdDonnees
        {
            get
            {
                return idDonnees;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id négatif : " + value);
                idDonnees = value;
            }
        }

        public int IdAxe
        {
            get
            {
                return idAxe;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id axe négatif : " + value);
                idAxe = value;
            }
        }

        public int IdMaladie
        {
            get
            {
                return idMaladie;
            }

            set
            {
                if (value <= 0)
                    throw new Exception("Id maladie négatif : " + value);
                idMaladie = value;
            }
        }

        public float Valeur
        {
            get
            {
                return valeur;
            }

            set
            {
                if (value < 0)
                    throw new Exception("Valeur négative : " + value);
                valeur = value;
            }
        }
    }
}
