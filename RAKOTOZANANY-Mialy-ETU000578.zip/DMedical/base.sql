CREATE TABLE [dbo].[Categorie] (
    [Id]       INT          IDENTITY (1, 1) NOT NULL,
    [intitule] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

SET IDENTITY_INSERT [dbo].[Categorie] ON
INSERT INTO [dbo].[Categorie] ([Id], [intitule]) VALUES (1, N'Hématologie')
SET IDENTITY_INSERT [dbo].[Categorie] OFF

CREATE TABLE [dbo].[Composition] (
    [Id]        INT             IDENTITY (1, 1) NOT NULL,
    [IdMaladie] INT             NOT NULL,
    [IdElement] INT             NOT NULL,
    [Min]       DECIMAL (18, 2) NOT NULL,
    [Max]       DECIMAL (18, 2) NOT NULL,
    [Type]      INT             NOT NULL,
    [Sexe]      INT             NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Table_ToTable_3] FOREIGN KEY ([IdMaladie]) REFERENCES [dbo].[Maladie] ([Id])
);

SET IDENTITY_INSERT [dbo].[Composition] ON
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (1, 1, 1002, CAST(5.70 AS Decimal(18, 2)), CAST(7.00 AS Decimal(18, 2)), 1, 1)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (2, 1, 1002, CAST(5.30 AS Decimal(18, 2)), CAST(7.00 AS Decimal(18, 2)), 1, 2)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (3, 1, 1002, CAST(5.40 AS Decimal(18, 2)), CAST(7.00 AS Decimal(18, 2)), 1, 3)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (4, 2, 1002, CAST(3.00 AS Decimal(18, 2)), CAST(4.20 AS Decimal(18, 2)), 2, 1)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (5, 2, 1002, CAST(3.00 AS Decimal(18, 2)), CAST(4.00 AS Decimal(18, 2)), 2, 2)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (6, 2, 1002, CAST(3.00 AS Decimal(18, 2)), CAST(4.00 AS Decimal(18, 2)), 2, 3)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (7, 2, 1010, CAST(3000.00 AS Decimal(18, 2)), CAST(4000.00 AS Decimal(18, 2)), 2, 1)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (8, 2, 1010, CAST(3000.00 AS Decimal(18, 2)), CAST(4000.00 AS Decimal(18, 2)), 2, 2)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (9, 2, 1010, CAST(3000.00 AS Decimal(18, 2)), CAST(5000.00 AS Decimal(18, 2)), 2, 3)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (10, 2, 1015, CAST(1000.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 1, 1)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (13, 2, 1015, CAST(1000.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 1, 2)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (16, 2, 1015, CAST(1500.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 1, 3)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (17, 2, 1011, CAST(1500.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 2, 1)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (18, 2, 1011, CAST(1500.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 2, 2)
INSERT INTO [dbo].[Composition] ([Id], [IdMaladie], [IdElement], [Min], [Max], [Type], [Sexe]) VALUES (19, 2, 1011, CAST(1500.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 2, 3)
SET IDENTITY_INSERT [dbo].[Composition] OFF

CREATE TABLE [dbo].[Dosage] (
    [Id]        INT             IDENTITY (1, 1) NOT NULL,
    [Sexe]      INT             NOT NULL,
    [IdElement] INT             NOT NULL,
    [NormMax]   DECIMAL (18, 2) NOT NULL,
    [NormMin]   DECIMAL (18, 2) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

SET IDENTITY_INSERT [dbo].[Dosage] ON
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (1, 1, 1002, CAST(5.70 AS Decimal(18, 2)), CAST(4.20 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (2, 2, 1002, CAST(5.30 AS Decimal(18, 2)), CAST(4.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (3, 3, 1002, CAST(5.40 AS Decimal(18, 2)), CAST(4.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (4, 1, 1010, CAST(10000.00 AS Decimal(18, 2)), CAST(4000.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (5, 2, 1010, CAST(10000.00 AS Decimal(18, 2)), CAST(4000.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (7, 3, 1010, CAST(11000.00 AS Decimal(18, 2)), CAST(5000.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (8, 1, 1015, CAST(1000.00 AS Decimal(18, 2)), CAST(80.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (9, 2, 1015, CAST(1000.00 AS Decimal(18, 2)), CAST(80.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (10, 3, 1015, CAST(1500.00 AS Decimal(18, 2)), CAST(100.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (11, 1, 1011, CAST(8000.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (12, 2, 1011, CAST(8000.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[Dosage] ([Id], [Sexe], [IdElement], [NormMax], [NormMin]) VALUES (13, 3, 1011, CAST(6000.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)))
SET IDENTITY_INSERT [dbo].[Dosage] OFF

CREATE TABLE [dbo].[Element] (
    [Id]      INT             IDENTITY (1, 1) NOT NULL,
    [libelle] VARCHAR (50)    NOT NULL,
    [unite]   VARCHAR (50)    NOT NULL,
    [max]     DECIMAL (18, 2) NOT NULL,
    [min]     DECIMAL (18, 2) NOT NULL,
    [current] DECIMAL (18, 2) NOT NULL,
    [idCat]   INT             NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [idCat] FOREIGN KEY ([idCat]) REFERENCES [dbo].[Categorie] ([Id])
);

SET IDENTITY_INSERT [dbo].[Element] ON
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1002, N'Hématies', N'millions/mm3', CAST(7.00 AS Decimal(18, 2)), CAST(3.00 AS Decimal(18, 2)), CAST(7.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1004, N'Hémoglobine', N'g/100mL', CAST(19.00 AS Decimal(18, 2)), CAST(10.00 AS Decimal(18, 2)), CAST(19.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1005, N'Hématocrite', N'%', CAST(60.00 AS Decimal(18, 2)), CAST(34.00 AS Decimal(18, 2)), CAST(60.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1006, N'V.G.M', N'µ3', CAST(100.00 AS Decimal(18, 2)), CAST(70.00 AS Decimal(18, 2)), CAST(100.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1007, N'T.C.M.H', N'pg', CAST(35.00 AS Decimal(18, 2)), CAST(20.00 AS Decimal(18, 2)), CAST(35.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1009, N'C.C.M.H', N'%', CAST(37.00 AS Decimal(18, 2)), CAST(26.00 AS Decimal(18, 2)), CAST(37.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1010, N'Leucocytes', N'mm3', CAST(12000.00 AS Decimal(18, 2)), CAST(3000.00 AS Decimal(18, 2)), CAST(12000.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1011, N'Polynucléaires neutrophiles', N'mm3', CAST(8500.00 AS Decimal(18, 2)), CAST(1500.00 AS Decimal(18, 2)), CAST(8500.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1012, N'Polynucléaires éosinophiles', N'mm3', CAST(600.00 AS Decimal(18, 2)), CAST(20.00 AS Decimal(18, 2)), CAST(600.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1013, N'Polynucléaires basophiles', N'mm3', CAST(200.00 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)), CAST(200.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1014, N'Lymphocytes', N'mm3', CAST(8000.00 AS Decimal(18, 2)), CAST(950.00 AS Decimal(18, 2)), CAST(8000.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1015, N'Monocytes', N'mm3', CAST(2000.00 AS Decimal(18, 2)), CAST(60.00 AS Decimal(18, 2)), CAST(2000.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1016, N'Plaquettes', N'mm3', CAST(550000.00 AS Decimal(18, 2)), CAST(150000.00 AS Decimal(18, 2)), CAST(550000.00 AS Decimal(18, 2)), 1)
INSERT INTO [dbo].[Element] ([Id], [libelle], [unite], [max], [min], [current], [idCat]) VALUES (1018, N'V.P.M', N'µ3', CAST(10.00 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)), CAST(10.00 AS Decimal(18, 2)), 1)
SET IDENTITY_INSERT [dbo].[Element] OFF

CREATE TABLE [dbo].[Maladie] (
    [Id]  INT          IDENTITY (1, 1) NOT NULL,
    [nom] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

SET IDENTITY_INSERT [dbo].[Maladie] ON
INSERT INTO [dbo].[Maladie] ([Id], [nom]) VALUES (1, N'Polyglobulie')
INSERT INTO [dbo].[Maladie] ([Id], [nom]) VALUES (2, N'Anémie')
SET IDENTITY_INSERT [dbo].[Maladie] OFF
