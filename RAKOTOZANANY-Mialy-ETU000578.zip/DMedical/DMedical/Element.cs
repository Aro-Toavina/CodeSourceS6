﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Element
    {
        private int id;
        private String libelle;
        private String unite;
        private decimal max;
        private decimal min;
        private decimal current;

        public Element()
        {

        }

        public Element(int id, String libelle, String unite, decimal max, decimal min, decimal current)
        {
            this.setid(id);
            this.setlibelle(libelle);
            this.setunite(unite);
            this.setmax(max);
            this.setmin(min);
            this.setcurrent(current);
        }

        public int getid() { return id; }
        public void setid(int id) { this.id = id; }
        public String getlibelle() { return libelle; }
        public void setlibelle(String libelle) { this.libelle = libelle; }
        public String getunite() { return unite; }
        public void setunite(String unite) { this.unite = unite; }
        public decimal getmax() { return max; }
        public void setmax(decimal max) { this.max = max; }
        public decimal getmin() { return min; }
        public void setmin(decimal min) { this.min = min; }
        public decimal getcurrent() { return current; }
        public void setcurrent(decimal current) { this.current = current; }
    }
}
