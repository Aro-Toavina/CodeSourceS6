﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Maladie
    {
        private int id;
        private String nom;

        public Maladie(int id,String nom)
        {
            this.setid(id);
            this.setnom(nom);
        }

        public int getid() { return id; }
        public void setid(int id) { this.id = id; }
        public String getnom() { return nom; }
        public void setnom(String nom) { this.nom = nom; }
    }
}
