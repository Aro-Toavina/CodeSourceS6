﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Categorie
    {
        private int id;
        private String intitule;

        public Categorie(int idC,String intitule)
        {
            this.setid(idC);
            this.setintitule(intitule);
        }

        public int getid(){ return id; }
        public void setid(int idC) { this.id = idC; }
        public String getintitule() { return intitule; }
        public void setintitule(String intitules) { this.intitule = intitules; }
    }
}
