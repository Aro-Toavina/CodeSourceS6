﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class DAO
    {
        public List<Object> findObject(SqlConnection connection, string nomTable, string critere)
        {
            List<Object> result = new List<Object>();

            string fullname = "DMedical." +nomTable;
            /*try
            {*/
            Type type = Type.GetType(fullname);
            MethodInfo[] methods = type.GetMethods();

            string query = "SELECT * FROM " + nomTable;
            if (critere != null)
                query += " WHERE " + critere;

            //Console.WriteLine("Query : " + query);

            connection.Open();

            SqlDataReader myReader = null;
            SqlCommand myCommand = new SqlCommand(query, connection);

            myReader = myCommand.ExecuteReader();

            int indiceResult = 0;
            while (myReader.Read())
            {
                result.Add(Activator.CreateInstance(type));

                for (int i = 0; i < myReader.FieldCount; i++)
                {
                    PropertyInfo prop = type.GetProperty(myReader.GetName(i));
                    /*Console.WriteLine("DataType:" + myReader.GetDataTypeName(i));
                    Console.WriteLine("Prop:" + prop);*/



                    if (myReader.GetDataTypeName(i).Equals("int"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetInt32(i));
                    else if (myReader.GetDataTypeName(i).Equals("tinyint"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetByte(i));
                    else if (myReader.GetDataTypeName(i).Equals("date") || myReader.GetDataTypeName(i).Equals("datetime"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? DateTime.Now : myReader.GetDateTime(i));
                    else if (myReader.GetDataTypeName(i).Equals("decimal") || myReader.GetDataTypeName(i).Equals("decimal"))
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? 0 : myReader.GetDecimal(i));
                    else
                        prop.SetValue(result.ElementAt(indiceResult), myReader.IsDBNull(i) ? "" : myReader.GetString(i));
                }
                indiceResult++;
            }

            myReader.Close();
            connection.Close();
            /*}
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }*/

            return result;
        }

        public List<Categorie> findCategorie(String critere)
        {
            List<Categorie> liste = new List<Categorie>();
            List<Int32> id = new List<Int32>();
            List<String> intitule = new List<String>();

            Categorie ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            try
            {
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Categorie]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Categorie] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                        id.Add(read.GetInt32(0));
                        intitule.Add(read.GetString(1));

                    }

                    for (int i = 0; i < id.Count; i++)
                    {
                        ma = new Categorie(id[i], intitule[i]);
                        liste.Add(ma);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connexion.Close();
            }

            return liste;
        }

        public List<Element> findElement(String critere)
        {
            List<Element> liste = new List<Element>();
            List<Int32> id = new List<Int32>();
            List<String> libelle = new List<String>();
            List<String> unite = new List<String>();
            List<decimal> max = new List<decimal>();
            List<decimal> min = new List<decimal>();
            List<decimal> current = new List<decimal>();

            Element ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            try
            {
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Element]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Element] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                        id.Add(read.GetInt32(0));
                        libelle.Add(read.GetString(1));
                        unite.Add(read.GetString(2));
                        max.Add(read.GetDecimal(3));
                        min.Add(read.GetDecimal(4));
                        current.Add(read.GetDecimal(5));
                    }

                    for (int i = 0; i < id.Count; i++)
                    {
                        ma = new Element(id[i], libelle[i], unite[i],max[i],min[i],current[i]);
                        liste.Add(ma);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connexion.Close();
            }

            return liste;
        }

        public List<Maladie> findMaladie(String critere)
        {
            List<Maladie> liste = new List<Maladie>();
            List<Int32> id = new List<Int32>();
            List<String> nom = new List<String>();

            Maladie ma;

            Connexion co = new Connexion();
            System.Data.SqlClient.SqlConnection connexion = co.getCo();
            System.Data.SqlClient.SqlCommand cmdt;
            System.Data.SqlClient.SqlDataReader read;

            try
            {
                connexion.Open();
                if (critere == null)
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Maladie]", connexion);
                }
                else
                {
                    cmdt = new System.Data.SqlClient.SqlCommand("select * from [dbo].[Maladie] " + critere + "", connexion);
                }
                read = cmdt.ExecuteReader();
                if (read.HasRows)
                {
                    while (read.Read())
                    {
                        id.Add(read.GetInt32(0));
                        nom.Add(read.GetString(1));
                    }

                    for (int i = 0; i < id.Count; i++)
                    {
                        ma = new Maladie(id[i], nom[i]);
                        liste.Add(ma);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connexion.Close();
            }

            return liste;
        }

        public String sexe(int sex)
        {
            String sexe = null;
            if (sex == 1)
            {
                sexe = "Homme";
            }
            if (sex == 2)
            {
                sexe = "Femme";
            }
            if (sex == 3)
            {
                sexe = "Enfant";
            }
            return sexe;
        }
        

        public List<decimal> analyse(SqlConnection c,List<Element> element,Patient patient)
        {
            DAO dao = new DAO();
            List<Maladie> listeMaladie = dao.findMaladie(null);
            List<Object> listeComposition = null;
            List<Object> listeDosage = null;
            Composition compo;
            Dosage dosage;
            List<decimal> pourcent = new List<decimal>();
            for (int i = 0; i < listeMaladie.Count; i++)
            {
                decimal pourcentage = 0;
                decimal pourcentageFinal = 0;
                listeComposition = dao.findObject(c, "Composition", " IdMaladie="+listeMaladie[i].getid()+" and sexe="+patient.getsexe());
                //Console.WriteLine("Taille composition : "+listeComposition.Count);
                for(int j = 0; j < listeComposition.Count; j++)
                {
                    compo = (Composition)listeComposition[j];
                    //Console.WriteLine("Composition : " + compo.IdElement);
                    for(int k = 0; k < element.Count; k++)
                    {
                        //Console.WriteLine("Element : " + element[k].getid());
                        if (compo.IdElement.Equals(element[k].getid()))
                        {
                            //Console.WriteLine("Element : " + element[k].getlibelle());
                            listeDosage = dao.findObject(c, "Dosage", " IdElement=" + element[k].getid() + " and Sexe=" + patient.getsexe());
                            dosage = (Dosage)listeDosage[0];
                            //Console.WriteLine("Current : " + element[k].getcurrent());
                            if (dosage.NormMin <= element[k].getcurrent() && element[k].getcurrent() <= dosage.NormMax)
                            {
                                //Console.WriteLine("Normal");
                                pourcentage = pourcentage + 0;
                            }
                            else
                            {
                                if(compo.Min<=element[k].getcurrent() && element[k].getcurrent() <= compo.Max)
                                {                                   
                                    if (compo.Type == 1)
                                    {
                                        //Console.WriteLine("Current : " + element[k].getcurrent());
                                        decimal res = ((element[k].getcurrent() - compo.Min) * 100) / (compo.Max - compo.Min);
                                        //Console.WriteLine("Hausse");
                                        //Console.WriteLine(element[k].getmax() + "-" + element[k].getcurrent() + "*100/" + element[k].getmax() + "-" + dosage.NormMax);
                                        pourcentage = pourcentage + res;
                                    }
                                    if (compo.Type == 2)
                                    {
                                        decimal res = ((element[k].getcurrent() - compo.Max) * 100) / (compo.Min - compo.Max);
                                        //Console.WriteLine("Baisse");
                                        pourcentage = pourcentage + res;
                                    }
                                }
                                else
                                {
                                    //Console.WriteLine("Normal");
                                    pourcentage = pourcentage + 0;
                                }
                            }                            
                        }
                    }
                }
                Console.WriteLine("Pourcentage : " + pourcentage);
                Console.WriteLine("Nombre de composition : " + listeComposition.Count);
                pourcentageFinal = pourcentage / listeComposition.Count;
                //Console.WriteLine("Pourcentage finale : " + pourcentageFinal);
                pourcent.Add(Math.Round(pourcentageFinal,2));
                //Console.WriteLine("Taille resulat : " + pourcent.Count);
            }            
            for (int l = 0; l < listeMaladie.Count; l++)
            {
                Console.WriteLine("Maladie : " + listeMaladie[l].getnom() + " avec un pourcentage de : " + pourcent[l]);
            }
            return pourcent;
        }
    }
}
