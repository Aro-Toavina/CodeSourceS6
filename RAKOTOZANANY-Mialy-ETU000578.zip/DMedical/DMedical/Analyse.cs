﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
   public  class Analyse
    {
        private int Id;
        private int IdC;
        private String libelle;
        private decimal max;
        private decimal min;
        private decimal maxNorm;
        private decimal minNorm;

        public Analyse()
        {

        }

        public Analyse(int Id,int IdC, String libelle,decimal max,decimal min,decimal maxNorm,decimal minNorm)
        {
            this.setid(Id);
            this.setidC(IdC);
            this.setlibelle(libelle);
            this.setmax(max);
            this.setmin(min);
            this.setmaxNorm(maxNorm);
            this.setminNorm(minNorm);
        }

        public int getid(){ return Id; }

        public void setid(int ID) { this.Id = ID; }

        public int getidC() { return IdC; }

        public void setidC(int IDC) { this.IdC = IDC; }

        public string getlibelle() { return libelle; }

        public void setlibelle(string lib) { this.libelle = lib; }

        public decimal getmax() { return max; }

        public void setmax(decimal MAX) { this.max = MAX; }

        public decimal getmin() { return min; }

        public void setmin(decimal MIN) { this.min = MIN; }

        public decimal getmaxNorm() { return maxNorm; }

        public void setmaxNorm(decimal MAXN) { this.maxNorm = MAXN; }

        public decimal getminNorm() { return minNorm; }

        public void setminNorm(decimal MINN) { this.minNorm = MINN; }
    }
}
