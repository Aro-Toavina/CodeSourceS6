﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    class Dosage
    {
        private int id;
        private int sexe;
        private int idElement;
        private decimal normMax;
        private decimal normMin;

        public Dosage()
        {

        }

        public Dosage(int id, int sexe, int idElement, decimal normMax, decimal normMin)
        {
            Id = id;
            Sexe = sexe;
            IdElement = idElement;
            NormMax = normMax;
            NormMin = normMin;
        }

        public int Id { get => id; set => id = value; }
        public int Sexe { get => sexe; set => sexe = value; }
        public int IdElement { get => idElement; set => idElement = value; }
        public decimal NormMax { get => normMax; set => normMax = value; }
        public decimal NormMin { get => normMin; set => normMin = value; }
    }
}
