﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    class Composition
    {
        private int id;
        private int idMaladie;
        private int idElement;
        private decimal min;
        private decimal max;
        private int type;
        private int sexe;

        public Composition()
        {

        }

        public Composition(int id,int idMaladie,int idElement, decimal min, decimal max, int type, int sexe)
        {
            Id = id;
            IdMaladie = idMaladie;
            IdElement = idElement;
            Min = min;
            Max = max;
            Type = type;
            Sexe = sexe;
        }

        public int Id { get => id; set => id = value; }
        public int IdMaladie { get => idMaladie; set => idMaladie = value; }
        public int IdElement { get => idElement; set => idElement = value; }
        public decimal Min { get => min; set => min = value; }
        public decimal Max { get => max; set => max = value; }
        public int Type { get => type; set => type = value; }
        public int Sexe { get => sexe; set => sexe = value; }
    }
}
