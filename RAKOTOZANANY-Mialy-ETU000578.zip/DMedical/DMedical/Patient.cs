﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMedical
{
    public class Patient
    {
        private String nom;
        private int age;
        private int sexe;
        private decimal poids;
        private int categorie;

        public Patient(String name, int age, String sex, int poid,int categ)
        {
            this.setnom(name);
            this.setage(age);
            this.setsexe(sex);
            this.setpoids(poid);
            this.setcategorie(categ);
        }

        public String getnom() { return nom; }
        public void setnom(String name) { this.nom = name; }
        public int getage() { return age; }
        public void setage(int age) { this.age = age; }
        public int getsexe() { return sexe; }
        public void setsexe(String sex) {
            if (sex == "Homme")
            {
                this.sexe = 1;
            }
            if (sex == "Femme")
            {
                this.sexe = 2;
            }
            if (sex == "Enfant")
            {
                this.sexe = 3;
            }
        }
        public decimal getpoids() { return poids; }
        public void setpoids(decimal poid) { this.poids = poid; }
        public int getcategorie() { return categorie; }
        public void setcategorie(int categ) { this.categorie = categ; }
    }
}
