﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMedical
{
    public partial class Form1 : Form
    {

        int xMiddle;
        int yMiddle;
        int rayon;
        double angle;
        List<Rond> point;
        List<int> x;
        List<int> y;

        DAO dao = new DAO();
        List<Element> liste = new List<Element>();

        List<Element> ElementGraphe = new List<Element>();
        List<decimal> resultat = new List<decimal>();
        Connexion c = new Connexion();

        Patient patient;


        public Form1(Patient p)
        {
            InitializeComponent();

            label2.Text = p.getnom();
            label3.Text = dao.sexe(p.getsexe());
            label4.Text = p.getage() + " ans";
            label5.Text = p.getpoids() + " kg";
            List<Categorie> categ = dao.findCategorie("where id=" + p.getcategorie());
            label6.Text = categ[0].getintitule();

            patient = p; 

            point = new List<Rond>();
            x = new List<int>();
            y = new List<int>();
            liste = dao.findElement("where idCat=" + p.getcategorie());
            addPoint();
            initListRond();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            /*xMiddle = panel1.Width / 2;
            yMiddle = panel1.Height / 2;
            rayon = panel1.Width / 2;*/
            xMiddle = 551 / 2;
            yMiddle = 551 / 2;
            rayon = 551 / 2;
            Graphics g = e.Graphics;
            Point pointLast = new Point(xMiddle, 0);
            for (int i = 0; i < liste.Count; i++)
            {
                angle = (2*Math.PI / liste.Count) * i;
                Point p = angle1(g, angle);
                g.DrawString(liste[i].getlibelle(), new Font("Arial", 10), new SolidBrush(Color.Black), new Point(p.X, p.Y+25));
            }
            showNiveau(g);
        }

        public void addPoint()
        {
            xMiddle = 551 / 2;
            yMiddle = 551 / 2;
            rayon = 551 / 2;
            Point pointLast = new Point(xMiddle, 0);
            for (int i = 0; i <= liste.Count; i++)
            {
                angle = (2*Math.PI / liste.Count) * i;
                Point p = getAngle(angle);
                this.x.Add(p.X);
                this.y.Add(p.Y);
                //Console.WriteLine("X : " + this.x[i] + " Y : " + this.y[i]);
            }
        }

        public Point getAngle(double angle)
        {
            int x = (int)((rayon) * (1 + Math.Sin(angle)));
            int y = (int)((rayon) * (1 - Math.Cos(angle)));
            Point point2 = new Point(x, y);
            return point2;
        }

        public Point angle1(Graphics g, double angle)
        {
            Pen p = new Pen(Color.Black, 2);
            int x = (int)((rayon) * (1 + Math.Sin(angle)));
            int y = (int)((rayon) * (1 - Math.Cos(angle)));
            Point point = new Point(xMiddle, yMiddle);
            Point point2 = new Point(x, y);
            g.DrawLine(p, point, point2);
            return point2;
        }

        public void drawJoinpoint(Graphics g, Point point1,Point point2)
        {
            Pen p = new Pen(Color.Red, 2);
            g.DrawLine(p, point1, point2);
        }

        public void initListRond()
        {         
            for (int j = 0; j < this.liste.Count; j++)
            {               
                point.Add(new Rond(this.x[j], this.y[j], new Point(551 / 2, 551 / 2),liste[j]));
            }
            

            for (int i = 0; i < point.Count; i++)
            {
                panel1.Controls.Add(point[i]);
            }
        }

        public void showNiveau(Graphics g)
        {
            Point a = new Point();
            Point point2 = new Point();
            for (int i = 0; i < point.Count; i++)
            {
                point2 = new Point(point[i].Location.X, point[i].Location.Y);
                //panel1.Controls.Add(new Pourcent(point[i].Location.X, point[i].Location.Y));
                if (i != 0)
                {              
                    drawJoinpoint(g, a, point2);                   
                }
                a = point2;                
            }

            Point first = new Point(point.ElementAt(0).Location.X, point.ElementAt(0).Location.Y);
            Pen p = new Pen(Color.Red, 2);
            drawJoinpoint(g, a, first);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ElementGraphe.Count != 0)
            {
                ElementGraphe.Clear();
            }

            for (int i = 0; i < point.Count; i++)
            {
                ElementGraphe.Add(point[i].element);               
            }
            dataGridView1.Rows.Clear();
            resultat.Clear();
            resultat = dao.analyse(c.getCo(), ElementGraphe, patient);
            List<Maladie> maladie = dao.findMaladie(null);
            for (int k = 0; k < maladie.Count; k++)
            {
                    dataGridView1.Rows.Add(maladie[k].getnom(),resultat[k]);
            }
        }
    }
}
