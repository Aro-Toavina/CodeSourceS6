﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMedical
{
    public partial class Rond : Panel
    {
        
        int x = 0;
        int y = 0;
        bool down;
        Point top;
        Point center;
        public Element element;

        public Rond(int ix,int iy,Point centre,Element analyse)
        {
            top = new Point(ix,iy);
            center = centre;
            setX(ix);
            setY(iy);

            this.x = ix;
            this.y = iy;

            this.Width = 100;
            this.Height = 20;
            this.Location = new Point(ix, iy);
            this.BackColor = Color.Transparent;

            element = analyse;
            
            element.setcurrent(analyse.getmax());
        }

        public double distance(Point pt1, Point pt2)
        {
            double x = Math.Pow((pt2.X - pt1.X), 2);
            double y = Math.Pow((pt2.Y - pt1.Y), 2);
            double xy = x + y;
            double result = Math.Sqrt(xy);
            return result;
        }

        public double pourcentage(double d1, double d2)
        {
            double result = (d2 * 100) / d1;
            return result;
        }

        public double getdifference(double max,double min)
        {
            return max - min;
        }
        
        public double getvalue(Point pt1,Point pt2,double max,double min,Point top)
        {
            return ((distance(pt1, pt2) * getdifference(max, min)) / (distance(pt1, top))) + (double)min;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(new SolidBrush(Color.Orange),0 , 0, 10, 10);
            String value = element.getcurrent().ToString();
            g.DrawString(value, new Font("Arial", 10), new SolidBrush(Color.Black), new Point(10, 0));
        }

        public int getX()
        {
            return this.x;
        }

        public void setX(int X)
        {
            this.x = X;
        }

        public int getY()
        {
            return this.y;
        }

        public void setY(int Y)
        {
            this.y = Y;
        }

        public double getA0(Point pt1,Point pt2)
        {
            double A0 = (double)(pt2.Y - pt1.Y) / (double)(pt2.X - pt1.X);
            return A0;
        }

        public double getB0(Point pt1,double A0)
        {
            double B0 = (double)pt1.Y - (double)(A0 * pt1.X);
            return B0;
        }

        public double getA1(double A0)
        {
            double A1 = -1 / A0;
            return A1;
        }

        public double getB1(Point pt3,double A1)
        {
            double B1 = pt3.Y - (A1 * pt3.X);
            return B1;
        }

        public Point getXY(Point pt1,Point pt2,Point pt3)
        {
            int X;
            int Y;
            if (pt1.X == pt2.X)
            {
                X = pt1.X;
                Y = pt3.Y;
            }
            else
            {
                X = (int)((getB1(pt3, getA1(getA0(pt1, pt2))) - getB0(pt1, getA0(pt1, pt2))) / (getA0(pt1, pt2) - getA1(getA0(pt1, pt2))));
                Y = (int)((getA1(getA0(pt1, pt2)) * X) + getB1(pt3, getA1(getA0(pt1, pt2))));
            }
            Point p = new Point(X, Y);
            return p;
        }

        public void drawString(PaintEventArgs e,String text,Point place)
        {
            Graphics g = e.Graphics;
            g.DrawString(text, new Font("Arial", 10), new SolidBrush(Color.Black),place);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int mouseX = e.X + this.Location.X;
            int mouseY = e.Y + this.Location.Y;
            if (down)
            {
                Point mouse = new Point(mouseX, mouseY);
                Point temp = getXY(center, top, mouse);
                double res = this.getvalue(this.center, temp, (Double)element.getmax(), (Double)element.getmin(), this.top);
                if ((temp.X<top.X && temp.X>center.X) || (temp.X<center.X && temp.X>top.X) && (temp.Y<center.Y && temp.Y>top.Y) || (temp.Y<top.Y && temp.Y>center.Y) || (temp.Y>top.Y && temp.Y<center.Y))
                {
                    element.setcurrent(Math.Round((decimal)res,2));
                    this.Location = temp;
                    this.Parent.Refresh();        
                }
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
        }

    }
}
