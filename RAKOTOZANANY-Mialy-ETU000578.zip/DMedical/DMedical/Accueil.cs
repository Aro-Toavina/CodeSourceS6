﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMedical
{
    public partial class Accueil : Form
    {
        public Accueil()
        {
            InitializeComponent();
            comboBox1.Items.Add("Homme");
            comboBox1.Items.Add("Femme");
            comboBox1.Items.Add("Enfant");

            DAO dao = new DAO();
            List<Categorie> categorie = dao.findCategorie(null);
            for(int i = 0; i < categorie.Count; i++)
            {
                comboBox2.Items.Add(categorie[i].getintitule());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String nom = textBox1.Text;
            String sexe = comboBox1.Text;
            int age = Int32.Parse(textBox2.Text);
            int poids = Int32.Parse(textBox3.Text);
            String categorie = comboBox2.SelectedItem.ToString();
            DAO dao = new DAO();
            List<Categorie> categ = dao.findCategorie("where intitule='"+categorie+"'");
            Patient patient = new Patient(nom,age,sexe,poids,categ[0].getid());

            Console.WriteLine(patient.getnom() + " " + patient.getsexe() + " " + patient.getage() + " " + patient.getpoids()+" "+patient.getcategorie());

            Form1 form1 = new Form1(patient);
            form1.Show();
        }
    }
}
