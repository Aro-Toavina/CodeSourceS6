﻿Create table Maladie(
	id varchar(10) primary key NOT NULL,
	nom varchar(50) NOT NULL
);
Create table Critere(
	id varchar(10) primary key NOT NULL,
	maladie varchar(10) NOT NULL,
	foreign key (maladie) references Maladie(id)
);
Create table ElementAnalyse(
	id varchar(10) primary key NOT NULL,
	nom varchar(50) NOT NULL,
	unite varchar(10) NOT NULL,
	min decimal(5,2) NOT NULL,
	max decimal(5,2) NOT NULL
);
Create table Correspondance(
	id varchar(10) primary key NOT NULL,
	critere varchar(10) NOT NULL,
	elementAnalyse varchar(10) NOT NULL,
	min decimal(5,2) NOT NULL,
	max decimal(5,2) NOT NULL,
    type int NOT NULL,
    ageMin int NOT NULL,
    ageMax int NOT NULL,
    sexe int NOT NULL,
	foreign key (critere) references Critere(id),
	foreign key (elementAnalyse) references ElementAnalyse(id)
);


--SEQUENCES
CREATE TABLE SequenceMaladie
(
    ID BIGINT IDENTITY  
);
GO
CREATE PROCEDURE dbo.GetSequenceMaladie ( @value VARCHAR(10) OUTPUT)
AS
    --Act like we are INSERTing a row to increment the IDENTITY
    BEGIN TRANSACTION;
    INSERT SequenceMaladie WITH (TABLOCKX) DEFAULT VALUES;
    ROLLBACK TRANSACTION;
    --Return the latest IDENTITY value.
    IF(SCOPE_IDENTITY()<10 AND SCOPE_IDENTITY()>0)
    BEGIN
        SELECT @value = 'MAL000'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<100 AND SCOPE_IDENTITY()>=10)
    BEGIN
        SELECT @value = 'MAL00'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<1000 AND SCOPE_IDENTITY()>=100)
    BEGIN
        SELECT @value = 'MAL0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()>=1000)
    BEGIN
        SELECT @value = 'MAL0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END  
GO

--SEQUENCES
CREATE TABLE SequenceCritere
(
    ID BIGINT IDENTITY  
);
GO
CREATE PROCEDURE dbo.GetSequenceCritere ( @value VARCHAR(10) OUTPUT)
AS
    --Act like we are INSERTing a row to increment the IDENTITY
    BEGIN TRANSACTION;
    INSERT SequenceCritere WITH (TABLOCKX) DEFAULT VALUES;
    ROLLBACK TRANSACTION;
    --Return the latest IDENTITY value.
    IF(SCOPE_IDENTITY()<10 AND SCOPE_IDENTITY()>0)
    BEGIN
        SELECT @value = 'CRT000'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<100 AND SCOPE_IDENTITY()>=10)
    BEGIN
        SELECT @value = 'CRT00'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<1000 AND SCOPE_IDENTITY()>=100)
    BEGIN
        SELECT @value = 'CRT0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()>=1000)
    BEGIN
        SELECT @value = 'CRT0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END  
GO

--SEQUENCES
CREATE TABLE SequenceElementAnalyse
(
    ID BIGINT IDENTITY  
);
GO
CREATE PROCEDURE dbo.GetSequenceElementAnalyse ( @value VARCHAR(10) OUTPUT)
AS
    --Act like we are INSERTing a row to increment the IDENTITY
    BEGIN TRANSACTION;
    INSERT SequenceElementAnalyse WITH (TABLOCKX) DEFAULT VALUES;
    ROLLBACK TRANSACTION;
    --Return the latest IDENTITY value.
    IF(SCOPE_IDENTITY()<10 AND SCOPE_IDENTITY()>0)
    BEGIN
        SELECT @value = 'ELM000'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<100 AND SCOPE_IDENTITY()>=10)
    BEGIN
        SELECT @value = 'ELM00'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<1000 AND SCOPE_IDENTITY()>=100)
    BEGIN
        SELECT @value = 'ELM0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()>=1000)
    BEGIN
        SELECT @value = 'ELM0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END  
GO

--SEQUENCES
CREATE TABLE SequenceCorrespondance
(
    ID BIGINT IDENTITY  
);
GO
CREATE PROCEDURE dbo.GetSequenceCorrespondance ( @value VARCHAR(10) OUTPUT)
AS
    --Act like we are INSERTing a row to increment the IDENTITY
    BEGIN TRANSACTION;
    INSERT SequenceCorrespondance WITH (TABLOCKX) DEFAULT VALUES;
    ROLLBACK TRANSACTION;
    --Return the latest IDENTITY value.
    IF(SCOPE_IDENTITY()<10 AND SCOPE_IDENTITY()>0)
    BEGIN
        SELECT @value = 'CSP000'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<100 AND SCOPE_IDENTITY()>=10)
    BEGIN
        SELECT @value = 'CSP00'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()<1000 AND SCOPE_IDENTITY()>=100)
    BEGIN
        SELECT @value = 'CSP0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END
    IF(SCOPE_IDENTITY()>=1000)
    BEGIN
        SELECT @value = 'CSP0'+CAST(SCOPE_IDENTITY() as VARCHAR(5));
    END  
GO

Create view CorrespondanceMaladie as select correspondance.*,critere.maladie from correspondance,critere where correspondance.critere = critere.id;