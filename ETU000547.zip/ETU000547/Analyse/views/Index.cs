﻿using Analyse.models;
using dao;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using table;

namespace Analyse
{
    public partial class Analyse : Form
    {
        private int circleWidth = 0;
        private int marge = 0;
        private int markerWidth = 0;
        private PointF[] pointList;
        private Item [] pointValues;
        private ElementAnalyse[] elements;
        private bool isMove = false;
        private int currentIndexAxe;
        private CorrespondanceMaladie [] cm;
        public Analyse()
        {
            cm = new CorrespondanceMaladieDAO().find_CorrespondanceMaladie(" ");
            elements = new ElementAnalyseDAO().find_ElementAnalyse(" ");

            InitializeComponent();
            
            
            this.marge = 0;
            this.circleWidth = ConteneurGraphe.Height - 50 ;
            this.markerWidth = 15;
            this.initializePoints();
            this.combo_sexe.Items.Add(new Item(1,"Homme"));
            this.combo_sexe.Items.Add(new Item(2,"Femme"));
            this.combo_sexe.SelectedIndex = 0;
            for (int i = 1; i <= 100; i++)
            {
                this.combo_age.Items.Add(i);
            }
            this.combo_age.SelectedIndex = 19;
            markers_panel.MouseDown += OnEllipseMouseDown;
            markers_panel.MouseMove += OnEllipseMouseMove;
            markers_panel.MouseUp += OnEllipseMouseUp;
            this.combo_age.SelectedIndexChanged += ageChange;
            this.combo_sexe.SelectedIndexChanged += sexeChange;

        }
        void OnEllipseMouseDown(object sender, MouseEventArgs e)
        {

            if (pointList != null)
            {
                for(int i=0;i< pointList.Count();i++)
                {
                    if (e.X >= pointList[i].X - markerWidth && e.X <= pointList[i].X + markerWidth && e.Y >= pointList[i].Y - markerWidth && e.Y <= pointList[i].Y + markerWidth)
                    {
                        Cursor.Current = Cursors.Hand;
                        this.isMove = true;
                        this.currentIndexAxe = i;
                        break;
                    }
                }
            }
        }
        void OnEllipseMouseMove(object sender, MouseEventArgs e)
        {
            if (isMove)
            {
                Cursor.Current = Cursors.Hand;

                int axisNumber = elements.Count();
                int i= this.currentIndexAxe + 1;
                double distance = 0;
                PointF centre = new PointF(circleWidth / 2, circleWidth / 2);
                PointF depart = pointList[i - 1];
                PointF arrive = new PointF(e.X, e.Y);
                

                if (getDistance(depart, centre) >= getDistance(arrive,centre))
                {
                    distance = getDistance(depart, centre) - getDistance(depart, arrive);
                }
                else if(getDistance(depart, centre) <= getDistance(arrive, centre))
                {
                    distance = getDistance(arrive, centre);
                }
                if (distance-1<=0)
                {
                    distance = 0;
                }
                if (distance+10>=circleWidth/2)
                {
                    distance = circleWidth / 2;
                }
                float x = float.Parse(((Math.Cos((2 * Math.PI * i) / axisNumber) * (distance)) + (circleWidth / 2 + marge)).ToString());
                float y = float.Parse(((Math.Sin((2 * Math.PI * i) / axisNumber) * (distance)) + (circleWidth / 2 + marge)).ToString());
                pointList[this.currentIndexAxe].X = x;
                pointList[this.currentIndexAxe].Y = y;
                double value = (getDistance(pointList[this.currentIndexAxe], centre) * elements[this.currentIndexAxe].get_max()) / (circleWidth / 2);
                if (value <= elements[this.currentIndexAxe].get_min()) {
                    value = elements[this.currentIndexAxe].get_min();
                }
                if (value >= elements[this.currentIndexAxe].get_max())
                {
                    elements[this.currentIndexAxe].get_max();
                }
                pointValues[this.currentIndexAxe].value = value;
                this.element_panel.Refresh();
            }
            return;
        }
        void OnEllipseMouseUp(object sender, MouseEventArgs e)
        {
            this.isMove = false;
            this.currentIndexAxe = -1;
            refreshResult();
        }
        void ageChange(object sender, EventArgs e)
        {
            refreshResult();
        }
        void sexeChange(object sender, EventArgs e)
        {
            refreshResult();
        }
        public void refreshResult()
        {
            Util util = new Util();
            this.label2.Text = " ";
            int age = int.Parse(this.combo_age.SelectedItem.ToString());
            Item select = (Item)this.combo_sexe.SelectedItem;
            int sexe = int.Parse(select.key.ToString());
            var elementCorrespondance = from correspondance in cm
                                        where correspondance.get_ageMin() <= age && correspondance.get_ageMax() >= age && correspondance.get_sexe() == sexe
                                        select correspondance;
            CorrespondanceMaladie[] correspendanceActuel = elementCorrespondance.ToArray();

            Item[] resultat = util.getTopMaladie(correspendanceActuel, pointValues);
            int compteur = 0;
            foreach (Item item in resultat)
            {
                if (double.Parse(item.value.ToString()) != 0 && double.Parse(item.value.ToString()) > 0)
                    this.label2.Text += Environment.NewLine + item.key + " : " + Math.Round(double.Parse(item.value.ToString()), 2) + "%";
                else
                    compteur++;
            }
            if (compteur == 3)
            {
                this.label2.Text = "Aucune maladie " + Environment.NewLine + " correspondant";
                compteur = 0;
            }
        }
        private void initializePoints()
        {

            int axisNumber = elements.Count();
            float x, y = 0;
            List<PointF> pList = new List<PointF>();
            List<Item> pValues = new List<Item>();
            for (int i = 1; i <= axisNumber; i++)
            {
                x = float.Parse(((Math.Cos((2 * Math.PI * i) / axisNumber) * (circleWidth / 2)) + (circleWidth / 2 + marge)).ToString());
                y = float.Parse(((Math.Sin((2 * Math.PI * i) / axisNumber) * (circleWidth / 2)) + (circleWidth / 2 + marge)).ToString());

                pList.Add(new PointF(x, y));
                pValues.Add(new Item(elements[i-1].get_id(), elements[i-1].get_max()));
            }
            pointList = new PointF[pList.Count];
            pList.CopyTo(pointList);
            this.pointValues = new Item[pValues.Count()];
            pValues.CopyTo(pointValues);
        }
        private void printElement(PaintEventArgs e)
        {
            Font font = new Font("Calibri", 12);
            SolidBrush brush = new SolidBrush(Color.Black);
            for (int i = 0; i < pointList.Count(); i++)
            {
                float x = pointList[i].X + 5;
                float y = pointList[i].Y + 5;
                
                e.Graphics.DrawString(elements[i].get_nom()+" : "+ Math.Round(double.Parse(pointValues[i].value.ToString()),2)+" "+ elements[i].get_unite(), font, brush, new PointF(x,y));
            }
        }
        private void drawCircle(PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.Black, 1);

            int x = marge;
            int y = marge;
            int width = circleWidth;
            int height = circleWidth;
            int startAngle = 0;
            int sweepAngle = 360;

            e.Graphics.DrawArc(blackPen, x, y, width, height, startAngle, sweepAngle);
        }
        private void drawXYAxis(PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.Red, 3);


            Point pointx1 = new Point(0, circleWidth / 2);
            Point pointx2 = new Point(circleWidth, circleWidth / 2);

            Point pointy1 = new Point(circleWidth / 2, 0);
            Point pointy2 = new Point(circleWidth / 2, circleWidth);

            e.Graphics.DrawLine(blackPen, pointx1, pointx2);
            e.Graphics.DrawLine(blackPen, pointy1, pointy2);
        }
        private void drawAxis(float x, float y, PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.SlateBlue, 1);
            e.Graphics.DrawLine(blackPen,circleWidth / 2 + marge , circleWidth / 2 + marge , x, y);
        }
        private void drawAllAxis(PaintEventArgs e){
            Panel axisPan = new Panel();
            axisPan.Height = ConteneurGraphe.Height;
            axisPan.Width = ConteneurGraphe.Width;
            float x = 0, y = 0;
            int axisNumber = elements.Count();
            for (int i = 0; i < pointList.Count(); i++)
            {
                x = float.Parse(((Math.Cos((2 * Math.PI * i) / axisNumber) * (circleWidth / 2)) + (circleWidth / 2 + marge)).ToString());
                y = float.Parse(((Math.Sin((2 * Math.PI * i) / axisNumber) * (circleWidth / 2)) + (circleWidth / 2 + marge)).ToString());
                drawAxis(x, y, e);
            }
        }
  
        private void linkAllPoint(PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Green, 2);
            List<PointF> listPoint = pointList.ToList();
            listPoint.Add(pointList[0]);
            e.Graphics.DrawLines(pen, listPoint.ToArray());
            listPoint.RemoveAt(listPoint.Count() - 1);
        }
        private void placeMarker(float x,float y,PaintEventArgs e)
        {
            // Create solid brush.
            SolidBrush redBrush = new SolidBrush(Color.OrangeRed);

            // Create location and size of ellipse.
            float width = markerWidth;
            float height = markerWidth;

            // Fill ellipse on screen.
            e.Graphics.FillEllipse(redBrush, x- height/2, y-width/2, width, height);
            
        }
        private void placeAllMarkers(PaintEventArgs e)
        {
            for(int i=0; i<pointList.Count();i++)
            {
                placeMarker(pointList.ElementAt(i).X, pointList.ElementAt(i).Y,e);
            }
        }
        private void fillPolygon(PaintEventArgs e)
        {
            // Create solid brush.
            SolidBrush blueBrush = new SolidBrush(Color.WhiteSmoke);

            for (int i = 0; i < pointList.Count(); i++)
            {
                e.Graphics.FillPolygon(blueBrush, pointList);
            }
        }
        private double getDistance(PointF A ,PointF B)
        {
            double xA = A.X , xB = B.X, yA = A.Y , yB = B.Y;
            return Math.Sqrt(Math.Pow(xB - xA,2) + Math.Pow(yB - yA, 2));
        }

        private void circle_panel_Paint_1(object sender, PaintEventArgs e)
        {
            drawCircle(e);
            //drawXYAxis(e);
            drawAllAxis(e);
        }

        private void element_panel_Paint_1(object sender, PaintEventArgs e)
        {
            printElement(e);
        }

        private void markers_panel_Paint(object sender, PaintEventArgs e)
        {
            linkAllPoint(e);
            placeAllMarkers(e);
            // fillPolygon(e);
        }
    }
}