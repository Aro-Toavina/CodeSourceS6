﻿namespace Analyse
{
    partial class Analyse
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConteneurGraphe = new System.Windows.Forms.Panel();
            this.circle_panel = new System.Windows.Forms.Panel();
            this.element_panel = new System.Windows.Forms.Panel();
            this.markers_panel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.combo_age = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.combo_sexe = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.circle_panel.SuspendLayout();
            this.element_panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConteneurGraphe
            // 
            this.ConteneurGraphe.BackColor = System.Drawing.Color.Transparent;
            this.ConteneurGraphe.Location = new System.Drawing.Point(22, 13);
            this.ConteneurGraphe.Name = "ConteneurGraphe";
            this.ConteneurGraphe.Size = new System.Drawing.Size(812, 678);
            this.ConteneurGraphe.TabIndex = 0;
            // 
            // circle_panel
            // 
            this.circle_panel.BackColor = System.Drawing.Color.Transparent;
            this.circle_panel.Controls.Add(this.element_panel);
            this.circle_panel.Location = new System.Drawing.Point(22, 10);
            this.circle_panel.Name = "circle_panel";
            this.circle_panel.Size = new System.Drawing.Size(812, 678);
            this.circle_panel.TabIndex = 0;
            this.circle_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.circle_panel_Paint_1);
            // 
            // element_panel
            // 
            this.element_panel.BackColor = System.Drawing.Color.Transparent;
            this.element_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.element_panel.Controls.Add(this.markers_panel);
            this.element_panel.Location = new System.Drawing.Point(0, 0);
            this.element_panel.Name = "element_panel";
            this.element_panel.Size = new System.Drawing.Size(812, 678);
            this.element_panel.TabIndex = 1;
            this.element_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.element_panel_Paint_1);
            // 
            // markers_panel
            // 
            this.markers_panel.BackColor = System.Drawing.Color.Transparent;
            this.markers_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.markers_panel.Location = new System.Drawing.Point(0, 3);
            this.markers_panel.Name = "markers_panel";
            this.markers_panel.Size = new System.Drawing.Size(812, 678);
            this.markers_panel.TabIndex = 2;
            this.markers_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.markers_panel_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(860, 273);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(463, 418);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AccessibleName = "";
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 30F);
            this.label2.Location = new System.Drawing.Point(41, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 49);
            this.label2.TabIndex = 1;
            this.label2.Text = "Contenu";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 24F);
            this.label1.Location = new System.Drawing.Point(164, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Résultat :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.combo_age);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.combo_sexe);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(860, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(463, 187);
            this.panel2.TabIndex = 2;
            // 
            // combo_age
            // 
            this.combo_age.FormattingEnabled = true;
            this.combo_age.Location = new System.Drawing.Point(137, 98);
            this.combo_age.Name = "combo_age";
            this.combo_age.Size = new System.Drawing.Size(167, 21);
            this.combo_age.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(54, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 39);
            this.label4.TabIndex = 2;
            this.label4.Text = "Age";
            // 
            // combo_sexe
            // 
            this.combo_sexe.FormattingEnabled = true;
            this.combo_sexe.Location = new System.Drawing.Point(137, 37);
            this.combo_sexe.Name = "combo_sexe";
            this.combo_sexe.Size = new System.Drawing.Size(167, 21);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(54, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 39);
            this.label3.TabIndex = 0;
            this.label3.Text = "Sexe";
            // 
            // Analyse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1335, 718);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.circle_panel);
            this.Controls.Add(this.ConteneurGraphe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MinimizeBox = false;
            this.Name = "Analyse";
            this.Text = "Analyse";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.circle_panel.ResumeLayout(false);
            this.element_panel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ConteneurGraphe;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel circle_panel;
        private System.Windows.Forms.Panel element_panel;
        private System.Windows.Forms.Panel markers_panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox combo_sexe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox combo_age;
        private System.Windows.Forms.Label label4;
    }
}

