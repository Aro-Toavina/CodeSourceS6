using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using table;
using System.Data.SqlClient;
using Connexion;
using System.Windows.Forms;
 namespace dao{
	class ElementAnalyseDAO{
			public void update_ElementAnalyse(String modif, String condition, SqlConnection con){
				try{
					String query = "update ElementAnalyse set "+modif+" where "+condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void update_ElementAnalyse(String modif, String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				update_ElementAnalyse(modif, condition, con);
				return;
			}
			public void delete_ElementAnalyse(SqlConnection con, String condition){
				try{
					String query = "delete from ElementAnalyse where " + condition; 
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void delete_ElementAnalyse(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				delete_ElementAnalyse(con, condition);
				return;
			}
			public void insert_ElementAnalyse(ElementAnalyse med, SqlConnection con){
				try{
					String query = "DECLARE @value_ElementAnalyse VARCHAR(10);EXECUTE dbo.GetSequenceElementAnalyse @value_ElementAnalyse OUTPUT;insert into ElementAnalyse values (@value_ElementAnalyse,'"+med.get_nom()+"','"+med.get_unite()+"','"+med.get_min()+"','"+med.get_max()+"')";
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void insert_ElementAnalyse(ElementAnalyse n){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				insert_ElementAnalyse(n,con);
				return;
			}
			public ElementAnalyse[] find_ElementAnalyse(String condition, SqlConnection con, String table){
				try{
					String query = "Select * from " + table + " " + condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
                    SqlDataReader reader = st.ExecuteReader();
                    List<ElementAnalyse> v = new List<ElementAnalyse>();
					while (reader.Read()){
						ElementAnalyse med = new ElementAnalyse();
						med.set_id(reader.GetValue(0).ToString());
						med.set_nom(reader.GetValue(1).ToString());
						med.set_unite(reader.GetValue(2).ToString());
						med.set_min(reader.GetValue(3).ToString());
						med.set_max(reader.GetValue(4).ToString());
                        v.Add(med);
					}
					ElementAnalyse[] listeTable = new ElementAnalyse [v.Count];
					v.CopyTo(listeTable); 
					return listeTable;
				}
				catch(Exception e){
                    throw e;
				}
				finally{
					con.Close();
				}
			}
			public ElementAnalyse[] find_ElementAnalyse(String condition,String table){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				ElementAnalyse[] med = find_ElementAnalyse(condition,con,table);
				return med;
			}
			public ElementAnalyse[] find_ElementAnalyse(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				ElementAnalyse[] med = find_ElementAnalyse(condition,con,"ElementAnalyse");
				return med;
			}
		}
	}