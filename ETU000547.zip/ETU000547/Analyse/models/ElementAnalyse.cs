using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace table{
	class ElementAnalyse{
		private String id;
		private String nom;
		private String unite;
		private double min;
		private double max;

        public ElementAnalyse() { }
		public ElementAnalyse(String id,String nom,String unite,double min,double max){
			this.set_id(id);
			this.set_nom(nom);
			this.set_unite(unite);
			this.set_min(min);
			this.set_max(max);
		}
		public ElementAnalyse(String id,String nom,String unite,String min,String max){
			this.set_id(id);
			this.set_nom(nom);
			this.set_unite(unite);
			this.set_min(min);
			this.set_max(max);
		} 
		public void set_id(String id){
			this.id=id;
		} 
		public void set_nom(String nom){
			this.nom=nom;
		} 
		public void set_unite(String unite){
			this.unite=unite;
		} 
		public void set_min(double min){
			if(min>=0){
 				this.min=min;
			}
			else{
				throw new Exception("min invalide : negatif ou nul ");
			}
		} 
		public void set_min(String min){
			this.set_min(double.Parse(min));
		} 
		public void set_max(double max){
			if(max>=0){
 				this.max=max;
			}
			else{
				throw new Exception("max invalide : negatif ou nul ");
			}
		} 
		public void set_max(String max){
			this.set_max(double.Parse(max));
		} 
		public String get_id(){
			 return this.id;
		} 
		public String get_nom(){
			 return this.nom;
		} 
		public String get_unite(){
			 return this.unite;
		} 
		public double get_min(){
			 return this.min;
		} 
		public double get_max(){
			 return this.max;
		} 
	}
}