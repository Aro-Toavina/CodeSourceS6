﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Connexion
{
    class Connection
    {
        public SqlConnection getConnexion(String login,String pass,String database){
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog="+database+";Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";                

                con.Open();
                Console.WriteLine("Connexion ok");
                return con;
            }
            catch (Exception e)
            {
                Console.WriteLine("error occured during connexion");
                throw new Exception("Erreur lors de la connexion à la base de donnée \n\nPlus de details:\n\n "+e.StackTrace);
            }
        }
    }
}
