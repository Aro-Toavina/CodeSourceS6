﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using table;
using dao;

namespace Analyse.models
{
    class Util
    {
        const double marge = 0.1;
        public Item [] getTopMaladie(CorrespondanceMaladie[] correspondances, Item [] items)
        {
            Item [] result = new Item[3];

            List<Item> pourcentages = new List<Item>();
            Maladie[] maladies = new MaladieDAO().find_Maladie(" ");
            foreach (Maladie maladie in maladies)
            {
                pourcentages.Add(new Item(maladie.get_nom(),getPourcentageMaladie(correspondances,items, maladie)));
            }
            pourcentages = pourcentages.OrderByDescending(pourcentage => pourcentage.value).ToList();
            result[0] = pourcentages[0];
            result[1] = pourcentages[1];
            result[2] = pourcentages[2];

            return result;
        } 
        public double getPourcentageMaladie(CorrespondanceMaladie [] correspondances,Item [] items,Maladie maladie)
        {
           
            double result = 0;
            var elementCorrespondance = from correspondance in correspondances
                          where (string)correspondance.get_maladie() == maladie.get_id()
                          select correspondance;
            correspondances = elementCorrespondance.ToArray();
            int nombreAxe = correspondances.Count();
            
            foreach (CorrespondanceMaladie correspondance in correspondances)
            {
                var element = from item in items
                           where (string)item.key == correspondance.get_elementAnalyse()
                           select item;
                Item elem = element.ToArray()[0];
                result += getPourcentageCritere(correspondances,elem,maladie,correspondance.get_type()); 
            }
            result /= nombreAxe;
            return result*100;
        }
        public double getPourcentageCritere(CorrespondanceMaladie[] correspondances, Item item, Maladie maladie,int type)
        {
            if(type==0 || type == 1)
            {
                return getPourcentageCritereExtreme(correspondances, item, maladie, type);
            }
            else if (type == 2)
            {
                return getPourcentageCritereMilieu(correspondances, item, maladie);
            }
            
            else
            {
                return getPourcentageCritereUnique(correspondances, item, maladie);
            }
        }
        
        public double getPourcentageCritereUnique(CorrespondanceMaladie[] correspondances, Item item,Maladie maladie)
        {
            try
            {
                double value = double.Parse(item.value.ToString());

                var elementCorrespondance = from correspondanceCursor in correspondances
                                            where correspondanceCursor.get_maladie() == maladie.get_id() && correspondanceCursor.get_elementAnalyse() == item.key.ToString()
                                            select correspondanceCursor;
                CorrespondanceMaladie correspondance = elementCorrespondance.ToArray()[0];
                if (value>=correspondance.get_min() && value<=correspondance.get_max())
                {
                    return 1;
                }
                return 0;
            }catch(Exception)
            {
                throw;
            }
        }
        public double getPourcentageCritereMilieu(CorrespondanceMaladie[] correspondances, Item item, Maladie maladie)
        {
            try
            {
                double result = 0;
                double value = double.Parse(item.value.ToString());
                var elementCorrespondance = from correspondanceCursor in correspondances
                                            where correspondanceCursor.get_maladie() == maladie.get_id() && correspondanceCursor.get_elementAnalyse() == item.key.ToString()
                                            select correspondanceCursor;
                CorrespondanceMaladie correspondance = elementCorrespondance.ToArray()[0];
                double milieu = (correspondance.get_max() + correspondance.get_min()) / 2;
                double longueur = milieu - correspondance.get_min();
                if (value >= correspondance.get_min() && value <= correspondance.get_max())
                {
                    if (value <= milieu)
                    {
                        result = (value - correspondance.get_min()) / longueur;
                    }
                    else if (value > milieu)
                    {
                        result = (correspondance.get_max() - value) / longueur;
                    }
                    
                    if (result < marge && result > 0 || value == correspondance.get_min() || value == correspondance.get_max())
                    {
                        result = marge;
                    }
                }
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public double getPourcentageCritereExtreme(CorrespondanceMaladie[] correspondances, Item item, Maladie maladie,int type)
        {
            try
            {
                double result = 0;
                double value = double.Parse(item.value.ToString());
                var elementCorrespondance = from correspondanceCursor in correspondances
                                            where correspondanceCursor.get_maladie() == maladie.get_id() && correspondanceCursor.get_elementAnalyse() == item.key.ToString()
                                            select correspondanceCursor;
                CorrespondanceMaladie correspondance = elementCorrespondance.ToArray()[0];
                double longueur = correspondance.get_max() - correspondance.get_min();
                if (value >= correspondance.get_min() && value <= correspondance.get_max())
                {
                    if (type == 0)
                    {
                        result = (correspondance.get_max() - value) / longueur;
                    }
                    else if (type==1)
                    {
                        result = (value - correspondance.get_min()) / longueur;
                    }
                    if ((result < marge && result > 0)|| value == correspondance.get_max() || value == correspondance.get_min())
                    {
                        if (type == 0)
                        {
                            if (value == correspondance.get_max())
                            {
                                result = marge;
                            }
                        }
                        else if (type == 1)
                        {
                            if (value == correspondance.get_min())
                            {
                                result = marge;
                            }
                        }
                    }
                }
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
