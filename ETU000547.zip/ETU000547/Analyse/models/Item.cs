﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyse.models
{
    class Item
    {
        public Object key;
        public Object value;
        public Item() { }
        public Item(Object key,Object value)
        {
            this.setKey(key);
            this.setValue(value);
        }
        public void setKey(Object o)
        {
            key = o;
        }
        public void setValue(Object o)
        {
            value = o;
        }
        override
        public string ToString()
        {
            return value.ToString();
        }
    }
}
