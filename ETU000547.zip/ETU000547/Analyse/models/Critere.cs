using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace table{
	class Critere{
		private String id;
		private String maladie;
       

		public Critere(String id,String maladie){
			this.set_id(id);
			this.set_maladie(maladie);
            
		}
        public Critere(){
		
		} 
		public void set_id(String id){
			this.id=id;
		} 
		public void set_maladie(String maladie){
			this.maladie=maladie;
		} 
        
        

        public String get_id(){
			 return this.id;
		} 
		public String get_maladie(){
			 return this.maladie;
		} 
        
    }
}