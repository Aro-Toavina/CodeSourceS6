using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using table;
using System.Data.SqlClient;
using Connexion;
using System.Windows.Forms;
 namespace dao{
	class MaladieDAO{
			public void update_Maladie(String modif, String condition, SqlConnection con){
				try{
					String query = "update Maladie set "+modif+" where "+condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void update_Maladie(String modif, String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				update_Maladie(modif, condition, con);
				return;
			}
			public void delete_Maladie(SqlConnection con, String condition){
				try{
					String query = "delete from Maladie where " + condition; 
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void delete_Maladie(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				delete_Maladie(con, condition);
				return;
			}
			public void insert_Maladie(Maladie med, SqlConnection con){
				try{
					String query = "DECLARE @value_Maladie VARCHAR(10);EXECUTE dbo.GetSequenceMaladie @value_Maladie OUTPUT;insert into Maladie values (@value_Maladie,'"+med.get_nom()+"')";
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void insert_Maladie(Maladie n){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				insert_Maladie(n,con);
				return;
			}
			public Maladie[] find_Maladie(String condition, SqlConnection con, String table){
				try{
					String query = "Select * from " + table + " " + condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					List<Maladie> v = new List<Maladie>();
                    SqlDataReader reader = st.ExecuteReader();
                    while (reader.Read()){
						Maladie med = new Maladie();
						med.set_id(reader.GetValue(0).ToString());
						med.set_nom(reader.GetValue(1).ToString());
                        v.Add(med);
					}
					Maladie[] listeTable = new Maladie [v.Count];
					v.CopyTo(listeTable); 
					return listeTable;
				}
				catch(Exception e){
                    throw e;
				}
				finally{
					con.Close();
				}
			}
			public Maladie[] find_Maladie(String condition,String table){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Maladie[] med = find_Maladie(condition,con,table);
				return med;
			}
			public Maladie[] find_Maladie(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Maladie[] med = find_Maladie(condition,con,"Maladie");
				return med;
			}
		}
	}