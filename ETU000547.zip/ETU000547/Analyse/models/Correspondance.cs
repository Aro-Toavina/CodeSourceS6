using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace table{
	class Correspondance{
		private String id;
		private String critere;
		private String elementAnalyse;
		private double min;
		private double max;
        private int type;
        private int ageMin;
        private int ageMax;
        private int sexe;
        public Correspondance() { }
		public Correspondance(String id,String critere,String elementAnalyse,double min,double max,int type, int ageMin, int ageMax, int sexe)
        {
			this.set_id(id);
			this.set_critere(critere);
			this.set_elementAnalyse(elementAnalyse);
			this.set_min(min);
			this.set_max(max);
            this.set_type(type);
            this.set_ageMin(ageMin);
            this.set_ageMax(ageMax);
            this.set_sexe(sexe);
        }
		public Correspondance(String id,String critere,String elementAnalyse,String min,String max,String type, String ageMin, String ageMax, String sexe)
        {
			this.set_id(id);
			this.set_critere(critere);
			this.set_elementAnalyse(elementAnalyse);
			this.set_min(min);
			this.set_max(max);
            this.set_type(type);
            this.set_ageMin(ageMin);
            this.set_ageMax(ageMax);
            this.set_sexe(sexe);
        } 
		public void set_id(String id){
			this.id=id;
		} 
		public void set_critere(String critere){
			this.critere=critere;
		} 
		public void set_elementAnalyse(String elementAnalyse){
			this.elementAnalyse=elementAnalyse;
		} 
		public void set_min(double min){
			if(min>=0){
 				this.min=min;
			}
			else{
				throw new Exception("min invalide : negatif ou nul ");
			}
		} 
		public void set_min(String min){
			this.set_min(double.Parse(min));
		} 
		public void set_max(double max){
			if(max>=0){
 				this.max=max;
			}
			else{
				throw new Exception("max invalide : negatif ou nul ");
			}
		} 
        public void set_type(int type)
        {
            this.type = type;
        }
        public void set_type(String type)
        {
            set_type(int.Parse(type));
        }
		public void set_max(String max){
			this.set_max(double.Parse(max));
		}
        public void set_ageMin(int ageMin)
        {
            this.ageMin = ageMin;
        }
        public void set_ageMax(int ageMax)
        {
            this.ageMax = ageMax;
        }
        public void set_sexe(int sexe)
        {
            this.sexe = sexe;
        }
        public void set_ageMin(string ageMin)
        {
            this.set_ageMin(int.Parse(ageMin));
        }
        public void set_ageMax(string ageMax)
        {
            this.set_ageMax(int.Parse(ageMax));
        }
        public void set_sexe(string sexe)
        {
            this.set_sexe(int.Parse(sexe));
        }
        public String get_id(){
			 return this.id;
		} 
		public String get_critere(){
			 return this.critere;
		} 
		public String get_elementAnalyse(){
			 return this.elementAnalyse;
		} 
		public double get_min(){
			 return this.min;
		} 
		public double get_max(){
			 return this.max;
		} 
        public int get_type()
        {
            return this.type;
        }
        public int get_ageMin()
        {
            return this.ageMin;
        }
        public int get_ageMax()
        {
            return this.ageMax;
        }
        public int get_sexe()
        {
            return this.sexe;
        }
        override
        public string ToString()
        {
            return this.get_id() +" "+ this.get_critere() + " " + this.get_elementAnalyse() + " " + this.get_min() + " " + this.get_max();
        }
	}
}