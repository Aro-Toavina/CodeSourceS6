using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using table;
using System.Data.SqlClient;
using Connexion;
using System.Windows.Forms;
 namespace dao{
	class CorrespondanceDAO{
			public void updateCorrespondance(String modif, String condition, SqlConnection con){
				try{
					String query = "update Correspondance set "+modif+" where "+condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void update_Correspondance(String modif, String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				updateCorrespondance(modif, condition, con);
				return;
			}
			public void delete_Correspondance(SqlConnection con, String condition){
				try{
					String query = "delete from Correspondance where " + condition; 
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void delete_Correspondance(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				delete_Correspondance(con, condition);
				return;
			}
			public void insert_Correspondance(Correspondance med, SqlConnection con){
				try{
					String query = "DECLARE @value_Correspondance VARCHAR(10);EXECUTE dbo.GetSequenceCorrespondance @value_Correspondance OUTPUT;insert into Correspondance values (@value_Correspondance,'"+med.get_critere()+"','"+med.get_elementAnalyse()+"','"+med.get_min()+"','"+med.get_max()+ "','" + med.get_type() + "','" + med.get_ageMin() + "','" + med.get_ageMax() + "','" + med.get_sexe() + "')";
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void insert_Correspondance(Correspondance n){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				insert_Correspondance(n,con);
				return;
			}
			public Correspondance[] find_Correspondance(String condition, SqlConnection con, String table){
				try{
					String query = "Select * from " + table + " " + condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					List<Correspondance> v = new List<Correspondance>();
                    SqlDataReader reader = st.ExecuteReader();
                    while (reader.Read()){
						Correspondance med = new Correspondance();
						med.set_id(reader.GetValue(0).ToString());
						med.set_critere(reader.GetValue(1).ToString());
						med.set_elementAnalyse(reader.GetValue(2).ToString());
						med.set_min(reader.GetValue(3).ToString());
						med.set_max(reader.GetValue(4).ToString());
                        med.set_type(reader.GetValue(5).ToString());
                        med.set_ageMin(reader.GetValue(6).ToString());
                        med.set_ageMax(reader.GetValue(7).ToString());
                        med.set_sexe(reader.GetValue(8).ToString());
                        v.Add(med);
					}
					Correspondance[] listeTable = new Correspondance [v.Count];
					v.CopyTo(listeTable); 
					return listeTable;
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
                    throw e;
				}
				finally{
					con.Close();
				}
			}
			public Correspondance[] find_Correspondance(String condition,String table){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Correspondance[] med = find_Correspondance(condition,con,table);
				return med;
			}
			public Correspondance[] find_Correspondance(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Correspondance[] med = find_Correspondance(condition,con,"Correspondance");
				return med;
			}
		}
	}