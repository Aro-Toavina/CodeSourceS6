using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace table{
	class Maladie{
		private String id;
		private String nom;

        public Maladie() { }

        public Maladie(String id,String nom){
			this.set_id(id);
			this.set_nom(nom);
		}
		
		public void set_id(String id){
			this.id=id;
		} 
		public void set_nom(String nom){
			this.nom=nom;
		} 
		public String get_id(){
			 return this.id;
		} 
		public String get_nom(){
			 return this.nom;
		} 
	}
}