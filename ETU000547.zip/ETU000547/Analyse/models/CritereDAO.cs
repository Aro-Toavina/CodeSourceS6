using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using table;
using System.Data.SqlClient;
using Connexion;
using System.Windows.Forms;
 namespace dao{
	class CritereDAO{
			public void update_Critere(String modif, String condition, SqlConnection con){
				try{
					String query = "update Critere set "+modif+" where "+condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void update_Critere(String modif, String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				update_Critere(modif, condition, con);
				return;
			}
			public void delete_Critere(SqlConnection con, String condition){
				try{
					String query = "delete from Critere where " + condition; 
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void delete_Critere(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				delete_Critere(con, condition);
				return;
			}
			public void insert_Critere(Critere med, SqlConnection con){
				try{
					String query = "DECLARE @value_Critere VARCHAR(10);EXECUTE dbo.GetSequenceCritere @value_Critere OUTPUT;insert into Critere values (@value_Critere,'"+med.get_maladie()+ "')";
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					int result = st.ExecuteNonQuery();
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
					MessageBox.Show(e.Message);
				}
				finally{
					con.Close();
				}
			}
			public void insert_Critere(Critere n){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				insert_Critere(n,con);
				return;
			}
			public Critere[] find_Critere(String condition, SqlConnection con, String table){
				try{
					String query = "Select * from " + table + " " + condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					List<Critere> v = new List<Critere>();
                    SqlDataReader reader = st.ExecuteReader();
                    while (reader.Read()){
						Critere med = new Critere();
						med.set_id(reader.GetValue(0).ToString());
						med.set_maladie(reader.GetValue(1).ToString());
                        v.Add(med);
					}
					Critere[] listeTable = new Critere [v.Count];
					v.CopyTo(listeTable); 
					return listeTable;
				}
				catch(Exception e){
                    throw e;
				}
				finally{
					con.Close();
				}
			}
			public Critere[] find_Critere(String condition,String table){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Critere[] med = find_Critere(condition,con,table);
				return med;
			}
			public Critere[] find_Critere(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				Critere[] med = find_Critere(condition,con,"Critere");
				return med;
			}
		}
	}