using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace table{
	class CorrespondanceMaladie : Correspondance{
        private string maladie;
        public CorrespondanceMaladie() { }
		public CorrespondanceMaladie(String id,String critere,String elementAnalyse,double min,double max,int type,string maladie){
			base.set_id(id);
			base.set_critere(critere);
			base.set_elementAnalyse(elementAnalyse);
			base.set_min(min);
			base.set_max(max);
            base.set_type(type);
            this.set_maladie(maladie);
		}
		public CorrespondanceMaladie(String id,String critere,String elementAnalyse,String min,String max,int type,string maladie){
			base.set_id(id);
			base.set_critere(critere);
			base.set_elementAnalyse(elementAnalyse);
			base.set_min(min);
			base.set_max(max);
            base.set_type(type);
            this.set_maladie(maladie);
        } 
        public void set_maladie(string maladie)
        {
            this.maladie = maladie;
        }
        public string get_maladie()
        {
            return this.maladie;
        }
        override
        public string ToString()
        {
            return this.get_id() +" "+ this.get_critere() + " " + this.get_elementAnalyse() + " " + this.get_min() + " " + this.get_max();
        }
	}
}