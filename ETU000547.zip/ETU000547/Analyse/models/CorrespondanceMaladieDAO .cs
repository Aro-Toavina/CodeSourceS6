using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using table;
using System.Data.SqlClient;
using Connexion;
using System.Windows.Forms;
 namespace dao{
	class CorrespondanceMaladieDAO{
			public CorrespondanceMaladie[] find_CorrespondanceMaladie(String condition, SqlConnection con, String table){
				try{
					String query = "Select * from " + table + " " + condition;
					SqlCommand st = new SqlCommand(query, con);
					Console.WriteLine(query);
					List<CorrespondanceMaladie> v = new List<CorrespondanceMaladie>();
                    SqlDataReader reader = st.ExecuteReader();
                    while (reader.Read()){
                        CorrespondanceMaladie med = new CorrespondanceMaladie();
                        med.set_id(reader.GetValue(0).ToString());
                        med.set_critere(reader.GetValue(1).ToString());
                        med.set_elementAnalyse(reader.GetValue(2).ToString());
                        med.set_min(reader.GetValue(3).ToString());
                        med.set_max(reader.GetValue(4).ToString());
                        med.set_type(reader.GetValue(5).ToString());
                        med.set_ageMin(reader.GetValue(6).ToString());
                        med.set_ageMax(reader.GetValue(7).ToString());
                        med.set_sexe(reader.GetValue(8).ToString());
                        med.set_maladie(reader.GetValue(9).ToString());
                        v.Add(med);
					}
					CorrespondanceMaladie[] listeTable = new CorrespondanceMaladie [v.Count];
					v.CopyTo(listeTable); 
					return listeTable;
				}
				catch(Exception e){
					Console.WriteLine(e.ToString());
                    throw e;
				}
				finally{
					con.Close();
				}
			}
			public CorrespondanceMaladie[] find_CorrespondanceMaladie(String condition,String table){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				CorrespondanceMaladie[] med = find_CorrespondanceMaladie(condition,con,table);
				return med;
			}
			public CorrespondanceMaladie[] find_CorrespondanceMaladie(String condition){
				Connection db = new Connection();
				SqlConnection con = db.getConnexion("sa", "root", "Analyse");
				CorrespondanceMaladie[] med = find_CorrespondanceMaladie(condition,con,"CorrespondanceMaladie");
				return med;
			}
		}
	}